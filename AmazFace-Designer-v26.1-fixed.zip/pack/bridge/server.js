'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const {spawn, execFileSync} = require('child_process');

const PORT = 17865;
let child = null;
let state = {running:false, log:'', startedAt:null, projectDir:null};

function cors(res){
  res.setHeader('Access-Control-Allow-Origin','*');
  res.setHeader('Access-Control-Allow-Methods','GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers','Content-Type,X-Project-Name');
}
function json(res, code, obj){ cors(res); res.writeHead(code, {'Content-Type':'application/json; charset=utf-8'}); res.end(JSON.stringify(obj)); }
function addLog(s){ state.log += String(s); if(state.log.length>50000) state.log=state.log.slice(-50000); }
function findZeus(){
  try {
    const out = execFileSync('cmd.exe',['/d','/c','where zeus'],{encoding:'utf8',windowsHide:true}).trim();
    const hit = out.split(/\r?\n/).map(s=>s.trim()).find(Boolean);
    return hit || null;
  } catch { return null; }
}
function kill(){
  if(!child) return;
  try { spawn('taskkill',['/pid',String(child.pid),'/t','/f'],{windowsHide:true}); } catch(e) {}
  child=null; state.running=false;
}
function runPreview(dir){
  kill();
  const zeus = findZeus();
  if (!zeus) throw new Error('Команда zeus не найдена в PATH. Проверьте установку Zeus CLI.');
  state={running:true,log:'',startedAt:new Date().toISOString(),projectDir:dir};
  addLog(`$ \"${zeus}\" preview\n$ cwd: ${dir}\n\n`);
  // IMPORTANT: invoke the exact .cmd/.bat path returned by `where zeus`.
  // This also works when zeus is installed through a custom wrapper (for example zeus-wrap).
  const command = `\"${zeus.replace(/\"/g,'\\\"')}\" preview`;
  child=spawn('cmd.exe',['/d','/s','/c',command],{cwd:dir,windowsHide:false,stdio:['pipe','pipe','pipe']});
  child.stdout.on('data',d=>{
    const chunk=d.toString();
    addLog(chunk);
    if(/Which device would you like to preview\?/i.test(chunk)){
      try { child.stdin.write('Amazfit Balance 2\n'); } catch(e) {}
    }
  });
  child.stderr.on('data',d=>addLog(d.toString()));
  child.on('error',e=>{addLog(`\n[process error] ${e.message}\n`); state.running=false; child=null;});
  child.on('exit',(code,signal)=>{addLog(`\n[zeus exited] code=${code} signal=${signal||''}\n`); state.running=false; child=null;});
}
function body(req){return new Promise((resolve,reject)=>{const a=[];req.on('data',c=>a.push(c));req.on('end',()=>resolve(Buffer.concat(a)));req.on('error',reject);});}
async function preview(req,res){
  const zip=await body(req); if(!zip.length) return json(res,400,{error:'Пустой ZIP'});
  const root=path.join(os.tmpdir(),'AmazFace-ZeusBridge'); fs.mkdirSync(root,{recursive:true});
  const id=Date.now()+'-'+crypto.randomBytes(4).toString('hex');
  const dir=path.join(root,id); const zipPath=path.join(root,id+'.zip'); fs.mkdirSync(dir,{recursive:true}); fs.writeFileSync(zipPath,zip);
  try {
    execFileSync('powershell.exe',['-NoProfile','-ExecutionPolicy','Bypass','-Command',`Expand-Archive -LiteralPath '${zipPath.replace(/'/g,"''")}' -DestinationPath '${dir.replace(/'/g,"''")}' -Force`],{stdio:'pipe'});
  } catch(e) { return json(res,500,{error:'Не удалось распаковать проект: '+(e.stderr?.toString()||e.message)}); }
  try { runPreview(dir); } catch(e) { return json(res,500,{error:e.message}); }
  json(res,200,{ok:true,message:'Проект распакован. Запускаю Zeus Preview.',projectDir:dir,zeus:findZeus()});
}
const server=http.createServer(async(req,res)=>{
  cors(res); if(req.method==='OPTIONS'){res.writeHead(204);return res.end();}
  try {
    if(req.method==='GET'&&req.url==='/health') { const zeus=findZeus(); return json(res,200,{ok:true,zeus:zeus||'',running:state.running}); }
    if(req.method==='GET'&&req.url==='/status') return json(res,200,state);
    if(req.method==='POST'&&req.url==='/preview') return preview(req,res);
    if(req.method==='POST'&&req.url==='/stop'){kill(); return json(res,200,{ok:true});}
    json(res,404,{error:'Not found'});
  } catch(e){ json(res,500,{error:e.message}); }
});
server.listen(PORT,'127.0.0.1',()=>console.log(`AmazFace Zeus Bridge listening on http://127.0.0.1:${PORT}`));
