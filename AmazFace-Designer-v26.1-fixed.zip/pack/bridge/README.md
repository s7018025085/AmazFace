# AmazFace — Zeus Bridge

Редактор остаётся полностью в браузере. Bridge — локальный Windows Node.js сервер, который принимает ZIP проекта от браузера и запускает `zeus preview`.

## Запуск

1. Нужен Node.js.
2. В этой папке запустите `start-zeus-bridge.bat`.
3. Откройте `index.html`.
4. Нажмите `▶ Zeus Preview` → `▶ Собрать и запустить`.

Bridge слушает только `127.0.0.1:17865`.

### Важно для zeus-wrap

Bridge сначала выполняет `where zeus` и получает реальный путь, например:

`C:\Users\F117\bin\zeus-wrap\zeus.cmd`

После этого он запускает **именно этот файл**, а не абстрактную команду `zeus`. Это нужно для пользовательских wrapper-установок Zeus.

Окно Designer получает stdout/stderr процесса и показывает их в консоли Zeus Preview.
