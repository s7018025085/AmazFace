@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js не найден в PATH.
  echo Установите Node.js или запустите bridge из вашей среды Node.
  pause
  exit /b 1
)
echo Starting AmazFace Zeus Bridge on http://127.0.0.1:17865
node server.js
pause
