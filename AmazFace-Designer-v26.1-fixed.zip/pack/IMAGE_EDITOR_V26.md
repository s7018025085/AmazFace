# Image/Arrow Editor update

Добавлено:
- Редактор ресурсов: обрезка, перемещение, масштабирование колесом, поворот.
- Удаление однотонного фона: белый фон или связная область от краёв, настраиваемый допуск.
- Эффекты ресурсов: яркость, контраст, насыщенность, размытие, прозрачность, свечение, тень.
- Быстрое вырезание элемента из набора: во вкладке «Обрезка» можно мышью выделить прямоугольник и создать отдельный PNG.
- Кнопка `↗` в ресурсах для режима «Вырезать стрелку из набора».
- Кнопка редактирования ресурса рядом с полем изображения в Inspector.
- Редактор фона получил прямое перетаскивание изображения мышью и масштабирование колесом.
- В редакторе фона явно показана круглая область кадрирования 480×480; за кругом пиксели не попадают в итоговый PNG.

Все операции выполняются в браузере, результат сохраняется как новый PNG-ресурс и не уничтожает исходный.


## V26.1 — critical runtime fixes
- Removed an orphaned gradient-binding block that executed outside `Inspector` and caused `Cannot read properties of undefined (reading 'querySelectorAll')`.
- Removed a stale `.asset-open-tool` click binding from `AssetManager`; the element is not present in the generated toolbar and caused `Cannot set properties of null (setting 'onclick')`.
- The image editor remains loaded as a normal classic script and does not require an iframe.
