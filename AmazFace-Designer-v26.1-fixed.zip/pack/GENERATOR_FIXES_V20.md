# AmazFace Designer v20 — generator stability fixes

## Fixed

### 1. Weather icons are built-in resources
`weather_icon` uses a logical weather condition id such as `snowstorm`, not a user asset id. The exporter already generates the 29 PNG files under `assets/<target>/weather/`. The preflight validator no longer reports `MISSING_IMAGE` for these built-in weather ids.

### 2. Normal/AOD lexical isolation
Normal and AOD are generated independently and merged into one `WatchFace.build()`. Each scene is now wrapped in its own lexical block. Names such as `h`, `v`, `MS`, `now`, and `txt` may therefore safely repeat between scenes and cannot cause `Identifier ... has already been declared`.

### 3. Scope-aware diagnostics
The duplicate-declaration checker now understands lexical scopes. It only reports a duplicate when the same variable is declared more than once in the SAME scope. It no longer flags valid locals inside separate functions, try/catch blocks, or Normal/AOD blocks.

### 4. Export is blocked on generator errors
The Designer no longer offers “export anyway” when the generated `watchface/index.js` contains a critical error. Full ZIP and Direct ZIP generation stop before producing an invalid package.

### 5. Existing runtime checks retained
The preflight still checks syntax, widget references, AOD/Normal show levels, resources, fonts, background resources, app target/API, and other project invariants.
