# Background Circle Fix v21

- Background editor now treats the watch face as a 480×480 circle (center 240,240, radius 240).
- The source image and every baked effect are rendered inside one circular clip path.
- Edge fade, vignette, glass, volume, glow, grain and reflection can no longer paint the square corners.
- The exported processed PNG keeps transparent corners outside the circular dial.
- No change to the watchface generator/export validation logic.
