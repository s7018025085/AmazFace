// Side panel resizers: drag the separators between left/center/right panels.
// Widths are persisted in localStorage and restored on the next launch.
(function () {
  const body = document.querySelector('.app-body');
  if (!body) return;

  const KEY_LEFT = 'amazface.panel.leftWidth';
  const KEY_RIGHT = 'amazface.panel.rightWidth';
  const MIN_LEFT = 190, MAX_LEFT = 520;
  const MIN_RIGHT = 220, MAX_RIGHT = 520;
  const SPLITTER = 8;
  const DEFAULT_LEFT = 260, DEFAULT_RIGHT = 300;

  function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }
  function read(key, fallback) {
    const n = Number(localStorage.getItem(key));
    return Number.isFinite(n) ? n : fallback;
  }

  let leftWidth = clamp(read(KEY_LEFT, DEFAULT_LEFT), MIN_LEFT, MAX_LEFT);
  let rightWidth = clamp(read(KEY_RIGHT, DEFAULT_RIGHT), MIN_RIGHT, MAX_RIGHT);

  body.style.setProperty('--left-panel-width', leftWidth + 'px');
  body.style.setProperty('--right-panel-width', rightWidth + 'px');

  const leftSplitter = document.createElement('div');
  const rightSplitter = document.createElement('div');
  leftSplitter.className = 'panel-splitter panel-splitter-left';
  rightSplitter.className = 'panel-splitter panel-splitter-right';
  leftSplitter.setAttribute('role', 'separator');
  rightSplitter.setAttribute('role', 'separator');
  leftSplitter.setAttribute('aria-label', 'Изменить ширину левой панели');
  rightSplitter.setAttribute('aria-label', 'Изменить ширину правой панели');
  leftSplitter.tabIndex = 0;
  rightSplitter.tabIndex = 0;

  const center = body.querySelector('.center-panel');
  const right = body.querySelector('.right-panel');
  if (!center || !right) return;
  body.insertBefore(leftSplitter, center);
  body.insertBefore(rightSplitter, right);

  function setLeft(px, save = true) {
    leftWidth = clamp(Math.round(px), MIN_LEFT, MAX_LEFT);
    body.style.setProperty('--left-panel-width', leftWidth + 'px');
    if (save) localStorage.setItem(KEY_LEFT, String(leftWidth));
  }
  function setRight(px, save = true) {
    rightWidth = clamp(Math.round(px), MIN_RIGHT, MAX_RIGHT);
    body.style.setProperty('--right-panel-width', rightWidth + 'px');
    if (save) localStorage.setItem(KEY_RIGHT, String(rightWidth));
  }

  function drag(splitter, side, startX) {
    const startLeft = leftWidth;
    const startRight = rightWidth;
    document.body.classList.add('panel-resizing');
    splitter.classList.add('active');

    const move = (e) => {
      if (side === 'left') setLeft(startLeft + (e.clientX - startX), false);
      else setRight(startRight - (e.clientX - startX), false);
    };
    const stop = () => {
      document.body.classList.remove('panel-resizing');
      splitter.classList.remove('active');
      localStorage.setItem(side === 'left' ? KEY_LEFT : KEY_RIGHT, String(side === 'left' ? leftWidth : rightWidth));
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', stop);
      window.removeEventListener('pointercancel', stop);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', stop, { once: true });
    window.addEventListener('pointercancel', stop, { once: true });
  }

  leftSplitter.addEventListener('pointerdown', (e) => {
    if (e.button !== 0) return;
    e.preventDefault();
    leftSplitter.setPointerCapture?.(e.pointerId);
    drag(leftSplitter, 'left', e.clientX);
  });
  rightSplitter.addEventListener('pointerdown', (e) => {
    if (e.button !== 0) return;
    e.preventDefault();
    rightSplitter.setPointerCapture?.(e.pointerId);
    drag(rightSplitter, 'right', e.clientX);
  });

  // Double click restores the default width — convenient if a panel was made too wide.
  leftSplitter.addEventListener('dblclick', () => setLeft(DEFAULT_LEFT));
  rightSplitter.addEventListener('dblclick', () => setRight(DEFAULT_RIGHT));

  function keyboard(splitter, side, e) {
    const step = e.shiftKey ? 25 : 10;
    if (e.key === 'ArrowLeft') {
      e.preventDefault(); side === 'left' ? setLeft(leftWidth - step) : setRight(rightWidth + step);
    } else if (e.key === 'ArrowRight') {
      e.preventDefault(); side === 'left' ? setLeft(leftWidth + step) : setRight(rightWidth - step);
    } else if (e.key === 'Home') {
      e.preventDefault(); side === 'left' ? setLeft(MIN_LEFT) : setRight(MIN_RIGHT);
    } else if (e.key === 'End') {
      e.preventDefault(); side === 'left' ? setLeft(MAX_LEFT) : setRight(MAX_RIGHT);
    }
  }
  leftSplitter.addEventListener('keydown', e => keyboard(leftSplitter, 'left', e));
  rightSplitter.addEventListener('keydown', e => keyboard(rightSplitter, 'right', e));
})();
