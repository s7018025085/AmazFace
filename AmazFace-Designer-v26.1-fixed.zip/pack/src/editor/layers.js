// src/editor/layers.js
class LayersPanel {
  constructor(root, store) {
    this.root = root;
    this.store = store;
  }

  render() {
    const comps = [...this.store.state.components].reverse();
    const bg = this.store.state.background || {};
    const rows = [];
    rows.push(`
      <div class="layer-row layer-background ${this.store.selection.has('__background__') ? 'active' : ''}" data-id="__background__">
        <span class="layer-drag">▰</span><span class="layer-name">🎨 Фон</span><span class="layer-id">BACKGROUND</span>
        <button class="layer-btn" data-act="visible" title="Показать/скрыть фон">${Number(bg.alpha ?? 100) > 0 ? '👁' : '🚫'}</button>
        <button class="layer-btn" data-act="lock" title="Фон всегда закреплён">🔒</button>
      </div>`);
    for (const c of comps) {
      const active = this.store.selection.has(c.id);
      rows.push(`
        <div class="layer-row layer-component ${active ? 'active' : ''}" data-id="${c.id}">
          <span class="layer-drag">☰</span><span class="layer-name">${c.name}</span><span class="layer-id">${c.id}</span>
          <button class="layer-btn" data-act="visible" title="Показать/скрыть">${c.visible === false ? '🚫' : '👁'}</button>
          <button class="layer-btn" data-act="lock" title="Заблокировать">${c.locked ? '🔒' : '🔓'}</button>
          <button class="layer-btn" data-act="dup" title="Дублировать">⎘</button>
          <button class="layer-btn" data-act="del" title="Удалить">🗑</button>
        </div>`);
      for (const z of (c.tapZones || [])) {
        const zid = `tapzone:${c.id}:${z.id}`;
        rows.push(`
          <div class="layer-row layer-child layer-tap-zone ${this.store.selection.has(zid) ? 'active' : ''}" data-id="${zid}" data-parent-id="${c.id}" data-zone-id="${z.id}">
            <span class="layer-drag">↳</span><span class="layer-name">🎯 ${z.name || z.id}</span><span class="layer-id">TAP</span>
            <button class="layer-btn" data-act="visible" title="Показать/скрыть">${z.visible === false ? '🚫' : '👁'}</button>
            <button class="layer-btn" data-act="lock" title="Заблокировать">${z.locked ? '🔒' : '🔓'}</button>
            <button class="layer-btn" data-act="del" title="Удалить">🗑</button>
          </div>`);
      }
    }
    this.root.innerHTML = rows.join('');

    this.root.querySelectorAll('.layer-row').forEach((row) => {
      const id = row.dataset.id;
      row.addEventListener('click', (e) => {
        if (e.target.closest('.layer-btn')) return;
        if (e.shiftKey) {
          const sel = new Set(this.store.selection);
          sel.has(id) ? sel.delete(id) : sel.add(id);
          this.store.setSelection([...sel]);
        } else this.store.setSelection([id]);
      });

      if (id === '__background__') {
        row.querySelector('[data-act="visible"]').onclick = () => {
          const current = Number(this.store.state.background?.alpha ?? 100);
          this.store.state.background.alpha = current > 0 ? 0 : 100;
          this.store.commit();
        };
        row.querySelector('[data-act="lock"]').onclick = (e) => e.stopPropagation();
        return;
      }

      if (row.classList.contains('layer-tap-zone')) {
        const parentId = row.dataset.parentId, zoneId = row.dataset.zoneId;
        row.querySelector('[data-act="visible"]').onclick = () => {
          const s = this.store.getTapZoneSelection(id);
          if (s) this.store.updateTapZone(parentId, zoneId, { visible: s.zone.visible === false });
        };
        row.querySelector('[data-act="lock"]').onclick = () => {
          const s = this.store.getTapZoneSelection(id);
          if (s) this.store.updateTapZone(parentId, zoneId, { locked: !s.zone.locked });
        };
        row.querySelector('[data-act="del"]').onclick = () => this.store.removeTapZone(parentId, zoneId);
        return;
      }

      row.querySelector('[data-act="visible"]').onclick = () => {
        const c = this.store.state.components.find((x) => x.id === id);
        if (c) this.store.updateComponent(id, { visible: c.visible === false });
      };
      row.querySelector('[data-act="lock"]').onclick = () => {
        const c = this.store.state.components.find((x) => x.id === id);
        if (c) this.store.updateComponent(id, { locked: !c.locked });
      };
      row.querySelector('[data-act="dup"]').onclick = () => this.store.duplicateComponents([id]);
      row.querySelector('[data-act="del"]').onclick = () => confirmRemoveComponents(this.store, [id]);
    });

    // Reordering applies only to real components; child tap zones are always
    // rendered under their parent and cannot escape that hierarchy.
    let draggedId = null;
    this.root.querySelectorAll('.layer-component').forEach((row) => {
      row.draggable = true;
      row.addEventListener('dragstart', () => { draggedId = row.dataset.id; });
      row.addEventListener('dragover', (e) => e.preventDefault());
      row.addEventListener('drop', (e) => {
        e.preventDefault();
        const targetId = row.dataset.id;
        if (!draggedId || draggedId === targetId) return;
        const arr = this.store.state.components;
        const from = arr.findIndex((c) => c.id === draggedId);
        const to = arr.findIndex((c) => c.id === targetId);
        if (from < 0 || to < 0) return;
        const [item] = arr.splice(from, 1);
        arr.splice(to, 0, item);
        this.store.commit();
      });
    });
  }
}
