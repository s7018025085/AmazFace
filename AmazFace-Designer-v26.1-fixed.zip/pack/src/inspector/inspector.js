// src/inspector/inspector.js

class Inspector {
  constructor(root, store) {
    this.root = root;
    this.store = store;
    // true, пока изменение прилетело из поля ввода самого Inspector:
    // в этот момент перерисовывать панель нельзя — innerHTML пересоздаёт
    // <input>, и фокус слетает после каждой введённой цифры.
    this._selfEdit = false;
  }

  // Запоминает, какое поле было в фокусе и где стоял курсор, чтобы вернуть
  // их после перерисовки (перерисовка приходит, например, по Enter).
  _captureFocus() {
    const el = document.activeElement;
    if (!el || !this.root.contains(el)) return null;
    const sel = el.dataset && (el.dataset.prop ? `[data-prop="${el.dataset.prop}"]` : el.dataset.field ? `[data-field="${el.dataset.field}"]` : null);
    if (!sel) return null;
    const desc = { sel };
    // selectionStart у input[type=number] в Chrome бросает исключение —
    // сохраняем каретку только для текстовых полей.
    if (el.type === 'text') { desc.start = el.selectionStart; desc.end = el.selectionEnd; }
    return desc;
  }

  _restoreFocus(desc) {
    if (!desc) return;
    const el = this.root.querySelector(desc.sel);
    if (!el || typeof el.focus !== 'function') return;
    el.focus();
    if (desc.start != null && typeof el.setSelectionRange === 'function') {
      try { el.setSelectionRange(desc.start, desc.end); } catch (e) { /* не текстовое поле */ }
    }
  }

  render() {
    if (this._selfEdit) return;
    const focusDesc = this._captureFocus();
    const result = this._render();
    this._restoreFocus(focusDesc);
    // В панели появились новые элементы с data-tip — их нужно привязать
    // к менеджеру подсказок заново (см. src/ui/tooltips.js).
    if (window.tooltipManager) window.tooltipManager.refresh();
    return result;
  }

  _render() {
    const sel = [...this.store.selection];
    if (sel.length === 0) { this.root.innerHTML = `<div class="empty-hint">Выберите компонент, чтобы изменить его свойства.</div>`; return; }
    if (sel.length > 1) { this._renderMulti(sel); return; }

    // Background is a first-class layer, but remains stored in the scene
    // background object so old projects and exports stay compatible.
    if (sel[0] === '__background__') {
      this._renderBackground();
      return;
    }

    const zoneSel = this.store.getTapZoneSelection(sel[0]);
    if (zoneSel) {
      this._renderTapZone(zoneSel.parent, zoneSel.zone);
      return;
    }
    const comp = this.store.state.components.find((c) => c.id === sel[0]);
    if (!comp) { this.root.innerHTML = ''; return; }
    const def = REGISTRY[comp.defId];
    const compat = isApiCompatible(def.apiLevel, this.store.state.apiLevel);

    const rows = [];
    rows.push(`
      <div class="insp-header">
        <input class="insp-name" value="${this._esc(comp.name)}" data-field="name" data-tip="Имя компонента в панели слоёв и в комментарии сгенерированного кода. На сам циферблат не выводится." />
        <div class="insp-id">${comp.id} · ${def.widgetId}</div>
        <div class="api-badge ${compat ? 'ok' : 'bad'}">API ${def.apiLevel}${def.apiLevel.includes('+') ? '' : '+'} ${compat ? '✓' : '⚠ несовместимо с API проекта ' + this.store.state.apiLevel}</div>
        ${def.confidence === 'unverified' ? '<div class="api-badge warn">⚠ Непроверенный набор свойств — сверьтесь с docs.zepp.com перед публикацией</div>' : ''}
      </div>
    `);

    rows.push(`<div class="insp-section-title">Позиция и размер</div>`);
    rows.push(`<div class="insp-grid">`);
    for (const key of ['x', 'y', 'w', 'h']) {
      const isCircle = def.widgetId === 'CIRCLE' || def.widgetId === 'STROKE_CIRCLE';
      if (isCircle) continue;
      rows.push(this._numberField(key, key.toUpperCase(), comp[key]));
    }
    rows.push(`</div>`);
    if (this.store.state.mode === 'aod') {
      rows.push(`<div class="insp-section-title">Трансформация AOD</div>`);
      rows.push(`<div class="insp-grid">`);
      rows.push(this._numberField('rotation', 'ПОВОРОТ °', Number(comp.props.rotation || 0)));
      rows.push(this._numberField('scale', 'МАСШТАБ', Number(comp.props.scale || 1)));
      rows.push(`</div>`);
    }

    const zones = Array.isArray(comp.tapZones) ? comp.tapZones : [];
    rows.push(`<div class="insp-section-title">Тап-зоны <button class="insp-inline-btn" data-act="add-tap-zone">＋ Добавить</button></div>`);
    if (!zones.length) {
      rows.push(`<div class="empty-hint insp-empty-small">Нет дочерних тап-зон. Добавьте зону — она будет отдельным слоем и не изменит сам компонент.</div>`);
    } else {
      rows.push(`<div class="tap-zone-list">${zones.map(z => `
        <button type="button" class="tap-zone-list-item" data-zone-id="${this._escAttr(z.id)}">
          <span>🎯 ${this._esc(z.name || z.id)}</span><small>${Math.round(z.x)}, ${Math.round(z.y)} · ${Math.round(z.w)}×${Math.round(z.h)}</small>
        </button>`).join('')}</div>`);
    }

    const groups = {};
    for (const p of def.properties) {
      if (['x', 'y', 'w', 'h'].includes(p.key)) continue;
      if (String(p.key).startsWith('tap_')) continue; // tap actions live on child zones
      const groupName = this._groupFor(p.key);
      groups[groupName] = groups[groupName] || [];
      groups[groupName].push(p);
    }


    // Универсальный TEXT с выбором источника данных (data_source): добавляем
    // в группу "Источник данных" поля, специфичные для текущего выбранного
    // источника (DATA_SOURCES[val].fields) — они не входят в def.properties,
    // потому что зависят от значения, выбранного пользователем "на лету".
    let dsNote = null;
    if (def.dataSourceSelectable) {
      const dsVal = comp.props.data_source || 'NONE';
      const dsDef = DATA_SOURCES[dsVal];
      if (dsDef && dsDef.fields && dsDef.fields.length) {
        const groupName = this._groupFor('data_source');
        groups[groupName] = groups[groupName] || [];
        groups[groupName].push(...dsDef.fields);
      }
      if (dsDef && dsVal !== 'NONE') {
        dsNote = (dsDef.confidence === 'unverified' ? '⚠ ' : '') +
          (dsDef.note || '') +
          ' Значение поля «Текст» при этом игнорируется — оно подставляется автоматически из источника данных.';
      }
    }

    for (const [groupName, props] of Object.entries(groups)) {
      rows.push(`<div class="insp-section-title">${groupName}</div>`);
      rows.push(`<div class="insp-grid">`);
      for (const p of props) rows.push(this._fieldFor(comp, p));
      rows.push(`</div>`);
    }
    if (dsNote) rows.push(`<div class="insp-note">${dsNote}</div>`);

    rows.push(`<div class="insp-section-title">Поведение</div>`);
    rows.push(`<div class="insp-grid">`);
    rows.push(`
      <label class="field checkbox" data-tip="Снятая галочка прячет компонент и в редакторе, и при экспорте: он не попадёт в сгенерированный index.js.">
        <input type="checkbox" data-field="visible" ${comp.visible !== false ? 'checked' : ''}>
        Видимый
      </label>
      <label class="field checkbox" data-tip="Заблокированный компонент нельзя двигать и растягивать мышью на холсте — удобно, чтобы не сдвинуть готовый фон или стрелки. Свойства при этом редактируются как обычно.">
        <input type="checkbox" data-field="locked" ${comp.locked ? 'checked' : ''}>
        Заблокирован
      </label>
    `);
    if (def.dataBindable) {
      rows.push(`<div class="field"><label>Источник данных</label><input type="text" value="${def.dataSource}" disabled></div>`);
    } else if (def.dataSourceSelectable) {
      const eff = getEffectiveDataSource(comp, def);
      rows.push(`<div class="field"><label>Эффективный источник данных</label><input type="text" value="${eff || 'нет (статический текст)'}" disabled></div>`);
    }
    rows.push(`</div>`);

    if (def.id === 'time_pointer_second' && (comp.props.motion || 'TICK') === 'SMOOTH') {
      rows.push(`<div class="insp-note">⚠ Плавный ход: штатный TIME_POINTER двигает секундную стрелку скачками,
        поэтому при экспорте она будет создана отдельным виджетом IMG и повёрнута вручную из таймера
        '@zos/timer' (${Number(comp.props.smooth_fps ?? 20)} к/с). Свойство поворота IMG не подтверждено цитатой из
        docs.zepp.com — проверьте результат в симуляторе. Учтите также расход батареи: чем выше частота кадров,
        тем дороже анимация; в AOD-режиме плавный ход обычно недоступен.</div>`);
    }
    if (def.note) rows.push(`<div class="insp-note">${def.note}</div>`);

    this.root.innerHTML = rows.join('');
    const addZone = this.root.querySelector('[data-act="add-tap-zone"]');
    if (addZone) addZone.onclick = () => this.store.addTapZone(comp.id);
    this.root.querySelectorAll('[data-zone-id]').forEach(el => {
      el.onclick = () => this.store.setSelection([`tapzone:${comp.id}:${el.dataset.zoneId}`]);
    });
    this._bind(comp, def);
  }

  _renderTapZone(parent, zone) {
    const p = zone.props || {};
    this.root.innerHTML = `
      <div class="insp-header">
        <input class="insp-name" value="${this._esc(zone.name || zone.id)}" data-field="zone-name">
        <div class="insp-id">🎯 ${this._esc(zone.id)} · дочка ${this._esc(parent.name)}</div>
      </div>
      <div class="insp-section-title">Позиция и размер относительно родителя</div>
      <div class="insp-grid">
        ${this._numberField('zx', 'X', zone.x)}
        ${this._numberField('zy', 'Y', zone.y)}
        ${this._numberField('zw', 'ШИРИНА', zone.w)}
        ${this._numberField('zh', 'ВЫСОТА', zone.h)}
      </div>
      <div class="insp-section-title">Действие по тапу</div>
      <div class="insp-grid">
        <div class="field wide"><label>ДЕЙСТВИЕ</label><select data-zone-prop="tap_action">
          <option value="NONE" ${p.tap_action === 'NONE' ? 'selected' : ''}>Ничего</option>
          <option value="METRIC" ${p.tap_action === 'METRIC' ? 'selected' : ''}>Системный экран</option>
          <option value="APP" ${p.tap_action === 'APP' ? 'selected' : ''}>Другое приложение</option>
        </select></div>
        ${p.tap_action === 'METRIC' ? `<div class="field wide"><label>ЭКРАН</label><select data-zone-prop="tap_metric">${['STATUS','HR','SPORT','WEATHER','SPORT_HISTORY','PAI','SLEEP','SPO2','CALENDAR','MEASUREMENT','READINESS'].map(v => `<option value="${v}" ${p.tap_metric === v ? 'selected' : ''}>${v}</option>`).join('')}</select></div>` : ''}
        ${p.tap_action === 'APP' ? `
          <div class="field"><label>APP ID</label><input type="number" data-zone-prop="tap_app_id" value="${Number(p.tap_app_id || 0)}"></div>
          <div class="field wide"><label>URL</label><input type="text" data-zone-prop="tap_app_url" value="${this._escAttr(p.tap_app_url || 'pages/index')}"></div>
        ` : ''}
      </div>
      <div class="insp-section-title">Поведение</div>
      <div class="insp-grid">
        <label class="field checkbox"><input type="checkbox" data-zone-visible ${zone.visible !== false ? 'checked' : ''}> Видимая в редакторе</label>
        <label class="field checkbox"><input type="checkbox" data-zone-locked ${zone.locked ? 'checked' : ''}> Заблокирована</label>
      </div>
      <div class="insp-actions"><button class="btn-danger" data-act="delete-tap-zone">Удалить тап-зону</button></div>
    `;
    this.root.querySelector('[data-field="zone-name"]').onchange = e =>
      this.store.updateTapZone(parent.id, zone.id, { name: e.target.value });
    this.root.querySelectorAll('[data-zone-prop]').forEach(el => el.onchange = () => {
      let value = el.value;
      if (el.type === 'number') value = Number(value) || 0;
      this.store.updateTapZone(parent.id, zone.id, { props: { [el.dataset.zoneProp]: value } });
    });
    [['zx','x'],['zy','y'],['zw','w'],['zh','h']].forEach(([field,key]) => {
      const el = this.root.querySelector(`[data-prop="${field}"]`);
      if (el) el.onchange = () => this.store.updateTapZone(parent.id, zone.id, { [key]: Math.max(key === 'w' || key === 'h' ? 4 : -99999, Number(el.value) || 0) });
    });
    const vis = this.root.querySelector('[data-zone-visible]');
    const lock = this.root.querySelector('[data-zone-locked]');
    vis.onchange = () => this.store.updateTapZone(parent.id, zone.id, { visible: vis.checked });
    lock.onchange = () => this.store.updateTapZone(parent.id, zone.id, { locked: lock.checked });
    this.root.querySelector('[data-act="delete-tap-zone"]').onclick = () => this.store.removeTapZone(parent.id, zone.id);
  }

  _renderBackground() {
    const bg = this.store.state.background || { color: '#000000', imageAssetId: null, alpha: 100 };
    const assets = this.store.state.assets || [];
    const aod = this.store.state.mode === 'aod';
    this.root.innerHTML = `
      <div class="insp-header">
        <div class="insp-name-static">🎨 Фон</div>
        <div class="insp-id">Слой фона · ${aod ? 'AOD' : 'Normal'}</div>
      </div>
      <div class="insp-section-title">Внешний вид</div>
      <div class="insp-grid">
        <div class="field"><label>Цвет</label><input type="color" data-bg="color" value="${this._escAttr(bg.color || '#000000')}"></div>
        <div class="field"><label>Прозрачность</label><input type="number" data-bg="alpha" min="0" max="100" value="${Number(bg.alpha ?? 100)}"></div>
        <div class="field wide"><label>Изображение</label>
          <select data-bg="imageAssetId">
            <option value="">— нет (только цвет) —</option>
            ${assets.map((a) => `<option value="${this._escAttr(a.id)}" ${bg.imageAssetId === a.id ? 'selected' : ''}>${this._esc(a.name)}</option>`).join('')}
          </select>
        </div>
        <div class="field wide bg-editor-actions">
          <button type="button" class="btn-primary" data-bg-edit="new">🖼 Выбрать и обработать фон</button>
          ${bg.imageAssetId ? '<button type="button" data-bg-edit="current">✎ Редактировать текущий</button>' : ''}
        </div>
      </div>
      <div class="insp-note">Фон можно выбрать, обрезать под круглый циферблат, увеличить/сдвинуть, повернуть, настроить яркость/контраст и автоматически получить PNG 480×480. Прозрачность изображения PNG сохраняется.</div>
    `;
    const apply = (key, value) => {
      this.store.state.background = Object.assign({ color: '#000000', imageAssetId: null, alpha: 100 }, this.store.state.background || {}, { [key]: value });
      if (aod && key === 'color') {
        const settings = this.store.getAodSettings();
        settings.background = value;
      }
      this.store.commit();
    };
    this.root.querySelectorAll('[data-bg]').forEach((el) => {
      const key = el.dataset.bg;
      const read = () => key === 'alpha' ? Number(el.value) : el.value;
      el.addEventListener('change', () => apply(key, read()));
      if (el.type === 'number') el.addEventListener('input', () => {
        this._selfEdit = true;
        try {
          this.store.state.background = Object.assign({}, this.store.state.background || {}, { [key]: read() });
          if (aod && key === 'alpha') { /* live editor only */ }
          this.store._emit();
        } finally { this._selfEdit = false; }
      });
    });
    this.root.querySelector('[data-bg-edit="new"]')?.addEventListener('click', () => this._pickBackgroundFile());
    this.root.querySelector('[data-bg-edit="current"]')?.addEventListener('click', () => {
      const id = this.store.state.background?.imageAssetId;
      const a = (this.store.state.assets || []).find(x => x.id === id);
      if (a) this._openBackgroundEditor(a);
    });
  }

  _pickBackgroundFile() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/png,image/jpeg,image/webp';
    input.onchange = () => {
      const file = input.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        const img = new Image();
        img.onload = () => this._openBackgroundEditor({ name: file.name.replace(/\\.(png|jpe?g|webp)$/i, ''), dataUrl: reader.result, width: img.width, height: img.height, format: 'PNG', size: file.size });
        img.src = reader.result;
      };
      reader.readAsDataURL(file);
    };
    input.click();
  }

  _openBackgroundEditor(asset) {
    const modal = document.createElement('div');
    modal.className = 'bg-editor-modal';
    modal.innerHTML = `
      <div class="bg-editor-dialog">
        <div class="bg-editor-head"><b>Предварительная обработка фонового изображения</b><button type="button" data-bg-close>✕</button></div>
        <div class="bg-editor-body">
          <div class="bg-editor-preview"><canvas width="480" height="480"></canvas><div class="bg-editor-drag-hint">Перетаскивайте фон мышью · колесо — масштаб</div></div>
          <div class="bg-editor-controls">
            <label>Масштаб <input type="range" data-k="zoom" min="100" max="300" value="100"><output data-o="zoom">100%</output></label>
            <label>Сдвиг X <input type="range" data-k="x" min="-240" max="240" value="0"><output data-o="x">0</output></label>
            <label>Сдвиг Y <input type="range" data-k="y" min="-240" max="240" value="0"><output data-o="y">0</output></label>
            <label>Поворот <input type="range" data-k="rot" min="-180" max="180" value="0"><output data-o="rot">0°</output></label>
            <label>Яркость <input type="range" data-k="brightness" min="50" max="150" value="100"><output data-o="brightness">100%</output></label>
            <label>Контраст <input type="range" data-k="contrast" min="50" max="150" value="100"><output data-o="contrast">100%</output></label>
            <label>Прозрачность <input type="range" data-k="alpha" min="0" max="100" value="100"><output data-o="alpha">100%</output></label>
            <div class="bg-editor-effects-title">Обрезка</div><div class="bg-editor-note">Круг 480×480 уже является областью кадрирования: всё за кругом не попадёт в PNG. Потяните картинку мышью для точного позиционирования.</div><div class="bg-editor-effects-title">Эффекты фона</div>
            <label>Затухание краёв <input type="range" data-k="edgeFade" min="0" max="100" value="0"><output data-o="edgeFade">0%</output></label>
            <label>Виньетка <input type="range" data-k="vignette" min="0" max="100" value="0"><output data-o="vignette">0%</output></label>
            <label>Стекло <input type="range" data-k="glass" min="0" max="100" value="0"><output data-o="glass">0%</output></label>
            <label>Объём <input type="range" data-k="volume" min="0" max="100" value="0"><output data-o="volume">0%</output></label>
            <label>Свечение <input type="range" data-k="glow" min="0" max="100" value="0"><output data-o="glow">0%</output></label>
            <label>Зерно <input type="range" data-k="grain" min="0" max="100" value="0"><output data-o="grain">0%</output></label>
            <label>Отражение <input type="range" data-k="reflection" min="0" max="100" value="0"><output data-o="reflection">0%</output></label>
            <div class="bg-editor-effect-actions"><button type="button" data-bg-reset-effects>↺ Сбросить эффекты</button></div>
            <div class="bg-editor-note">Область циферблата: <b>круг 480×480</b>. Все эффекты применяются только внутри круга, без квадратных углов. Выход: <b>PNG 480×480</b>; эффекты запекаются непосредственно в PNG.</div>
            <div class="bg-editor-buttons"><button type="button" data-bg-cancel>Отмена</button><button type="button" class="btn-primary" data-bg-apply>Применить фон</button></div>
          </div>
        </div>
      </div>`;
    document.body.appendChild(modal);
    const canvas = modal.querySelector('canvas'), ctx = canvas.getContext('2d');
    const img = new Image(); img.src = asset.dataUrl;
    const state = {zoom:100,x:0,y:0,rot:0,brightness:100,contrast:100,alpha:100,edgeFade:0,vignette:0,glass:0,volume:0,glow:0,grain:0,reflection:0};
    const draw = () => {
      ctx.clearRect(0,0,480,480);

      // ВАЖНО: фон циферблата — это КРУГ, а не квадрат 480×480.
      // Весь рендер (исходник + все эффекты) ограничиваем круглой областью.
      // Благодаря этому виньетка, стекло, объём, свечение, зерно, отражение
      // и затухание краёв никогда не рисуются в квадратных углах.
      const cx=240, cy=240, dialR=240;
      ctx.save();
      ctx.beginPath();
      ctx.arc(cx, cy, dialR, 0, Math.PI * 2);
      ctx.clip();

      ctx.save();
      ctx.translate(240 + state.x, 240 + state.y);
      ctx.rotate(state.rot*Math.PI/180);
      const base = Math.max(480/img.width, 480/img.height) * state.zoom/100;
      const w = img.width*base, h = img.height*base;
      ctx.filter = `brightness(${state.brightness}%) contrast(${state.contrast}%)`;
      ctx.globalAlpha = state.alpha/100;
      ctx.drawImage(img,-w/2,-h/2,w,h);
      ctx.restore();

      // Эффекты запекаются в результирующий PNG. Они не требуют поддержки
      // фильтров на часах и поэтому одинаково работают в Preview и на устройстве.
      // Все они уже находятся внутри круглого clip-path выше.
      if (state.glow > 0) {
        const g=ctx.createRadialGradient(cx,cy,40,cx,cy,300);
        const a=(state.glow/100)*0.34;
        g.addColorStop(0,`rgba(255,255,255,${a})`); g.addColorStop(.45,`rgba(180,210,255,${a*.35})`); g.addColorStop(1,'rgba(0,0,0,0)');
        ctx.fillStyle=g; ctx.fillRect(0,0,480,480);
      }
      if (state.glass > 0) {
        const a=state.glass/100;
        const g=ctx.createLinearGradient(70,20,420,460);
        g.addColorStop(0,`rgba(255,255,255,${0.34*a})`); g.addColorStop(.22,`rgba(255,255,255,${0.08*a})`); g.addColorStop(.48,'rgba(255,255,255,0)'); g.addColorStop(.7,`rgba(100,180,255,${0.05*a})`); g.addColorStop(1,`rgba(255,255,255,${0.12*a})`);
        ctx.fillStyle=g; ctx.fillRect(0,0,480,480);
        ctx.save(); ctx.globalAlpha=0.10*a; ctx.filter=`blur(${1+4*a}px)`; ctx.strokeStyle='#fff'; ctx.lineWidth=10+18*a; ctx.beginPath(); ctx.arc(240,240,210,Math.PI*1.05,Math.PI*1.65); ctx.stroke(); ctx.restore();
      }
      if (state.volume > 0) {
        const a=state.volume/100;
        ctx.save();
        ctx.globalCompositeOperation='multiply';
        let g=ctx.createRadialGradient(240,240,150,240,240,340);
        g.addColorStop(0,'rgba(0,0,0,0)'); g.addColorStop(.72,`rgba(0,0,0,${0.10*a})`); g.addColorStop(1,`rgba(0,0,0,${0.62*a})`);
        ctx.fillStyle=g; ctx.fillRect(0,0,480,480);
        ctx.globalCompositeOperation='screen';
        g=ctx.createLinearGradient(80,70,400,390); g.addColorStop(0,`rgba(255,255,255,${0.16*a})`); g.addColorStop(.35,'rgba(255,255,255,0)'); g.addColorStop(1,`rgba(0,0,0,${0.08*a})`);
        ctx.fillStyle=g; ctx.fillRect(0,0,480,480); ctx.restore();
      }
      if (state.vignette > 0 || state.edgeFade > 0) {
        const a=state.vignette/100;
        const fade=state.edgeFade/100;
        const g=ctx.createRadialGradient(cx,cy,Math.max(80,220-130*a),cx,cy,dialR);
        if (fade>0) { g.addColorStop(0,'rgba(0,0,0,0)'); g.addColorStop(Math.max(.05,1-fade*.72),'rgba(0,0,0,0)'); g.addColorStop(1,'rgba(0,0,0,1)'); }
        else { g.addColorStop(0,'rgba(0,0,0,0)'); g.addColorStop(.65,'rgba(0,0,0,0)'); g.addColorStop(1,`rgba(0,0,0,${.88*a})`); }
        if (fade>0) {
          // Для затухания краёв нужен альфа-маскирование, поэтому применяем
          // compositing через временный canvas, не затемняя содержимое.
          const mask=document.createElement('canvas'); mask.width=mask.height=480; const mx=mask.getContext('2d');
          const mg=mx.createRadialGradient(cx,cy,Math.max(40,180+120*(1-fade)),cx,cy,dialR);
          mg.addColorStop(0,'rgba(255,255,255,1)'); mg.addColorStop(Math.max(.45,1-fade*.35),'rgba(255,255,255,1)'); mg.addColorStop(1,'rgba(255,255,255,0)');
          mx.fillStyle=mg; mx.fillRect(0,0,480,480);
          ctx.save(); ctx.globalCompositeOperation='destination-in'; ctx.drawImage(mask,0,0); ctx.restore();
        }
        if (a>0) { ctx.fillStyle=g; ctx.fillRect(0,0,480,480); }
      }
      if (state.reflection > 0) {
        const a=state.reflection/100; ctx.save(); ctx.globalAlpha=.28*a; ctx.globalCompositeOperation='screen'; ctx.translate(240,240); ctx.rotate(-0.55); ctx.scale(1,0.34); const rg=ctx.createRadialGradient(0,-90,20,0,-90,230); rg.addColorStop(0,'rgba(255,255,255,.85)'); rg.addColorStop(1,'rgba(255,255,255,0)'); ctx.fillStyle=rg; ctx.beginPath(); ctx.arc(0,-90,230,0,Math.PI*2); ctx.fill(); ctx.restore();
      }
      if (state.grain > 0) {
        const n=Math.round(9000*state.grain/100); ctx.save(); ctx.globalAlpha=.10*(state.grain/100); ctx.fillStyle='#fff'; for(let i=0;i<n;i++){const x=Math.random()*480,y=Math.random()*480,s=Math.random()<.7?1:2;ctx.fillRect(x,y,s,s);} ctx.restore();
      }
      // Пунктирной окружности здесь больше нет: это была только техническая
      // рамка редактора и она ошибочно выглядела как часть циферблата.
      ctx.restore();
    };
    let dragBg = false, dragStart = null;
    canvas.style.cursor = 'grab';
    canvas.addEventListener('mousedown', (e) => {
      dragBg = true; dragStart = { x: e.clientX, y: e.clientY, sx: state.x, sy: state.y };
      canvas.style.cursor = 'grabbing'; e.preventDefault();
    });
    window.addEventListener('mousemove', (e) => {
      if (!dragBg) return;
      state.x = Math.max(-240, Math.min(240, dragStart.sx + (e.clientX - dragStart.x)));
      state.y = Math.max(-240, Math.min(240, dragStart.sy + (e.clientY - dragStart.y)));
      for (const k of ['x','y']) { const el=modal.querySelector(`[data-k="${k}"]`); if(el) el.value=state[k]; const o=modal.querySelector(`[data-o="${k}"]`); if(o)o.textContent=state[k]+' px'; }
      draw();
    });
    window.addEventListener('mouseup', () => { dragBg=false; canvas.style.cursor='grab'; });
    canvas.addEventListener('wheel', (e) => {
      e.preventDefault(); state.zoom=Math.max(100,Math.min(300,state.zoom+(e.deltaY<0?5:-5)));
      const z=modal.querySelector('[data-k="zoom"]'); if(z) z.value=state.zoom; const o=modal.querySelector('[data-o="zoom"]'); if(o)o.textContent=state.zoom+'%'; draw();
    }, {passive:false});
    img.onload = draw;
    modal.querySelectorAll('[data-k]').forEach(el => el.addEventListener('input', () => {
      state[el.dataset.k]=Number(el.value);
      const o=modal.querySelector(`[data-o="${el.dataset.k}"]`);
      if(o) {
        const k=el.dataset.k;
        o.textContent = k==='rot' ? `${el.value}°` : `${el.value}${k==='x'||k==='y'?' px':'%'}`;
      }
      draw();
    }));
    modal.querySelector('[data-bg-reset-effects]').onclick=()=>{
      for (const k of ['edgeFade','vignette','glass','volume','glow','grain','reflection']) { state[k]=0; const el=modal.querySelector(`[data-k="${k}"]`); if(el) el.value='0'; const o=modal.querySelector(`[data-o="${k}"]`); if(o)o.textContent='0%'; }
      draw();
    };
    const close=()=>modal.remove();
    modal.querySelector('[data-bg-close]').onclick=close;
    modal.querySelector('[data-bg-cancel]').onclick=close;
    modal.querySelector('[data-bg-apply]').onclick=()=>{
      canvas.toBlob(blob=>{
        const r=new FileReader();
        r.onload=()=>{
          const out={id:makeAssetId(),name:`${asset.name || 'background'}-480`,dataUrl:r.result,width:480,height:480,format:'PNG',size:blob.size};
          this.store.addAsset(out);
          this.store.state.background=Object.assign({color:'#000000',imageAssetId:null,alpha:100},this.store.state.background||{},{imageAssetId:out.id,alpha:100});
          this.store.commit(); close();
        };
        r.readAsDataURL(blob);
      },'image/png');
    };
  }

  _renderMulti(ids) {
    this.root.innerHTML = `
      <div class="insp-header"><div class="insp-id">${ids.length} компонентов выбрано</div></div>
      <div class="insp-section-title">Выравнивание</div>
      <div class="align-row">
        <button data-align="left">⯇ Слева</button>
        <button data-align="center-h">По центру X</button>
        <button data-align="right">Справа ⯈</button>
      </div>
      <div class="align-row">
        <button data-align="top">⯅ Сверху</button>
        <button data-align="center-v">По центру Y</button>
        <button data-align="bottom">Снизу ⯆</button>
      </div>
      <div class="insp-section-title">Распределение</div>
      <div class="align-row">
        <button data-align="dist-h">По горизонтали</button>
        <button data-align="dist-v">По вертикали</button>
      </div>
      <div class="insp-section-title">Слой</div>
      <div class="align-row">
        <button data-layer="top">На передний план</button>
        <button data-layer="bottom">На задний план</button>
      </div>
    `;
    this.root.querySelectorAll('[data-align]').forEach((btn) => {
      btn.onclick = () => this._align(ids, btn.dataset.align);
    });
    this.root.querySelectorAll('[data-layer]').forEach((btn) => {
      btn.onclick = () => { for (const id of ids) this.store.moveLayer(id, btn.dataset.layer); };
    });
  }

  _align(ids, mode) {
    const comps = ids.map((id) => this.store.state.components.find((c) => c.id === id)).filter(Boolean);
    if (!comps.length) return;
    if (mode === 'left') { const v = Math.min(...comps.map((c) => c.x)); comps.forEach((c) => c.x = v); }
    if (mode === 'right') { const v = Math.max(...comps.map((c) => c.x + c.w)); comps.forEach((c) => c.x = v - c.w); }
    if (mode === 'top') { const v = Math.min(...comps.map((c) => c.y)); comps.forEach((c) => c.y = v); }
    if (mode === 'bottom') { const v = Math.max(...comps.map((c) => c.y + c.h)); comps.forEach((c) => c.y = v - c.h); }
    if (mode === 'center-h') { const cx = this.store.state.device.w / 2; comps.forEach((c) => c.x = cx - c.w / 2); }
    if (mode === 'center-v') { const cy = this.store.state.device.h / 2; comps.forEach((c) => c.y = cy - c.h / 2); }
    if (mode === 'dist-h' && comps.length > 2) {
      comps.sort((a, b) => a.x - b.x);
      const first = comps[0], last = comps[comps.length - 1];
      const span = (last.x) - (first.x);
      const step = span / (comps.length - 1);
      comps.forEach((c, i) => { if (i > 0 && i < comps.length - 1) c.x = first.x + step * i; });
    }
    if (mode === 'dist-v' && comps.length > 2) {
      comps.sort((a, b) => a.y - b.y);
      const first = comps[0], last = comps[comps.length - 1];
      const span = (last.y) - (first.y);
      const step = span / (comps.length - 1);
      comps.forEach((c, i) => { if (i > 0 && i < comps.length - 1) c.y = first.y + step * i; });
    }
    this.store.commit();
  }

  _groupFor(key) {
    if (key.startsWith('tap_')) return 'Открытие по тапу';
    if (key === 'data_source' || /^(time_|ampm_|date_|weekday_|battery_|step_|heart_|calorie_|distance_|weather_|hour_|minute_|second_|day_|month_|year_)/.test(key)) return 'Источник данных';
    if (['color', 'text_size', 'align_h', 'align_v', 'text_style', 'font'].includes(key)) return 'Типографика';
    if (['text', 'format', 'prefix', 'suffix', 'unit'].includes(key)) return 'Содержимое';
    if (['src'].includes(key)) return 'Изображение';
    if (['center_x', 'center_y', 'radius', 'start_angle', 'end_angle', 'line_width'].includes(key)) return 'Форма';
    if (['alpha'].includes(key)) return 'Внешний вид';
    if (key.startsWith('pos_') || key.startsWith('center')) return 'Точка опоры';
    if (key === 'path' || key === 'cover_path') return 'Изображение стрелки';
    if (['motion', 'smooth_fps', 'smooth_step_deg'].includes(key)) return 'Ход стрелки';
    return 'Свойства';
  }

  _numberField(key, label, value) {
    const tip = hintForProperty({ key });
    return `<div class="field"${tip ? ` data-tip="${this._escAttr(tip)}"` : ''}><label>${label}</label><input type="number" data-field="${key}" value="${Math.round(value)}"></div>`;
  }

  _fieldFor(comp, p) {
    const val = comp.props[p.key];
    // Подсказка к свойству (см. PROPERTY_HINTS в registry.js). Вешаем её на
    // контейнер поля, чтобы всплывала и при наведении на подпись, и при
    // переходе в поле с клавиатуры.
    const tip = hintForProperty(p);
    const T = tip ? ` data-tip="${this._escAttr(tip)}"` : '';
    switch (p.kind) {
      case 'number':
        return `<div class="field"${T}><label>${p.label}${p.confidence === 'unverified' ? ' ⚠' : ''}</label><input type="number" data-prop="${p.key}" value="${val ?? p.default ?? 0}" ${p.min !== undefined ? `min="${p.min}"` : ''} ${p.max !== undefined ? `max="${p.max}"` : ''}></div>`;
      case 'color':
        if (p.key === 'color' && (comp.defId === 'fill_rect' || comp.defId === 'circle')) {
          const g = comp.props.gradient || {};
          return `<div class="field"${T}><label>${p.label}</label><input type="color" data-prop="${p.key}" value="${val || p.default || '#ffffff'}"></div>
            <div class="field checkbox"><input type="checkbox" data-gradient-enable ${g.enabled ? 'checked' : ''}> Градиент</div>
            <div class="field"><label>Цвет 2</label><input type="color" data-gradient-to value="${g.to || '#000000'}"></div>
            <div class="field"><label>Тип</label><select data-gradient-type><option value="linear" ${g.type !== 'radial' ? 'selected':''}>Линейный</option><option value="radial" ${g.type === 'radial' ? 'selected':''}>Радиальный</option></select></div>`;
        }
        return `<div class="field"${T}><label>${p.label}</label><input type="color" data-prop="${p.key}" value="${val || p.default || '#ffffff'}"></div>`;
      case 'text':
        return `<div class="field wide"${T}><label>${p.label}</label><input type="text" data-prop="${p.key}" value="${this._esc(val ?? p.default ?? '')}"></div>`;
      case 'select': {
        // options: массив строк ИЛИ массив { value, label } — второй вариант
        // нужен, когда машинное значение (TICK/SMOOTH) не годится как подпись.
        const opts = p.options.map((o) => (typeof o === 'object' ? o : { value: o, label: o }));
        const cur = val ?? p.default;
        const wide = opts.some((o) => String(o.label).length > 18) ? ' wide' : '';
        return `<div class="field${wide}"${T}><label>${p.label}${p.confidence === 'unverified' ? ' ⚠' : ''}</label><select data-prop="${p.key}">${opts.map((o) => `<option value="${o.value}" ${cur === o.value ? 'selected' : ''}>${this._esc(o.label)}</option>`).join('')}</select></div>`;
      }
      case 'checkbox': {
        const checked = val !== undefined ? !!val : !!p.default;
        return `<label class="field checkbox"${T}><input type="checkbox" data-prop="${p.key}" ${checked ? 'checked' : ''}> ${p.label}${p.confidence === 'unverified' ? ' ⚠' : ''}</label>`;
      }
      case 'font':
        return this._fontField(comp, p, val, T);
      case 'asset':
        return this._assetField(p, val, T);
      case 'weathericon': {
        const curIcon = normalizeWeatherIconId(val) || p.default;
        return `<div class="field wide"${T}><label>${p.label} (34 состояния — см. подсказку)</label><div class="icon-picker" data-prop="${p.key}">${WEATHER_ICON_SET.map((w) => `<button type="button" class="icon-opt ${curIcon === w.id ? 'active' : ''}" data-icon="${w.id}" title="${this._escAttr(w.label)}">${w.glyph} ${this._esc(w.label)}</button>`).join('')}</div></div>`;
      }
      default:
        return '';
    }
  }

  _fontField(comp, p, val, tipAttr = '') {
    const fonts = this.store.state.fonts || [];
    const options = fonts.map((f) => `<option value="${this._escAttr(f.id)}" ${val === f.id ? 'selected' : ''}>${this._esc(f.name)}</option>`).join('');
    return `<div class="field wide font-field"${tipAttr}>
      <label>${p.label}</label>
      <select data-prop="${p.key}">
        <option value="" ${!val ? 'selected' : ''}>Системный шрифт</option>
        ${options}
      </select>
      <label class="btn-file font-upload">＋ Добавить файл шрифта
        <input type="file" accept=".ttf,.otf,.woff,.woff2,font/ttf,font/otf,font/woff,font/woff2" hidden data-font-upload>
      </label>
    </div>`;
  }

  _assetField(p, val, tipAttr = '') {
    const assets = this.store.state.assets;
    return `<div class="field wide asset-prop-field"${tipAttr}><label>${p.label}</label>
      <div class="asset-prop-row"><select data-prop="${p.key}">
        <option value="">— нет —</option>
        ${assets.map((a) => `<option value="${a.id}" ${val === a.id ? 'selected' : ''}>${this._esc(a.name)}</option>`).join('')}
      </select><button type="button" data-edit-asset="${this._escAttr(val || '')}" title="Обрезать / удалить фон / эффекты">✎</button></div>
    </div>`;
  }

  _bind(comp, def) {
    this.root.querySelectorAll('[data-field]').forEach((el) => {
      const field = el.dataset.field;
      const readValue = () => (el.type === 'number' ? Number(el.value) : el.type === 'checkbox' ? el.checked : el.value);
      el.addEventListener('change', () => {
        if (this.store.state.mode === 'aod' && (field === 'rotation' || field === 'scale')) this.store.updateComponentProp(comp.id, field, readValue());
        else this.store.updateComponent(comp.id, { [field]: readValue() });
      });
      if (el.type === 'number' || el.type === 'text') {
        el.addEventListener('input', () => {
          this._selfEdit = true;
          try {
            if (this.store.state.mode === 'aod' && (field === 'rotation' || field === 'scale')) this.store.updateComponentProp(comp.id, field, readValue(), { silent: true });
            else this.store.updateComponent(comp.id, { [field]: readValue() }, { silent: true });
          }
          finally { this._selfEdit = false; }
        });
      }
    });
    this.root.querySelectorAll('[data-prop]').forEach((el) => {
      if (el.classList.contains('icon-picker')) return;
      const key = el.dataset.prop;
      const readValue = () => {
        if (el.type === 'checkbox') return el.checked;
        if (el.type === 'number') return Number(el.value);
        return el.value;
      };
      const commit = () => this.store.updateComponentProp(comp.id, key, readValue());
      el.addEventListener('change', commit);
      if (el.type === 'text' || el.type === 'number') el.addEventListener('input', () => {
        // Холст и слои обновляются вживую, а сам Inspector пропускает эту
        // перерисовку (_selfEdit), иначе поле теряет фокус на каждом символе.
        this._selfEdit = true;
        try { this.store.updateComponentProp(comp.id, key, readValue(), { silent: true }); }
        finally { this._selfEdit = false; }
      });
    });
    this.root.querySelectorAll('[data-edit-asset]').forEach((btn) => {
      btn.onclick = () => {
        const id = btn.dataset.editAsset;
        const a = this.store.state.assets.find(x => x.id === id);
        if (!a || typeof ImageAssetEditor === 'undefined') return;
        ImageAssetEditor.open(a, { title: 'Редактор ресурса', onApply: (out) => this.store.addAsset(out) });
      };
    });
    this.root.querySelectorAll('.icon-picker').forEach((wrap) => {
      const key = wrap.dataset.prop;
      wrap.querySelectorAll('.icon-opt').forEach((btn) => {
        btn.onclick = () => this.store.updateComponentProp(comp.id, key, btn.dataset.icon);
      });
    });
    this.root.querySelectorAll('[data-font-upload]').forEach((input) => {
      input.addEventListener('change', () => {
        const file = input.files && input.files[0];
        if (!file) return;
        const ext = (file.name.match(/\.[^.]+$/) || [''])[0].toLowerCase();
        if (!['.ttf','.otf','.woff','.woff2'].includes(ext)) {
          alert('Поддерживаются TTF, OTF, WOFF и WOFF2.');
          input.value = '';
          return;
        }
        const reader = new FileReader();
        reader.onload = async () => {
          const id = makeFontId();
          const family = `ProjectFont_${id.replace(/[^a-zA-Z0-9_]/g, '_')}`;
          const font = { id, name: file.name.replace(/\.[^.]+$/, ''), filename: file.name, ext, dataUrl: reader.result, size: file.size, cssFamily: family };
          this.store.addFont(font);
          if (typeof registerProjectFont === 'function') await registerProjectFont(font);
          this.store.updateComponentProp(comp.id, 'font', id);
        };
        reader.readAsDataURL(file);
      });
    });
  }

  _esc(s) { return String(s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;'); }

  // Для data-tip: подсказки содержат кавычки и угловые скобки (<= 20 px и т.п.).
  _escAttr(s) { return this._esc(s == null ? '' : s).replace(/\n/g, ' '); }
}
