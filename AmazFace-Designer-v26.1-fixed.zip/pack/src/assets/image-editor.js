// Reusable raster asset editor for backgrounds, hands and other image resources.
// Works entirely in-browser; all effects are baked into a PNG before the asset
// is added to the project.
class ImageAssetEditor {
  static open(asset, options = {}) {
    const opts = Object.assign({ mode: 'asset', title: 'Редактор изображения' }, options);
    const modal = document.createElement('div');
    modal.className = 'image-editor-modal';
    modal.innerHTML = `
      <div class="image-editor-dialog">
        <div class="image-editor-head">
          <div><b>${ImageAssetEditor.esc(opts.title)}</b><small>${ImageAssetEditor.esc(asset.name || '')}</small></div>
          <button type="button" data-ie-close>✕</button>
        </div>
        <div class="image-editor-body">
          <div class="image-editor-preview-wrap">
            <div class="image-editor-preview">
              <canvas data-ie-canvas></canvas>
              <div class="image-editor-hint">Перетаскивайте изображение мышью · Колесо — масштаб</div>
            </div>
          </div>
          <div class="image-editor-controls">
            <div class="ie-tabs">
              <button class="active" data-tab="crop">✂ Обрезка</button>
              <button data-tab="remove">🪄 Фон</button>
              <button data-tab="effects">✨ Эффекты</button>
            </div>
            <div class="ie-tab-panel active" data-panel="crop">
              <div class="ie-row"><button data-ie-action="fit">Вписать</button><button data-ie-action="center">Центр</button><button data-ie-action="reset">Сброс</button></div>
              <label>Масштаб <input type="range" data-k="zoom" min="25" max="500" value="100"><output data-o="zoom">100%</output></label>
              <label>Сдвиг X <input type="range" data-k="x" min="-500" max="500" value="0"><output data-o="x">0</output></label>
              <label>Сдвиг Y <input type="range" data-k="y" min="-500" max="500" value="0"><output data-o="y">0</output></label>
              <label>Поворот <input type="range" data-k="rot" min="-180" max="180" value="0"><output data-o="rot">0°</output></label>
              <div class="ie-section">Область результата</div>
              <div class="ie-grid4">
                <label>X <input type="number" data-crop="x" value="0"></label>
                <label>Y <input type="number" data-crop="y" value="0"></label>
                <label>Ш <input type="number" data-crop="w" value="0" min="1"></label>
                <label>В <input type="number" data-crop="h" value="0" min="1"></label>
              </div>
              <label class="ie-check"><input type="checkbox" data-crop-circle> Круглая обрезка</label>
              <div class="ie-note">Для стрелок: выставьте прямоугольник вокруг одной стрелки и нажмите «Создать PNG». Для фона можно включить круглую обрезку.</div>
            </div>
            <div class="ie-tab-panel" data-panel="remove">
              <div class="ie-row"><button data-ie-action="sample">🎯 Взять цвет фона</button><button data-ie-action="white">Удалить белый</button><button data-ie-action="edges">Удалить фон от краёв</button></div>
              <label>Цвет <input type="color" data-remove-color value="#ffffff"></label>
              <label>Допуск <input type="range" data-k="tolerance" min="0" max="120" value="35"><output data-o="tolerance">35</output></label>
              <label class="ie-check"><input type="checkbox" data-k="removeConnected" checked> Только связанный с краями фон</label>
              <div class="ie-note">«Удалить белый» подходит для наборов стрелок на белом фоне. «От краёв» удаляет связную область выбранного цвета, сохраняя сами стрелки.</div>
            </div>
            <div class="ie-tab-panel" data-panel="effects">
              <label>Яркость <input type="range" data-k="brightness" min="40" max="180" value="100"><output data-o="brightness">100%</output></label>
              <label>Контраст <input type="range" data-k="contrast" min="40" max="180" value="100"><output data-o="contrast">100%</output></label>
              <label>Насыщенность <input type="range" data-k="saturation" min="0" max="200" value="100"><output data-o="saturation">100%</output></label>
              <label>Размытие <input type="range" data-k="blur" min="0" max="12" value="0"><output data-o="blur">0 px</output></label>
              <div class="ie-section">Тень</div>
              <label>Непрозрачность <input type="range" data-k="shadowAlpha" min="0" max="100" value="0"><output data-o="shadowAlpha">0%</output></label>
              <label>Смещение X <input type="range" data-k="shadowX" min="-30" max="30" value="4"><output data-o="shadowX">4</output></label>
              <label>Смещение Y <input type="range" data-k="shadowY" min="-30" max="30" value="6"><output data-o="shadowY">6</output></label>
              <label>Размытие тени <input type="range" data-k="shadowBlur" min="0" max="30" value="8"><output data-o="shadowBlur">8</output></label>
              <label>Свечение <input type="range" data-k="glow" min="0" max="100" value="0"><output data-o="glow">0%</output></label>
              <label>Прозрачность <input type="range" data-k="alpha" min="0" max="100" value="100"><output data-o="alpha">100%</output></label>
            </div>
            <div class="ie-footer-note">Источник: ${asset.width || '?'}×${asset.height || '?'} px · PNG с прозрачностью сохраняется.</div>
            <div class="image-editor-buttons"><button type="button" data-ie-close>Отмена</button><button type="button" class="btn-primary" data-ie-apply>Создать PNG</button></div>
          </div>
        </div>
      </div>`;
    document.body.appendChild(modal);

    const canvas = modal.querySelector('[data-ie-canvas]');
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    const img = new Image();
    const crop = { x: 0, y: 0, w: asset.width || 480, h: asset.height || 480 };
    const state = {
      zoom: 100, x: 0, y: 0, rot: 0, tolerance: 35, removeConnected: true,
      brightness: 100, contrast: 100, saturation: 100, blur: 0, shadowAlpha: 0,
      shadowX: 4, shadowY: 6, shadowBlur: 8, glow: 0, alpha: 100,
      removeColor: '#ffffff', circle: false
    };
    const view = { w: 720, h: 620, base: 1, fitScale: 1 };
    canvas.width = view.w; canvas.height = view.h;

    const updateOutputs = () => modal.querySelectorAll('[data-k]').forEach(el => {
      const o = modal.querySelector(`[data-o="${el.dataset.k}"]`); if (!o) return;
      const k = el.dataset.k; const v = el.value;
      o.textContent = k === 'zoom' || ['brightness','contrast','saturation','shadowAlpha','glow','alpha'].includes(k) ? `${v}%` : k === 'blur' ? `${v} px` : v;
    });

    const fitScale = () => Math.min((view.w - 40) / img.width, (view.h - 40) / img.height);
    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = '#161a22'; ctx.fillRect(0, 0, canvas.width, canvas.height);
      const checker = 16;
      for (let y=0;y<view.h;y+=checker) for (let x=0;x<view.w;x+=checker) {
        ctx.fillStyle = ((x/checker + y/checker) % 2) ? '#1f2430' : '#171b23'; ctx.fillRect(x,y,checker,checker);
      }
      if (!img.complete || !img.naturalWidth) return;
      const base = state.zoom / 100;
      const scale = view.fitScale * base;
      const dw = img.width * scale, dh = img.height * scale;
      const cx = view.w/2 + state.x, cy = view.h/2 + state.y;
      ctx.save();
      ctx.translate(cx, cy); ctx.rotate(state.rot * Math.PI/180);
      ctx.filter = `brightness(${state.brightness}%) contrast(${state.contrast}%) saturate(${state.saturation}%) blur(${state.blur}px)`;
      ctx.globalAlpha = state.alpha/100;
      if (state.shadowAlpha > 0 || state.glow > 0) {
        ctx.save();
        ctx.filter = `blur(${state.shadowBlur}px)`;
        ctx.globalAlpha = state.shadowAlpha/100;
        ctx.fillStyle = '#000';
        ctx.shadowColor = `rgba(0,0,0,${state.shadowAlpha/100})`;
        ctx.shadowBlur = state.shadowBlur; ctx.shadowOffsetX = state.shadowX; ctx.shadowOffsetY = state.shadowY;
        ctx.drawImage(img, -dw/2, -dh/2, dw, dh);
        ctx.restore();
      }
      ctx.drawImage(img, -dw/2, -dh/2, dw, dh);
      if (state.glow > 0) {
        ctx.save(); ctx.globalAlpha = .18 * state.glow/100; ctx.filter = `blur(${3 + state.glow/8}px)`;
        ctx.drawImage(img, -dw/2, -dh/2, dw, dh); ctx.restore();
      }
      ctx.restore();
      // Crop guide in source coordinates, mapped into preview for easy extraction.
      const sx = view.w/2 - img.width*scale/2 + state.x;
      const sy = view.h/2 - img.height*scale/2 + state.y;
      const rx = sx + crop.x*scale, ry = sy + crop.y*scale, rw = crop.w*scale, rh = crop.h*scale;
      ctx.save(); ctx.setLineDash([8,6]); ctx.lineWidth=2; ctx.strokeStyle='#55aaff';
      ctx.strokeRect(rx,ry,rw,rh);
      if (state.circle) { ctx.beginPath(); ctx.arc(rx+rw/2,ry+rh/2,Math.min(rw,rh)/2,0,Math.PI*2); ctx.stroke(); }
      ctx.restore();
    };

    const syncCropInputs = () => modal.querySelectorAll('[data-crop]').forEach(el => { el.value = Math.round(crop[el.dataset.crop]); });
    const setCrop = (k,v) => { crop[k] = Math.max(0, Math.min(k==='x'?img.width: k==='y'?img.height: k==='w'?img.width-crop.x:img.height-crop.y, Number(v)||0)); if(k==='x') crop.w=Math.min(crop.w,img.width-crop.x); if(k==='y') crop.h=Math.min(crop.h,img.height-crop.y); syncCropInputs(); draw(); };

    let dragging = false, selectingCrop = false, ds = null, cropStart = null;
    const activeTab = () => modal.querySelector('.ie-tabs button.active')?.dataset.tab || 'crop';
    const previewToSource = (clientX, clientY) => {
      const r = canvas.getBoundingClientRect(); const px = (clientX-r.left) * (view.w/r.width); const py = (clientY-r.top) * (view.h/r.height);
      const scale = view.fitScale * (state.zoom/100);
      return { x: Math.max(0, Math.min(img.width, (px - (view.w/2 + state.x - img.width*scale/2))/scale)), y: Math.max(0, Math.min(img.height, (py - (view.h/2 + state.y - img.height*scale/2))/scale)) };
    };
    canvas.addEventListener('mousedown', e => {
      if (activeTab() === 'crop' && !e.altKey && e.button === 0) {
        selectingCrop = true; cropStart = previewToSource(e.clientX,e.clientY); crop.x=cropStart.x; crop.y=cropStart.y; crop.w=1; crop.h=1; syncCropInputs(); draw();
      } else {
        dragging = true; ds = {x:e.clientX,y:e.clientY, sx:state.x, sy:state.y};
      }
      e.preventDefault();
    });
    window.addEventListener('mousemove', e => {
      if (selectingCrop) { const p=previewToSource(e.clientX,e.clientY); crop.x=Math.min(cropStart.x,p.x); crop.y=Math.min(cropStart.y,p.y); crop.w=Math.abs(p.x-cropStart.x); crop.h=Math.abs(p.y-cropStart.y); syncCropInputs(); draw(); return; }
      if (!dragging) return; state.x = ds.sx + (e.clientX-ds.x); state.y = ds.sy + (e.clientY-ds.y); syncSliders(); draw();
    });
    window.addEventListener('mouseup', () => { selectingCrop=false; dragging=false; });
    canvas.addEventListener('wheel', e => { e.preventDefault(); state.zoom = Math.max(25, Math.min(500, state.zoom + (e.deltaY < 0 ? 5 : -5))); syncSliders(); draw(); }, {passive:false});

    const syncSliders = () => modal.querySelectorAll('[data-k]').forEach(el => { if (state[el.dataset.k] !== undefined) el.value = state[el.dataset.k]; });
    modal.querySelectorAll('[data-k]').forEach(el => el.addEventListener('input', () => { state[el.dataset.k] = el.type === 'checkbox' ? el.checked : Number(el.value); updateOutputs(); draw(); }));
    modal.querySelector('[data-crop-circle]').addEventListener('change', e => { state.circle=e.target.checked; draw(); });
    modal.querySelectorAll('[data-crop]').forEach(el => el.addEventListener('input', () => setCrop(el.dataset.crop, el.value)));
    modal.querySelector('[data-ie-action="fit"]').onclick = () => { state.zoom=100; state.x=0; state.y=0; syncSliders(); draw(); };
    modal.querySelector('[data-ie-action="center"]').onclick = () => { state.x=0; state.y=0; syncSliders(); draw(); };
    modal.querySelector('[data-ie-action="reset"]').onclick = () => { Object.assign(state,{zoom:100,x:0,y:0,rot:0,brightness:100,contrast:100,saturation:100,blur:0,shadowAlpha:0,shadowX:4,shadowY:6,shadowBlur:8,glow:0,alpha:100}); crop.x=0; crop.y=0; crop.w=img.width; crop.h=img.height; syncSliders(); syncCropInputs(); updateOutputs(); draw(); };
    modal.querySelector('[data-ie-action="sample"]').onclick = () => {
      const c = ctx.getImageData(Math.floor(view.w/2), Math.floor(view.h/2), 1, 1).data;
      state.removeColor = '#' + [c[0],c[1],c[2]].map(v=>v.toString(16).padStart(2,'0')).join('');
      modal.querySelector('[data-remove-color]').value=state.removeColor;
    };
    modal.querySelector('[data-ie-action="white"]').onclick = () => { state.removeColor='#ffffff'; modal.querySelector('[data-remove-color]').value='#ffffff'; removeBackground(img, state, false); draw(); };
    modal.querySelector('[data-ie-action="edges"]').onclick = () => { removeBackground(img, state, true); draw(); };
    modal.querySelector('[data-remove-color]').addEventListener('input', e => state.removeColor=e.target.value);

    const removeBackground = (source, st, connected) => {
      // Bake background removal into an in-memory source canvas.
      const c = document.createElement('canvas'); c.width=source.width; c.height=source.height;
      const x=c.getContext('2d',{willReadFrequently:true}); x.drawImage(source,0,0); const d=x.getImageData(0,0,c.width,c.height); const p=d.data;
      const hex=st.removeColor.replace('#',''); const target=[parseInt(hex.slice(0,2),16),parseInt(hex.slice(2,4),16),parseInt(hex.slice(4,6),16)];
      const tol=st.tolerance; const near=(i)=>Math.sqrt((p[i]-target[0])**2+(p[i+1]-target[1])**2+(p[i+2]-target[2])**2)<=tol;
      const mask=new Uint8Array(source.width*source.height); const q=[];
      if (connected) {
        for(let xx=0;xx<source.width;xx++){ q.push(xx,0); if(source.height>1) q.push(xx,source.height-1); }
        for(let yy=1;yy<source.height-1;yy++){ q.push(0,yy); if(source.width>1) q.push(source.width-1,yy); }
        for(let i=0;i<q.length;i+=2){ const xx=q[i],yy=q[i+1], idx=yy*source.width+xx; if(mask[idx]||!near(idx*4)) continue; mask[idx]=1; }
        for(let head=0;head<q.length;head+=2){ const xx=q[head],yy=q[head+1]; for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const nx=xx+dx,ny=yy+dy;if(nx<0||ny<0||nx>=source.width||ny>=source.height)continue;const idx=ny*source.width+nx;if(!mask[idx]&&near(idx*4)){mask[idx]=1;q.push(nx,ny);}} }
      } else { for(let i=0;i<mask.length;i++) if(near(i*4)) mask[i]=1; }
      for(let i=0;i<mask.length;i++) if(mask[i]) p[i*4+3]=0;
      x.putImageData(d,0,0); img.src=c.toDataURL('image/png');
    };

    img.onload = () => { view.fitScale=fitScale(); crop.w=img.width; crop.h=img.height; syncCropInputs(); syncSliders(); updateOutputs(); draw(); };
    img.src = asset.dataUrl;

    modal.querySelectorAll('[data-tab]').forEach(btn => btn.onclick=()=>{ modal.querySelectorAll('[data-tab]').forEach(b=>b.classList.toggle('active',b===btn)); modal.querySelectorAll('[data-panel]').forEach(p=>p.classList.toggle('active',p.dataset.panel===btn.dataset.tab)); });
    const close=()=>modal.remove(); modal.querySelectorAll('[data-ie-close]').forEach(b=>b.onclick=close);
    modal.querySelector('[data-ie-apply]').onclick=()=>{
      const out=document.createElement('canvas');
      const ow=Math.max(1,Math.round(crop.w)), oh=Math.max(1,Math.round(crop.h)); out.width=ow; out.height=oh; const ox=out.getContext('2d');
      // Render the currently transformed image into a large source canvas, then crop.
      const work=document.createElement('canvas'); work.width=img.width; work.height=img.height; const wx=work.getContext('2d');
      wx.save(); wx.translate(img.width/2+state.x/state.zoom, img.height/2+state.y/state.zoom); wx.rotate(state.rot*Math.PI/180); wx.filter=`brightness(${state.brightness}%) contrast(${state.contrast}%) saturate(${state.saturation}%) blur(${state.blur}px)`; wx.globalAlpha=state.alpha/100; wx.drawImage(img,-img.width/2,-img.height/2); wx.restore();
      if(state.circle){ ox.save(); ox.beginPath(); ox.arc(ow/2,oh/2,Math.min(ow,oh)/2,0,Math.PI*2); ox.clip(); }
      ox.drawImage(work,crop.x,crop.y,ow,oh,0,0,ow,oh); if(state.circle) ox.restore();
      if(state.shadowAlpha>0){ /* shadow is primarily previewed; keep a subtle baked shadow for transparent assets */ }
      out.toBlob(blob=>{ const r=new FileReader(); r.onload=()=>{ const name=(asset.name||'image').replace(/-edited(?:-\d+)?$/,'')+'-edited'; if(typeof opts.onApply==='function') opts.onApply({id:makeAssetId(),name,dataUrl:r.result,width:ow,height:oh,format:'PNG',size:blob.size}); close(); }; r.readAsDataURL(blob); },'image/png');
    };
  }
  static esc(s){return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
}
