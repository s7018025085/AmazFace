// src/exporter/zip-reader.js
//
// Минимальный ZIP-ридер: нужен, чтобы прочитать app.json из чужого device.zip
// (например, из рабочего циферблата, скачанного со стороннего сайта) и собрать
// вокруг него корректный .zpk. Поддерживает STORE и DEFLATE.

function zipReadU16(bytes, offset) {
  return bytes[offset] | (bytes[offset + 1] << 8);
}

function zipReadU32(bytes, offset) {
  return (bytes[offset] | (bytes[offset + 1] << 8) | (bytes[offset + 2] << 16) | (bytes[offset + 3] << 24)) >>> 0;
}

function zipFindEocd(bytes) {
  // EOCD лежит в конце файла; комментарий архива может занимать до 64 КБ.
  const minOffset = Math.max(0, bytes.length - 65557);
  for (let i = bytes.length - 22; i >= minOffset; i--) {
    if (zipReadU32(bytes, i) === 0x06054b50) return i;
  }
  return -1;
}

/**
 * Разбирает ZIP и возвращает содержимое файлов.
 * @param {Uint8Array} bytes
 * @returns {Promise<Map<string, Uint8Array>>} путь внутри архива → данные
 */
async function readZipEntries(bytes) {
  const eocd = zipFindEocd(bytes);
  if (eocd < 0) throw new Error('Это не ZIP-архив (не найден конец центрального каталога).');

  const count = zipReadU16(bytes, eocd + 10);
  let offset = zipReadU32(bytes, eocd + 16);
  const entries = new Map();

  for (let i = 0; i < count; i++) {
    if (zipReadU32(bytes, offset) !== 0x02014b50) {
      throw new Error('Повреждённый центральный каталог ZIP.');
    }
    const method = zipReadU16(bytes, offset + 10);
    const compressedSize = zipReadU32(bytes, offset + 20);
    const nameLen = zipReadU16(bytes, offset + 28);
    const extraLen = zipReadU16(bytes, offset + 30);
    const commentLen = zipReadU16(bytes, offset + 32);
    const localOffset = zipReadU32(bytes, offset + 42);
    const name = new TextDecoder().decode(bytes.subarray(offset + 46, offset + 46 + nameLen));

    // Длины полей в локальном заголовке могут отличаться от центрального.
    const localNameLen = zipReadU16(bytes, localOffset + 26);
    const localExtraLen = zipReadU16(bytes, localOffset + 28);
    const dataStart = localOffset + 30 + localNameLen + localExtraLen;
    const raw = bytes.subarray(dataStart, dataStart + compressedSize);

    if (!name.endsWith('/')) {
      if (method === 0) {
        entries.set(name, new Uint8Array(raw));
      } else if (method === 8) {
        if (typeof DecompressionStream === 'undefined') {
          throw new Error('Браузер не умеет распаковывать deflate — обновите браузер.');
        }
        const stream = new Blob([raw]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
        entries.set(name, new Uint8Array(await new Response(stream).arrayBuffer()));
      } else {
        throw new Error(`Неподдерживаемый метод сжатия (${method}) у файла ${name}.`);
      }
    }

    offset += 46 + nameLen + extraLen + commentLen;
  }
  return entries;
}
