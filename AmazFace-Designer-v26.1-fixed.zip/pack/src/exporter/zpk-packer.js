// src/exporter/zpk-packer.js

const DIRECT_BALANCE2_SOURCES_FOR_MANIFEST = [9568512, 9568513, 9568515];
//
// Упаковка готового device.zip в контейнер .zpk — тот самый формат, который
// Zepp App принимает при установке по QR-коду в режиме разработчика.
//
// Структура реального пакета (проверена распаковкой .zab от Watchface Maker):
//   watchface.zab
//     ├── manifest.json
//     ├── .ip-package
//     └── <target>.zpk
//           ├── app-side.zip
//           └── device.zip
//                 ├── app.json
//                 ├── app.js
//                 ├── assets/…
//                 └── watchface/index.js
//
// Для установки по ссылке zpkd1:// нужен именно средний уровень — .zpk.
// Уровень .zab здесь не собирается: он нужен только для загрузки в магазин
// через аккаунт Zepp, а это ровно тот путь, от которого мы уходим.

// Минимальный сервисный скрипт app-side. Циферблату побочный сервис не нужен,
// но в настоящих пакетах app-side.zip присутствует всегда, поэтому кладём
// корректную заглушку, а не пустой файл.
const ZPK_APP_SIDE_JS = `try {
  AppSideService({
    onInit() {},
    onRun() {},
    onDestroy() {}
  });
} catch (e) {
  console.log('app-side error', e);
}`;

/**
 * Собирает app-side.zip (app.json + app-side/index.js).
 * Манифест берётся тот же, что и у device.zip — так делает и Zeus.
 * @param {string} appJson
 * @returns {Uint8Array}
 */
async function buildAppSideZipBytes(appJson, options = {}) {
  const zip = new ZipWriter();
  zip.addFile('app.json', appJson);
  zip.addFile('app-side/index.js', ZPK_APP_SIDE_JS);
  return zip.generateBytesAsync({ compress: options.compress !== false });
}

/**
 * Оборачивает готовый device.zip (в том числе чужой, из рабочего циферблата)
 * в контейнер .zpk. Нужно для диагностики: если чужой device.zip в нашем
 * контейнере ставится, значит контейнер верный и дело в содержимом пакета,
 * и наоборот.
 *
 * @param {Uint8Array} deviceZipBytes
 * @param {{includeAppSide?: boolean}} [options]
 * @returns {Promise<{blob: Blob, bytes: Uint8Array, appJson: string|null, files: string[]}>}
 */
async function wrapDeviceZipIntoZpk(deviceZipBytes, options = {}) {
  let appJson = null;
  try {
    const entries = await readZipEntries(deviceZipBytes);
    if (!entries.has('app.json')) {
      throw new Error('В архиве нет app.json — это не device.zip.');
    }
    appJson = new TextDecoder().decode(entries.get('app.json'));
  } catch (e) {
    throw new Error('Не удалось прочитать device.zip: ' + e.message);
  }

  const zip = new ZipWriter();
  if (options.includeAppSide !== false) {
    zip.addFile('app-side.zip', await buildAppSideZipBytes(appJson, options));
  }
  zip.addFile('device.zip', deviceZipBytes);

  const bytes = zip.generateBytes();
  return {
    blob: new Blob([bytes], { type: 'application/octet-stream' }),
    bytes,
    appJson,
    files: zip.files.map(f => f.name)
  };
}

/**
 * Собирает .zpk из проекта: внутри вызывает Direct-экспортёр и оборачивает
 * полученный device.zip в контейнер.
 *
 * @param {object} project
 * @param {{includeAppSide?: boolean}} [options]
 * @returns {Promise<{blob: Blob, bytes: Uint8Array, deviceZipBlob: Blob, validation: object, files: string[]}>}
 */
async function exportZpkPackage(project, options = {}) {
  const direct = await exportDirectDeviceZip(project, { compress: options.compress !== false });

  const zip = new ZipWriter();
  if (options.includeAppSide !== false) {
    zip.addFile('app-side.zip', await buildAppSideZipBytes(direct.appJson, options));
  }
  zip.addFile('device.zip', direct.bytes);

  // Внешний контейнер не сжимаем: внутри уже сжатые архивы.
  const bytes = zip.generateBytes();
  return {
    blob: new Blob([bytes], { type: 'application/octet-stream' }),
    bytes,
    deviceZipBlob: direct.blob,
    validation: direct.validation,
    format: '.zpk',
    files: zip.files.map(f => f.name),
    deviceFiles: direct.files
  };
}

/**
 * Собирает верхний контейнер настоящего пакета Zepp — тот, что реально
 * нужно раздавать по ссылке для установки через zpkd1://.
 *
 * Подтверждено байт-в-байт на официальном пакете (zpm 2.9.1, циферблат
 * "Cute Mushroom Panda"): внутри лежит manifest.json с md5 КАЖДОГО
 * целевого .zpk и настоящее устройство узнаёт свой пакет по platforms,
 * сверяя md5 перед установкой. То, что мы раньше называли ".zpk" и
 * отдавали напрямую по ссылке (app-side.zip + device.zip), — это только
 * средний уровень настоящей структуры. Он корректно распаковывается
 * (это подтвердила первая проверка вашей ссылки), но без внешнего
 * manifest.json Zepp App не может сопоставить его с часами — отсюда
 * «send package to device failed» вместо «download failed».
 *
 * @param {object} project
 * @param {{compress?: boolean, targetName?: string}} [options]
 * @returns {Promise<{blob: Blob, bytes: Uint8Array, targetName: string, targetMd5: string, files: string[], validation: object}>}
 */
async function exportZabContainer(project, options = {}) {
  const inner = await exportZpkPackage(project, options);
  const targetMd5 = md5Hex(inner.bytes);
  // Схема platforms проверена байт-в-байт на настоящем manifest.json
  // (репозиторий SarahBass/Zepp-Amazfit-Panda — тот самый эталонный .zab,
  // "Cute Mushroom Panda", zpm 2.9.1, который уже сверялся раньше):
  //   "platforms":[{"name":"Amazfit Falcon","deviceSource":414}, ...]
  // Прежняя версия ("screenType"/"screenResolution"/"cpuPlatform": "ZPS")
  // была ошибочно перенесена из C#-исходника Саши — в настоящем manifest.json
  // такой схемы нет, там та же пара name/deviceSource, что и в app.json.
  // Признак чипа (NXP/MHS у Falcon и GTR Mini соответственно) в реальном
  // файле встречается только в ИМЕНИ вложенного .zpk, не как JSON-поле —
  // это мы и так уже делали (targetName ниже), тут менять было не нужно.
  const targetName = options.targetName || 'balance-2-ZPS-480x480.zpk';

  const app = project.app || {};
  const manifest = {
    configVersion: 'v2',
    zpks: [{
      name: targetName,
      version: { code: Number(app.versionCode) || 1, name: app.versionName || '1.0.0' },
      appType: 'watchface',
      platforms: DIRECT_BALANCE2_SOURCES_FOR_MANIFEST.map(deviceSource => ({
        name: 'Amazfit Balance 2',
        deviceSource
      })),
      md5: targetMd5
    }],
    bundleInfo: {
      // Тот же zpm, что и в app.json внутри device.zip (см.
      // direct-zip-exporter.js) — в настоящем .zab оба уровня
      // проштампованы одной версией сборщика, а не двумя разными.
      zpm: '2.9.1',
      timeStamp: Math.floor(Date.now() / 1000),
      // Раньше это поле сознательно опускали (аргумент был «файла .sc нет
      // в пакете — значит, и поле не нужно»). Но в подтверждённо рабочем
      // эталонном manifest.json (SarahBass/Zepp-Amazfit-Panda) поле
      // присутствует именно со значением ".sc", хотя сам .sc-файл (для
      // веб-симулятора Watchface Maker) в пакет тоже не входит — значит,
      // это фиксированный элемент схемы манифеста, а не указатель на
      // реально существующий файл. Возвращаем как константу.
      csc: '.sc'
    }
  };

  const zip = new ZipWriter();
  zip.addFile('manifest.json', JSON.stringify(manifest));
  zip.addFile(targetName, inner.bytes);
  // Внешний контейнер в оригинале не сжат (проверено на реальном .zab).
  const bytes = zip.generateBytes();

  return {
    blob: new Blob([bytes], { type: 'application/octet-stream' }),
    bytes,
    targetName,
    targetMd5,
    validation: inner.validation,
    files: zip.files.map(f => f.name)
  };
}

/**
 * Превращает обычную ссылку на .zpk в ссылку схемы zpkd1://, которую понимает
 * сканер в режиме разработчика Zepp App. Именно эта строка кодируется в QR.
 *
 * @param {string} url прямая ссылка на файл (http/https или уже zpkd1)
 * @returns {string}
 */
function toZpkd1Url(url) {
  const raw = String(url || '').trim();
  if (!raw) throw new Error('Укажите ссылку на файл .zpk.');
  const withoutScheme = raw.replace(/^[a-z0-9+.-]+:\/\//i, '');
  if (!withoutScheme || withoutScheme.startsWith('/')) {
    throw new Error('Ссылка выглядит неполной — нужен домен и путь к файлу.');
  }
  return 'zpkd1://' + withoutScheme;
}

/**
 * Необязательные замечания по ссылке. Установку они не блокируют, но
 * подсвечивают самые частые причины, по которым QR потом «не срабатывает».
 * @param {string} url
 * @returns {string[]}
 */
function checkZpkUrl(url) {
  const raw = String(url || '').trim();
  const notes = [];
  if (!/\.zpk(\?|$)/i.test(raw)) {
    notes.push('Ссылка не оканчивается на .zpk — часы скачивают файл как есть, расширение должно быть именно таким.');
  }
  if (/drive\.google\.com|disk\.yandex\.[a-z]+\/d\/|dropbox\.com\/s\//i.test(raw) && !/direct|raw|download=1|dl=1/i.test(raw)) {
    notes.push('Похоже на страницу просмотра, а не на прямую ссылку. Нужен URL, который сразу отдаёт файл.');
  }
  if (/^http:\/\//i.test(raw)) {
    notes.push('Ссылка по http:// — некоторые прошивки скачивают только по https://.');
  }
  return notes;
}
