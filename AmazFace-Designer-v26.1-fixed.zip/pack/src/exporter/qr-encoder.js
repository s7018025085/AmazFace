// src/exporter/qr-encoder.js
//
// Минимальный генератор QR-кода (ISO/IEC 18004) на чистом JS, без зависимостей и CDN.
// Режим кодирования — byte (8 бит), уровни коррекции L/M/Q/H, версии 1..20.
// Нужен для установки по zpkd1://-ссылке без Zeus CLI и без облака Zepp.

// Полное число кодовых слов в символе для версий 1..20.
const QR_TOTAL_CODEWORDS = [
  26, 44, 70, 100, 134, 172, 196, 242, 292, 346,
  404, 466, 532, 581, 655, 733, 815, 901, 991, 1085
];

// Для каждого уровня коррекции: [кодовых слов коррекции на блок, число блоков].
// Число блоков перепроверяется инвариантом ecPerBlock * blocks === ecTotal.
const QR_EC_TABLE = {
  L: [[7,1],[10,1],[15,1],[20,1],[26,1],[18,2],[20,2],[24,2],[30,2],[18,4],
      [20,4],[24,4],[26,4],[30,4],[22,6],[24,6],[28,6],[30,6],[28,7],[28,8]],
  M: [[10,1],[16,1],[26,1],[18,2],[24,2],[16,4],[18,4],[22,4],[22,5],[26,5],
      [30,5],[22,8],[22,9],[24,9],[24,10],[28,10],[28,11],[26,13],[26,14],[26,16]],
  Q: [[13,1],[22,1],[18,2],[26,2],[18,4],[24,4],[18,6],[22,6],[20,8],[24,8],
      [28,8],[26,10],[24,12],[20,16],[30,12],[24,17],[28,16],[28,18],[26,21],[30,20]],
  H: [[17,1],[28,1],[22,2],[16,4],[22,4],[28,4],[26,5],[26,6],[24,8],[28,8],
      [24,11],[28,11],[22,16],[24,16],[24,18],[30,16],[28,19],[28,21],[26,25],[28,25]]
};

const QR_ALIGN_POS = [
  [], [6,18], [6,22], [6,26], [6,30], [6,34], [6,22,38], [6,24,42], [6,26,46], [6,28,50],
  [6,30,54], [6,32,58], [6,34,62], [6,26,46,66], [6,26,48,70], [6,26,50,74], [6,30,54,78],
  [6,30,56,82], [6,30,58,86], [6,34,62,90]
];

const QR_EC_FORMAT_BITS = { L: 1, M: 0, Q: 3, H: 2 };

// ---- Арифметика в GF(256), порождающий полином x^8+x^4+x^3+x^2+1 (0x11d) ----
const QR_GF_EXP = new Uint8Array(512);
const QR_GF_LOG = new Uint8Array(256);
(() => {
  let x = 1;
  for (let i = 0; i < 255; i++) {
    QR_GF_EXP[i] = x;
    QR_GF_LOG[x] = i;
    x <<= 1;
    if (x & 0x100) x ^= 0x11d;
  }
  for (let i = 255; i < 512; i++) QR_GF_EXP[i] = QR_GF_EXP[i - 255];
})();

function qrGfMul(a, b) {
  if (a === 0 || b === 0) return 0;
  return QR_GF_EXP[QR_GF_LOG[a] + QR_GF_LOG[b]];
}

function qrRsGenerator(degree) {
  let poly = [1];
  for (let i = 0; i < degree; i++) {
    const next = new Array(poly.length + 1).fill(0);
    for (let j = 0; j < poly.length; j++) {
      next[j] ^= qrGfMul(poly[j], 1);
      next[j + 1] ^= qrGfMul(poly[j], QR_GF_EXP[i]);
    }
    poly = next;
  }
  return poly;
}

function qrRsEncode(data, ecLen) {
  const gen = qrRsGenerator(ecLen);
  const res = new Uint8Array(ecLen);
  for (let i = 0; i < data.length; i++) {
    const factor = data[i] ^ res[0];
    res.copyWithin(0, 1);
    res[ecLen - 1] = 0;
    if (factor !== 0) {
      for (let j = 0; j < ecLen; j++) res[j] ^= qrGfMul(gen[j + 1], factor);
    }
  }
  return res;
}

// ---- Кодирование данных ----
function qrUtf8Bytes(str) {
  if (typeof TextEncoder !== 'undefined') return new TextEncoder().encode(str);
  const out = [];
  for (const ch of str) {
    let cp = ch.codePointAt(0);
    if (cp < 0x80) out.push(cp);
    else if (cp < 0x800) out.push(0xc0 | (cp >> 6), 0x80 | (cp & 63));
    else if (cp < 0x10000) out.push(0xe0 | (cp >> 12), 0x80 | ((cp >> 6) & 63), 0x80 | (cp & 63));
    else out.push(0xf0 | (cp >> 18), 0x80 | ((cp >> 12) & 63), 0x80 | ((cp >> 6) & 63), 0x80 | (cp & 63));
  }
  return Uint8Array.from(out);
}

function qrCapacityBytes(version, ecLevel) {
  const [ecPerBlock, blocks] = QR_EC_TABLE[ecLevel][version - 1];
  const dataCodewords = QR_TOTAL_CODEWORDS[version - 1] - ecPerBlock * blocks;
  const lenBits = version < 10 ? 8 : 16;
  return dataCodewords - 1 - Math.ceil(lenBits / 8) + (lenBits === 8 ? 0 : 0);
}

function qrPickVersion(byteLen, ecLevel) {
  for (let v = 1; v <= 20; v++) {
    const [ecPerBlock, blocks] = QR_EC_TABLE[ecLevel][v - 1];
    const dataCodewords = QR_TOTAL_CODEWORDS[v - 1] - ecPerBlock * blocks;
    const lenBits = v < 10 ? 8 : 16;
    const needBits = 4 + lenBits + byteLen * 8;
    if (needBits <= dataCodewords * 8) return v;
  }
  throw new Error('Строка слишком длинная для QR-кода (максимум — версия 20).');
}

class QrBitBuffer {
  constructor() { this.bits = []; }
  put(value, length) {
    for (let i = length - 1; i >= 0; i--) this.bits.push((value >>> i) & 1);
  }
  get length() { return this.bits.length; }
}

function qrBuildCodewords(bytes, version, ecLevel) {
  const [ecPerBlock, blocks] = QR_EC_TABLE[ecLevel][version - 1];
  const totalCodewords = QR_TOTAL_CODEWORDS[version - 1];
  const dataCodewords = totalCodewords - ecPerBlock * blocks;
  const lenBits = version < 10 ? 8 : 16;

  const bb = new QrBitBuffer();
  bb.put(0b0100, 4);              // режим byte
  bb.put(bytes.length, lenBits);
  for (const b of bytes) bb.put(b, 8);

  const capacityBits = dataCodewords * 8;
  const terminator = Math.min(4, capacityBits - bb.length);
  bb.put(0, terminator);
  while (bb.length % 8 !== 0) bb.bits.push(0);

  const data = new Uint8Array(dataCodewords);
  for (let i = 0; i < bb.length; i += 8) {
    let v = 0;
    for (let j = 0; j < 8; j++) v = (v << 1) | bb.bits[i + j];
    data[i / 8] = v;
  }
  const padBytes = [0xec, 0x11];
  for (let i = bb.length / 8, k = 0; i < dataCodewords; i++, k++) data[i] = padBytes[k % 2];

  // Разбиение на блоки: короткие блоки идут первыми, длинные — на один кодослов больше.
  const shortLen = Math.floor(dataCodewords / blocks);
  const longCount = dataCodewords % blocks;
  const shortCount = blocks - longCount;

  const dataBlocks = [];
  const ecBlocks = [];
  let offset = 0;
  for (let i = 0; i < blocks; i++) {
    const len = i < shortCount ? shortLen : shortLen + 1;
    const block = data.slice(offset, offset + len);
    offset += len;
    dataBlocks.push(block);
    ecBlocks.push(qrRsEncode(block, ecPerBlock));
  }

  // Чередование
  const result = new Uint8Array(totalCodewords);
  let pos = 0;
  const maxData = shortLen + (longCount > 0 ? 1 : 0);
  for (let i = 0; i < maxData; i++) {
    for (const blk of dataBlocks) if (i < blk.length) result[pos++] = blk[i];
  }
  for (let i = 0; i < ecPerBlock; i++) {
    for (const blk of ecBlocks) result[pos++] = blk[i];
  }
  return result;
}

// ---- Построение матрицы ----
function qrCreateMatrix(version) {
  const size = version * 4 + 17;
  const modules = [];
  const reserved = [];
  for (let i = 0; i < size; i++) {
    modules.push(new Uint8Array(size));
    reserved.push(new Uint8Array(size));
  }
  return { size, modules, reserved };
}

function qrPlaceFinder(m, row, col) {
  for (let r = -1; r <= 7; r++) {
    for (let c = -1; c <= 7; c++) {
      const rr = row + r, cc = col + c;
      if (rr < 0 || rr >= m.size || cc < 0 || cc >= m.size) continue;
      const inner = (r >= 0 && r <= 6 && (c === 0 || c === 6)) ||
                    (c >= 0 && c <= 6 && (r === 0 || r === 6)) ||
                    (r >= 2 && r <= 4 && c >= 2 && c <= 4);
      m.modules[rr][cc] = inner ? 1 : 0;
      m.reserved[rr][cc] = 1;
    }
  }
}

function qrPlaceAlignment(m, version) {
  const pos = QR_ALIGN_POS[version - 1] || [];
  for (const r of pos) {
    for (const c of pos) {
      const isFinder = (r <= 8 && c <= 8) ||
                       (r <= 8 && c >= m.size - 9) ||
                       (r >= m.size - 9 && c <= 8);
      if (isFinder) continue;
      for (let dr = -2; dr <= 2; dr++) {
        for (let dc = -2; dc <= 2; dc++) {
          const on = Math.max(Math.abs(dr), Math.abs(dc)) !== 1;
          m.modules[r + dr][c + dc] = on ? 1 : 0;
          m.reserved[r + dr][c + dc] = 1;
        }
      }
    }
  }
}

function qrPlaceTiming(m) {
  for (let i = 8; i < m.size - 8; i++) {
    const on = i % 2 === 0 ? 1 : 0;
    m.modules[6][i] = on; m.reserved[6][i] = 1;
    m.modules[i][6] = on; m.reserved[i][6] = 1;
  }
}

function qrReserveFormat(m, version) {
  for (let i = 0; i < 9; i++) {
    if (!(i === 6)) { m.reserved[8][i] = 1; m.reserved[i][8] = 1; }
  }
  m.reserved[8][6] = 1; m.reserved[6][8] = 1;
  for (let i = 0; i < 8; i++) {
    m.reserved[8][m.size - 1 - i] = 1;
    m.reserved[m.size - 1 - i][8] = 1;
  }
  // Тёмный модуль
  m.modules[m.size - 8][8] = 1;
  m.reserved[m.size - 8][8] = 1;
  if (version >= 7) {
    for (let i = 0; i < 6; i++) {
      for (let j = 0; j < 3; j++) {
        m.reserved[i][m.size - 11 + j] = 1;
        m.reserved[m.size - 11 + j][i] = 1;
      }
    }
  }
}

function qrBchFormat(data) {
  let v = data << 10;
  for (let i = 14; i >= 10; i--) {
    if ((v >>> i) & 1) v ^= 0x537 << (i - 10);
  }
  return ((data << 10) | v) ^ 0x5412;
}

function qrBchVersion(version) {
  let v = version << 12;
  for (let i = 17; i >= 12; i--) {
    if ((v >>> i) & 1) v ^= 0x1f25 << (i - 12);
  }
  return (version << 12) | v;
}

function qrDrawFormat(m, ecLevel, mask) {
  const bits = qrBchFormat((QR_EC_FORMAT_BITS[ecLevel] << 3) | mask);
  for (let i = 0; i < 15; i++) {
    const bit = (bits >>> i) & 1;
    // Копия 1: столбец 8 сверху вниз, затем снизу (пропуская линию синхронизации).
    if (i < 6) m.modules[i][8] = bit;
    else if (i < 8) m.modules[i + 1][8] = bit;
    else m.modules[m.size - 15 + i][8] = bit;
    // Копия 2: строка 8 справа налево, затем слева.
    if (i < 8) m.modules[8][m.size - 1 - i] = bit;
    else if (i === 8) m.modules[8][7] = bit;
    else m.modules[8][14 - i] = bit;
  }
  m.modules[m.size - 8][8] = 1; // тёмный модуль
}

function qrDrawVersion(m, version) {
  if (version < 7) return;
  const bits = qrBchVersion(version);
  for (let i = 0; i < 18; i++) {
    const bit = (bits >>> i) & 1;
    const r = Math.floor(i / 3);
    const c = i % 3;
    m.modules[r][m.size - 11 + c] = bit;
    m.modules[m.size - 11 + c][r] = bit;
  }
}

function qrMaskFn(mask, r, c) {
  switch (mask) {
    case 0: return (r + c) % 2 === 0;
    case 1: return r % 2 === 0;
    case 2: return c % 3 === 0;
    case 3: return (r + c) % 3 === 0;
    case 4: return (Math.floor(r / 2) + Math.floor(c / 3)) % 2 === 0;
    case 5: return ((r * c) % 2) + ((r * c) % 3) === 0;
    case 6: return (((r * c) % 2) + ((r * c) % 3)) % 2 === 0;
    case 7: return (((r + c) % 2) + ((r * c) % 3)) % 2 === 0;
    default: return false;
  }
}

function qrPlaceData(m, codewords, mask) {
  let bitIndex = 0;
  let upward = true;
  for (let col = m.size - 1; col > 0; col -= 2) {
    if (col === 6) col--; // вертикальная линия синхронизации
    for (let i = 0; i < m.size; i++) {
      const row = upward ? m.size - 1 - i : i;
      for (let k = 0; k < 2; k++) {
        const c = col - k;
        if (m.reserved[row][c]) continue;
        let bit = 0;
        if (bitIndex < codewords.length * 8) {
          bit = (codewords[bitIndex >> 3] >>> (7 - (bitIndex & 7))) & 1;
        }
        bitIndex++;
        if (qrMaskFn(mask, row, c)) bit ^= 1;
        m.modules[row][c] = bit;
      }
    }
    upward = !upward;
  }
}

function qrPenalty(m) {
  const n = m.size;
  let penalty = 0;
  // Правило 1: серии одинаковых модулей
  for (let pass = 0; pass < 2; pass++) {
    for (let i = 0; i < n; i++) {
      let run = 1;
      let prev = pass === 0 ? m.modules[i][0] : m.modules[0][i];
      for (let j = 1; j < n; j++) {
        const cur = pass === 0 ? m.modules[i][j] : m.modules[j][i];
        if (cur === prev) { run++; }
        else { if (run >= 5) penalty += 3 + (run - 5); run = 1; prev = cur; }
      }
      if (run >= 5) penalty += 3 + (run - 5);
    }
  }
  // Правило 2: блоки 2x2
  for (let r = 0; r < n - 1; r++) {
    for (let c = 0; c < n - 1; c++) {
      const v = m.modules[r][c];
      if (v === m.modules[r][c + 1] && v === m.modules[r + 1][c] && v === m.modules[r + 1][c + 1]) penalty += 3;
    }
  }
  // Правило 3: последовательности, похожие на искатель
  const p1 = [1,0,1,1,1,0,1,0,0,0,0];
  const p2 = [0,0,0,0,1,0,1,1,1,0,1];
  const match = (get, i) => {
    let a = true, b = true;
    for (let k = 0; k < 11; k++) {
      const v = get(i + k);
      if (v !== p1[k]) a = false;
      if (v !== p2[k]) b = false;
    }
    return a || b;
  };
  for (let r = 0; r < n; r++) {
    for (let c = 0; c + 11 <= n; c++) {
      if (match(x => m.modules[r][x], c)) penalty += 40;
    }
  }
  for (let c = 0; c < n; c++) {
    for (let r = 0; r + 11 <= n; r++) {
      if (match(x => m.modules[x][c], r)) penalty += 40;
    }
  }
  // Правило 4: баланс тёмных модулей
  let dark = 0;
  for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) dark += m.modules[r][c];
  const percent = (dark * 100) / (n * n);
  penalty += Math.floor(Math.abs(percent - 50) / 5) * 10;
  return penalty;
}

/**
 * Кодирует строку в матрицу QR.
 * @param {string} text
 * @param {'L'|'M'|'Q'|'H'} ecLevel
 * @returns {{size:number, modules:Uint8Array[], version:number, ecLevel:string, mask:number}}
 */
function qrEncodeToMatrix(text, ecLevel = 'M') {
  if (!QR_EC_TABLE[ecLevel]) throw new Error('Неизвестный уровень коррекции: ' + ecLevel);
  const bytes = qrUtf8Bytes(String(text));
  const version = qrPickVersion(bytes.length, ecLevel);
  const codewords = qrBuildCodewords(bytes, version, ecLevel);

  let best = null;
  for (let mask = 0; mask < 8; mask++) {
    const m = qrCreateMatrix(version);
    qrPlaceFinder(m, 0, 0);
    qrPlaceFinder(m, 0, m.size - 7);
    qrPlaceFinder(m, m.size - 7, 0);
    qrPlaceAlignment(m, version);
    qrPlaceTiming(m);
    qrReserveFormat(m, version);
    qrDrawVersion(m, version);
    qrPlaceData(m, codewords, mask);
    qrDrawFormat(m, ecLevel, mask);
    const score = qrPenalty(m);
    if (!best || score < best.score) best = { score, m, mask };
  }
  return { size: best.m.size, modules: best.m.modules, version, ecLevel, mask: best.mask };
}

/**
 * Отрисовывает матрицу в SVG-строку (quiet zone — 4 модуля, как требует стандарт).
 */
function qrMatrixToSvg(matrix, moduleSize = 8, quiet = 4) {
  const n = matrix.size;
  const dim = (n + quiet * 2) * moduleSize;
  let path = '';
  for (let r = 0; r < n; r++) {
    for (let c = 0; c < n; c++) {
      if (!matrix.modules[r][c]) continue;
      const x = (c + quiet) * moduleSize;
      const y = (r + quiet) * moduleSize;
      path += `M${x} ${y}h${moduleSize}v${moduleSize}h-${moduleSize}z`;
    }
  }
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${dim}" height="${dim}" viewBox="0 0 ${dim} ${dim}" shape-rendering="crispEdges">` +
         `<rect width="${dim}" height="${dim}" fill="#ffffff"/>` +
         `<path d="${path}" fill="#000000"/></svg>`;
}

/**
 * Отрисовывает матрицу в PNG data URL через canvas (только в браузере).
 */
function qrMatrixToPngDataUrl(matrix, moduleSize = 8, quiet = 4) {
  const n = matrix.size;
  const dim = (n + quiet * 2) * moduleSize;
  const canvas = document.createElement('canvas');
  canvas.width = dim;
  canvas.height = dim;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, dim, dim);
  ctx.fillStyle = '#000000';
  for (let r = 0; r < n; r++) {
    for (let c = 0; c < n; c++) {
      if (matrix.modules[r][c]) ctx.fillRect((c + quiet) * moduleSize, (r + quiet) * moduleSize, moduleSize, moduleSize);
    }
  }
  return canvas.toDataURL('image/png');
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { qrEncodeToMatrix, qrMatrixToSvg };
}
