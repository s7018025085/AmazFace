// src/exporter/direct-zip-exporter.js
//
// Direct browser-only device.zip exporter for Amazfit Balance 2.
// It deliberately does NOT invoke Zeus CLI and does NOT build BIN files.
// Existing Zeus/full-project export remains untouched.

const DIRECT_BALANCE2_SOURCES = [9568512, 9568513, 9568515];

const DIRECT_APP_JS = `try {
  (() => {
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    function getApp() { return __$$app$$__.app; }
    function getCurrentPage() { return __$$app$$__.current && __$$app$$__.current.module; }
    __$$app$$__.__globals__ = {
      lang: new DeviceRuntimeCore.HmUtils.Lang(DeviceRuntimeCore.HmUtils.getLanguage()),
      px: DeviceRuntimeCore.HmUtils.getPx(454)
    };
    const {px} = __$$app$$__.__globals__;
    const languageTable = {};
    __$$app$$__.__globals__.gettext = DeviceRuntimeCore.HmUtils.gettextFactory(languageTable, __$$app$$__.__globals__.lang, 'en-US');
    function getGlobal() {
      if (typeof self !== 'undefined') return self;
      if (typeof window !== 'undefined') return window;
      if (typeof global !== 'undefined') return global;
      if (typeof globalThis !== 'undefined') return globalThis;
      throw new Error('unable to locate global object');
    }
    let globalNS$2 = getGlobal();
    if (!globalNS$2.Logger && typeof DeviceRuntimeCore !== 'undefined') globalNS$2.Logger = DeviceRuntimeCore.HmLogger;
    let globalNS$1 = getGlobal();
    if (!globalNS$1.Buffer) globalNS$1.Buffer = typeof Buffer !== 'undefined' ? Buffer : DeviceRuntimeCore.Buffer;
    function isHmTimerDefined() { return typeof timer !== 'undefined'; }
    let globalNS = getGlobal();
    if (typeof setTimeout === 'undefined' && isHmTimerDefined()) {
      globalNS.clearTimeout = function(t) { t && timer.stopTimer(t); };
      globalNS.setTimeout = function(fn, ns) {
        const t = timer.createTimer(ns || 1, Number.MAX_SAFE_INTEGER, function() { globalNS.clearTimeout(t); fn && fn(); }, {});
        return t;
      };
      globalNS.clearImmediate = function(t) { t && timer.stopTimer(t); };
      globalNS.setImmediate = function(fn) { return globalNS.setTimeout(fn, 1); };
      globalNS.clearInterval = function(t) { t && timer.stopTimer(t); };
      globalNS.setInterval = function(fn, ms) {
        const t = timer.createTimer(1, ms, function() { fn && fn(); }, {});
        return t;
      };
    }
    __$$app$$__.app = DeviceRuntimeCore.App({ globalData: {}, onCreate() {}, onDestroy() {}, onError() {}, onPageNotFound() {}, onUnhandledRejection() {} });
  })();
} catch (e) {
  console.log('Mini Program Error', e);
  e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}`;

function directHash(str) {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}

function directAppId(project) {
  const supplied = Number(project.app?.appId);
  if (Number.isFinite(supplied) && supplied > 0 && supplied !== 10001) return supplied;
  // Deterministic 7-digit fallback. A real Developer Console appId should be
  // entered before publication; the fallback is intended for local packaging.
  return 1000000 + (directHash(String(project.meta?.name || 'AmazFace')) % 8999999);
}

// Уровень API берётся из проекта, но не опускается ниже 3.0: пакет для
// Balance 2 не должен объявлять себя как API 1.x, иначе Zepp App и часы
// трактуют его по правилам старого рантайма.
const DIRECT_MIN_API_LEVEL = '3.0';

function directParseApiLevel(value) {
  const parts = String(value || '').trim().match(/^(\d+)(?:\.(\d+))?(?:\.(\d+))?$/);
  if (!parts) return null;
  return [Number(parts[1]), Number(parts[2] || 0), Number(parts[3] || 0)];
}

function directCompareVersions(a, b) {
  for (let i = 0; i < 3; i++) {
    const d = (a[i] || 0) - (b[i] || 0);
    if (d !== 0) return d < 0 ? -1 : 1;
  }
  return 0;
}

/**
 * Возвращает блок runtime.apiVersion для app.json.
 * compatible/minVersion — выбранный уровень (не ниже 3.0),
 * target — тот же уровень с патч-версией 1, как это делает Zeus.
 */
function directBuildApiVersion(project) {
  const floor = directParseApiLevel(DIRECT_MIN_API_LEVEL);
  let level = directParseApiLevel(project?.apiLevel);
  if (!level || directCompareVersions(level, floor) < 0) level = floor;
  const base = `${level[0]}.${level[1]}.${level[2]}`;
  return {
    compatible: base,
    target: `${level[0]}.${level[1]}.${(level[2] || 0) + 1}`,
    minVersion: base
  };
}

function directBuildAppJson(project) {
  const name = String(project.meta?.name || 'AmazFace Watch Face').slice(0, 64);
  const app = project.app || {};
  return JSON.stringify({
    // v2, не v3: сверено с настоящим device.zip рабочего циферблата для
    // Balance 2 (mrc254, deviceSource 9568512/13/15 — те же ID, что и у
    // нас). v3 разблокирует необязательные модули (app-service/app-event),
    // которых мы не используем, — держаться v2 безопаснее раз он
    // подтверждённо ставится именно на эту модель.
    configVersion: 'v2',
    app: {
      appIdType: 0,
      appId: directAppId(project),
      appName: name,
      appType: 'watchface',
      version: { code: Number(app.versionCode) || 1, name: app.versionName || '1.0.0' },
      vender: app.vendor || 'zepp',
      description: '',
      icon: 'Preview.png',
      cover: ['Preview.png'],
      extraInfo: { madeBy: 1, fromZoom: false }
    },
    permissions: typeof computePermissions === 'function' ? computePermissions(project) : [],
    // Без "type" — в реальном app.json этого поля нет. apiVersion оставляем
    // по проекту (не занижаем до 1.0.0 из референса: тот файл собран другим
    // инструментом (Watch_Face_Editor Саши) под его собственный
    // legacy-рантайм DeviceRuntimeCore, а не под ESM `@zos/*`, которые
    // реально использует наш index.js — для них 1.0 недостаточно).
    runtime: { apiVersion: directBuildApiVersion(project) },
    i18n: { 'en-US': { icon: 'Preview.png', appName: name } },
    defaultLanguage: 'en-US',
    debug: false,
    module: { watchface: { path: 'watchface/index', main: 1, editable: 0, lockscreen: 1, hightCost: 0 } },
    platforms: DIRECT_BALANCE2_SOURCES.map(deviceSource => ({ name: 'Amazfit Balance 2', deviceSource })),
    designWidth: 480,
    packageInfo: {
      mode: 'production',
      timeStamp: Math.floor(Date.now() / 1000),
      expiredTime: 172800,
      // 2.8.2, не 2.9.1: тот же genuine-референс (mrc254) собран именно
      // этим zpm. Раньше это число было «выровнено» под другой эталон
      // (Panda/GTR Mini, устройство 2023 года, другое поколение чипа) —
      // перенос между поколениями был необоснован. Разные подтверждённо
      // рабочие пакеты используют разные zpm — похоже, это просто метка
      // версии тулчейна и на парсинг не влияет, но раз есть прямой
      // референс для Balance 2 — держимся его числа.
      zpm: '2.8.2'
    }
  }, null, 2);
}

function directAssetPath(filename) {
  return `assets/${filename}`;
}

async function directEncodeAsset(dataUrl, label) {
  try {
    return await encodeZeppImageDataUrl(dataUrl);
  } catch (e) {
    throw new Error(`Не удалось преобразовать ресурс «${label}»: ${e.message}`);
  }
}

async function exportDirectDeviceZip(project, directOptions = {}) {
  if (typeof runDesignerPreflight === 'function') {
    const preflight = runDesignerPreflight(project);
    if (!preflight.ok) throw new Error(`Предварительная проверка не пройдена.\n${preflight.errors.join('\n')}`);
  }
  if (!project?.device || Number(project.device.w) !== 480 || Number(project.device.h) !== 480 || project.device.id !== 'amazfit_balance_2') {
    throw new Error('Direct ZIP сейчас реализован для Amazfit Balance 2 480×480. Для других устройств оставлен существующий экспорт Zeus.');
  }

  const validation = typeof validateProject === 'function' ? validateProject(project) : { errors: [], warnings: [] };
  const assetMap = computeAssetFilenames(project);
  const fontMap = computeFontFilenames(project);
  const zip = new ZipWriter();

  // Preview is always generated from the same renderer as the existing exporter.
  const previewDataUrl = await buildPreviewDataUrl(project, 324);
  const previewBytes = await directEncodeAsset(previewDataUrl, 'Preview');
  zip.addFile('app.json', directBuildAppJson(project));
  zip.addFile('app.js', DIRECT_APP_JS);
  zip.addFile('assets/Preview.png', previewBytes);

  // User image resources: decode in browser and convert to the special indexed format.
  for (const asset of project.assets || []) {
    if (!asset?.dataUrl) continue;
    const filename = assetMap[asset.id];
    if (!filename) continue;
    zip.addFile(directAssetPath(filename), await directEncodeAsset(asset.dataUrl, asset.name || filename));
  }

  // Fonts remain normal font files; index.js refers to fonts/<file> relative to assets/.
  for (const font of project.fonts || []) {
    if (!font?.dataUrl) continue;
    const safe = (font.filename || `${font.name || font.id}.ttf`).replace(/[^a-zA-Z0-9._-]+/g, '_');
    const rel = fontMap[font.id] || `fonts/${font.id}_${safe}`;
    zip.addFile(`assets/${rel}`, zeppDataUrlToBytes(font.dataUrl));
  }

  // Keep the same 29-state weather resource set already used by index-js-exporter.
  const usesWeatherIcon = [...(project.components || []), ...(project.scenes?.aod?.components || [])]
    .some(c => REGISTRY[c.defId]?.id === 'weather_icon');
  if (usesWeatherIcon) {
    const weatherFiles = WEATHER_ICON_FILES || [];
    for (let i = 0; i < weatherFiles.length; i++) {
      const name = weatherFiles[i];
      const canvas = drawWeatherIcon(i, 64);
      const dataUrl = canvas.toDataURL('image/png');
      zip.addFile(`assets/weather/${name}`, await directEncodeAsset(dataUrl, `weather ${i}`));
    }
  }

  // Reuse the existing index.js generator. No second runtime implementation is introduced.
  const indexResult = exportIndexJsDual(project, assetMap, fontMap);
  zip.addFile('watchface/index.js', indexResult.code);

  // The generated runtime addresses image/font resources relative to assets/.
  // Validate every quoted PNG/TTF/OTF path so a Direct ZIP cannot silently
  // contain an index.js reference that is absent from the archive.
  const directResourceErrors = [];
  const referenced = new Set();
  // index.js also contains WEATHER_ICON_FILES as a data array. Those names are
  // resource filenames, but not standalone runtime paths; the actual paths are
  // generated as `weather/<name>` in the IMG_LEVEL image_array below. Ignore the
  // declaration itself and validate the resolved runtime paths instead.
  const codeForResourceScan = indexResult.code.replace(
    /const\s+WEATHER_ICON_FILES\s*=\s*\[[\s\S]*?\];/m,
    ''
  );
  const refRe = /['\"]([^'\"]+\.(?:png|ttf|otf))['\"]/gi;
  let match;
  while ((match = refRe.exec(codeForResourceScan))) referenced.add(match[1].replace(/^\\+/, ''));
  for (const ref of referenced) {
    const normalized = ref.startsWith('assets/') ? ref : `assets/${ref}`;
    if (!zip.files.some(f => f.name === normalized)) {
      directResourceErrors.push(`Direct ZIP: ресурс из index.js отсутствует: ${normalized}`);
    }
  }

  const allErrors = [...(validation.errors || []), ...(indexResult.validation?.errors || []), ...directResourceErrors];
  if (allErrors.length) {
    throw new Error(`Генерация Direct ZIP остановлена: обнаружено ${allErrors.length} критических ошибок.\n${[...new Set(allErrors)].join('\n')}`);
  }
  const allWarnings = [...(validation.warnings || []), ...(indexResult.validation?.warnings || [])];
  // bytes отдаются наружу, чтобы упаковщик .zpk мог вложить device.zip
  // внутрь контейнера без повторной сборки проекта.
  const bytes = await zip.generateBytesAsync({ compress: directOptions.compress !== false });
  return {
    blob: new Blob([bytes], { type: 'application/zip' }),
    bytes,
    appJson: directBuildAppJson(project),
    validation: { errors: [...new Set(allErrors)], warnings: [...new Set(allWarnings)] },
    format: 'device.zip',
    files: zip.files.map(f => f.name)
  };
}
