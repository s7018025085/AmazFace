// src/exporter/zepp-image-encoder.js
//
// Browser-only encoder for the Balance 2 / Sasha indexed Zepp image format.
// The resulting file intentionally keeps the .png extension, although it is
// NOT a normal PNG file. It is the TGA-like indexed payload used by the device.
//
// Final indexed layout:
//   18-byte TGA header
//   46-byte image description: "SOMH" + real width (uint16 LE)
//   256 * 4 byte palette: A R G B
//   8-bit palette indices, encoded width padded to a multiple of 16
//
// Balance 2 uses fix_color=1 in Sasha's converter: RGB is premultiplied by A.

function zeppDataUrlToBytes(dataUrl) {
  const comma = String(dataUrl || '').indexOf(',');
  if (comma < 0) return new Uint8Array();
  const meta = String(dataUrl).slice(0, comma);
  const data = String(dataUrl).slice(comma + 1);
  if (/;base64/i.test(meta)) {
    const binary = atob(data);
    const out = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) out[i] = binary.charCodeAt(i);
    return out;
  }
  return new TextEncoder().encode(decodeURIComponent(data));
}

function zeppLoadImage(dataUrl) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('Не удалось декодировать изображение.'));
    img.src = dataUrl;
  });
}

function zeppCanvasRgba(dataUrl) {
  return zeppLoadImage(dataUrl).then((img) => {
    const canvas = document.createElement('canvas');
    canvas.width = img.naturalWidth || img.width;
    canvas.height = img.naturalHeight || img.height;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(img, 0, 0);
    const image = ctx.getImageData(0, 0, canvas.width, canvas.height);
    return { width: canvas.width, height: canvas.height, rgba: image.data };
  });
}

function zeppPremultiplyRgba(rgba) {
  const out = new Uint8Array(rgba.length);
  for (let i = 0; i < rgba.length; i += 4) {
    const a = rgba[i + 3];
    out[i + 3] = a;
    if (a === 0) {
      out[i] = out[i + 1] = out[i + 2] = 0;
    } else if (a === 255) {
      out[i] = rgba[i]; out[i + 1] = rgba[i + 1]; out[i + 2] = rgba[i + 2];
    } else {
      out[i] = Math.floor(rgba[i] * a / 255);
      out[i + 1] = Math.floor(rgba[i + 1] * a / 255);
      out[i + 2] = Math.floor(rgba[i + 2] * a / 255);
    }
  }
  return out;
}

// Median-cut palette generation. Sasha delegates palette selection to
// ImageMagick; this is the browser-only replacement. The byte-level container
// is exact even though palette selection will not be bit-for-bit identical to
// ImageMagick.
function zeppBuildPalette(rgba, maxColors = 256) {
  const total = rgba.length / 4;
  const maxSamples = 100000;
  const step = total > maxSamples ? Math.ceil(total / maxSamples) : 1;
  const points = [];
  for (let p = 0, i = 0; p < total; p += step, i += step) {
    const j = p * 4;
    points.push([rgba[j], rgba[j + 1], rgba[j + 2], rgba[j + 3]]);
  }
  if (!points.length) points.push([0, 0, 0, 0]);

  const boxes = [{ points, weight: points.length }];
  while (boxes.length < maxColors) {
    let best = -1;
    let bestScore = -1;
    for (let b = 0; b < boxes.length; b++) {
      const pts = boxes[b].points;
      if (pts.length < 2) continue;
      const range = [0, 0, 0, 0];
      for (const p of pts) {
        for (let c = 0; c < 4; c++) range[c] = Math.max(range[c], p[c]);
      }
      const min = [255, 255, 255, 255];
      for (const p of pts) {
        for (let c = 0; c < 4; c++) min[c] = Math.min(min[c], p[c]);
      }
      const ranges = range.map((v, c) => v - min[c]);
      const maxRange = Math.max(...ranges);
      const score = maxRange * pts.length;
      if (score > bestScore) { bestScore = score; best = b; }
    }
    if (best < 0) break;
    const box = boxes[best];
    const min = [255, 255, 255, 255], max = [0, 0, 0, 0];
    for (const p of box.points) {
      for (let c = 0; c < 4; c++) { if (p[c] < min[c]) min[c] = p[c]; if (p[c] > max[c]) max[c] = p[c]; }
    }
    let channel = 0;
    for (let c = 1; c < 4; c++) if ((max[c] - min[c]) > (max[channel] - min[channel])) channel = c;
    box.points.sort((a, b) => a[channel] - b[channel]);
    const mid = Math.floor(box.points.length / 2);
    if (mid <= 0 || mid >= box.points.length) break;
    boxes.splice(best, 1, { points: box.points.slice(0, mid) }, { points: box.points.slice(mid) });
  }

  const palette = [];
  for (const box of boxes) {
    let a = 0, r = 0, g = 0, b = 0;
    for (const p of box.points) { r += p[0]; g += p[1]; b += p[2]; a += p[3]; }
    const n = box.points.length || 1;
    palette.push([Math.round(a / n), Math.round(r / n), Math.round(g / n), Math.round(b / n)]);
  }
  while (palette.length < maxColors) palette.push([0, 0, 0, 0]);
  return palette.slice(0, maxColors);
}

function zeppNearestPaletteIndex(r, g, b, a, palette) {
  let best = 0, bestD = Infinity;
  for (let i = 0; i < palette.length; i++) {
    const p = palette[i];
    const da = a - p[0], dr = r - p[1], dg = g - p[2], db = b - p[3];
    // Alpha is deliberately weighted more strongly: transparent pixels must
    // not accidentally acquire visible RGB values from opaque palette entries.
    const d = da * da * 4 + dr * dr + dg * dg + db * db;
    if (d < bestD) { bestD = d; best = i; if (d === 0) break; }
  }
  return best;
}

function zeppQuantize(rgba, palette) {
  const out = new Uint8Array(rgba.length / 4);
  const cache = new Map();
  for (let i = 0, p = 0; i < rgba.length; i += 4, p++) {
    const r = rgba[i], g = rgba[i + 1], b = rgba[i + 2], a = rgba[i + 3];
    // 4 bits/channel cache: at most 65,536 nearest-colour searches per asset.
    const key = ((r >> 4) << 12) | ((g >> 4) << 8) | ((b >> 4) << 4) | (a >> 4);
    let idx = cache.get(key);
    if (idx === undefined) {
      idx = zeppNearestPaletteIndex(r, g, b, a, palette);
      cache.set(key, idx);
    }
    out[p] = idx;
  }
  return out;
}

function zeppBuildTgaIndexed(width, height, palette, indices) {
  const encodedWidth = Math.ceil(width / 16) * 16;
  const header = new Uint8Array(18);
  header[0] = 46;      // image ID length
  header[1] = 1;       // color map present
  header[2] = 1;       // uncompressed color-mapped image
  header[5] = 0;       // 256, little endian
  header[6] = 1;
  header[7] = 32;      // 32-bit palette entries
  header[12] = encodedWidth & 0xff;
  header[13] = (encodedWidth >>> 8) & 0xff;
  header[14] = height & 0xff;
  header[15] = (height >>> 8) & 0xff;
  header[16] = 8;      // 8-bit indices
  header[17] = 0x20;   // top-left origin

  const desc = new Uint8Array(46);
  desc[0] = 0x53; desc[1] = 0x4f; desc[2] = 0x4d; desc[3] = 0x48; // SOMH
  desc[4] = width & 0xff;
  desc[5] = (width >>> 8) & 0xff;

  const pal = new Uint8Array(256 * 4);
  for (let i = 0; i < 256; i++) {
    const p = palette[i] || [0, 0, 0, 0];
    pal[i * 4] = p[0];       // A
    pal[i * 4 + 1] = p[1];   // R
    pal[i * 4 + 2] = p[2];   // G
    pal[i * 4 + 3] = p[3];   // B
  }

  const pixels = new Uint8Array(encodedWidth * height);
  // New padding pixels are transparent index 0. If index 0 is not transparent,
  // replace it with the nearest transparent/black palette entry below.
  let transparentIndex = 0;
  let transparentDistance = Infinity;
  for (let i = 0; i < 256; i++) {
    const p = palette[i] || [0, 0, 0, 0];
    const d = p[0] * p[0] + p[1] * p[1] + p[2] * p[2] + p[3] * p[3];
    if (d < transparentDistance) { transparentDistance = d; transparentIndex = i; }
  }
  pixels.fill(transparentIndex);
  for (let y = 0; y < height; y++) {
    pixels.set(indices.subarray(y * width, (y + 1) * width), y * encodedWidth);
  }

  const out = new Uint8Array(18 + 46 + pal.length + pixels.length);
  let off = 0;
  out.set(header, off); off += header.length;
  out.set(desc, off); off += desc.length;
  out.set(pal, off); off += pal.length;
  out.set(pixels, off);
  return out;
}

async function encodeZeppImageDataUrl(dataUrl) {
  const { width, height, rgba: raw } = await zeppCanvasRgba(dataUrl);
  const rgba = zeppPremultiplyRgba(raw);
  const palette = zeppBuildPalette(rgba, 256);
  const indices = zeppQuantize(rgba, palette);
  return zeppBuildTgaIndexed(width, height, palette, indices);
}
