// src/exporter/project-exporter.js
//
// Собирает из состояния проекта полноценный проект Zepp OS (структуру,
// которую ожидает Zeus CLI / студия разработки), а не один файл index.js:
//
//   app.json
//   app.js
//   package.json
//   README.md
//   assets/<device>/...          (загруженные пользователем PNG/JPEG)
//   icon.png / Preview.png / preview_en.png (phone-side metadata resources)
//   assets/<device>/icon.png     (device-side icon resource)
//   assets/<device>/weather/*.png (29 PNG-иконок погоды)
//   watchface/index.js           (тот же код, что и в обычном экспорте)

function dataUrlToBytes(dataUrl) {
  const comma = dataUrl.indexOf(',');
  const meta = dataUrl.slice(5, comma);
  const data = dataUrl.slice(comma + 1);
  if (/;base64/.test(meta)) {
    const binary = atob(data);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return bytes;
  }
  return new TextEncoder().encode(decodeURIComponent(data));
}

function canvasToPngBytes(canvas) {
  return dataUrlToBytes(canvas.toDataURL('image/png'));
}

function drawPlaceholderIcon(size, bgColor, glyph) {
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = bgColor || '#20242c';
  ctx.fillRect(0, 0, size, size);
  ctx.fillStyle = '#ffffff';
  ctx.font = `${Math.round(size * 0.55)}px sans-serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(glyph, size / 2, size / 2 + Math.round(size * 0.04));
  return canvas;
}

function weatherGlyphFor(cond) {
  const id = normalizeWeatherIconId(cond);
  const entry = WEATHER_ICON_SET.find((w) => w.id === id);
  return (entry && entry.glyph) || '☀';
}

// Реальные PNG-ассеты погодных состояний: рисуем простые векторные пиктограммы
// на прозрачном canvas, чтобы экспорт содержал физические файлы, а не emoji/заглушки.
function drawWeatherIcon(index, size = 64) {
  const c = document.createElement('canvas'); c.width = c.height = size;
  const x = c.getContext('2d'); const s = size / 64;
  x.clearRect(0, 0, size, size); x.strokeStyle = '#ffffff'; x.fillStyle = '#ffffff';
  x.lineWidth = Math.max(2, 3*s); x.lineCap = 'round'; x.lineJoin = 'round';
  const sun = (cx, cy, r) => { x.beginPath(); x.arc(cx*s, cy*s, r*s, 0, Math.PI*2); x.stroke(); for(let a=0;a<8;a++){const t=a*Math.PI/4; x.beginPath(); x.moveTo((cx+Math.cos(t)*(r+6))*s,(cy+Math.sin(t)*(r+6))*s); x.lineTo((cx+Math.cos(t)*(r+11))*s,(cy+Math.sin(t)*(r+11))*s); x.stroke();} };
  const cloud = (cx=34, cy=38) => { x.beginPath(); x.arc((cx-10)*s,cy*s,9*s,Math.PI,0); x.arc(cx*s,(cy-5)*s,12*s,Math.PI,0); x.arc((cx+11)*s,cy*s,8*s,Math.PI,0); x.lineTo((cx+19)*s,(cy+9)*s); x.lineTo((cx-19)*s,(cy+9)*s); x.closePath(); x.fill(); };
  const rain = (n=3) => { for(let i=0;i<n;i++){const xx=(25+i*8); x.beginPath(); x.moveTo(xx*s,50*s); x.lineTo((xx-3)*s,59*s); x.stroke();} };
  const snow = (n=3) => { for(let i=0;i<n;i++){const xx=(25+i*8), yy=50; x.beginPath(); x.arc(xx*s,yy*s,2.2*s,0,Math.PI*2); x.fill();} };
  const moon = (cx=32, cy=30, r=12) => { x.save(); x.beginPath(); x.arc(cx*s,cy*s,r*s,0,Math.PI*2); x.arc((cx+r*0.55)*s,(cy-r*0.45)*s,r*s,0,Math.PI*2,true); x.fill(); x.restore(); };
  if (index === 3) sun(32,32,10);
  else if (index === 28) moon(32,32,12);
  else if (index === 26) { moon(22,26,9); cloud(37,40); }
  else if (index === 27) { moon(22,24,8); cloud(37,38); rain(3); }
  else if ([0,4].includes(index)) cloud();
  else if ([1,5,7,10,18,21,24].includes(index)) { cloud(); rain(index===10||index===18||index===21||index===24?4:3); }
  else if ([2,6,8,9,16].includes(index)) { cloud(37,39); snow(3); }
  else if ([11,22,23,17,30,31].includes(index)) { x.beginPath(); x.arc(32*s,32*s,18*s,0,Math.PI*2); x.stroke(); x.beginPath(); x.moveTo(16*s,42*s); x.quadraticCurveTo(32*s,24*s,48*s,42*s); x.stroke(); }
  else if ([13,14,25].includes(index)) { for(let i=0;i<4;i++){x.beginPath();x.moveTo(10*s,(22+i*8)*s);x.lineTo(54*s,(22+i*8)*s);x.stroke();} }
  else if ([15,20].includes(index)) { cloud(); x.beginPath();x.moveTo(34*s,44*s);x.lineTo(28*s,54*s);x.lineTo(34*s,51*s);x.lineTo(31*s,60*s);x.stroke(); }
  else if (index === 19) { cloud(); x.beginPath();x.arc(45*s,52*s,4*s,0,Math.PI*2);x.stroke(); }
  else if (index === 12) { cloud(); rain(2); snow(2); }
  else { sun(32,32,10); }
  return c;
}

// Коды разрешений взяты из docs.zepp.com (раздел sensor, блок "permission code"
// у каждого датчика). У датчика Weather такого блока нет — отдельного разрешения
// он не требует, поэтому для погоды ничего не добавляется. Учитывается и
// источник данных универсального TEXT (props.data_source), а не только пресеты.
const PERMISSION_BY_SOURCE = {
  HEART: 'data:user.hd.heart_rate',
  STEP: 'data:user.hd.step',
  CALORIE: 'data:user.hd.calorie',
  DISTANCE: 'data:user.hd.distance',
  ALTITUDE: 'device:os.barometer',
  AIR_PRESSURE: 'device:os.barometer',
};

function computePermissions(project) {
  const perms = new Set();
  for (const comp of project.components) {
    const def = REGISTRY[comp.defId];
    if (!def) continue;
    const source = (comp.props && comp.props.data_source) || def.dataSource;
    const perm = PERMISSION_BY_SOURCE[source];
    if (perm) perms.add(perm);
  }
  return [...perms];
}


function loadPreviewImage(dataUrl) {
  return new Promise((resolve) => {
    if (!dataUrl) return resolve(null);
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => resolve(null);
    img.src = dataUrl;
  });
}

function previewTextForComponent(comp, def) {
  const source = comp.props?.data_source || def.dataSource || 'NONE';
  if (source === 'TIME' || source === 'TIME_POINTER_HOUR' || source === 'TIME_POINTER_MINUTE' || source === 'TIME_POINTER_SECOND') return '10:10';
  if (source === 'AMPM') return 'AM';
  if (source === 'DATE') return '17.09';
  if (source === 'WEEKDAY') return 'Thu';
  if (source === 'HOUR') return '10';
  if (source === 'MINUTE') return '10';
  if (source === 'SECOND') return '00';
  if (source === 'DAY') return '17';
  if (source === 'MONTH') return '09';
  if (source === 'YEAR') return '2026';
  if (source === 'BATTERY') return '85';
  if (source === 'HEART') return '72';
  if (source === 'STEP') return '8452';
  if (source === 'CALORIE') return '340';
  if (source === 'DISTANCE') return '4.2 km';
  if (source === 'ALTITUDE') return '185 м';
  if (source === 'AIR_PRESSURE') return '1013 hPa';
  const nativePreview = { STEP_TARGET:'10000', CAL_TARGET:'500', PAI_DAILY:'42', PAI_WEEKLY:'180', STAND:'8 ч', STAND_TARGET:'12 ч', HUMIDITY:'42%', UVI:'4', AQI:'26', FAT_BURNING:'35 мин', FAT_BURNING_TARGET:'60 мин', SUN_CURRENT:'02:14', SUN_RISE:'06:30', SUN_SET:'19:42', WIND:'4', STRESS:'32', SPO2:'98%', BODY_TEMP:'36.5 °C', FLOOR:'12', ALARM_CLOCK:'07:00', COUNT_DOWN:'05:00', STOP_WATCH:'12:34', SLEEP:'07:42', TRAINING_LOAD:'68', VO2MAX:'42', RECOVERY_TIME:'18', MONTH_RUN_TIMES:'8', MONTH_RUN_DISTANCE:'54.2', READINESS:'82' };
  if (nativePreview[source]) return nativePreview[source];
  if (source === 'WEATHER_TEMP') return '24°';
  return String(comp.props?.text ?? def.name ?? '');
}


async function buildPreviewDataUrl(project, size = 324) {
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = size;
  await WatchfacePreviewRenderer.draw(project, canvas, { size, previewMode: true });
  return canvas.toDataURL('image/png');
}

function buildAppJson(project) {
  const device = project.device;
  const app = project.app || {};
  const apiVersion = `${project.apiLevel}.0`;
  return JSON.stringify({
    configVersion: 'v3',
    app: {
      appId: Number(app.appId) || 10001,
      appName: project.meta.name,
      appType: 'watchface',
      version: { code: Number(app.versionCode) || 1, name: app.versionName || '1.0.0' },
      icon: 'Preview.png',
      cover: ['Preview.png'],
      vender: app.vendor || 'designer',
      description: `${project.meta.name} — экспортировано из Watch Face Designer`,
    },
    permissions: computePermissions(project),
    runtime: { apiVersion: { compatible: apiVersion, target: apiVersion, minVersion: apiVersion } },
    targets: {
      [device.targetKey]: {
        module: { watchface: { path: 'watchface/index', main: 1, editable: 0, lockscreen: 1, photoscreen: 0 } },
        platforms: (device.deviceSources || []).map((id) => ({ deviceSource: id })),
        designWidth: device.designWidth || device.w,
      },
    },
    i18n: { 'en-US': { appName: project.meta.name } },
    defaultLanguage: 'en-US',
    debug: true,
  }, null, 2);
}

function buildPackageJson(project) {
  // npm-имя пакета обязано быть ASCII и в нижнем регистре: транслитерируем
  // название проекта, а не режем его до 'asset' при кириллице.
  const slug = latinSlug(project.meta.name, 'watchface').toLowerCase();
  return JSON.stringify({
    name: slug,
    version: '1.0.0',
    private: true,
    description: `${project.meta.name} — watch face, экспортировано из Watch Face Designer`,
  }, null, 2);
}

const APP_JS_TEMPLATE = `App({\n  globalData: {},\n})\n`;

function buildReadme(project) {
  return `# ${project.meta.name}\n\n` +
    `Проект циферблата Zepp OS (API 3.0), сгенерирован в Watch Face Designer.\n` +
    `Код watchface/index.js использует современный ESM-стиль API 3.0:\n` +
    `import из '@zos/ui' / '@zos/sensor' / '@zos/timer' и обёртку WatchFace({...}).\n\n` +
    `## Сборка (ВАЖНО: не просто открыть эту папку как есть)\n\n` +
    `Экспорт из Designer содержит только "полезную нагрузку" (app.json, app.js,\n` +
    `watchface/index.js, assets/) — но НЕ служебные файлы сборщика Zeus CLI,\n` +
    `которые создаёт \`zeus create\`. Поэтому:\n\n` +
    `1. Установите Zeus CLI: \`npm install -g @zeppos/zeus-cli\` (см. docs.zepp.com).\n` +
    `2. В отдельной пустой папке выполните \`zeus create\` и выберите: тип — Watchface,\n` +
    `   API — 3.0, устройство — то же, что выбрано в Designer (${project.device.name}).\n` +
    `   Это создаст полноценный скаффолд со всеми служебными файлами сборщика.\n` +
    `3. Скопируйте поверх шаблона файлы из этого архива: \`app.json\`, \`app.js\`,\n` +
    `   \`watchface/index.js\` и папку \`assets/\`. Служебные файлы самого шаблона\n` +
    `   Zeus (которые Designer не создаёт) не трогайте.\n` +
    `4. Выполните \`npm install\` в корне свежесозданного проекта.\n` +
    `5. Запустите \`zeus dev\` при включённом Device Simulator.\n\n` +
    `## На что обратить внимание\n\n` +
    `- Свойства компонентов, помеченные в Designer значком ⚠ (unverified), стоит сверить с\n` +
    `  официальной документацией docs.zepp.com перед публикацией.\n` +
    `- \`assets/.../icon.png\` и \`assets/.../weather/*.png\` — автосгенерированные заглушки.\n` +
    `  Замените их своими изображениями перед публикацией.\n` +
    `- Список \`permissions\` в app.json подобран автоматически по использованным источникам\n` +
    `  данных на циферблате — проверьте его вручную.\n` +
    `- Погода использует нативные hmUI.data_type.WEATHER_CURRENT/WEATHER_LOW/WEATHER_HIGH и WEATHER_CURRENT для иконки.\n` +
    `  (поля high / low — прогноз на сегодня в °C, index — код состояния 0..28).\n` +
    `  «Текущей» температуры этот API не отдаёт; что показывать — настраивается\n` +
    `  в свойствах компонента. Данные появляются только после синхронизации\n` +
    `  погоды с телефоном: без неё виджеты покажут '--' и стартовую иконку.\n` +
    `- Калории — new Calorie().getCurrent(), дистанция — new Distance().getCurrent()\n` +
    `  (отдельные датчики @zos/sensor, а не методы Step).\n` +
    `- В архиве лежат aod-config.json и AOD_INTEGRATION.md. Runtime AOD также встраивается непосредственно в watchface/index.js; режим определяется через @zos/app.getScene() / SCENE_AOD, а AOD-виджеты получают hmUI.show_level.ONLY_AOD.\n` +
     `- Данные пульса/шагов/батареи/погоды подключены через реальные сенсоры\n` +
    `  '@zos/sensor'; если сенсор недоступен (часть симуляторов), виджет покажет '--'.\n` +
    `  Проверьте, что \`appId\` в app.json заменён на свой перед публикацией (сейчас заглушка).\n`;
}

/**
 * Экспортируемая карта тап-зон.
 *
 * В index.js зоны превращаются в реальные прозрачные BUTTON, а этот JSON
 * сохраняет исходную структуру редактора для диагностики/повторного импорта.
 * Координаты child-zone остаются локальными; absoluteRect показывает итоговую
 * область на экране 480×480 и потому удобен для проверки готового проекта.
 */

function diagnoseGeneratedWatchfaceCode(code) {
  const diagnostics = [];
  const lines = String(code || '').split(/\r?\n/);
  const add = (severity, codeName, message, line, detail='') => diagnostics.push({ severity, code: codeName, message, line: Number(line) || null, detail });

  const declarations = collectLexicalDeclarations(code);
  const byScope = new Map();
  for (const d of declarations) {
    const key = `${d.scope}::${d.name}`;
    if (!byScope.has(key)) byScope.set(key, []);
    byScope.get(key).push(d);
  }
  for (const items of byScope.values()) {
    if (items.length <= 1) continue;
    const where = items.map(d => d.line);
    add('error', 'DUPLICATE_DECLARATION', `Переменная «${items[0].name}» объявлена ${items.length} раз в одной области видимости.`, where[1], `Найдено объявления: строки ${where.join(', ')}. Генератор должен разделять области видимости или использовать уникальные имена.`);
  }

  try {
    const parseable = String(code || '').replace(/^\s*import\b[^\n]*$/gm, '');
    new Function(parseable);
  } catch (err) {
    const msg = String(err?.message || err);
    const m = msg.match(/Identifier ['"]([^'"]+)['"] has already been declared/i);
    const lm = msg.match(/(?:line|строк[ае])\s*(\d+)/i);
    if (m) {
      const where = declarations.filter(d => d.name === m[1]).map(d => d.line);
      add('error', 'SYNTAX_DUPLICATE', `Синтаксическая ошибка: переменная «${m[1]}» объявлена повторно.`, lm ? lm[1] : where[1], `Объявления: ${where.join(', ') || 'не найдены'}. Генератор должен исправить конфликт автоматически.`);
    } else {
      add('error', 'SYNTAX_ERROR', `Синтаксическая ошибка в watchface/index.js: ${msg}.`, lm ? lm[1] : null, 'Zeus не должен запускаться, пока эта ошибка не устранена.');
    }
  }

  const declared = new Set(declarations.map(d => d.name));
  lines.forEach((line, i) => {
    const call = line.match(/\b([A-Za-z_$][A-Za-z0-9_$]*)\.(set[A-Z][A-Za-z0-9_]*|setProperty|setText|setAlpha)\s*\(/);
    if (call && !declared.has(call[1]) && !['console','self','this'].includes(call[1])) {
      add('error', 'UNDECLARED_WIDGET', `Объект «${call[1]}» используется методом ${call[2]}(), но переменная не объявлена.`, i + 1, 'На часах это приводит к ReferenceError и останавливает build() в этой точке.');
    }
  });

  lines.forEach((line, i) => {
    if (/^\s*createWidget\s*\(/.test(line)) {
      const next = lines[i + 1] || '';
      if (/\.set[A-Z]|\.setProperty|\.setText|\.setAlpha/.test(next)) {
        add('error', 'LOST_WIDGET_REFERENCE', 'createWidget() создал виджет без сохранения результата, а следующая строка пытается изменить этот виджет.', i + 1, 'Генератор должен создавать `const имя = createWidget(...)`, затем вызывать методы у `имя`.');
      }
    }
  });

  const normalCount = (String(code).match(/show_level:\s*show_level\.ONLY_NORMAL/g) || []).length;
  const aodCount = (String(code).match(/show_level:\s*show_level\.(?:ONAL_AOD|ONLY_AOD)/g) || []).length;
  if (normalCount === 0) add('warning', 'NO_NORMAL_LEVEL', 'В итоговом index.js не найден show_level.ONLY_NORMAL.', null, 'Если Normal должен содержать виджеты, они могут быть невидимы или экспортированы с неверным уровнем отображения.');
  if (aodCount === 0) add('warning', 'NO_AOD_LEVEL', 'В итоговом index.js не найден show_level.ONAL_AOD/ONLY_AOD.', null, 'Если AOD должен быть кастомным, его виджеты не получат AOD-уровень.');
  if (/hmUI\.show_level\./.test(code)) add('error', 'LEGACY_AOD_REFERENCE', 'Генератор оставил `hmUI.show_level.*`, хотя современный экспорт использует импортированный `show_level.*`.', null, 'Это может дать ReferenceError в новом runtime.');
  return diagnostics;
}

function validateGeneratedWatchfaceCode(code) {
  return diagnoseGeneratedWatchfaceCode(code)
    .filter(d => d.severity === 'error')
    .map(d => `${d.message}${d.line ? ` Строка ${d.line}.` : ''}${d.detail ? ` ${d.detail}` : ''}`);
}

function buildTapZonesManifest(project) {
  const scenes = {
    normal: project.scenes?.normal || (project.mode === 'normal'
      ? { components: project.components || [] }
      : { components: [] }),
    aod: project.scenes?.aod || (project.mode === 'aod'
      ? { components: project.components || [] }
      : { components: [] })
  };

  const out = {
    version: 2,
    coordinateSystem: '480x480-device-space',
    childCoordinates: 'local-to-parent-editor-box',
    runtime: 'watchface/index.js -> transparent hmUI.widget.BUTTON',
    overlapPolicy: 'last-created-zone-wins (topmost component layer)',
    scenes: {},
    overlaps: {}
  };

  for (const [sceneName, scene] of Object.entries(scenes)) {
    out.scenes[sceneName] = [];
    for (const comp of (scene.components || [])) {
      const def = REGISTRY[comp.defId];
      if (!Array.isArray(comp.tapZones) || !comp.tapZones.length) continue;

      // Keep this calculation in sync with index-js-exporter.js.
      let parent = {
        x: Number(comp.x) || 0, y: Number(comp.y) || 0,
        w: Number(comp.w) || 10, h: Number(comp.h) || 10
      };
      if (def && (def.widgetId === 'CIRCLE' || def.widgetId === 'STROKE_CIRCLE')) {
        const radius = Math.max(1, Number(comp.props?.radius) || parent.w / 2);
        const cx = Number(comp.props?.center_x ?? (Number(comp.x) + radius));
        const cy = Number(comp.props?.center_y ?? (Number(comp.y) + radius));
        parent = { x: Math.max(0, Math.round(cx - radius)), y: Math.max(0, Math.round(cy - radius)),
          w: Math.round(radius * 2), h: Math.round(radius * 2) };
      }

      for (const zone of comp.tapZones) {
        const x = Number(zone.x) || 0, y = Number(zone.y) || 0;
        const w = Number(zone.w) || 0, h = Number(zone.h) || 0;
        out.scenes[sceneName].push({
          id: zone.id,
          name: zone.name || zone.id,
          parentId: comp.id,
          parentName: comp.name || comp.id,
          localRect: { x, y, w, h },
          absoluteRect: {
            x: Math.max(0, Math.round(parent.x + x)),
            y: Math.max(0, Math.round(parent.y + y)),
            w: Math.max(1, Math.round(w)),
            h: Math.max(1, Math.round(h))
          },
          visible: zone.visible !== false,
          locked: !!zone.locked,
          action: Object.assign({ tap_action: 'NONE' }, zone.props || {})
        });
      }
    }
  }
  for (const [sceneName, zones] of Object.entries(out.scenes)) {
    const overlaps = [];
    for (let i = 0; i < zones.length; i++) {
      const a = zones[i].absoluteRect;
      for (let j = i + 1; j < zones.length; j++) {
        const b = zones[j].absoluteRect;
        const ix = Math.max(0, Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x));
        const iy = Math.max(0, Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y));
        if (ix > 0 && iy > 0) overlaps.push({ first: zones[i].id, second: zones[j].id, overlap: { x: Math.max(a.x,b.x), y: Math.max(a.y,b.y), w: ix, h: iy }, priority: zones[j].id });
      }
    }
    out.overlaps[sceneName] = overlaps;
  }
  return out;
}

function runDesignerPreflight(project) {
  const errors = [];
  const warnings = [];
  const diagnostics = [];
  const p = project || {};
  const push = (severity, code, message, detail='', scene='') => {
    const d = { severity, code, message, detail, scene };
    diagnostics.push(d);
    (severity === 'error' ? errors : warnings).push(`${message}${scene ? ` [${scene}]` : ''}${detail ? ` ${detail}` : ''}`);
  };

  if (!p.meta?.name) push('warning', 'PROJECT_NAME', 'У проекта не задано название.', 'Будет использовано имя по умолчанию.');
  if (p.device?.id !== 'amazfit_balance_2') push('warning', 'DEVICE', `Текущее устройство: ${p.device?.id || 'не задано'}.`, 'Часть проверок ниже рассчитана на Amazfit Balance 2 480×480.');
  if (Number(p.device?.w) !== 480 || Number(p.device?.h) !== 480) push('error', 'DEVICE_SIZE', 'Размер устройства не 480×480.', `Получено ${p.device?.w}×${p.device?.h}.`);
  if (!p.device?.targetKey) push('error', 'TARGET_KEY', 'Не задан targetKey устройства.', 'Zeus не сможет однозначно определить папку ресурсов.');
  if (!Array.isArray(p.device?.deviceSources) || !p.device.deviceSources.length) push('error', 'DEVICE_SOURCES', 'Не заданы deviceSource.', 'В app.json получится пустой список платформ.');
  if (!p.apiLevel) push('error', 'API_LEVEL', 'Не задан уровень API проекта.');

  const assets = new Map((p.assets || []).filter(a => a?.id).map(a => [a.id, a]));
  const fonts = new Map((p.fonts || []).filter(f => f?.id).map(f => [f.id, f]));
  if (!Array.isArray(p.assets)) push('error', 'ASSETS_TYPE', 'Поле assets не является массивом.');
  if (!Array.isArray(p.fonts)) push('error', 'FONTS_TYPE', 'Поле fonts не является массивом.');

  const scenes = {
    normal: p.scenes?.normal || { components: p.mode === 'normal' ? (p.components || []) : [], background: p.background },
    aod: p.scenes?.aod || { components: p.mode === 'aod' ? (p.components || []) : [], background: null },
  };
  const allComponents = [];
  for (const [sceneName, scene] of Object.entries(scenes)) {
    const comps = Array.isArray(scene?.components) ? scene.components : [];
    for (const comp of comps) {
      allComponents.push({ sceneName, comp });
      const def = REGISTRY[comp.defId];
      if (!def) { push('error', 'UNKNOWN_COMPONENT', `Неизвестный компонент «${comp.defId || '(без defId)'}».`, 'Компонент не может быть надёжно экспортирован.', sceneName); continue; }
      for (const key of ['x','y','w','h']) {
        if (!Number.isFinite(Number(comp[key]))) push('error', 'GEOMETRY', `Компонент «${comp.id || comp.defId}» имеет некорректное поле ${key}.`, `Значение: ${comp[key]}`, sceneName);
      }
      if (Number(comp.w) <= 0 || Number(comp.h) <= 0) push('error', 'GEOMETRY_SIZE', `Компонент «${comp.id || comp.defId}» имеет нулевой или отрицательный размер.`, `w=${comp.w}, h=${comp.h}`, sceneName);
      const props = comp.props || {};
      if (props.font && !fonts.has(props.font)) push('error', 'MISSING_FONT', `Компонент «${comp.id || comp.defId}» ссылается на отсутствующий шрифт «${props.font}».`, 'Добавьте шрифт или выберите существующий.', sceneName);
      // weather_icon does NOT reference a user asset. Its props.src is a logical
      // weather-condition id (for example `snowstorm`), while the exporter
      // generates the complete 29-file weather icon set into assets/.../weather/.
      // Treating that id as a normal asset was a false-positive MISSING_IMAGE.
      const isBuiltInWeatherIcon = def.id === 'weather_icon' || comp.defId === 'weather_icon';
      if (def.widgetId === 'IMG' && props.src && !assets.has(props.src) && !isBuiltInWeatherIcon && !String(props.src).startsWith('weather')) {
        push('error', 'MISSING_IMAGE', `Компонент «${comp.id || comp.defId}» ссылается на отсутствующий ресурс «${props.src}».`, 'PNG не будет найден в экспортированном архиве.', sceneName);
      }
      if (def.widgetId === 'TIME_POINTER' && props.path && !assets.has(props.path)) push('error', 'MISSING_POINTER', `Стрелка «${comp.id || comp.defId}» ссылается на отсутствующий PNG «${props.path}».`, 'Проверьте ресурс стрелки.', sceneName);
      if (sceneName === 'aod' && comp.defId === 'time_pointer_second') push('warning', 'AOD_SECOND_HAND', `Секундная стрелка «${comp.id || comp.defId}» находится в AOD.`, 'Для AOD она будет автоматически исключена из runtime-экспорта для снижения нагрузки.', sceneName);
    }
    if (scene?.background?.imageAssetId && !assets.has(scene.background.imageAssetId)) push('error', 'MISSING_BACKGROUND', `Фон сцены ссылается на отсутствующий ресурс «${scene.background.imageAssetId}».`, 'Экспорт остановлен, чтобы не получить пустой фон.', sceneName);
    const alpha = Number(scene?.background?.alpha ?? 100);
    if (!Number.isFinite(alpha) || alpha < 0 || alpha > 100) push('error', 'BACKGROUND_ALPHA', 'Прозрачность фона должна быть от 0 до 100%.', `Получено ${scene?.background?.alpha}.`, sceneName);
  }

  const normalComponents = scenes.normal.components || [];
  const aodComponents = (scenes.aod.components || []).filter(c => c.defId !== 'time_pointer_second');
  if (aodComponents.length === 0) push('warning', 'EMPTY_AOD', 'AOD-сцена пустая.', 'Обычный циферблат будет экспортирован, но кастомных AOD-виджетов не будет.');
  if (normalComponents.length === 0) push('warning', 'EMPTY_NORMAL', 'Normal-сцена пустая.', 'На обычном экране может остаться только фон.');

  // Build the exact runtime code used by the exporters and validate it before creating any ZIP.
  try {
    const assetMap = computeAssetFilenames(p);
    const fontMap = computeFontFilenames(p);
    const result = exportIndexJsDual(p, assetMap, fontMap);
    const codeDiags = diagnoseGeneratedWatchfaceCode(result.code);
    for (const d of codeDiags) {
      diagnostics.push(Object.assign({ stage: 'generated-index.js' }, d));
      const text = `${d.message}${d.line ? ` Строка ${d.line}.` : ''}${d.detail ? ` ${d.detail}` : ''}`;
      (d.severity === 'error' ? errors : warnings).push(text);
    }

    const appJson = JSON.parse(buildAppJson(p));
    const target = appJson.targets?.[p.device?.targetKey];
    if (!target) push('error', 'APP_TARGET', 'app.json не содержит target текущего устройства.', `targetKey=${p.device?.targetKey || '(пусто)'}`);
    if (target && Number(target.designWidth) !== 480) push('error', 'APP_WIDTH', 'В app.json designWidth не равен 480.', `Получено ${target.designWidth}.`);
    if (target && target.module?.watchface?.lockscreen !== 1) push('error', 'AOD_LOCKSCREEN', 'В app.json lockscreen не включён.', 'Без lockscreen=1 устройство может не предоставлять AOD для циферблата.');
    const runtime = appJson.runtime?.apiVersion;
    if (!runtime?.compatible || !runtime?.target || !runtime?.minVersion) push('error', 'APP_API', 'В app.json неполно задан runtime.apiVersion.', 'compatible/target/minVersion должны быть согласованы.');
    if (runtime && !(runtime.compatible === runtime.target && runtime.target === runtime.minVersion)) push('warning', 'API_MISMATCH', 'compatible/target/minVersion в app.json различаются.', JSON.stringify(runtime));

    const normalLevelCount = (result.code.match(/show_level:\s*show_level\.ONLY_NORMAL/g) || []).length;
    const aodLevelCount = (result.code.match(/show_level:\s*show_level\.(?:ONAL_AOD|ONLY_AOD)/g) || []).length;
    if (normalComponents.length && normalLevelCount === 0) push('error', 'NORMAL_VISIBILITY', 'Normal-компоненты есть, но в generated index.js нет show_level.ONLY_NORMAL.', 'Это приведёт к неправильной видимости виджетов.');
    if (aodComponents.length && aodLevelCount === 0) push('error', 'AOD_VISIBILITY', 'AOD-компоненты есть, но в generated index.js нет AOD show_level.', 'AOD-виджеты могут не появиться на часах.');
    if (/hmUI\.show_level\./.test(result.code)) push('error', 'HMUI_LEVEL', 'В generated index.js осталась ссылка hmUI.show_level.*.', 'Современный генератор использует импортированный show_level.*.');

    // Every declared asset must have bytes and a usable data URL.
    for (const [id, asset] of assets) {
      if (!asset.dataUrl) push('error', 'EMPTY_ASSET', `Ресурс «${asset.name || id}» не содержит dataUrl.`, 'Файл не попадёт в архив корректно.');
      else if (!/^data:image\//i.test(asset.dataUrl)) push('warning', 'ASSET_FORMAT', `Ресурс «${asset.name || id}» имеет неожиданный data URL.`, 'Ожидается PNG/JPEG/WebP data URL.');
    }
  } catch (e) {
    push('error', 'PREFLIGHT_CRASH', 'Внутренняя ошибка предварительной проверки генератора.', e?.stack || e?.message || String(e));
  }

  return { ok: errors.length === 0, errors: [...new Set(errors)], warnings: [...new Set(warnings)], diagnostics };
}

/**
 * Собирает полный проект и возвращает Blob (.zip), готовый к скачиванию.
 */
async function exportFullProject(project) {
  const preflight = runDesignerPreflight(project);
  if (!preflight.ok) throw new Error(`Предварительная проверка не пройдена.
${preflight.errors.join('\n')}`);
  const assetMap = computeAssetFilenames(project);
  const zip = new ZipWriter();
  const device = project.device;
  const assetsRoot = `assets/${device.targetKey}`;

  const previewDataUrl = await buildPreviewDataUrl(project, 324);
  const previewBytes = dataUrlToBytes(previewDataUrl);
  zip.addFile('app.json', buildAppJson(project));
  // Keep a root copy for the exported project and a target asset copy for Zeus.
  // Zeus resolves target resources from assets/<target>; the cover metadata
  // therefore points to Preview.png below.
  zip.addFile('Preview.png', previewBytes);
  zip.addFile('preview_en.png', previewBytes);
  // Keep both names in the target asset directory for compatibility with
  // Zeus/Zepp tooling versions; Preview.png is the legacy name used by v2.
  // The phone-side package is produced by Zeus; it must retain the root preview/icon
  // resources referenced by app.json rather than relying only on encoded device assets.
  zip.addFile(`${assetsRoot}/Preview.png`, previewBytes);
  zip.addFile(`${assetsRoot}/preview_en.png`, previewBytes);
  zip.addFile('app.js', APP_JS_TEMPLATE);
  zip.addFile('package.json', buildPackageJson(project));
  zip.addFile('README.md', buildReadme(project));
  zip.addFile('aod-config.json', JSON.stringify(buildAodConfig(project), null, 2));
  zip.addFile('AOD_INTEGRATION.md', `# AOD Studio runtime export\n\nThis project exports Normal and AOD together into watchface/index.js. Both sets of widgets are created in the same WatchFace build; Normal uses show_level.ONLY_NORMAL and AOD uses show_level.ONLY_AOD. app.json enables watchface lockscreen/AOD support. The editor configuration aod-config.json is also included for round-trip editing.\n\nImportant: AOD support depends on the target Zepp OS firmware/device. The exporter does not claim unsupported widget APIs.\n`);

  for (const a of project.assets || []) {
    const filename = assetMap[a.id];
    zip.addFile(`${assetsRoot}/${filename}`, dataUrlToBytes(a.dataUrl));
  }

  // Встроенные шрифты — физические файлы внутри проекта. Каждый выбранный
  // TEXT получает путь assets/<target>/fonts/<filename> в index.js.
  const fontMap = {};
  for (const f of project.fonts || []) {
    const safe = (f.filename || `${f.name || f.id}.ttf`).replace(/[^a-zA-Z0-9._-]+/g, '_');
    const filename = `${assetsRoot}/fonts/${f.id}_${safe}`;
    fontMap[f.id] = `fonts/${f.id}_${safe}`;
    zip.addFile(filename, dataUrlToBytes(f.dataUrl));
  }

  // Legacy icon paths are kept for compatibility, but use the same real watchface preview.
  // app.json explicitly points to Preview.png, which is the primary watchface preview.
  zip.addFile('icon.png', previewBytes);
  zip.addFile(`${assetsRoot}/icon.png`, previewBytes);

  const exportNormalComponents = Array.isArray(project.scenes?.normal?.components)
    ? project.scenes.normal.components
    : (project.mode === 'normal' ? project.components : []);
  const exportAodComponents = Array.isArray(project.scenes?.aod?.components) ? project.scenes.aod.components : [];
  const exportComponents = [...exportNormalComponents, ...exportAodComponents];
  const usesWeatherIcon = exportComponents.some((comp) => {
    const def = REGISTRY[comp.defId];
    return def && def.id === 'weather_icon';
  });
  if (usesWeatherIcon) {
    const weatherFiles = [
      '0_cloudy.png','1_showers.png','2_snow_showers.png','3_sunny.png','4_overcast.png',
      '5_light_rain.png','6_light_snow.png','7_moderate_rain.png','8_moderate_snow.png','9_heavy_snow.png',
      '10_heavy_rain.png','11_sandstorm.png','12_rain_snow.png','13_fog.png','14_hazy.png',
      '15_thunderstorm.png','16_snowstorm.png','17_floating_dust.png','18_very_heavy_rainstorm.png',
      '19_rain_hail.png','20_thunderstorm_hail.png','21_heavy_rainstorm.png','22_dust.png','23_heavy_sandstorm.png',
      '24_rainstorm.png','25_unknown.png','26_cloudy_night.png','27_showers_night.png','28_sunny_night.png'
    ];
    weatherFiles.forEach((name, index) => zip.addFile(`${assetsRoot}/weather/${name}`, canvasToPngBytes(drawWeatherIcon(index))));
  }

  const { code, validation } = exportIndexJsDual(project, assetMap, fontMap);
  const generatedErrors = validateGeneratedWatchfaceCode(code);
  validation.errors.push(...generatedErrors);
  validation.warnings.push(...preflight.warnings);
  // Never produce a ZIP containing known-invalid generated code. The Designer
  // must stop before Zeus/device installation rather than asking the user to
  // knowingly export a broken watchface.
  if (validation.errors.length) {
    throw new Error(`Генерация остановлена: Designer обнаружил ${validation.errors.length} критических ошибок в итоговом watchface/index.js.\n${[...new Set(validation.errors)].join('\n')}`);
  }
  zip.addFile('watchface/index.js', code);

  // Also ship the complete editor-side tap-zone map. Runtime uses index.js;
  // this file makes every child zone explicitly present in the exported
  // project and preserves local geometry/action settings for inspection or
  // future re-import.
  zip.addFile('tap-zones.json', JSON.stringify(buildTapZonesManifest(project), null, 2));

  return { blob: zip.generate(), validation };
}
