// src/exporter/md5.js
//
// Чистая реализация MD5 (RFC 1321). Нужна только для одного поля:
// manifest.json внутри .zab-контейнера требует md5 от байтов вложенного
// .zpk. Ни один Web Crypto API MD5 не даёт браузер — алгоритм устарел
// и подсчитывается только вручную.

function md5RotateLeft(x, c) {
  return (x << c) | (x >>> (32 - c));
}

function md5Add(a, b) {
  return (a + b) | 0;
}

const MD5_K = new Int32Array(64);
for (let i = 0; i < 64; i++) {
  MD5_K[i] = Math.floor(Math.abs(Math.sin(i + 1)) * 4294967296) | 0;
}

const MD5_S = [
  7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22,
  5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20,
  4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23,
  6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21
];

/**
 * @param {Uint8Array} bytes
 * @returns {string} md5 в hex, строчными буквами
 */
function md5Hex(bytes) {
  const msgLenBits = bytes.length * 8;
  const withOne = bytes.length + 1;
  const padded = Math.ceil((withOne + 8) / 64) * 64;
  const buf = new Uint8Array(padded);
  buf.set(bytes);
  buf[bytes.length] = 0x80;
  // Длина сообщения в битах, little-endian, 64 бита (используем нижние 32).
  const view = new DataView(buf.buffer);
  view.setUint32(padded - 8, msgLenBits >>> 0, true);
  view.setUint32(padded - 4, Math.floor(msgLenBits / 4294967296), true);

  let a0 = 0x67452301, b0 = 0xefcdab89, c0 = 0x98badcfe, d0 = 0x10325476;

  for (let chunk = 0; chunk < padded; chunk += 64) {
    const m = new Int32Array(16);
    for (let i = 0; i < 16; i++) m[i] = view.getInt32(chunk + i * 4, true);

    let a = a0, b = b0, c = c0, d = d0;
    for (let i = 0; i < 64; i++) {
      let f, g;
      if (i < 16) { f = (b & c) | (~b & d); g = i; }
      else if (i < 32) { f = (d & b) | (~d & c); g = (5 * i + 1) % 16; }
      else if (i < 48) { f = b ^ c ^ d; g = (3 * i + 5) % 16; }
      else { f = c ^ (b | ~d); g = (7 * i) % 16; }

      const tmp = d;
      d = c;
      c = b;
      const sum = md5Add(md5Add(md5Add(a, f), MD5_K[i]), m[g]);
      b = md5Add(b, md5RotateLeft(sum, MD5_S[i]));
      a = tmp;
    }

    a0 = md5Add(a0, a);
    b0 = md5Add(b0, b);
    c0 = md5Add(c0, c);
    d0 = md5Add(d0, d);
  }

  const out = new Uint8Array(16);
  const outView = new DataView(out.buffer);
  outView.setInt32(0, a0, true);
  outView.setInt32(4, b0, true);
  outView.setInt32(8, c0, true);
  outView.setInt32(12, d0, true);

  let hex = '';
  for (let i = 0; i < 16; i++) hex += out[i].toString(16).padStart(2, '0');
  return hex;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { md5Hex };
}
