// src/app.js

const store = new ProjectStore();

const paletteEl = document.getElementById('palette');
const canvasRoot = document.getElementById('canvas-root');
const layersRoot = document.getElementById('layers-root');
const inspectorRoot = document.getElementById('inspector-root');
const assetsRoot = document.getElementById('assets-root');
const apiSelect = document.getElementById('api-level-select');
const projectNameEl = document.getElementById('project-name');

const canvasEditor = new CanvasEditor(canvasRoot, store);
// Раз в секунду обновляем ТОЛЬКО текст «живых» виджетов (время/дата/AM-PM/день
// недели), а не пересобираем DOM всей сцены: полный render() каждую секунду
// пересоздавал узлы всех компонентов, ронял фокус и грузил браузер на больших
// макетах. См. CanvasEditor.tickLiveText().
setInterval(() => canvasEditor.tickLiveText(), 1000);
const layers = new LayersPanel(layersRoot, store);

// Сворачиваемые секции боковых панелей (кроме «Ресурсов» — ими управляет
// AssetManager). Панель «Слои» по умолчанию свёрнута: список нужен не всегда,
// а в развёрнутом виде он отодвигает «Свойства» вниз. Состояние запоминается
// в localStorage, поэтому развёрнутая панель такой и останется.
function initCollapsibleSections(defaults) {
  document.querySelectorAll('.panel-title.collapsible[data-section]').forEach((title) => {
    const section = title.dataset.section;
    if (section === 'resources') return;
    const content = document.querySelector(`.collapsible-content[data-section="${section}"]`);
    const btn = title.querySelector('.toggle-btn');
    if (!content || !btn) return;

    const apply = (collapsed) => {
      content.classList.toggle('collapsed', collapsed);
      btn.textContent = collapsed ? '▶' : '▼';
    };
    const key = `${section}-collapsed`;
    const saved = localStorage.getItem(key);
    apply(saved === null ? !!(defaults && defaults[section]) : saved === 'true');

    title.addEventListener('click', () => {
      const collapsed = !content.classList.contains('collapsed');
      apply(collapsed);
      localStorage.setItem(key, String(collapsed));
    });
  });
}
initCollapsibleSections({ layers: true });
const inspector = new Inspector(inspectorRoot, store);
const assetManager = new AssetManager(assetsRoot, store);
const projectSettings = new ProjectSettings(document.getElementById('project-settings-root'), store);

// Экранирует текст для безопасной вставки в HTML-атрибут (data-tip, title).
function escAttr(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;')
    .replace(/"/g, '&quot;')
    .replace(/</g, '&lt;');
}

// Собирает полный текст подсказки для компонента палитры: описание +
// техническая справка (widget id, мин. API, статус проверки, источник данных).
function paletteTooltipFor(def, compat) {
  const parts = [];
  parts.push(def.description || def.name);
  parts.push(`Виджет: hmUI.widget.${def.widgetId} · Мин. API: ${def.apiLevel}+ · ${def.confidence === 'unverified' ? '⚠ не полностью подтверждено документацией' : '✓ подтверждено docs.zepp.com'}.`);
  if (def.dataBindable) parts.push(`Источник данных: ${def.dataSource} (фиксированный).`);
  if (def.dataSourceSelectable) parts.push('Источник данных выбирается в Inspector после добавления на холст (по умолчанию — статический текст).');
  if (!compat) parts.push(`⚠ Недоступно при текущем уровне API проекта — требуется API ${def.apiLevel}+.`);
  return parts.join(' ');
}

const COMPONENT_ICONS = {
  text:'T', time_hm:'◷', time_hms:'◴', image:'▧', rect:'□', circle:'○', line:'╱', arc:'⌒', polygon:'◇',
  weather_icon:'☁', weather_temp:'°', weather:'☀', analog_hand:'↗', analog_hour:'↗', analog_minute:'↗', analog_second:'↗',
  battery:'▰', heart_rate:'♥', step:'♟', calorie:'🔥', distance:'↔', altitude:'⛰', air_pressure:'⌁',
  step_target:'🎯', cal_target:'🎯', pai_daily:'P', pai_weekly:'P', stand:'▥', stand_target:'🎯',
  humidity:'💧', uvi:'☀', aqi:'AQ', fat_burning:'🔥', fat_burning_target:'🎯', sun_current:'◐', sun_rise:'↑', sun_set:'↓',
  wind:'≋', stress:'◉', spo2:'O₂', body_temp:'🌡', floor:'▥', alarm_clock:'⏰', count_down:'⌛', stop_watch:'⏱',
  sleep:'☾', training_load:'⚡', vo2max:'V₂', recovery_time:'↻', month_run_times:'🏃', month_run_distance:'↔', readiness:'✓',
  date:'D', weekday:'W', hour:'H', minute:'M', second:'S', day:'D', month:'M', year:'Y', ampm:'A'
};

function componentIcon(def) {
  if (COMPONENT_ICONS[def.id]) return COMPONENT_ICONS[def.id];
  const n = String(def.name || '').toLowerCase();
  if (n.includes('погода')) return '☁';
  if (n.includes('текст')) return 'T';
  if (n.includes('время')) return '◷';
  if (n.includes('стрел')) return '↗';
  if (n.includes('данн')) return '◉';
  if (n.includes('фигур')) return '□';
  return '•';
}

function renderPalette() {
  const byCat = listByCategory();
  paletteEl.innerHTML = CATEGORIES.map((cat) => `
    <div class="palette-cat">
      <div class="palette-cat-title">${cat}</div>
      <div class="palette-items">
        ${byCat[cat].map((def) => {
          const compat = isApiCompatible(def.apiLevel, store.state.apiLevel);
          return `<button class="palette-item ${compat ? '' : 'disabled'}" draggable="true"
              data-def="${def.id}" data-tip="${escAttr(paletteTooltipFor(def, compat))}">
            <span class="palette-item-icon" aria-hidden="true">${componentIcon(def)}</span>
            <span class="palette-item-content">
              <span class="palette-item-name">${def.name}</span>
              <span class="palette-item-api">API ${def.apiLevel}+${def.confidence === 'unverified' ? ' · ⚠' : ''}</span>
            </span>
          </button>`;
        }).join('')}
      </div>
    </div>
  `).join('');

  paletteEl.querySelectorAll('.palette-item').forEach((btn) => {
    if (btn.classList.contains('disabled')) { btn.addEventListener('click', (e) => e.preventDefault()); return; }
    btn.addEventListener('dblclick', () => {
      store.addComponent(btn.dataset.def, 140, 140);
    });
    btn.addEventListener('dragstart', (e) => {
      e.dataTransfer.setData('text/plain', btn.dataset.def);
    });
  });

  // Палитра перерисовывается через innerHTML при каждом renderAll(), поэтому
  // новые кнопки нужно заново привязать к менеджеру подсказок (tooltips.js).
  if (window.tooltipManager) window.tooltipManager.refresh();
}

canvasRoot.addEventListener('dragover', (e) => e.preventDefault());
canvasRoot.addEventListener('drop', (e) => {
  e.preventDefault();
  const defId = e.dataTransfer.getData('text/plain');
  if (!defId || !REGISTRY[defId]) return;
  const frameRect = canvasEditor.frame.getBoundingClientRect();
  const x = (e.clientX - frameRect.left) / canvasEditor.zoom;
  const y = (e.clientY - frameRect.top) / canvasEditor.zoom;
  store.addComponent(defId, Math.max(0, Math.round(x)), Math.max(0, Math.round(y)));
});

// ---- Validation strip ----
// Единственная точка валидации проекта. Раньше renderValidation() вызывал
// validateProject(), но такой функции в Designer не было. Из-за ReferenceError
// выполнение app.js останавливалось прямо во время первого renderAll(): после
// этого не навешивались обработчики «Новый», «Открыть» и «Демо».
function validateProject(project) {
  const errors = [];
  const warnings = [];
  const p = project || {};

  if (!p.meta || !p.meta.name) warnings.push('У проекта нет названия.');
  if (!p.device || !Number.isFinite(Number(p.device.w)) || !Number.isFinite(Number(p.device.h))) {
    errors.push('Не задан корректный размер устройства.');
  }
  if (!Array.isArray(p.components)) errors.push('Поле components должно быть массивом.');
  if (!Array.isArray(p.assets)) errors.push('Поле assets должно быть массивом.');
  if (!Array.isArray(p.fonts)) errors.push('Поле fonts должно быть массивом.');

  const assets = new Set((p.assets || []).map(a => a && a.id).filter(Boolean));
  const fonts = new Set((p.fonts || []).map(f => f && f.id).filter(Boolean));

  for (const c of (p.components || [])) {
    if (!c || !c.defId) { errors.push('Обнаружен компонент без defId.'); continue; }
    const def = REGISTRY[c.defId];
    if (!def) { errors.push(`Неизвестный компонент: ${c.defId}.`); continue; }
    if (!Number.isFinite(Number(c.x)) || !Number.isFinite(Number(c.y)) ||
        !Number.isFinite(Number(c.w)) || !Number.isFinite(Number(c.h))) {
      errors.push(`Некорректные координаты или размер компонента ${c.id || c.defId}.`);
    }
    const props = c.props || {};
    if (props.font && !fonts.has(props.font)) {
      errors.push(`Компонент ${c.id || c.defId} ссылается на отсутствующий шрифт ${props.font}.`);
    }
    if (def.widgetId === 'IMG' && props.src && !assets.has(props.src)) {
      warnings.push(`Изображение компонента ${c.id || c.defId} не найдено среди ресурсов.`);
    }
    if (def.widgetId === 'TIME_POINTER' && props.path && !assets.has(props.path)) {
      warnings.push(`Ресурс стрелки компонента ${c.id || c.defId} не найден среди ресурсов.`);
    }

    // Tap zones are exported as independent transparent BUTTON widgets.
    // Validate their geometry/action here so a broken zone cannot silently
    // disappear from the generated watchface/index.js.
    if (c.tapZones != null && !Array.isArray(c.tapZones)) {
      errors.push(`Тап-зоны компонента ${c.id || c.defId} должны быть массивом.`);
    }
    for (const z of (Array.isArray(c.tapZones) ? c.tapZones : [])) {
      if (!z || !z.id) {
        errors.push(`У компонента ${c.id || c.defId} есть тап-зона без id.`);
        continue;
      }
      for (const key of ['x', 'y', 'w', 'h']) {
        if (!Number.isFinite(Number(z[key]))) {
          errors.push(`Тап-зона ${c.id || c.defId}/${z.id}: некорректное поле ${key}.`);
        }
      }
      if (Number(z.w) <= 0 || Number(z.h) <= 0) {
        errors.push(`Тап-зона ${c.id || c.defId}/${z.id}: ширина и высота должны быть больше 0.`);
      }
      const action = z.props?.tap_action || 'NONE';
      if (!['NONE', 'METRIC', 'APP'].includes(action)) {
        errors.push(`Тап-зона ${c.id || c.defId}/${z.id}: неизвестное действие ${action}.`);
      }
      if (action === 'APP' && !Number(z.props?.tap_app_id)) {
        warnings.push(`Тап-зона ${c.id || c.defId}/${z.id}: не задан App ID — зона попадёт в экспорт, но действие APP работать не будет.`);
      }
    }
  }

  // Normal/AOD are persisted separately. Validate both scenes even when the
  // editor is currently displaying only one of them, otherwise a broken AOD
  // component can pass validation and fail later during Zeus build.
  for (const [sceneName, scene] of Object.entries(p.scenes || {})) {
    if (!scene || !Array.isArray(scene.components)) continue;
    for (const c of scene.components) {
      if (!c || !c.defId) { errors.push(`Сцена ${sceneName}: компонент без defId.`); continue; }
      const def = REGISTRY[c.defId];
      if (!def) { errors.push(`Сцена ${sceneName}: неизвестный компонент ${c.defId}.`); continue; }
      const props = c.props || {};
      if (!Number.isFinite(Number(c.x)) || !Number.isFinite(Number(c.y)) ||
          !Number.isFinite(Number(c.w)) || !Number.isFinite(Number(c.h))) {
        errors.push(`Сцена ${sceneName}: некорректные координаты или размер ${c.id || c.defId}.`);
      }
      if (props.font && !fonts.has(props.font)) {
        errors.push(`Сцена ${sceneName}: компонент ${c.id || c.defId} ссылается на отсутствующий шрифт ${props.font}.`);
      }
      if (def.widgetId === 'IMG' && props.src && !assets.has(props.src) && !String(props.src).startsWith('weather')) {
        warnings.push(`Сцена ${sceneName}: изображение ${c.id || c.defId} не найдено среди ресурсов.`);
      }
      if (def.widgetId === 'TIME_POINTER' && props.path && !assets.has(props.path)) {
        warnings.push(`Сцена ${sceneName}: ресурс стрелки ${c.id || c.defId} не найден.`);
      }
    }
    if (scene.background?.imageAssetId && !assets.has(scene.background.imageAssetId)) {
      warnings.push(`Сцена ${sceneName}: фоновое изображение ${scene.background.imageAssetId} не найдено.`);
    }
  }

  if (p.background && p.background.imageAssetId && !assets.has(p.background.imageAssetId)) {
    warnings.push(`Фоновое изображение ${p.background.imageAssetId} не найдено среди ресурсов.`);
  }
  if (p.device && !p.device.targetKey) {
    warnings.push('У устройства не задан targetKey — экспорт полного проекта потребует ручной настройки.');
  }
  return { errors, warnings };
}

function renderPreflightDialog(result) {
  const dlg = document.getElementById('diagnostic-dialog');
  const summary = document.getElementById('diagnostic-summary');
  const list = document.getElementById('diagnostic-list');
  const raw = document.getElementById('diagnostic-raw');
  if (!dlg || !summary || !list) return;
  const esc = (t) => String(t ?? '').replace(/[&<>]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
  const errors = result?.errors || [];
  const warnings = result?.warnings || [];
  summary.innerHTML = `<b>${errors.length ? '❌ Сборка заблокирована' : '✅ Проверка пройдена'}</b> · ${errors.length} ошибок · ${warnings.length} предупреждений`;
  const details = result?.diagnostics || [];
  list.innerHTML = details.length ? details.map((d, i) => `
    <div class="diagnostic-item ${d.severity === 'error' ? 'error' : 'warn'}">
      <div><b>${d.severity === 'error' ? 'Ошибка' : 'Предупреждение'} ${i + 1}</b> · <code>${esc(d.code)}</code>${d.line ? ` · строка ${d.line}` : ''}${d.scene ? ` · ${esc(d.scene)}` : ''}</div>
      <div class="diagnostic-message">${esc(d.message)}</div>
      ${d.detail ? `<div class="diagnostic-detail">${esc(d.detail)}</div>` : ''}
    </div>`).join('') : '<div class="diagnostic-empty">Проблем не обнаружено.</div>';
  if (raw) {
    raw.textContent = JSON.stringify(result, null, 2);
    raw.hidden = true;
  }
  if (typeof dlg.showModal === 'function') dlg.showModal(); else dlg.setAttribute('open','');
}

async function runFullPreflight(showDialog = true) {
  const status = document.getElementById('preflight-status');
  if (status) status.textContent = 'Проверяю проект и generated index.js…';
  try {
    const result = runDesignerPreflight(store.state);
    if (status) status.textContent = result.ok ? `✓ Готово: ошибок нет${result.warnings.length ? `, предупреждений ${result.warnings.length}` : ''}` : `❌ Найдено ошибок: ${result.errors.length}`;
    if (showDialog) renderPreflightDialog(result);
    renderValidation();
    return result;
  } catch (e) {
    const result = { ok: false, errors: [`Внутренняя ошибка диагностики: ${e?.stack || e?.message || e}`], warnings: [], diagnostics: [] };
    if (status) status.textContent = '❌ Ошибка диагностики';
    if (showDialog) renderPreflightDialog(result);
    return result;
  }
}

document.getElementById('act-preflight')?.addEventListener('click', () => runFullPreflight(true));
document.getElementById('diagnostic-close')?.addEventListener('click', () => document.getElementById('diagnostic-dialog')?.close());

const validationEl = document.getElementById('validation-strip');
function renderValidation() {
  const { errors, warnings } = validateProject(store.state);
  if (errors.length === 0 && warnings.length === 0) {
    validationEl.innerHTML = '<span class="valid-ok">✓ Проблем не обнаружено</span>';
    return;
  }
  const escV = (t) => String(t).replace(/[&<>]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
  validationEl.innerHTML = `
    <div class="validation-summary">
      <b>Проверка проекта:</b> ${errors.length ? `<span class="valid-error">${errors.length} ошибок</span>` : '<span class="valid-ok">ошибок нет</span>'} · ${warnings.length ? `<span class="valid-warn">${warnings.length} предупреждений</span>` : 'предупреждений нет'}
      ${(errors.length || warnings.length) ? '<button type="button" class="validation-details-btn">Подробно</button>' : ''}
    </div>
    ${(errors.length || warnings.length) ? `<details class="validation-details"><summary>Показать диагностику</summary>${errors.map((e,i)=>`<div class="validation-item error"><b>Ошибка ${i+1}.</b> ${escV(e)}</div>`).join('')}${warnings.map((w,i)=>`<div class="validation-item warn"><b>Предупреждение ${i+1}.</b> ${escV(w)}</div>`).join('')}</details>` : ''}`;
  const db=validationEl.querySelector('.validation-details-btn');
  const det=validationEl.querySelector('.validation-details');
  if(db&&det) db.onclick=()=>{det.open=!det.open;};
}

const sceneNormalBtn = document.getElementById('scene-normal');
const sceneAodBtn = document.getElementById('scene-aod');
const aodPanel = document.getElementById('aod-panel');
const aodStatus = document.getElementById('aod-status');

function syncAodControls() {
  if (!aodPanel) return;
  const active = store.state.mode === 'aod';
  aodPanel.hidden = !active;
  document.body.classList.toggle('aod-mode', active);
  sceneNormalBtn?.classList.toggle('active', !active);
  sceneAodBtn?.classList.toggle('active', active);
  if (!active) { if (aodStatus) aodStatus.hidden = true; return; }
  const st = store.getAodSettings();
  const set = (id, val) => { const el=document.getElementById(id); if(el && document.activeElement!==el) el.value=val; };
  set('aod-bg', st.background || '#000000');
  set('aod-brightness', st.brightness ?? 100);
  set('aod-test-time', st.testTime || '10:10');
  set('aod-test-date', st.testDate || '');
  set('aod-battery', st.sensorValues?.battery ?? 85);
  set('aod-steps', st.sensorValues?.steps ?? 8452);
  set('aod-heart', st.sensorValues?.heart ?? 72);
  const sec=document.getElementById('aod-show-seconds'); if(sec) sec.checked=!!st.showSeconds;
  document.querySelectorAll('[data-aod-preview]').forEach(b=>b.classList.toggle('active', b.dataset.aodPreview === (st.previewMode || 'AOD')));
  if (aodStatus) {
    const cfg=buildAodConfig(store.state);
    aodStatus.hidden=false;
    aodStatus.innerHTML=`<b>AOD Studio</b><br>Объектов: ${store.state.components.length}. Экспортируемых: ${cfg.objects.filter(o=>o.exportable).length}. Только конфигурация редактора — без выдуманного Zepp OS AOD API.`;
  }
}

function updateAodSettingFromUi() {
  if (store.state.mode !== 'aod') return;
  const sensorValues = {
    battery: Number(document.getElementById('aod-battery')?.value || 0),
    steps: Number(document.getElementById('aod-steps')?.value || 0),
    heart: Number(document.getElementById('aod-heart')?.value || 0)
  };
  store.updateAodSettings({
    background: document.getElementById('aod-bg')?.value || '#000000',
    brightness: Number(document.getElementById('aod-brightness')?.value || 100),
    testTime: document.getElementById('aod-test-time')?.value || '10:10',
    testDate: document.getElementById('aod-test-date')?.value || '',
    showSeconds: !!document.getElementById('aod-show-seconds')?.checked,
    sensorValues
  });
}

sceneNormalBtn?.addEventListener('click',()=>store.switchScene('normal'));
sceneAodBtn?.addEventListener('click',()=>store.switchScene('aod'));
function createAodSubset(kind) {
  const existingAod = store.state.mode === 'aod' ? store.state.components : (store.state.scenes?.aod?.components || []);
  if (existingAod.length && !confirm('Заменить существующую AOD-сцену выбранными элементами Normal?')) return;

  const filter = (c) => {
    const def = REGISTRY[c.defId];
    if (!def) return false;
    if (kind === 'images') return def.widgetId === 'IMG';
    if (kind === 'hands') return def.widgetId === 'TIME_POINTER';
    if (kind === 'text') return def.widgetId === 'TEXT' || !!def.dataSource || !!c.props?.data_source;
    return true;
  };

  const count = store.createAodFromNormal({ filter });
  if (aodStatus) {
    aodStatus.hidden = false;
    aodStatus.innerHTML = `<b>AOD Studio</b><br>Перенесено из Normal: <strong>${count}</strong> объектов.`;
  }
  renderAll();
}
document.getElementById('aod-from-normal')?.addEventListener('click',()=>createAodSubset('all'));
document.getElementById('aod-from-images')?.addEventListener('click',()=>createAodSubset('images'));
document.getElementById('aod-from-hands')?.addEventListener('click',()=>createAodSubset('hands'));
document.getElementById('aod-from-text')?.addEventListener('click',()=>createAodSubset('text'));
document.getElementById('aod-clear')?.addEventListener('click',()=>{
  if(confirm('Очистить только AOD-сцену? Normal останется без изменений.')) store.clearAod();
});
document.getElementById('aod-export')?.addEventListener('click',()=>{
  const cfg=downloadAodConfig(store.state);
  alert(`AOD-конфигурация экспортирована. Предупреждений: ${cfg.warnings.length}.`);
});
['aod-bg','aod-brightness','aod-test-time','aod-test-date','aod-battery','aod-steps','aod-heart','aod-show-seconds'].forEach(id=>{
  document.getElementById(id)?.addEventListener('change', updateAodSettingFromUi);
});
document.querySelectorAll('[data-aod-preview]').forEach(btn=>btn.addEventListener('click',()=>{
  if(store.state.mode!=='aod') return;
  store.updateAodSettings({previewMode:btn.dataset.aodPreview});
}));

function renderAll() {
  canvasEditor.render();
  layers.render();
  inspector.render();
  assetManager.render();
  projectSettings.render();
  apiSelect.value = store.state.apiLevel;
  projectNameEl.value = store.state.meta.name;
  renderPalette();
  renderValidation();
  syncAodControls();
}

store.subscribe(renderAll);
renderAll();

apiSelect.addEventListener('change', () => {
  store.state.apiLevel = apiSelect.value;
  store.commit();
});

projectNameEl.addEventListener('change', () => {
  store.state.meta.name = projectNameEl.value || 'AmazFace Watch Face';
  store.commit();
});



// ---- Zeus Preview bridge ----
const ZEUS_BRIDGE = 'http://127.0.0.1:17865';
let zeusPollTimer = null;
let zeusBusy = false;

function zeusEls() {
  return {
    dlg: document.getElementById('zeus-dialog'),
    status: document.getElementById('zeus-bridge-status'),
    dot: document.getElementById('zeus-dot'),
    log: document.getElementById('zeus-log'),
    run: document.getElementById('zeus-run'),
    stop: document.getElementById('zeus-stop')
  };
}
function zeusSetBridge(ok, text) {
  const {status, dot} = zeusEls();
  if (!status || !dot) return;
  status.textContent = text;
  dot.classList.toggle('ok', !!ok);
  dot.classList.toggle('bad', !ok);
}
async function zeusHealth() {
  try {
    const r = await fetch(`${ZEUS_BRIDGE}/health`, {cache:'no-store'});
    if (!r.ok) throw new Error('Bridge недоступен');
    const j = await r.json();
    zeusSetBridge(true, `Zeus Bridge подключён · ${j.zeus || 'zeus'}`);
    return true;
  } catch (e) {
    zeusSetBridge(false, 'Zeus Bridge не запущен');
    return false;
  }
}
async function zeusPoll() {
  try {
    const r = await fetch(`${ZEUS_BRIDGE}/status`, {cache:'no-store'});
    const j = await r.json();
    const {log, run, stop} = zeusEls();
    if (log) log.textContent = j.log || '';
    if (run) run.disabled = !!j.running;
    if (stop) stop.disabled = !j.running;
    if (j.running) zeusPollTimer = setTimeout(zeusPoll, 600);
    else { zeusBusy = false; if (run) run.disabled = false; if (stop) stop.disabled = true; }
  } catch (e) {
    const {log} = zeusEls();
    if (log) log.textContent += `\n[Bridge] ${e.message}`;
    zeusBusy = false;
  }
}
async function zeusRunPreview() {
  if (zeusBusy) return;
  const {log, run, stop} = zeusEls();
  if (!(await zeusHealth())) {
    if (log) log.textContent = 'Запустите bridge\\start-zeus-bridge.bat и повторите.';
    return;
  }
  zeusBusy = true;
  if (run) run.disabled = true;
  if (stop) stop.disabled = false;
  if (log) log.textContent = 'Собираю проект…\n';
  try {
    const preflight = await runFullPreflight(false);
    if (!preflight.ok) { renderPreflightDialog(preflight); zeusBusy = false; if(run)run.disabled=false; if(stop)stop.disabled=true; return; }
    const result = await exportFullProject(store.state);
    const errors = result.validation?.errors || [];
    if (errors.length && !confirmIssuesForZeus(errors)) { zeusBusy = false; if(run)run.disabled=false; if(stop)stop.disabled=true; return; }
    const buf = await result.blob.arrayBuffer();
    const r = await fetch(`${ZEUS_BRIDGE}/preview`, {
      method:'POST', headers:{'Content-Type':'application/zip','X-Project-Name': latinSlug(store.state.meta.name, 'watchface')}, body:buf
    });
    const j = await r.json();
    if (!r.ok) throw new Error(j.error || 'Bridge error');
    if (log) log.textContent += (j.message || 'Передано в Zeus.') + '\n';
    zeusPoll();
  } catch (e) {
    if (log) log.textContent += `\nОШИБКА: ${e.message}\n`;
    zeusBusy = false; if(run)run.disabled=false; if(stop)stop.disabled=true;
  }
}
function confirmIssuesForZeus(errors) {
  return confirm(`Сборка остановлена диагностикой. Найдено ${errors.length} ошибок.\n\n${errors.map((e,i)=>`[${i+1}] ${e}`).join('\n\n')}\n\nПродолжить в Zeus Preview несмотря на ошибки?`);
}

document.getElementById('act-zeus-preview')?.addEventListener('click', async () => {
  const {dlg, log} = zeusEls();
  if (dlg && typeof dlg.showModal === 'function') dlg.showModal();
  else dlg?.setAttribute('open','');
  if (log) log.textContent = '';
  await zeusHealth();
  await zeusPoll();
});
document.getElementById('zeus-run')?.addEventListener('click', zeusRunPreview);
document.getElementById('zeus-stop')?.addEventListener('click', async () => {
  try { await fetch(`${ZEUS_BRIDGE}/stop`, {method:'POST'}); } catch(e) {}
  zeusPoll();
});

// ---- Toolbar actions ----
document.getElementById('act-undo').onclick = () => store.undo();
document.getElementById('act-redo').onclick = () => store.redo();
document.getElementById('act-dup').onclick = () => store.duplicateComponents([...store.selection]);
document.getElementById('act-del').onclick = () => confirmRemoveComponents(store, [...store.selection]);

document.getElementById('act-new').onclick = () => {
  if (confirm('Создать новый проект? Несохранённые изменения будут потеряны.')) store.newProject();
};

document.getElementById('act-save').onclick = async () => {
  try {
    store.state.preview = store.state.preview || {};
    store.state.preview.dataUrl = await buildPreviewDataUrl(store.state, 324);
    store.state.preview.width = 324;
    store.state.preview.height = 324;
    store.state.preview.handsTime = '10:10';
  } catch (e) { console.warn('Preview generation failed:', e); }
  store._saveActiveScene();
  const blob = new Blob([store.toJSON()], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  // Имя файла всегда латиницей: кириллические названия транслитерируются
  // (см. src/util/slug.js), иначе файл неудобно передавать в Zeus CLI/git/архивы.
  a.download = `${latinSlug(store.state.meta.name, 'watchface')}.watchface.json`;
  a.click();
};

document.getElementById('act-open').addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    try { store.loadFromJSON(reader.result); }
    catch (err) { alert('Не удалось загрузить проект: ' + err.message); }
  };
  reader.readAsText(file);
  e.target.value = '';
});

// ---- Background is edited from the Layers panel ----
// The old standalone background controls were intentionally removed.
// Selecting the "Фон" layer opens its color/image/opacity properties in Inspector.

// ---- Export: full project (.zip) ----
document.getElementById('act-export-project').onclick = async () => {
  try {
    const { blob, validation } = await exportFullProject(store.state);
    if (validation.errors.length) {
      // Critical generator errors are never exportable. The Designer must
      // repair the generated code instead of offering a broken ZIP.
      runFullPreflight(true);
      alert(`Экспорт заблокирован: Designer обнаружил ${validation.errors.length} критических ошибок.\n\n${validation.errors.join('\n')}`);
      return;
    }
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `${latinSlug(store.state.meta.name, 'watchface')}.zip`;
    a.click();
  } catch (err) {
    alert('Сборка остановлена: ' + err.message);
    runFullPreflight(true);
  }
};

// ---- Export: direct Balance 2 device.zip (no Zeus / no BIN) ----
document.getElementById('act-export-direct')?.addEventListener('click', async () => {
  try {
    const result = await exportDirectDeviceZip(store.state);
    if (result.validation.errors.length) {
      runFullPreflight(true);
      alert(`Direct ZIP заблокирован: Designer обнаружил ${result.validation.errors.length} критических ошибок.\n\n${result.validation.errors.join('\n')}`);
      return;
    }
    const warnings = result.validation.warnings || [];
    if (warnings.length) console.warn('Direct ZIP warnings:', warnings);
    const a = document.createElement('a');
    a.href = URL.createObjectURL(result.blob);
    a.download = `${latinSlug(store.state.meta.name, 'watchface')}.device.zip`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 5000);
  } catch (err) {
    alert('Не удалось собрать Direct ZIP: ' + err.message);
  }
});


// ---- Export: .zpk + QR (установка через режим разработчика, без Zeus) ----
(() => {
  const dlg = document.getElementById('zpk-dialog');
  if (!dlg) return;

  const urlInput = document.getElementById('zpk-url');
  const buildStatus = document.getElementById('zpk-build-status');
  const urlStatus = document.getElementById('zpk-url-status');
  const qrOut = document.getElementById('zpk-qr-out');
  const qrText = document.getElementById('zpk-qr-text');
  const btnPng = document.getElementById('zpk-save-png');
  const btnSvg = document.getElementById('zpk-save-svg');

  let lastMatrix = null;
  let lastUrl = '';

  const say = (el, html) => { el.innerHTML = html; };
  const esc = (t) => String(t).replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));

  function download(blobOrUrl, filename) {
    const a = document.createElement('a');
    const isBlob = blobOrUrl instanceof Blob;
    a.href = isBlob ? URL.createObjectURL(blobOrUrl) : blobOrUrl;
    a.download = filename;
    a.click();
    if (isBlob) setTimeout(() => URL.revokeObjectURL(a.href), 5000);
  }

  // Ошибки проекта показываются один раз, при сборке пакета.
  function confirmIssues(validation) {
    const errors = validation?.errors || [];
    if (!errors.length) return true;
    return confirm(
      `В проекте ${errors.length} ошибок(-а):\n\n` + errors.join('\n') +
      `\n\nСобрать пакет как есть?`
    );
  }

  document.getElementById('act-export-zpk')?.addEventListener('click', () => {
    if (typeof dlg.showModal === 'function') dlg.showModal(); else dlg.setAttribute('open', '');
  });
  document.getElementById('zpk-close')?.addEventListener('click', () => dlg.close());

  const compressOn = () => document.getElementById('zpk-compress')?.checked !== false;
  const kb = (n) => `${Math.round(n / 1024)} КБ`;

  document.getElementById('zpk-build')?.addEventListener('click', async () => {
    say(buildStatus, 'Собираю пакет…');
    try {
      const result = await exportZabContainer(store.state, { compress: compressOn() });
      if (!confirmIssues(result.validation)) { say(buildStatus, ''); return; }
      const base = latinSlug(store.state.meta.name, 'watchface');
      download(result.blob, `${base}.zpk`);
      const warns = result.validation.warnings || [];
      say(buildStatus,
        `<span class="ok">Готово: ${base}.zpk (${kb(result.bytes.length)})</span> — manifest.json + ${result.targetName} (md5 ${result.targetMd5.slice(0, 8)}…).` +
        (warns.length ? ` <span class="warn">Предупреждений: ${warns.length} (см. консоль).</span>` : ''));
      if (warns.length) console.warn('ZPK warnings:', warns);
    } catch (err) {
      say(buildStatus, `<span class="err">Не удалось собрать .zpk: ${esc(err.message)}</span>`);
    }
  });

  document.getElementById('zpk-build-inner')?.addEventListener('click', async () => {
    say(buildStatus, 'Собираю средний уровень…');
    try {
      const result = await exportZpkPackage(store.state, { compress: compressOn() });
      if (!confirmIssues(result.validation)) { say(buildStatus, ''); return; }
      const base = latinSlug(store.state.meta.name, 'watchface');
      download(result.blob, `${base}.inner.zpk`);
      say(buildStatus, `<span class="ok">Готово: ${base}.inner.zpk (${kb(result.bytes.length)})</span> — без manifest, на часы напрямую не ставится.`);
    } catch (err) {
      say(buildStatus, `<span class="err">Не удалось собрать: ${esc(err.message)}</span>`);
    }
  });

  document.getElementById('zpk-build-device')?.addEventListener('click', async () => {
    say(buildStatus, 'Собираю device.zip…');
    try {
      const result = await exportDirectDeviceZip(store.state, { compress: compressOn() });
      if (!confirmIssues(result.validation)) { say(buildStatus, ''); return; }
      const base = latinSlug(store.state.meta.name, 'watchface');
      download(result.blob, `${base}.device.zip`);
      say(buildStatus, `<span class="ok">Готово: ${base}.device.zip (${kb(result.bytes.length)})</span>`);
    } catch (err) {
      say(buildStatus, `<span class="err">Не удалось собрать device.zip: ${esc(err.message)}</span>`);
    }
  });

  document.getElementById('zpk-make-qr')?.addEventListener('click', () => {
    qrOut.innerHTML = '';
    qrText.textContent = '';
    btnPng.disabled = true;
    btnSvg.disabled = true;
    lastMatrix = null;
    try {
      const deepLink = toZpkd1Url(urlInput.value);
      // Уровень M — компромисс между плотностью и устойчивостью к бликам экрана.
      const matrix = qrEncodeToMatrix(deepLink, 'M');
      lastMatrix = matrix;
      lastUrl = deepLink;

      const img = document.createElement('img');
      img.src = qrMatrixToPngDataUrl(matrix, 8);
      img.alt = 'QR-код для установки';
      qrOut.appendChild(img);
      qrText.textContent = deepLink;

      btnPng.disabled = false;
      btnSvg.disabled = false;

      const notes = checkZpkUrl(urlInput.value);
      say(urlStatus,
        `<span class="ok">QR готов (версия ${matrix.version}, коррекция ${matrix.ecLevel}).</span>` +
        notes.map(n => `<br><span class="warn">${esc(n)}</span>`).join(''));
    } catch (err) {
      say(urlStatus, `<span class="err">${esc(err.message)}</span>`);
    }
  });

  btnPng?.addEventListener('click', () => {
    if (!lastMatrix) return;
    const base = latinSlug(store.state.meta.name, 'watchface');
    download(qrMatrixToPngDataUrl(lastMatrix, 12), `${base}.qr.png`);
  });

  btnSvg?.addEventListener('click', () => {
    if (!lastMatrix) return;
    const base = latinSlug(store.state.meta.name, 'watchface');
    const svg = qrMatrixToSvg(lastMatrix, 8);
    download(new Blob([svg], { type: 'image/svg+xml' }), `${base}.qr.svg`);
  });

  // Диагностика: чужой device.zip → наш контейнер .zpk
  document.getElementById('zpk-wrap-file')?.addEventListener('change', async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const wrapStatus = document.getElementById('zpk-wrap-status');
    say(wrapStatus, 'Читаю архив…');
    try {
      const bytes = new Uint8Array(await file.arrayBuffer());
      const wrapped = await wrapDeviceZipIntoZpk(bytes, { compress: compressOn() });
      const manifest = JSON.parse(wrapped.appJson);
      const name = manifest?.app?.appName || 'watchface';
      download(wrapped.blob, `${latinSlug(name, 'watchface')}.wrapped.zpk`);
      const sources = (manifest?.platforms || []).map(p => p.deviceSource).join(', ');
      say(wrapStatus,
        `<span class="ok">Готово (${kb(wrapped.bytes.length)}).</span> ` +
        `Внутри манифест «${esc(name)}», API ${esc(manifest?.runtime?.apiVersion?.compatible || '?')}, deviceSource: ${esc(sources || '—')}.`);
    } catch (err) {
      say(wrapStatus, `<span class="err">${esc(err.message)}</span>`);
    } finally {
      e.target.value = '';
    }
  });

  urlInput?.addEventListener('input', () => {
    if (!lastMatrix) return;
    let current = '';
    try { current = toZpkd1Url(urlInput.value); } catch (e) { current = ''; }
    if (current !== lastUrl) {
      // Ссылку изменили — старый QR больше не соответствует полю.
      btnPng.disabled = true;
      btnSvg.disabled = true;
      qrOut.innerHTML = '';
      qrText.textContent = '';
      lastMatrix = null;
      say(urlStatus, '<span class="warn">Ссылка изменилась — сгенерируйте QR заново.</span>');
    }
  });
})();


// ---- Demo watch face ----
document.getElementById('act-demo').onclick = () => {
  if (!confirm('Заменить текущие компоненты демо-макетом?')) return;
  store.state.components = [];
  store.state.nextIndex = {};
  const cx = store.state.device.w / 2;
  const add = (defId, x, y, patch = {}) => {
    const idx = (store.state.nextIndex[defId] || 0) + 1;
    store.state.nextIndex[defId] = idx;
    const def = REGISTRY[defId];
    const props = {};
    for (const p of def.properties) if (p.default !== undefined) props[p.key] = p.default;
    Object.assign(props, patch.props || {});
    store.state.components.push({
      id: `${defId}_${String(idx).padStart(3, '0')}`, defId, name: def.name,
      x, y, w: patch.w ?? def.defaultSize.w, h: patch.h ?? def.defaultSize.h,
      visible: true, locked: false, props,
    });
  };
  add('time_hm', cx - 150, 150, { w: 300, h: 100, props: { text_size: 84, color: '#ffffff', align_h: 'CENTER_H', align_v: 'CENTER_V' } });
  add('date_full', cx - 110, 250, { w: 220, h: 36, props: { text_size: 26, color: '#aeb6c2', align_h: 'CENTER_H', align_v: 'CENTER_V', format: 'DD MMM' } });
  add('weather_icon', cx - 90, 300, { w: 48, h: 48, props: { src: 'sunny' } });
  add('weather_temp', cx - 30, 305, { w: 90, h: 40, props: { text_size: 30, color: '#ffffff', align_h: 'LEFT', align_v: 'CENTER_V', unit: '°C' } });
  add('heart_rate', cx - 60, 360, { w: 120, h: 34, props: { text_size: 26, color: '#ff5c7a', align_h: 'CENTER_H', align_v: 'CENTER_V', prefix: '♥ ' } });
  add('steps', cx - 90, 400, { w: 180, h: 34, props: { text_size: 24, color: '#8fd3ff', align_h: 'CENTER_H', align_v: 'CENTER_V', suffix: ' шагов' } });
  add('battery', cx - 40, 440, { w: 80, h: 30, props: { text_size: 22, color: '#8bffb0', align_h: 'CENTER_H', align_v: 'CENTER_V', suffix: '%' } });
  store.commit();
};

// keep palette compatibility in sync visually (re-render already handled by subscribe)
