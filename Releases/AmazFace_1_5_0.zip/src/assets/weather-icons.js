// src/assets/weather-icons.js
//
// Свой набор иконок погоды. В Zepp OS иконку погоды выбирает прошивка по индексу 0..28
// (IMG_LEVEL + data_type.WEATHER_CURRENT), поэтому набор — это 29 «слотов». Каждый слот
// можно заполнить своим PNG; незаполненные слоты получают запасной вариант
// (см. resolveIndex). Если ни один слот не заполнен — работает прежний набор-заглушка.
//
// Хранение: обычные ресурсы проекта (store.state.assets) с пометкой
// `weatherIcon: '<id состояния>'`. Такие ресурсы скрыты из общего списка «Ресурсы»
// и не попадают в корень assets/ при экспорте — их кладут в assets/.../weather/.
// Зависимости (глобальные): WEATHER_ICON_SET, WEATHER_ICON_FILES (экспортёр),
// makeAssetId, drawWeatherIcon (project-exporter.js — только для заглушек).

const WeatherIcons = (() => {
  // Запасные слоты: ночные варианты → дневные, остальные → «Неизвестно» (25).
  const NIGHT_BASE = { 26: 0, 27: 1, 28: 3 };
  const UNKNOWN_INDEX = 25;

  const norm = (s) => String(s || '').toLowerCase().replace(/ё/g, 'е')
    .replace(/\.(png|jpe?g)$/i, '').replace(/[^a-z0-9а-я]+/g, '_').replace(/^_+|_+$/g, '');

  const set = () => (typeof WEATHER_ICON_SET !== 'undefined' ? WEATHER_ICON_SET : []);
  const isIcon = (a) => !!(a && a.weatherIcon);

  function assetFor(project, condId) {
    return (project.assets || []).find((a) => a.weatherIcon === condId) || null;
  }
  function customCount(project) {
    return set().filter((w) => assetFor(project, w.id)).length;
  }
  function missing(project) {
    return set().filter((w) => !assetFor(project, w.id));
  }

  // Что реально попадёт в слот index при экспорте.
  // source: 'own' — своя иконка; 'fallback' — запасная своя иконка из другого слота;
  // 'generated' — встроенная заглушка (рисуется кодом).
  function resolveIndex(project, index) {
    const w = set()[index];
    if (!w) return { asset: null, source: 'generated', fromIndex: index };
    const own = assetFor(project, w.id);
    if (own) return { asset: own, source: 'own', fromIndex: index };
    if (customCount(project) > 0) {
      const chain = [];
      if (NIGHT_BASE[index] !== undefined) chain.push(NIGHT_BASE[index]);
      chain.push(UNKNOWN_INDEX);
      for (const i of chain) {
        const a = set()[i] && assetFor(project, set()[i].id);
        if (a) return { asset: a, source: 'fallback', fromIndex: i };
      }
    }
    return { asset: null, source: 'generated', fromIndex: index };
  }

  // PNG dataURL для файла слота index (для экспортёров).
  function dataUrlFor(project, index, size = 64) {
    const r = resolveIndex(project, index);
    if (r.asset && r.asset.dataUrl) return r.asset.dataUrl;
    return drawWeatherIcon(index, size).toDataURL('image/png');
  }

  function frameKey(comp) {
    const w = Math.max(1, Math.round(Number(comp && comp.w) || 64));
    const h = Math.max(1, Math.round(Number(comp && comp.h) || 64));
    return `${w}x${h}`;
  }

  function loadImageDataUrl(dataUrl) {
    return new Promise((resolve, reject) => {
      const image = new Image();
      image.onload = () => resolve(image);
      image.onerror = () => reject(new Error('Не удалось прочитать иконку погоды для экспорта.'));
      image.src = dataUrl;
    });
  }

  // Материализует каждый слот на прозрачном холсте размера компонента. Так все
  // кадры IMG_LEVEL имеют одинаковую рамку, а маленькие картинки остаются
  // исходного размера и располагаются по центру и в редакторе, и на часах.
  async function dataUrlForComponent(project, comp, index) {
    const width = Math.max(1, Math.round(Number(comp && comp.w) || 64));
    const height = Math.max(1, Math.round(Number(comp && comp.h) || 64));
    const resolved = resolveIndex(project, index);
    const image = resolved.asset && resolved.asset.dataUrl
      ? await loadImageDataUrl(resolved.asset.dataUrl)
      : drawWeatherIcon(index, 64);
    const iw = Math.max(1, Number(image.naturalWidth || image.width) || 1);
    const ih = Math.max(1, Number(image.naturalHeight || image.height) || 1);
    const scale = Math.min(1, width / iw, height / ih);
    const drawW = iw * scale, drawH = ih * scale;
    const canvas = document.createElement('canvas');
    canvas.width = width; canvas.height = height;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, width, height);
    const x = (width - drawW) / 2, y = (height - drawH) / 2;
    // Integer placement keeps a native-size icon crisp on the generated PNG.
    ctx.drawImage(image, scale === 1 ? Math.round(x) : x, scale === 1 ? Math.round(y) : y, drawW, drawH);
    return canvas.toDataURL('image/png');
  }

  // Ресурс, который нужно показать в превью редактора для состояния condId.
  function previewAsset(project, condId) {
    const w = set().find((x) => x.id === normalizeWeatherIconId(condId));
    if (!w) return null;
    return resolveIndex(project, w.index).asset;
  }

  // ---- распознавание слота по имени файла ----
  const RU = () => set().map((w) => ({ w, key: norm(w.label) }));
  // Название состояния в имени файла (английский id или русское название).
  function matchText(fileName) {
    const n = norm(fileName);
    if (!n) return -1;
    // 1) английский id как отдельное слово/словосочетание (длинные id — первыми)
    const byLen = [...set()].sort((a, b) => b.id.length - a.id.length);
    for (const w of byLen) {
      if (new RegExp(`(^|_)${w.id}(_|$)`).test(n)) return w.index;
    }
    // 2) русское название (длинные — первыми)
    for (const { w, key } of RU().sort((a, b) => b.key.length - a.key.length)) {
      if (key && (n === key || n.includes(key))) return w.index;
    }
    return -1;
  }
  // Номер слота в начале имени: «07», «7_что-то».
  function matchNumber(fileName) {
    const m = norm(fileName).match(/^(\d{1,2})(?:_|$)/);
    return m && Number(m[1]) <= 28 ? Number(m[1]) : -1;
  }
  // Название надёжнее номера: у чужих наборов нумерация своя.
  function matchFileName(fileName) {
    const t = matchText(fileName);
    return t >= 0 ? t : matchNumber(fileName);
  }

  const natCmp = (a, b) => a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' });

  // ---- чтение файла → PNG ----
  function fileToPng(file) {
    return new Promise((resolve, reject) => {
      const fr = new FileReader();
      fr.onerror = () => reject(new Error(`Не удалось прочитать файл ${file.name}`));
      fr.onload = () => {
        const img = new Image();
        img.onerror = () => reject(new Error(`Файл ${file.name} не является изображением`));
        img.onload = () => {
          // Всегда сохраняем как PNG (JPEG в weather/*.png не годится). Размер не меняем.
          const c = document.createElement('canvas');
          c.width = img.naturalWidth || img.width; c.height = img.naturalHeight || img.height;
          c.getContext('2d').drawImage(img, 0, 0);
          const dataUrl = c.toDataURL('image/png');
          resolve({ dataUrl, width: c.width, height: c.height, size: Math.round((dataUrl.length - 22) * 0.75) });
        };
        img.src = fr.result;
      };
      fr.readAsDataURL(file);
    });
  }

  function recolorPixels(pixels, width, height, color) {
    const match = String(color || '').match(/^#([0-9a-f]{6})$/i);
    if (!match) throw new Error('Выберите цвет в формате HEX.');
    const hex = match[1];
    const target = [0, 2, 4].map((i) => parseInt(hex.slice(i, i + 2), 16));
    const count = pixels.length / 4;
    let transparent = 0;
    for (let i = 3; i < pixels.length; i += 4) if (pixels[i] < 250) transparent++;
    const hasAlphaMask = transparent > Math.max(1, count * 0.002);
    let bg = [0, 0, 0];
    if (!hasAlphaMask && count) {
      // PNG/JPEG с однотонной подложкой: оцениваем фон по углам и делаем
      // его прозрачным, сохраняя края одноцветного рисунка.
      const corners = [[0, 0], [width - 1, 0], [0, height - 1], [width - 1, height - 1]];
      const samples = corners.map(([x, y]) => {
        const p = (Math.max(0, Math.min(height - 1, y)) * width + Math.max(0, Math.min(width - 1, x))) * 4;
        return [pixels[p], pixels[p + 1], pixels[p + 2]];
      });
      bg = [0, 1, 2].map((c) => Math.round(samples.reduce((sum, p) => sum + p[c], 0) / samples.length));
    }
    const maxDistance = Math.sqrt(3 * 255 * 255);
    for (let i = 0; i < pixels.length; i += 4) {
      let coverage = pixels[i + 3] / 255;
      if (!hasAlphaMask) {
        const dr = pixels[i] - bg[0], dg = pixels[i + 1] - bg[1], db = pixels[i + 2] - bg[2];
        const distance = Math.sqrt(dr * dr + dg * dg + db * db);
        coverage *= Math.max(0, Math.min(1, (distance - 12) / (maxDistance - 12)));
      }
      pixels[i] = target[0]; pixels[i + 1] = target[1]; pixels[i + 2] = target[2];
      pixels[i + 3] = Math.round(coverage * 255);
    }
    return pixels;
  }

  function recolorDataUrl(dataUrl, color) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onerror = () => reject(new Error('Не удалось обработать одну из иконок.'));
      img.onload = () => {
        try {
          const canvas = document.createElement('canvas');
          canvas.width = img.naturalWidth || img.width; canvas.height = img.naturalHeight || img.height;
          const ctx = canvas.getContext('2d', { willReadFrequently: true });
          ctx.drawImage(img, 0, 0);
          const image = ctx.getImageData(0, 0, canvas.width, canvas.height);
          recolorPixels(image.data, canvas.width, canvas.height, color);
          ctx.putImageData(image, 0, 0);
          resolve(canvas.toDataURL('image/png'));
        } catch (e) { reject(e); }
      };
      img.src = dataUrl;
    });
  }

  async function putIcon(store, w, png) {
    const asset = {
      id: makeAssetId(), name: `weather_${w.index}_${w.id}`, dataUrl: png.dataUrl,
      width: png.width, height: png.height, format: 'PNG', size: png.size, weatherIcon: w.id,
    };
    const tint = store.state.weatherIconsColor;
    if (tint) {
      asset.weatherIconOriginalDataUrl = png.dataUrl;
      asset.dataUrl = await recolorDataUrl(png.dataUrl, tint);
      asset.weatherIconTint = tint;
      asset.size = Math.round((asset.dataUrl.length - 22) * 0.75);
    }
    store.state.assets = (store.state.assets || []).filter((a) => a.weatherIcon !== w.id);
    store.state.assets.push(asset);
  }

  async function setOne(store, condId, file) {
    const w = set().find((x) => x.id === condId);
    if (!w) return;
    await putIcon(store, w, await fileToPng(file));
    store.commit();
  }

  function clearOne(store, condId) {
    store.state.assets = (store.state.assets || []).filter((a) => a.weatherIcon !== condId);
    store.commit();
  }

  function clearAll(store) {
    store.state.assets = (store.state.assets || []).filter((a) => !isIcon(a));
    store.commit();
  }

  async function applyColorToAll(store, color) {
    if (!/^#[0-9a-f]{6}$/i.test(String(color || ''))) throw new Error('Выберите цвет в формате HEX.');
    const icons = (store.state.assets || []).filter(isIcon);
    if (!icons.length) return 0;
    const prepared = [];
    for (const asset of icons) {
      const original = asset.weatherIconOriginalDataUrl || asset.dataUrl;
      const dataUrl = await recolorDataUrl(original, color);
      prepared.push({ asset, original, dataUrl });
    }
    for (const item of prepared) {
      item.asset.weatherIconOriginalDataUrl = item.original;
      item.asset.weatherIconTint = color;
      item.asset.dataUrl = item.dataUrl;
      item.asset.size = Math.round((item.dataUrl.length - 22) * 0.75);
    }
    store.state.weatherIconsColor = color;
    store.commit();
    return prepared.length;
  }

  function resetColor(store) {
    let restored = 0;
    for (const asset of store.state.assets || []) {
      if (!isIcon(asset) || !asset.weatherIconOriginalDataUrl) continue;
      asset.dataUrl = asset.weatherIconOriginalDataUrl;
      asset.size = Math.round((asset.dataUrl.length - 22) * 0.75);
      delete asset.weatherIconOriginalDataUrl;
      delete asset.weatherIconTint;
      restored++;
    }
    store.state.weatherIconsColor = null;
    store.commit();
    return restored;
  }

  // Пачка файлов → слоты.
  // mode 'name' — по имени файла (английское/русское название или номер), остальные —
  //               по порядку в свободные слоты;
  // mode 'order' — строго по порядку имён файлов, начиная со слота 0.
  async function distribute(store, files, mode) {
    const list = [...files].filter((f) => /image\/(png|jpeg)/.test(f.type) || /\.(png|jpe?g)$/i.test(f.name)).sort(natCmp);
    const report = { total: list.length, byName: 0, byOrder: 0, skipped: [], errors: [] };
    const slots = set();
    const target = new Map();    // index → file
    const rest = [];
    if (mode === 'order') {
      list.forEach((f, i) => { if (i < slots.length) target.set(i, f); else report.skipped.push(f.name); });
      report.byOrder = target.size;
    } else {
      // Два прохода: сначала по названию, потом по номеру, чтобы «03.png» не вытеснил «sunny.png».
      const pending = [];
      for (const f of list) {
        const idx = matchText(f.name);
        if (idx >= 0 && !target.has(idx)) { target.set(idx, f); report.byName++; } else pending.push(f);
      }
      for (const f of pending) {
        const idx = matchNumber(f.name);
        if (idx >= 0 && !target.has(idx)) { target.set(idx, f); report.byName++; } else rest.push(f);
      }
      const project = store.state;
      const free = slots.filter((w) => !target.has(w.index) && !assetFor(project, w.id));
      rest.forEach((f, i) => {
        if (i < free.length) { target.set(free[i].index, f); report.byOrder++; } else report.skipped.push(f.name);
      });
    }
    for (const [idx, f] of target) {
      try { await putIcon(store, slots[idx], await fileToPng(f)); } catch (e) { report.errors.push(e.message); }
    }
    store.commit();
    return report;
  }

  // ---- диалог ----
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  let dlg = null;

  function openDialog(store) {
    if (dlg) { dlg.remove(); dlg = null; }
    dlg = document.createElement('div');
    dlg.className = 'wi-overlay';
    dlg.innerHTML = `
      <div class="wi-dialog" role="dialog" aria-label="Иконки погоды">
        <div class="wi-head">
          <b>Иконки погоды</b>
          <span class="wi-count"></span>
          <button type="button" class="wi-close" title="Закрыть">✕</button>
        </div>
        <div class="wi-bulk">
          <label class="btn-file">Загрузить пачкой…
            <input type="file" class="wi-bulk-input" accept="image/png,image/jpeg" multiple hidden>
          </label>
          <select class="wi-mode" title="Как распределять файлы по слотам">
            <option value="name">по имени файла, остальные — по порядку</option>
            <option value="order">строго по порядку (по алфавиту, со слота 0)</option>
          </select>
          <button type="button" class="wi-clear-all">Очистить всё</button>
        </div>
        <div class="wi-color-tools">
          <label>Общий цвет <input type="color" class="wi-color" value="#ffffff" aria-label="Цвет всех иконок погоды"></label>
          <button type="button" class="wi-color-apply">Применить ко всем</button>
          <button type="button" class="wi-color-reset">Вернуть исходный цвет</button>
          <span class="wi-color-hint">для одноцветных иконок</span>
        </div>
        <div class="wi-report"></div>
        <div class="wi-grid"></div>
        <div class="wi-foot">Пустой слот на часах заменяется: ночные — дневными вариантами, остальные — иконкой «Неизвестно»;
          если нет и её — встроенной заглушкой. Файлы сохраняются в PNG, размер не меняется.</div>
      </div>`;
    document.body.appendChild(dlg);

    const grid = dlg.querySelector('.wi-grid');
    const report = dlg.querySelector('.wi-report');
    const close = () => { if (dlg) { dlg.remove(); dlg = null; } unsub && unsub(); };
    let unsub = null;
    dlg.querySelector('.wi-close').onclick = close;
    dlg.addEventListener('mousedown', (e) => { if (e.target === dlg) close(); });

    const render = () => {
      const project = store.state;
      dlg.querySelector('.wi-count').textContent = `загружено ${customCount(project)} из ${set().length}`;
      const colorInput = dlg.querySelector('.wi-color');
      if (project.weatherIconsColor) colorInput.value = project.weatherIconsColor;
      dlg.querySelector('.wi-color-apply').disabled = customCount(project) === 0;
      dlg.querySelector('.wi-color-reset').disabled = !project.weatherIconsColor;
      grid.innerHTML = set().map((w) => {
        const own = assetFor(project, w.id);
        const r = resolveIndex(project, w.index);
        let thumb, sub;
        if (own) {
          thumb = `<img src="${own.dataUrl}" alt="">`; sub = `${own.width}×${own.height}`;
        } else if (r.source === 'fallback') {
          thumb = `<img class="wi-dim" src="${r.asset.dataUrl}" alt="">`;
          sub = `пусто → как «${esc(set()[r.fromIndex].label)}»`;
        } else {
          thumb = `<span class="wi-dim">${esc(w.glyph)}</span>`; sub = 'пусто → заглушка';
        }
        return `<div class="wi-slot ${own ? 'has' : ''}" data-id="${w.id}">
          <div class="wi-thumb">${thumb}</div>
          <div class="wi-meta"><div class="wi-name">${w.index}. ${esc(w.label)}</div>
            <div class="wi-sub">${esc(w.id)} · ${sub}</div></div>
          <label class="btn-file wi-up" title="Загрузить иконку в этот слот">↑
            <input type="file" accept="image/png,image/jpeg" hidden data-id="${w.id}">
          </label>
          <button type="button" class="wi-del" data-id="${w.id}" ${own ? '' : 'disabled'} title="Очистить слот">✕</button>
        </div>`;
      }).join('');
      grid.querySelectorAll('input[type=file]').forEach((inp) => {
        inp.onchange = async () => {
          const f = inp.files && inp.files[0];
          if (!f) return;
          try { await setOne(store, inp.dataset.id, f); } catch (e) { report.textContent = e.message; }
        };
      });
      grid.querySelectorAll('.wi-del').forEach((b) => { b.onclick = () => clearOne(store, b.dataset.id); });
    };

    dlg.querySelector('.wi-bulk-input').onchange = async (e) => {
      const files = e.target.files;
      if (!files || !files.length) return;
      const mode = dlg.querySelector('.wi-mode').value;
      report.textContent = 'Загружаю…';
      const r = await distribute(store, files, mode);
      const parts = [`Файлов: ${r.total}`];
      if (mode === 'name') parts.push(`по имени: ${r.byName}`, `по порядку: ${r.byOrder}`); else parts.push(`размещено: ${r.byOrder}`);
      if (r.skipped.length) parts.push(`не поместилось: ${r.skipped.length} (${r.skipped.slice(0, 3).join(', ')}${r.skipped.length > 3 ? '…' : ''})`);
      if (r.errors.length) parts.push(`ошибки: ${r.errors.join('; ')}`);
      report.textContent = parts.join(' · ') + '. Проверьте слоты и при необходимости замените вручную.';
      e.target.value = '';
    };
    dlg.querySelector('.wi-clear-all').onclick = () => {
      if (customCount(store.state) && confirm('Удалить все загруженные иконки погоды?')) clearAll(store);
    };
    dlg.querySelector('.wi-color-apply').onclick = async () => {
      const button = dlg.querySelector('.wi-color-apply');
      button.disabled = true;
      report.textContent = 'Перекрашиваю иконки…';
      try {
        const count = await applyColorToAll(store, dlg.querySelector('.wi-color').value);
        report.textContent = `Цвет изменён у ${count} иконок. Исходники сохранены.`;
      } catch (e) { report.textContent = e.message || 'Не удалось изменить цвет иконок.'; }
      finally { if (dlg) button.disabled = customCount(store.state) === 0; }
    };
    dlg.querySelector('.wi-color-reset').onclick = () => {
      const count = resetColor(store);
      report.textContent = `Исходный вид восстановлен у ${count} иконок.`;
    };

    // Таблица перерисовывается при любых изменениях проекта (кроме момента, когда диалог закрыт).
    unsub = store.subscribe(() => { if (dlg) render(); });
    render();
  }

  return {
    assetFor, customCount, missing, resolveIndex, dataUrlFor, dataUrlForComponent, frameKey, previewAsset, matchFileName,
    recolorPixels, applyColorToAll, resetColor, setOne, clearOne, clearAll, distribute, openDialog, isIcon,
  };
})();

if (typeof window !== 'undefined') window.WeatherIcons = WeatherIcons;
if (typeof module !== 'undefined' && module.exports) module.exports = WeatherIcons;
