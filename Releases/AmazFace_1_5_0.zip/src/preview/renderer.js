// Shared preview renderer: the same raster engine is used by the editor and
// exported preview image. Coordinates are always device pixels.
(function () {
  const fontCache = new Map();
  const imageCache = new Map();

  function loadImage(dataUrl) {
    if (!dataUrl) return Promise.resolve(null);
    if (imageCache.has(dataUrl)) return imageCache.get(dataUrl);
    const p = new Promise(resolve => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => resolve(null);
      img.src = dataUrl;
    });
    imageCache.set(dataUrl, p);
    return p;
  }

  async function registerProjectFont(font) {
    if (!font || !font.dataUrl || !font.cssFamily || !window.FontFace) return;
    if (fontCache.has(font.id)) return fontCache.get(font.id);
    const p = (async () => {
      try {
        const ff = new FontFace(font.cssFamily, `url(${font.dataUrl})`);
        await ff.load();
        document.fonts.add(ff);
      } catch (e) { console.warn('Font preview load failed:', font.name, e); }
    })();
    fontCache.set(font.id, p);
    return p;
  }
  window.registerProjectFont = registerProjectFont;

  const WEEKDAYS_SHORT = {
    EN: ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'],
    RU: ['ВС', 'ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ']
  };
  const WEEKDAYS_RU_3 = ['ВОС', 'ПОН', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ'];
  const WEEKDAYS_FULL = {
    EN: ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'],
    RU: ['ВОСКРЕСЕНЬЕ', 'ПОНЕДЕЛЬНИК', 'ВТОРНИК', 'СРЕДА', 'ЧЕТВЕРГ', 'ПЯТНИЦА', 'СУББОТА']
  };
  const MONTHS_SHORT = {
    EN: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    RU: ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек']
  };
  const MONTHS_FULL = {
    EN: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
    RU: ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря']
  };
  const previewLocale = v => v === 'RU' ? 'RU' : 'EN';

  function getEffectiveDataSource(comp, def) {
    if (def && def.dataSource) return def.dataSource;
    return comp?.props?.data_source || 'NONE';
  }

  // Источники, которые в режиме «Живое время» берутся из реальных часов компьютера.
  const LIVE_SOURCES = new Set(['TIME', 'AMPM', 'DATE', 'WEEKDAY', 'HOUR', 'MINUTE', 'SECOND', 'DAY', 'MONTH', 'YEAR']);
  const DATE_SOURCES = new Set(['DATE', 'WEEKDAY', 'DAY', 'MONTH', 'YEAR']);

  function fitWeatherIconRect(comp, image) {
    const iw = Math.max(1, Number(image.naturalWidth || image.width) || 1);
    const ih = Math.max(1, Number(image.naturalHeight || image.height) || 1);
    const w = Math.max(1, Number(comp.w) || iw);
    const h = Math.max(1, Number(comp.h) || ih);
    const scale = Math.min(1, w / iw, h / ih); // never enlarge a small source icon
    const dw = iw * scale, dh = ih * scale;
    return {
      x: Number(comp.x || 0) + (w - dw) / 2,
      y: Number(comp.y || 0) + (h - dh) / 2,
      w: dw,
      h: dh,
    };
  }

  // liveTime=true — только предпросмотр в редакторе: время/дата идут по реальным часам
  // (форматирование — componentPreviewText из canvas.js). Экспорт и превью-PNG его не передают.
  function textFor(comp, def, fixedTime, liveTime, currentNow) {
    const p = comp.props || {};
    const source = getEffectiveDataSource(comp, def);
    // Формат времени/даты/дня недели/месяца считает одна функция (componentPreviewText) —
    // и для живых часов, и для фиксированной даты 18.09.2026 10:09:36 (пятница),
    // поэтому все выбранные форматы и языки применяются на холсте так же, как в экспорте.
    const useCurrent = !!currentNow && (liveTime || DATE_SOURCES.has(source));
    if ((liveTime || fixedTime || useCurrent) && LIVE_SOURCES.has(source) && typeof componentPreviewText === 'function') {
      let at = null;
      if (useCurrent) {
        at = currentNow;
      } else if (!liveTime) {
        const wi = Number.isInteger(p.__weekday_index) ? p.__weekday_index : 5;
        at = new Date(2026, 8, 13 + wi, 10, 9, 36); // 13.09.2026 — воскресенье
      }
      const txt = componentPreviewText(comp, def, at);
      if (txt != null) return txt;
    }
    // Выбранный источник данных всегда важнее статического поля TEXT.
    if (source === 'NONE' || !source) return p.text ?? '';
    if (def.widgetId === 'DIGITAL_DISPLAY') {
      const fmt = String(p.format || 'HH:MM'), sep = String(p.separator ?? ':');
      if (source === 'TIME') {
        const h = fmt.startsWith('hh') ? 10 : 10;
        let out = pad2(h);
        if (fmt.includes('MM')) out += sep + '09';
        if (fmt.includes('SS')) out += sep + '36';
        return out;
      }
      if (source === 'DATE') {
        const dateSep = (sep === '.' || sep === '/' || sep === ' ') ? sep : '.';
        // Форматы дня недели для источника «Дата» должны совпадать с холстом.
        if (fmt === 'EEE' || fmt === 'EEE3' || fmt === 'EEEE') {
          const loc = previewLocale(p.weekday_locale || p.date_locale);
          const wi = Number.isInteger(p.__weekday_index) ? p.__weekday_index : 5;
          if (loc === 'RU' && fmt === 'EEE3') return WEEKDAYS_RU_3[wi];
          return (fmt === 'EEEE' ? WEEKDAYS_FULL : WEEKDAYS_SHORT)[loc][wi];
        }
        if (fmt === 'DD') return '18';
        if (fmt === 'MM') return '09';
        if (fmt === 'YYYY') return '2026';
        if (fmt === 'DD.MM') return '18' + dateSep + '09';
        if (fmt === 'YYYY-MM-DD') return '2026-09-18';
        if (fmt === 'DD/MM') return '18/09';
        if (fmt === 'DD MMM') return '18 Sep';
        if (fmt === 'MMM DD') return 'Sep 18';
        if (fmt === 'DD MMMM') return '18 September';
        return '18' + dateSep + '09' + dateSep + '2026';
      }
      if (source === 'HOUR') return '10';
      if (source === 'MINUTE') return '09';
      if (source === 'SECOND') return '36';
      if (source === 'DAY') return '18';
      if (source === 'MONTH') return '09';
      if (source === 'YEAR') return '2026';
      if (source === 'BATTERY') return '82';
      if (source === 'STEP') return '8452';
      if (source === 'HEART') return '72';
      if (source === 'CALORIE') return '340';
      if (source === 'DISTANCE') return '4.2';
      if (source === 'ALTITUDE') return '185';
      if (source === 'AIR_PRESSURE') return '1013';
    }
    if (fixedTime) {
      if (source === 'TIME') {
        // Для статического растрового слоя используем репрезентативные цифры,
        // но учитываем выбранный формат, включая секунды у обычного «Текста».
        const isPreset = def.id !== 'text';
        const fmt = String(isPreset ? (p.format || 'HH:MM') : (p.time_format || 'HH:MM'));
        const sep = isPreset ? ':' : String(p.time_separator ?? ':');
        let out = '10';
        if (fmt.includes('MM')) out += sep + '09';
        if (fmt.includes('SS')) out += sep + '36';
        return out;
      }
      if (source === 'AMPM') return 'AM';
      if (source === 'HOUR') return '10';
      if (source === 'MINUTE') return '09';
      if (source === 'SECOND') return '36';
      if (source === 'DATE') {
        const loc = previewLocale(p.date_locale);
        const m = 8;
        const short = MONTHS_SHORT[loc][m];
        const full = MONTHS_FULL[loc][m];
        const dfmt = def.id === 'text' ? (p.date_format || 'DD.MM.YYYY') : p.format;
        if (dfmt === 'DD') return '18';
        if (dfmt === 'MM') return '09';
        if (dfmt === 'YYYY') return '2026';
        if (dfmt === 'DD.MM') return '18.09';
        if (dfmt === 'DD/MM') return '18/09';
        if (dfmt === 'YYYY-MM-DD') return '2026-09-18';
        if (dfmt === 'DD MMM') return `18 ${short}`;
        if (dfmt === 'MMM DD') return `${short} 18`;
        if (dfmt === 'DD MMMM') return `18 ${full}`;
        return '18.09.2026';
      }
      if (source === 'WEEKDAY') {
        const loc = previewLocale(p.weekday_locale);
        // У универсального «Текста» формат лежит в weekday_format, у пресета — в format.
        const wfmt = def.id === 'text' ? (p.weekday_format || 'EEE') : p.format;
        const wi = Number.isInteger(p.__weekday_index) ? p.__weekday_index : 5;
        if (loc === 'RU' && wfmt === 'EEE3') return WEEKDAYS_RU_3[wi];
        return (wfmt === 'EEEE' ? WEEKDAYS_FULL : WEEKDAYS_SHORT)[loc][wi];
      }
      if (source === 'DAY') return '18';
      if (source === 'MONTH') {
        const loc = previewLocale(p.month_locale);
        if (p.month_format === 'MMM') return MONTHS_SHORT[loc][8];
        if (p.month_format === 'MMMM') return MONTHS_FULL[loc][8];
        return '09';
      }
      if (source === 'YEAR') return '2026';
      if (source === 'ALTITUDE') {
        const prefix = p.prefix || '';
        const suffix = p.suffix ?? ' м';
        const decimals = p.altitude_decimals === '1' ? 1 : 0;
        return prefix + (decimals ? '185.0' : '185') + suffix;
      }
      if (source === 'AIR_PRESSURE') {
        const prefix = p.prefix || '';
        const suffix = p.suffix ?? ' hPa';
        const decimals = p.pressure_decimals === '1' ? 1 : 0;
        return prefix + (decimals ? '1013.2' : '1013') + suffix;
      }
      const nativePreview = { STEP_TARGET:'10000', CAL_TARGET:'500', PAI_DAILY:'42', PAI_WEEKLY:'180', STAND:'8 ч', STAND_TARGET:'12 ч', HUMIDITY:'42%', UVI:'4', AQI:'26', FAT_BURNING:'35 мин', FAT_BURNING_TARGET:'60 мин', SUN_CURRENT:'02:14', SUN_RISE:'06:30', SUN_SET:'19:42', WIND:'4', STRESS:'32', SPO2:'98%', BODY_TEMP:'36.5 °C', FLOOR:'12', ALARM_CLOCK:'07:00', COUNT_DOWN:'05:00', STOP_WATCH:'12:34', SLEEP:'07:42', TRAINING_LOAD:'68', VO2MAX:'42', RECOVERY_TIME:'18', MONTH_RUN_TIMES:'8', MONTH_RUN_DISTANCE:'54.2', READINESS:'82' };
      if (nativePreview[source]) return nativePreview[source];
      if (source === 'CALORIE') {
        const prefix = p.prefix || '';
        const suffix = p.suffix ?? ' kcal';
        const temp = '350';
        return prefix + temp + suffix;
      }
      if (source === 'WEATHER_TEMP') {
        const temp = ({ LOW: '17', HIGH: '26' })[p.weather_temp_source] || '22';
        // На часах нативная привязка выводит только число и знак °, без буквы C/F.
        const degreeSymbol = (p.weather_show_degree !== false) ? '°' : '';
        return temp + degreeSymbol;
      }
    }
    if (typeof componentPreviewText === 'function') return componentPreviewText(comp, def);
    return String(comp.props?.text ?? def.name ?? '');
  }


  function clamp01(v){ return Math.max(0, Math.min(1, Number(v) || 0)); }
  function hexToRgb(hex){
    const h=String(hex||'#fff').replace('#','');
    const n=h.length===3?h.split('').map(x=>x+x).join(''):h;
    const x=parseInt(n,16); return Number.isFinite(x)?{r:(x>>16)&255,g:(x>>8)&255,b:x&255}:{r:255,g:255,b:255};
  }
  function rgba(hex,a){ const c=hexToRgb(hex); return `rgba(${c.r},${c.g},${c.b},${clamp01(a)})`; }
  function makeTextGradient(ctx, p, x, y, w, h){
    const mode=p.metallic_mode || p.fill_type || 'solid';
    if(mode==='metallicGold' || mode==='gold'){
      // Metallic Gold respects the user's selected colors. The old renderer
      // hard-coded yellow values, making the color picker appear broken.
      const top=p.color||'#ffd95a', bottom=p.gradient_to||'#6b3506';
      const g=ctx.createLinearGradient(x,y,x,y+h);
      const mix=(a,b,t)=>{const A=hexToRgb(a),B=hexToRgb(b);const c=k=>Math.round(A[k]*(1-t)+B[k]*t);return `rgb(${c('r')},${c('g')},${c('b')})`;};
      g.addColorStop(0,mix(top,'#ffffff',.72));
      g.addColorStop(.14,mix(top,'#fff3a0',.25));
      g.addColorStop(.38,top);
      g.addColorStop(.55,mix(top,bottom,.28));
      g.addColorStop(.72,mix(top,bottom,.55));
      g.addColorStop(1,bottom); return g;
    }
    if(mode==='gradient'){
      const g=ctx.createLinearGradient(x,y,x+w,y+h);
      g.addColorStop(0,p.gradient_from||p.color||'#fff'); g.addColorStop(1,p.gradient_to||'#555'); return g;
    }
    return p.color || '#fff';
  }
  // ---------------------------------------------------------------------------
  // «Вместить в границы» (fit_bounds): подбираем максимальный размер шрифта
  // (не больше заданного p.text_size), при котором строка помещается по
  // ширине и высоте бокса компонента (boxW×boxH, в тех же нескейленных
  // "проектных" пикселях, что и text_size/comp.w/h). ctx.measureText не
  // зависит от текущей трансформации/масштаба канваса, только от ctx.font —
  // поэтому меряем в проектных единицах напрямую, без домножения на scale.
  // ---------------------------------------------------------------------------
  function measureLineWidth(ctx, text, size, style, weight, family, ls){
    ctx.font = `${style||'normal'} ${weight||'400'} ${Math.max(1,size)}px ${family||'sans-serif'}`;
    if(!ls) return ctx.measureText(String(text)).width;
    const chars=[...String(text)];
    let w=0; for(const ch of chars) w+=ctx.measureText(ch).width+ls;
    return Math.max(0,w-ls);
  }
  function fitTextSize(ctx, text, p, boxW, boxH){
    const family = p.__family || 'sans-serif';
    const style = p.font_style, weight = p.font_weight;
    const ls = Number(p.letter_spacing||0);
    const sx = Number(p.scale_x||1)||1, sy = Number(p.scale_y||1)||1;
    const minSize = Math.max(4, Number(p.fit_min_size) || 8);
    let size = Math.max(minSize, Math.round(Number(p.text_size) || 36));
    if (size <= minSize) return size;
    const PAD = 0.94; // небольшой запас, чтобы буквы не упирались впритык в рамку компонента
    const maxW = Math.max(1, Number(boxW||0) * PAD);
    const maxH = Math.max(1, Number(boxH||0) * PAD);
    const savedFont = ctx.font;
    const fits = s => {
      if (s * sy > maxH) return false;
      return measureLineWidth(ctx, text, s, style, weight, family, ls) * sx <= maxW;
    };
    while (size > minSize && !fits(size)) size -= 1;
    if (!fits(size)) size = minSize;
    ctx.font = savedFont;
    return size;
  }

  function textMetricsBox(ctx, text, p){
    const size=Number(p.text_size||36), ls=Number(p.letter_spacing||0);
    ctx.font=`${p.font_style||'normal'} ${p.font_weight||'400'} ${size}px ${p.__family||'sans-serif'}`;
    if(!ls) return {w:ctx.measureText(text).width,h:size};
    let w=0; for(const ch of String(text)) w+=ctx.measureText(ch).width+ls; return {w:Math.max(0,w-ls),h:size};
  }
  // ---------------------------------------------------------------------------
  // Текст по дуге (только компонент «Текст», статический). Символы раскладываются
  // по окружности радиуса arc_radius; якорь (0,0) — верхняя (или нижняя при
  // arc_bottom) точка окружности. Возвращает позицию/поворот каждого символа.
  // ---------------------------------------------------------------------------
  // Путь скруглённого прямоугольника (радиус уже ограничен половиной меньшей стороны).
  function roundRectPath(ctx, x, y, w, h, r){
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y); ctx.arcTo(x + w, y, x + w, y + r, r);
    ctx.lineTo(x + w, y + h - r); ctx.arcTo(x + w, y + h, x + w - r, y + h, r);
    ctx.lineTo(x + r, y + h); ctx.arcTo(x, y + h, x, y + h - r, r);
    ctx.lineTo(x, y + r); ctx.arcTo(x, y, x + r, y, r);
    ctx.closePath();
  }

  function arcLayout(ctx, chars, p){
    const R=Math.max(1,Number(p.arc_radius)||150), ls=Number(p.letter_spacing||0), bottom=!!p.arc_bottom;
    const widths=chars.map(ch=>ctx.measureText(ch).width);
    const total=Math.max(0,widths.reduce((a,w)=>a+w,0)+Math.max(0,chars.length-1)*ls);
    let s=-total/2; const out=[];
    for(let i=0;i<chars.length;i++){
      const sc=s+widths[i]/2, th=sc/R;
      out.push(bottom
        ? {x:R*Math.sin(th), y:-R+R*Math.cos(th), rot:-th}
        : {x:R*Math.sin(th), y:R-R*Math.cos(th), rot:th});
      s+=widths[i]+ls;
    }
    return out;
  }
  function arcTextExtent(project, comp){
    const def=REGISTRY[comp.defId]; if(!def) return null;
    const p=comp.props||{};
    const variants = arcIsWeekday(comp) ? [0,1,2,3,4,5,6].map(i=>textFor({...comp,props:{...p,__weekday_index:i}},def,true)) : [textFor(comp,def,true)];
    const pf=(project.fonts||[]).find(f=>f.id===p.font);
    const family=pf?`'${pf.cssFamily||pf.name}'`:'sans-serif';
    const size=Number(p.text_size||36);
    const c=document.createElement('canvas').getContext('2d');
    c.font=`${p.font_style||'normal'} ${p.font_weight||'400'} ${size}px ${family}`;
    let hw=0,hh=0;
    for(const text0 of variants){
      const text=p.text_transform==='uppercase'?String(text0).toUpperCase():p.text_transform==='lowercase'?String(text0).toLowerCase():String(text0);
      const lay=arcLayout(c,[...text],Object.assign({},p,{arc_radius:Number(p.arc_radius)||150}));
      for(const L of lay){ hw=Math.max(hw,Math.abs(L.x)); hh=Math.max(hh,Math.abs(L.y)); }
    }
    const m=size*1.1*Math.max(Number(p.scale_x||1),Number(p.scale_y||1),1);
    hw+=m; hh+=m;
    if(Number(comp.rotation||p.rotation||0)){ const r=Math.hypot(hw,hh); hw=hh=r; }
    return { halfW:Math.ceil(hw), halfH:Math.ceil(hh) };
  }
  function arcIsActive(comp){
    if(!comp||comp.defId!=='text') return false;
    const p=comp.props||{};
    if(p.arc_enabled!==true || !(Number(p.arc_radius)>0)) return false;
    const def=REGISTRY[comp.defId];
    const src=typeof getEffectiveDataSource==='function'?getEffectiveDataSource(comp,def):'NONE';
    return !src||src==='NONE'||src==='WEEKDAY';
  }
  function arcIsWeekday(comp){
    if(!arcIsActive(comp)) return false;
    const def=REGISTRY[comp.defId];
    return (typeof getEffectiveDataSource==='function'?getEffectiveDataSource(comp,def):'NONE')==='WEEKDAY';
  }

  function drawSpacedStrokeText(ctx,text,x,y,p,lineWidth){
    const ls=Number(p.letter_spacing||0), chars=[...String(text)];
    const overrides=Array.isArray(p.char_overrides)?p.char_overrides:[];
    const bend=Number(p.warp_bend||0);
    const baseFont=ctx.font;
    if(p.arc_enabled && Number(p.arc_radius)>0){
      const lay=arcLayout(ctx,chars,p);
      ctx.save(); ctx.textAlign='center'; ctx.lineWidth=lineWidth;
      for(let i=0;i<chars.length;i++){
        const L=lay[i], o=overrides[i]||{};
        ctx.save();
        ctx.translate(x+L.x+Number(o.x||0), y+L.y+Number(o.y||0));
        ctx.rotate(L.rot+Number(o.rotation||0)*Math.PI/180);
        ctx.scale(Number(o.scale_x||1),Number(o.scale_y||1));
        if(o.color) ctx.strokeStyle=o.color;
        if(o.alpha!=null) ctx.globalAlpha*=o.alpha;
        ctx.strokeText(chars[i],0,0);
        ctx.restore();
      }
      ctx.restore(); ctx.font=baseFont; return;
    }
    const widths=chars.map(ch=>ctx.measureText(ch).width);
    const total=Math.max(0,widths.reduce((a,w)=>a+w,0)+Math.max(0,chars.length-1)*ls);
    let xx=p.align_h==='LEFT'?x:p.align_h==='RIGHT'?x-total:x-total/2;
    ctx.lineWidth=lineWidth;
    for(let i=0;i<chars.length;i++){
      const ch=chars[i], o=overrides[i]||{};
      const w=widths[i];
      const center=(xx+(w/2)-x)/(total||1);
      const bendY=bend*center*center*24;
      const bendRot=(bend/100)*center*0.55;
      ctx.save();
      ctx.translate(xx+w/2+Number(o.x||0), y+bendY+Number(o.y||0));
      ctx.rotate((Number(o.rotation||0)*Math.PI/180)+bendRot);
      ctx.scale(Number(o.scale_x||1),Number(o.scale_y||1));
      if(o.color) ctx.strokeStyle=o.color;
      if(o.alpha!=null) ctx.globalAlpha*=o.alpha;
      ctx.strokeText(ch,0,0);
      ctx.restore();
      xx+=w+ls;
    }
    ctx.font=baseFont;
  }

  function drawSpacedText(ctx,text,x,y,p){
    const ls=Number(p.letter_spacing||0), chars=[...String(text)];
    const overrides=Array.isArray(p.char_overrides)?p.char_overrides:[];
    const bend=Number(p.warp_bend||0);
    if(p.arc_enabled && Number(p.arc_radius)>0){
      const lay=arcLayout(ctx,chars,p);
      ctx.save(); ctx.textAlign='center';
      for(let i=0;i<chars.length;i++){
        const L=lay[i], o=overrides[i]||{};
        ctx.save();
        ctx.translate(x+L.x+Number(o.x||0), y+L.y+Number(o.y||0));
        ctx.rotate(L.rot+Number(o.rotation||0)*Math.PI/180);
        ctx.scale(Number(o.scale_x||1),Number(o.scale_y||1));
        if(o.color) ctx.fillStyle=o.color;
        if(o.alpha!=null) ctx.globalAlpha*=o.alpha;
        ctx.fillText(chars[i],0,0);
        ctx.restore();
      }
      ctx.restore(); return;
    }
    if(!ls && !overrides.length && !bend){ ctx.fillText(text,x,y); return; }
    const widths=chars.map(ch=>ctx.measureText(ch).width);
    const total=Math.max(0,widths.reduce((a,w)=>a+w,0)+Math.max(0,chars.length-1)*ls);
    let xx=p.align_h==='LEFT'?x:p.align_h==='RIGHT'?x-total:x-total/2;
    for(let i=0;i<chars.length;i++){
      const ch=chars[i], o=overrides[i]||{}, w=widths[i];
      const center=(xx+(w/2)-x)/(total||1);
      const bendY=bend*center*center*24;
      const bendRot=(bend/100)*center*0.55;
      ctx.save();
      ctx.translate(xx+w/2+Number(o.x||0), y+bendY+Number(o.y||0));
      ctx.rotate((Number(o.rotation||0)*Math.PI/180)+bendRot);
      ctx.scale(Number(o.scale_x||1),Number(o.scale_y||1));
      if(o.color) ctx.fillStyle=o.color;
      if(o.alpha!=null) ctx.globalAlpha*=o.alpha;
      ctx.fillText(ch,0,0);
      ctx.restore();
      xx+=w+ls;
    }
  }

  /** Точка привязки текста в рамке компонента (в device-пикселях) по align_h / align_v. */
  function textAnchor(comp, p, centerOnly) {
    const ah = centerOnly ? 'CENTER_H' : p.align_h, av = centerOnly ? 'CENTER_V' : p.align_v;
    return {
      x: ah === 'LEFT' ? comp.x : ah === 'RIGHT' ? comp.x + comp.w : comp.x + comp.w / 2,
      y: av === 'TOP' ? comp.y : av === 'BOTTOM' ? comp.y + comp.h : comp.y + comp.h / 2
    };
  }

  function drawStyledText(ctx,text,tx,ty,p,scale){
    if(p.text_transform==='uppercase') text=String(text).toUpperCase();
    else if(p.text_transform==='lowercase') text=String(text).toLowerCase();
    const m=textMetricsBox(ctx,text,p), sx=Number(p.scale_x||1), sy=Number(p.scale_y||1);
    ctx.save();
    ctx.translate(tx,ty); ctx.rotate(Number(p.rotation||0)*Math.PI/180); ctx.scale(sx,sy);
    const skewX=Number(p.skew_x||0)*Math.PI/180, skewY=Number(p.skew_y||0)*Math.PI/180;
    if(skewX||skewY) ctx.transform(1,Math.tan(skewY),Math.tan(skewX),1,0,0);
    ctx.textAlign=p.align_h==='LEFT'?'left':p.align_h==='RIGHT'?'right':'center';
    ctx.textBaseline=p.align_v==='TOP'?'top':p.align_v==='BOTTOM'?'bottom':'middle';
    const anchorX=0, anchorY=0;
    const fill=makeTextGradient(ctx,p,p.align_h==='LEFT'?0:p.align_h==='RIGHT'?-m.w:-m.w/2,p.align_v==='TOP'?0:p.align_v==='BOTTOM'?-m.h:-m.h/2,m.w,m.h);
    const angle=Number(p.cast_shadow_angle??135)*Math.PI/180;
    const elevation=Math.max(1,Number(p.cast_shadow_elevation??45));
    const depth=Math.max(0,Number(p.depth||0));
    const shadowDist=Math.max(0,Number(p.cast_shadow_distance??(depth*1.5)));
    const shadowDx=Number.isFinite(Number(p.extrusion_x))?Number(p.extrusion_x):Math.cos(angle)*shadowDist;
    const shadowDy=Number.isFinite(Number(p.extrusion_y))?Number(p.extrusion_y):Math.sin(angle)*shadowDist*Math.max(.25,1/Math.tan(elevation));
    const shadowColor=p.cast_shadow_color||'#000000';

    if(p.glow_enabled){
      ctx.save(); ctx.globalAlpha=clamp01((p.glow_opacity??45)/100); ctx.filter=`blur(${Math.max(0,Number(p.glow_blur??8))}px)`; ctx.fillStyle=rgba(p.glow_color||p.color||'#ffd65a',1); drawSpacedText(ctx,text,anchorX,anchorY,p); ctx.restore();
    }
    if(p.cast_shadow_enabled){
      ctx.save();
      const density=clamp01((p.cast_shadow_opacity??42)/100);
      ctx.globalAlpha=density; ctx.fillStyle=rgba(shadowColor,1);
      const len=Math.max(0,Number(p.cast_shadow_length??shadowDist));
      const fall=clamp01(Number(p.cast_shadow_falloff??65)/100);
      const steps=Math.max(2,Math.min(24,Math.ceil(len/2)+2));
      for(let i=steps;i>=1;i--){
        const t=i/steps, fade=Math.pow(t,1+fall*2);
        ctx.save(); ctx.globalAlpha=density*fade; ctx.filter=`blur(${Math.max(0,Number(p.cast_shadow_blur??3))*(.55+.75*(1-t))}px)`;
        const dx=shadowDx*(i/steps), dy=shadowDy*(i/steps);
        ctx.translate(dx,dy);
        const persp=Number(p.cast_shadow_perspective||0)/100;
        if(persp) ctx.transform(1,0,persp*(i/steps),1,0,0);
        drawSpacedText(ctx,text,anchorX,anchorY,p); ctx.restore();
      }
      ctx.restore();
    }
    if(p.drop_shadow_enabled){
      ctx.save(); ctx.globalAlpha=clamp01((p.drop_shadow_opacity??35)/100); ctx.filter=`blur(${Math.max(0,Number(p.drop_shadow_blur??4))}px)`; ctx.fillStyle=rgba(p.drop_shadow_color||'#000',1); ctx.translate(Number(p.drop_shadow_x||2),Number(p.drop_shadow_y||2)); drawSpacedText(ctx,text,anchorX,anchorY,p); ctx.restore();
    }
    if(depth>0){
      const ex=Number.isFinite(Number(p.extrusion_x))?Number(p.extrusion_x)/Math.max(1,depth):Math.cos(angle), ey=Number.isFinite(Number(p.extrusion_y))?Number(p.extrusion_y)/Math.max(1,depth):Math.sin(angle);
      const layers=Math.max(1,Math.min(40,Math.round(Number(p.extrusion_layers||depth*2))));
      const sideTop=p.side_color||'#5a3108', sideBottom=p.side_color_dark||'#241204';
      for(let i=layers;i>=1;i--){
        const t=i/layers; ctx.save(); ctx.fillStyle=`rgb(${Math.round(hexToRgb(sideTop).r*(1-t)+hexToRgb(sideBottom).r*t)},${Math.round(hexToRgb(sideTop).g*(1-t)+hexToRgb(sideBottom).g*t)},${Math.round(hexToRgb(sideTop).b*(1-t)+hexToRgb(sideBottom).b*t)})`;
        ctx.translate(ex*depth*(i/layers),ey*depth*(i/layers)); drawSpacedText(ctx,text,anchorX,anchorY,p); ctx.restore();
      }
    }
    if(p.contact_shadow_enabled){
      ctx.save(); ctx.globalCompositeOperation='source-over'; ctx.globalAlpha=clamp01((p.contact_shadow_opacity??45)/100); ctx.filter=`blur(${Math.max(.2,Number(p.contact_shadow_blur??2))}px)`; ctx.fillStyle=rgba(p.contact_shadow_color||'#000',1); ctx.translate(Number(p.contact_shadow_x||1),Number(p.contact_shadow_y||2)); drawSpacedText(ctx,text,anchorX,anchorY,p); ctx.restore();
    }
    if(p.outline_enabled){
      ctx.save(); ctx.globalAlpha=clamp01((p.outline_opacity??90)/100); ctx.strokeStyle=p.outline_color||'#1b1006';
      drawSpacedStrokeText(ctx,text,anchorX,anchorY,p,Math.max(.5,Number(p.outline_width||1.2)*2)); ctx.restore();
    }
    ctx.save(); ctx.fillStyle=fill; drawSpacedText(ctx,text,anchorX,anchorY,p); ctx.restore();

    const bevel=Number(p.bevel_size||0);
    if(bevel>0){
      const smooth=clamp01((p.bevel_smoothness??70)/100);
      const prof=p.bevel_profile||'soft';
      const bright=prof==='hard'?1:prof==='deep'?1.2:.85;
      ctx.save(); ctx.globalCompositeOperation='source-atop'; ctx.globalAlpha=clamp01((p.top_highlight_opacity??55)/100)*bright; ctx.strokeStyle=p.top_highlight_color||'#fff6c0'; ctx.lineWidth=Math.max(.5,bevel*(.65+smooth*.45)); ctx.translate(-bevel*.35,-bevel*.35); drawSpacedStrokeText(ctx,text,anchorX,anchorY,p,ctx.lineWidth); ctx.restore();
      ctx.save(); ctx.globalCompositeOperation='source-atop'; ctx.globalAlpha=clamp01((p.inner_shadow_opacity??28)/100); ctx.strokeStyle=p.inner_shadow_color||'#4b2605'; ctx.lineWidth=Math.max(.5,bevel*(.65+smooth*.5)); ctx.translate(bevel*.35,bevel*.35); drawSpacedStrokeText(ctx,text,anchorX,anchorY,p,ctx.lineWidth); ctx.restore();
    }
    if(Number(p.specular_opacity||0)>0){
      ctx.save(); ctx.globalCompositeOperation='source-atop'; ctx.globalAlpha=clamp01(Number(p.specular_opacity)/100); ctx.filter=`blur(${Math.max(.2,Number(p.specular_blur??1))}px)`; ctx.strokeStyle=p.specular_color||'#ffffff'; ctx.lineWidth=Math.max(.5,Number(p.specular_width??2)); ctx.translate(Number(p.specular_offset_x||-1),Number(p.specular_offset_y||-1)); drawSpacedStrokeText(ctx,text,anchorX,anchorY,p,ctx.lineWidth); ctx.restore();
    }
    if(Number(p.reflection_opacity||0)>0){
      ctx.save(); ctx.globalCompositeOperation='source-atop'; ctx.globalAlpha=clamp01(Number(p.reflection_opacity)/100) * clamp01(Number(p.metallic??90)/100) * (1-clamp01(Number(p.roughness??25)/100)*.55); const rg=ctx.createLinearGradient(0,-m.h,0,m.h); rg.addColorStop(0,p.reflection_color||'#ffffff'); rg.addColorStop(.35,rgba(p.reflection_color||'#ffffff',.05)); rg.addColorStop(.6,'rgba(0,0,0,0)'); rg.addColorStop(1,'rgba(0,0,0,0)'); ctx.fillStyle=rg; drawSpacedText(ctx,text,anchorX,anchorY,p); ctx.restore();
    }
    ctx.restore();
  }

  async function draw(project, canvas, opts = {}) {
    const dw = project.device?.w || 480, dh = project.device?.h || 480;
    const size = opts.size || canvas.width || 324;
    const renderSize = opts.highQuality ? size * 4 : size;
    const frameNow = (opts.liveTime || opts.currentDate) ? (opts.now || new Date()) : null;
    canvas.width = renderSize; canvas.height = renderSize;
    const ctx = canvas.getContext('2d');
    const scale = renderSize / Math.max(dw, dh);
    const X = n => Number(n || 0) * scale;
    ctx.clearRect(0, 0, renderSize, renderSize);
    // Exported premium-text PNGs must keep a real transparent background.
    // The normal preview still paints the project background; only an explicit
    // transparentBackground render skips that fill.
    ctx.save();
    if (!opts.transparentBackground) {
      ctx.globalAlpha = Math.max(0, Math.min(100, Number(project.background?.alpha ?? 100))) / 100;
      ctx.fillStyle = project.background?.color || '#000';
      ctx.fillRect(0, 0, renderSize, renderSize);
    }

    const assets = new Map((project.assets || []).map(a => [a.id, a]));
    const imgs = new Map();
    await Promise.all((project.assets || []).map(async a => imgs.set(a.id, await loadImage(AssetBg.url(a)))));
    for (const f of project.fonts || []) await registerProjectFont(f);
    
    // Check if this render is still current after async asset loading
    if (opts.validateToken && !opts.validateToken()) return;

    // Кадр предпросмотра анимации фона (не сохраняется в проект) подменяет статичный фон.
    let bgId = opts.bgFrameId || project.background?.imageAssetId;
    if (!opts.bgFrameId && !(bgId && assets.has(bgId))) {
      // нет картинки фона, но есть анимация фона — статичным фоном служит её первый кадр
      const an = project.background?.anim;
      const first = an && an.enabled && Array.isArray(an.frames) ? an.frames.find((id) => assets.has(id)) : null;
      if (first) bgId = first;
    }
    const bg = assets.get(bgId);
    if (bg) { const im = imgs.get(bg.id); if (im) ctx.drawImage(im, 0, 0, renderSize, renderSize); }
    ctx.restore();

    // Единый порядок слоёв: массив components хранится СНИЗУ ВВЕРХ.
    // Поэтому рисуем строго слева направо по массиву без сортировок: последний
    // компонент физически находится поверх предыдущих. Это тот же порядок,
    // который показывает LayersPanel (там список развёрнут, чтобы верхний слой
    // был первым визуально).
    const comps = (project.components || []).filter(c => c.visible !== false);
    for (let layerIndex = 0; layerIndex < comps.length; layerIndex++) {
      const comp = comps[layerIndex];
      const def = REGISTRY[comp.defId]; if (!def) continue;
      if (opts.testMode && def.widgetId === 'TIME_POINTER') continue;
      const p = comp.props || {};
      ctx.save(); ctx.globalAlpha = Math.max(0, Math.min(100, Number(p.alpha ?? 100))) / 100;
      if (def.widgetId === 'WEEKDAY_STRIP') {
        const slots = WeekdayStripModel.layout(comp, p);
        const active = WeekdayStripModel.activeIndex(p, new Date());
        const markerStyle = p.marker_style || 'FRAME';
        const markerColor = p.marker_color || '#ff3158';
        const containerStyle = p.container_style || 'NONE';
        if (containerStyle !== 'NONE') {
          ctx.save();
          ctx.globalAlpha *= Math.max(0, Math.min(100, Number(p.container_alpha ?? 100))) / 100;
          const cx = X(comp.x), cy = X(comp.y), cw = X(comp.w), ch = X(comp.h);
          const cr = Math.min(X(Number(p.container_radius) || 0), cw / 2, ch / 2);
          if (containerStyle === 'FILL' || containerStyle === 'FILL_FRAME') {
            ctx.fillStyle = p.container_color || '#000000';
            if (cr > 0) { ctx.beginPath(); roundRectPath(ctx, cx, cy, cw, ch, cr); ctx.fill(); }
            else ctx.fillRect(cx, cy, cw, ch);
          }
          ctx.restore();
        }
        if (markerStyle !== 'NONE') {
          const slot = slots[active], m = slot.marker;
          const mw = X(m.w), mh = X(m.h), mx = X(m.x), my = X(m.y);
          ctx.save();
          ctx.globalAlpha *= Math.max(0, Math.min(100, Number(p.marker_alpha ?? 100))) / 100;
          ctx.fillStyle = markerColor; ctx.strokeStyle = p.marker_border_color || markerColor;
          const radius = Math.min(X(Number(p.marker_radius) || 0), mw / 2, mh / 2);
          if (markerStyle === 'FILL' || markerStyle === 'FILL_FRAME') {
            if (radius > 0) { ctx.beginPath(); roundRectPath(ctx, mx - mw / 2, my - mh / 2, mw, mh, radius); ctx.fill(); }
            else ctx.fillRect(mx - mw / 2, my - mh / 2, mw, mh);
          }
          if (markerStyle === 'FRAME' || markerStyle === 'FILL_FRAME') {
            ctx.lineWidth = X(Math.max(1, Number(p.marker_line_width) || 2));
            if (radius > 0) { ctx.beginPath(); roundRectPath(ctx, mx - mw / 2, my - mh / 2, mw, mh, radius); ctx.stroke(); }
            else ctx.strokeRect(mx - mw / 2, my - mh / 2, mw, mh);
          } else if (markerStyle === 'UNDERLINE') {
            ctx.fillRect(mx - mw / 2, my - mh / 2, mw, mh);
          } else if (markerStyle === 'DOT') {
            ctx.beginPath(); ctx.arc(mx, my, mw / 2, 0, Math.PI * 2); ctx.fill();
          }
          ctx.restore();
        }
        ctx.font = `${p.font_style || 'normal'} ${p.font_weight || '400'} ${X(Number(p.text_size) || 20)}px sans-serif`;
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        for (const slot of slots) {
          ctx.fillStyle = slot.index === active ? (p.active_text_color || '#ffffff') : (p.text_color || '#ffffff');
          ctx.fillText(slot.label, X(slot.x), X(slot.y), X(slot.w));
        }
        // Keep the component outline above its marker and labels so it remains visible.
        if (containerStyle === 'FRAME' || containerStyle === 'FILL_FRAME') {
          ctx.save();
          ctx.globalAlpha *= Math.max(0, Math.min(100, Number(p.container_alpha ?? 100))) / 100;
          const cx = X(comp.x), cy = X(comp.y), cw = X(comp.w), ch = X(comp.h);
          const cr = Math.min(X(Number(p.container_radius) || 0), cw / 2, ch / 2);
          ctx.strokeStyle = p.container_border_color || '#ffffff';
          ctx.lineWidth = X(Math.max(1, Number(p.container_line_width) || 2));
          if (cr > 0) { ctx.beginPath(); roundRectPath(ctx, cx, cy, cw, ch, cr); ctx.stroke(); }
          else ctx.strokeRect(cx, cy, cw, ch);
          ctx.restore();
        }
      } else if (def.widgetId === 'FILL_RECT') {
        if (p.gradient && p.gradient.enabled) {
          const g = p.gradient.type === 'radial'
            ? ctx.createRadialGradient(X(comp.x + comp.w/2), X(comp.y + comp.h/2), 0, X(comp.x + comp.w/2), X(comp.y + comp.h/2), X(Math.max(comp.w, comp.h)/2))
            : ctx.createLinearGradient(X(comp.x), X(comp.y), X(comp.x + comp.w), X(comp.y + comp.h));
          g.addColorStop(0, p.gradient.from || p.color || '#fff');
          g.addColorStop(1, p.gradient.to || '#000');
          ctx.fillStyle = g;
        } else ctx.fillStyle = p.color || '#fff';
        const fr = Math.min(X(Math.max(0, Number(p.radius) || 0)), X(comp.w) / 2, X(comp.h) / 2);
        if (fr > 0) { ctx.beginPath(); roundRectPath(ctx, X(comp.x), X(comp.y), X(comp.w), X(comp.h), fr); ctx.fill(); }
        else ctx.fillRect(X(comp.x), X(comp.y), X(comp.w), X(comp.h));
      } else if (def.widgetId === 'STROKE_RECT') {
        ctx.strokeStyle = p.color || '#fff'; ctx.lineWidth = X(p.line_width || 2);
        const sr = Math.min(X(Math.max(0, Number(p.radius) || 0)), X(comp.w) / 2, X(comp.h) / 2);
        if (sr > 0) { ctx.beginPath(); roundRectPath(ctx, X(comp.x), X(comp.y), X(comp.w), X(comp.h), sr); ctx.stroke(); }
        else ctx.strokeRect(X(comp.x), X(comp.y), X(comp.w), X(comp.h));
      } else if (def.widgetId === 'CIRCLE' || def.widgetId === 'STROKE_CIRCLE') {
        const cx = X(p.center_x ?? (comp.x + comp.w/2)), cy = X(p.center_y ?? (comp.y + comp.h/2)), r = X(p.radius ?? comp.w/2);
        ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2);
        if (def.widgetId === 'CIRCLE') {
          if (p.gradient && p.gradient.enabled) {
            const g = p.gradient.type === 'radial'
              ? ctx.createRadialGradient(cx, cy, 0, cx, cy, r)
              : ctx.createLinearGradient(cx-r, cy-r, cx+r, cy+r);
            g.addColorStop(0, p.gradient.from || p.color || '#fff');
            g.addColorStop(1, p.gradient.to || '#000');
            ctx.fillStyle = g;
          } else ctx.fillStyle = p.color || '#fff';
          ctx.fill();
        }
        else { ctx.strokeStyle = p.color || '#fff'; ctx.lineWidth = X(p.line_width || 2); ctx.stroke(); }
      } else if (def.widgetId === 'TRIANGLE') {
        // Те же вершины, что уйдут на часы (TriangleModel, src/components/triangle.js).
        const tri = TriangleModel.shape(comp);
        const triPath = (pts) => {
          ctx.beginPath();
          pts.forEach((pt, i) => { const px = X(comp.x + pt.x), py = X(comp.y + pt.y); if (i) ctx.lineTo(px, py); else ctx.moveTo(px, py); });
          ctx.closePath();
        };
        if (tri.fill) { triPath(tri.fillPts); ctx.fillStyle = tri.color; ctx.fill(); }
        if (tri.stroke) {
          triPath(tri.outlinePts);
          ctx.strokeStyle = tri.strokeColor; ctx.lineWidth = X(tri.strokeWidth);
          ctx.lineJoin = 'miter'; ctx.miterLimit = 20; ctx.stroke();
        }
      } else if (def.widgetId === 'ARC') {
        const cx = X(comp.x + comp.w/2), cy = X(comp.y + comp.h/2), r = X(Math.min(comp.w, comp.h)/2 - (p.line_width || 4)/2);
        const aS = Number(p.start_angle || 0), aE = Number(p.end_angle ?? 270);
        const toRad = (a) => (a - 90) * Math.PI / 180;
        ctx.save();
        ctx.lineCap = p.rounded_ends ? 'round' : 'butt';
        ctx.lineWidth = X(p.line_width || 4);
        const segd = window.ArcModel.isSegmented(p);
        const drawSegs = (list) => {
          ctx.lineCap = p.segment_rounded ? 'round' : 'butt';
          for (const sg of list) {
            ctx.strokeStyle = sg.color;
            ctx.beginPath(); ctx.arc(cx, cy, r, toRad(sg.a), toRad(sg.b)); ctx.stroke();
          }
        };
        if (p.track_enabled) {
          ctx.globalAlpha = Math.max(0, Math.min(100, Number(p.track_alpha ?? 100))) / 100;
          if (segd) drawSegs(window.ArcModel.segs(p, aS, aE, 1, true));
          else { ctx.strokeStyle = p.track_color || '#2a3042'; ctx.beginPath(); ctx.arc(cx, cy, r, toRad(aS), toRad(aE)); ctx.stroke(); }
        }
        // Кадр анимации дуги (только предпросмотр в редакторе): opts.arcAnim[comp.id] = {fill, fade, grow}.
        const arcOv = opts.arcAnim && opts.arcAnim[comp.id];
        const ratio = Math.min(1, window.ArcModel.previewRatio(p) * (arcOv ? arcOv.fill : 1));
        if (arcOv) ctx.lineWidth = Math.max(1, X(p.line_width || 4) * arcOv.grow);
        if (ratio > 0) {
          ctx.globalAlpha = Math.max(0, Math.min(100, Number(p.alpha ?? 100))) / 100 * (arcOv ? arcOv.fade : 1);
          if (segd) drawSegs(window.ArcModel.segs(p, aS, aE, ratio, false));
          else {
            ctx.strokeStyle = p.color || '#fff';
            ctx.beginPath(); ctx.arc(cx, cy, r, toRad(aS), toRad(aS + (aE - aS) * ratio)); ctx.stroke();
          }
        }
        ctx.restore();
      } else if (def.widgetId === 'DIGITAL_DISPLAY') {
        const text = textFor(comp, def, true, opts.liveTime, frameNow);
        const pf = (project.fonts || []).find(f => f.id === p.font);
        const family = pf ? `'${pf.cssFamily || pf.name}'` : 'sans-serif';
        const tp = Object.assign({}, p, { __family: family, rotation: Number(comp.rotation || p.rotation || 0) });
        const tx = X(comp.x + comp.w/2), ty = X(comp.y + comp.h/2);
        ctx.font = `${p.font_style || 'normal'} ${p.font_weight || '400'} ${X(p.text_size || 36)}px ${family}`;
        drawStyledText(ctx, text, tx, ty, Object.assign(tp,{text_size:X(p.text_size||36), letter_spacing:X(p.letter_spacing||0), depth:X(p.depth||0), bevel_size:X(p.bevel_size||0), scale_x:Number(p.scale_x||1), scale_y:Number(p.scale_y||1)}), scale);
      } else if (def.widgetId === 'TEXT') {
        // Кадр анимации текста (только предпросмотр в редакторе): opts.textAnim[comp.id].
        // Без него код ниже работает ровно как раньше.
        const taOv = opts.textAnim && opts.textAnim[comp.id];
        const text = taOv ? taOv.text : textFor(comp, def, true, opts.liveTime, frameNow);
        const pf = (project.fonts || []).find(f => f.id === p.font);
        const family = pf ? `'${pf.cssFamily || pf.name}'` : 'sans-serif';
        const effSize = taOv && taOv.size ? Number(taOv.size) : (p.fit_bounds ? fitTextSize(ctx, text, Object.assign({}, p, { __family: family }), p.__fit_w || comp.w, p.__fit_h || comp.h) : Number(p.text_size || 36));
        const tp = Object.assign({}, p, { __family: family, rotation: Number(comp.rotation || p.rotation || 0) });
        if (taOv && taOv.color) tp.color = taOv.color;
        if (taOv && taOv.alpha != null) ctx.globalAlpha *= taOv.alpha;
        if (taOv && Array.isArray(taOv.char_overrides)) {
          const originalCharOverrides = Array.isArray(tp.char_overrides) ? tp.char_overrides : [];
          tp.char_overrides = taOv.char_overrides.map((o, i) => Object.assign({}, originalCharOverrides[i] || {}, o || {}));
        }
        const arcOn = arcIsActive(comp);
        // Точка привязки зависит от выравнивания: LEFT/RIGHT — край рамки, TOP/BOTTOM — верх/низ (для текста по дуге остаётся центр).
        const anc = textAnchor(comp, p, arcOn);
        const tx = X(anc.x) + (taOv ? X(taOv.dx || 0) : 0), ty = X(anc.y) + (taOv ? X(taOv.dy || 0) : 0);
        ctx.font = `${p.font_style || 'normal'} ${p.font_weight || '400'} ${X(effSize)}px ${family}`;
        tp.arc_enabled = arcOn; tp.arc_radius = arcOn ? X(p.arc_radius) : 0;
        const styled = (str, px, align) => drawStyledText(ctx, str, px, ty, Object.assign({}, tp, {align_h: align || tp.align_h, text_size:X(effSize), letter_spacing:X(p.letter_spacing||0), depth:X(p.depth||0), bevel_size:X(p.bevel_size||0), scale_x:Number(p.scale_x||1), scale_y:Number(p.scale_y||1)}), scale);
        if (taOv && taOv.colonLayout && String(text).indexOf(':') >= 0) {
          // Мигающее двоеточие: как на часах — три текстовых виджета (часы | двоеточие | минуты).
          const cut = String(text).indexOf(':');
          const gap = Math.max(8, Math.round(effSize * 0.38));
          const cxm = comp.x + comp.w/2;
          styled(String(text).slice(0, cut), X(cxm - gap/2), 'RIGHT');
          if (taOv.colon !== false) styled(':', X(cxm), 'CENTER_H');
          styled(String(text).slice(cut + 1), X(cxm + gap/2), 'LEFT');
        } else {
          styled(text, tx);
        }
      } else if (def.widgetId === 'IMG' || def.widgetId === 'IMG_STATUS') {
        let assetId = p.src;
        // Special handling for weather icons: look for asset with matching weather condition
        if (isWeatherIconDef(def)) {
          const weatherId = p.src; // e.g., 'sunny', 'cloudy', etc.
          const ownIcon = (typeof WeatherIcons !== 'undefined') ? WeatherIcons.previewAsset(project, weatherId) : null;
          const matchingAsset = ownIcon || assets.get(weatherId);
          if (matchingAsset) {
            assetId = matchingAsset.id;
          } else {
            // Try to find any asset that looks like a weather icon (fallback to first available weather asset)
            for (const [id, asset] of assets.entries()) {
              if (asset.name && asset.name.includes('weather')) {
                assetId = id;
                break;
              }
            }
          }
        }
        const im = imgs.get(assetId);
        if (im && isWeatherIconDef(def)) {
          const rect = fitWeatherIconRect(comp, im);
          ctx.drawImage(im, X(rect.x), X(rect.y), X(rect.w), X(rect.h));
        } else if (im) ctx.drawImage(im, X(comp.x), X(comp.y), X(comp.w), X(comp.h));
        else if (isWeatherIconDef(def) && typeof builtinWeatherIconCanvas === 'function') {
          // Нет своих иконок — рисуем встроенную заглушку, как на часах.
          const bc = builtinWeatherIconCanvas(p.src, 64);
          if (bc) {
            const rect = fitWeatherIconRect(comp, bc);
            ctx.drawImage(bc, X(rect.x), X(rect.y), X(rect.w), X(rect.h));
          }
        }
      } else if (def.widgetId === 'TIME_POINTER') {
        const im = imgs.get(p.path);
        if (im) {
          // В обычном редакторе PNG всегда показывается строго вертикально
          // вверх — это исходная раскладка элемента. Координаты оси задаёт
          // center_x/center_y, а точку вращения внутри PNG — pos_x/pos_y.
          // В экспортируемом превью включаем отдельную имитацию времени 10:10.
          const cx = Number(p.center_x ?? dw / 2);
          const cy = Number(p.center_y ?? dh / 2);
          const iw = im.naturalWidth || im.width;
          const ih = im.naturalHeight || im.height;
          const px = Number(p.pos_x ?? iw / 2);
          const py = Number(p.pos_y ?? ih / 2);

          if (opts.liveTime || opts.previewMode) {
            // 10:10:00: hour = 305°, minute = 60°, second = 0°.
            // Clock angles are clockwise from 12 o'clock. Canvas rotation
            // is measured from +X, hence angle - 90°.
            let clockAngle = 0;
            if (opts.liveTime) {
              clockAngle = timePointerAngle(comp.defId, frameNow || new Date(), p.motion, p.smooth_step_deg);
            } else if (comp.defId === 'time_pointer_hour') clockAngle = 305;
            else if (comp.defId === 'time_pointer_minute') clockAngle = 60;
            else if (comp.defId === 'time_pointer_second') {
              // For smooth second hand, show actual time; otherwise fixed 0°
              if (p.motion === 'SMOOTH') {
                const now = new Date();
                clockAngle = (now.getSeconds() + now.getMilliseconds() / 1000) * 6;
              } else {
                clockAngle = 0;
              }
            }

            ctx.translate(X(cx), X(cy));
            ctx.rotate((clockAngle - 90) * Math.PI / 180);
            ctx.drawImage(im, -X(px), -X(py), X(iw), X(ih));
          } else {
            // Main editor: never rotate the source PNG.
            ctx.drawImage(im, X(cx - px), X(cy - py), X(iw), X(ih));
          }
        }
      }
      ctx.restore();
    }
    if (project.device?.shape === 'round') {
      const out = document.createElement('canvas'); out.width = out.height = renderSize;
      const o = out.getContext('2d'); o.save(); o.beginPath(); o.arc(renderSize/2,renderSize/2,renderSize/2,0,Math.PI*2); o.clip(); o.drawImage(canvas,0,0); o.restore();
      ctx.clearRect(0,0,renderSize,renderSize); ctx.drawImage(out,0,0);
    }
    if (opts.highQuality && renderSize !== size) {
      const tmp=document.createElement('canvas'); tmp.width=size; tmp.height=size; const t=tmp.getContext('2d'); t.imageSmoothingEnabled=true; t.imageSmoothingQuality='high'; t.drawImage(canvas,0,0,size,size); canvas.width=size; canvas.height=size; canvas.getContext('2d').drawImage(tmp,0,0);
    }
    return canvas;
  }


  // ---------------------------------------------------------------------------
  // ArcModel — общая логика дуги для редактора (canvas.js) и предпросмотра.
  // Формулы дублируют те, что экспортёр пишет в index.js (index-js-exporter.js).
  // ---------------------------------------------------------------------------
  const ARC_TIME_SOURCES = new Set(['SECOND', 'MINUTE', 'HOUR', 'DAY', 'WEEKDAY', 'MONTH']);
  const arcClamp01 = (v) => Math.max(0, Math.min(1, v));
  function arcTimeRatio(src, d) {
    switch (src) {
      case 'SECOND': return d.getSeconds() / 60;
      case 'MINUTE': return (d.getMinutes() + d.getSeconds() / 60) / 60;
      case 'HOUR': return ((d.getHours() % 12) + d.getMinutes() / 60) / 12;
      case 'DAY': return d.getDate() / new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
      case 'WEEKDAY': return (((d.getDay() + 6) % 7) + 1) / 7;
      case 'MONTH': return (d.getMonth() + 1) / 12;
      default: return 1;
    }
  }
  function arcPreviewRatio(p, now) {
    const src = (p && p.data_source) || 'NONE';
    if (src === 'NONE') return 1;
    if (ARC_TIME_SOURCES.has(src)) return arcClamp01(arcTimeRatio(src, now || new Date()));
    return arcClamp01(Number(p.preview_percent ?? 70) / 100);
  }
  function arcEase(name, k) {
    if (name === 'LINEAR') return k;
    if (name === 'EASE_IN_OUT') return k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2;
    return 1 - Math.pow(1 - k, 3); // EASE_OUT (по умолчанию)
  }
  // k — прогресс анимации 0..1. Возвращает множители: fill (доля от значения),
  // fade (непрозрачность 0..1), grow (толщина 0..1).
  function arcAnimState(p, k, target) {
    const type = p.anim_type || 'FILL';
    const e = arcEase(p.anim_easing || 'EASE_OUT', k);
    const back = 1 + 2.70158 * Math.pow(k - 1, 3) + 1.70158 * Math.pow(k - 1, 2);
    switch (type) {
      case 'FADE': return { fill: 1, fade: e, grow: 1 };
      case 'FADE_FILL': return { fill: e, fade: e, grow: 1 };
      case 'OVERSHOOT': return { fill: back, fade: 1, grow: 1 };
      case 'SWEEP': {
        // Спидометр: 0 → 100 % (первая половина), затем 100 % → значение. fill — множитель к значению.
        const tg = Number(target);
        if (!(tg > 0)) return { fill: 1, fade: 1, grow: 1 };
        const ease = p.anim_easing || 'EASE_OUT';
        const abs = k < 0.5 ? arcEase(ease, k * 2) : 1 - (1 - tg) * arcEase(ease, k * 2 - 1);
        return { fill: abs / tg, fade: 1, grow: 1 };
      }
      case 'GROW': return { fill: 1, fade: 1, grow: e };
      default: return { fill: e, fade: 1, grow: 1 };
    }
  }
  // Сегменты дуги (градиент / деления): [{a, b, color}] для заполненной доли ratio (углы редактора, 0° = 12 часов).
  // Раскладка та же, что в экспортёре: N сегментов, промежуток segment_gap, перекрытие 1° только у сплошной дуги без скруглений.
  function arcRgb(h) {
    let c = String(h || '#000000').replace('#', '');
    if (c.length === 3) c = c.split('').map((x) => x + x).join('');
    const n = parseInt(c, 16) || 0;
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }
  function arcMix(c1, c2, t) {
    const a = arcRgb(c1), b = arcRgb(c2);
    return '#' + a.map((v, i) => Math.round(v + (b[i] - v) * t).toString(16).padStart(2, '0')).join('');
  }
  const arcSegmented = (p) => !!(p && (p.gradient_enabled || p.segments_enabled));
  function arcSegs(p, aS, aE, ratio, track) {
    const N = Math.max(2, Math.min(48, Math.round(Number(p.gradient_steps) || 24)));
    const span = aE - aS, sgn = span >= 0 ? 1 : -1, abs = Math.abs(span);
    const gap = Math.max(0, Math.min(Math.max(0, Number(p.segment_gap) || 0), (abs - 0.5 * N) / (N - 1)));
    const w = (abs - gap * (N - 1)) / N;
    const ov = (gap === 0 && !p.segment_rounded) ? 1 : 0;
    const cur = aS + span * ratio, out = [];
    for (let i = 0; i < N; i++) {
      const a = aS + sgn * i * (w + gap), b0 = a + sgn * w;
      const b = (i < N - 1 && ov) ? (sgn > 0 ? Math.min(b0 + 1, aE) : Math.max(b0 - 1, aE)) : b0;
      const end = sgn > 0 ? Math.max(a, Math.min(b, cur)) : Math.min(a, Math.max(b, cur));
      if (end === a) break;
      const color = track ? (p.track_color || '#2a3042')
        : (p.gradient_enabled ? arcMix(p.color || '#3366ff', p.color2 || '#ff3366', i / (N - 1)) : (p.color || '#3366ff'));
      out.push({ a, b: end, color });
    }
    return out;
  }
  window.ArcModel = { TIME_SOURCES: ARC_TIME_SOURCES, previewRatio: arcPreviewRatio, animState: arcAnimState, ease: arcEase, segs: arcSegs, isSegmented: arcSegmented };

  function timePointerAngle(defId, now, motion = 'TICK', smoothStep = 0) {
    const h = now.getHours() % 12, m = now.getMinutes(), s = now.getSeconds(), ms = now.getMilliseconds();
    if (defId === 'time_pointer_hour') return (h + m / 60 + s / 3600) * 30;
    if (defId === 'time_pointer_minute') return (m + s / 60) * 6;
    if (defId === 'time_pointer_second') {
      let angle = (s + (motion === 'SMOOTH' ? ms / 1000 : 0)) * 6;
      const step = Number(smoothStep) || 0;
      if (motion === 'SMOOTH' && step > 0) angle = Math.floor(angle / step) * step;
      return angle;
    }
    return 0;
  }

  window.WatchfacePreviewRenderer = { textAnchor, draw, registerProjectFont, getEffectiveDataSource, arcTextExtent, arcIsActive, arcIsWeekday, textFor, timePointerAngle, fitWeatherIconRect };
  window.getEffectiveDataSource = getEffectiveDataSource;
})();
