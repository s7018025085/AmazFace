// src/components/image-set.js
// Модель компонента «Набор картинок по значению»: пользователь выбирает показатель
// (батарея, шаги, пульс, секунды…) и набор PNG-кадров; кадр выбирается по доле значения.
// ЕДИНАЯ логика выбора кадра для редактора (canvas.js), предпросмотра (renderer.js) и
// экспорта (index-js-exporter.js). Классический <script>; в Node — через vm.
//
// Распределение: доля 0..1 → индекс кадра 0..N-1.
//   FLOOR   (по умолчанию): кадр = floor(доля × N), 100% = последний кадр.
//           Батарея, 10 кадров: 0–9% → 1-й, 10–19% → 2-й, … 90–100% → 10-й.
//   NEAREST: кадр = round(доля × (N − 1)). Первый кадр — ровно «пусто», последний — «полно».
// Нужна GaugeNeedleModel (общие формулы долей времени) — подключается раньше.

const ImageSetModel = (() => {
  // Датчики, значение которых читает код циферблата (@zos/sensor): для них работает диапазон «от — до».
  const SENSOR_SOURCES = ['BATTERY', 'STEP', 'CALORIE', 'DISTANCE', 'HEART', 'PAI_DAILY', 'STAND', 'FAT_BURNING', 'STRESS', 'ALTITUDE', 'AIR_PRESSURE'];
  const TIME_SOURCES = ['SECOND', 'MINUTE', 'HOUR', 'DAY', 'WEEKDAY', 'MONTH'];
  // «Родные» источники: значения нет в JS API — кадр выбирает прошивка (IMG_LEVEL + data_type),
  // диапазон 0–100 делится на число кадров. Свой диапазон «от — до» для них невозможен.
  const NATIVE_SOURCES = ['HYBRID_CHARGE', 'READINESS'];
  const NATIVE_CHAINS = {
    // Как у компонента HybridCharge: берётся первая константа, которая есть в прошивке.
    HYBRID_CHARGE: ['HYBRID_CHARGE', 'HYBRIDCHARGE', 'BIO_CHARGE', 'BIOCHARGE', 'READINESS'],
    READINESS: ['READINESS'],
  };
  const SOURCES = ['NONE', ...SENSOR_SOURCES, ...NATIVE_SOURCES, ...TIME_SOURCES];
  // Значение «полно» по умолчанию (когда value_max = 0). Для высоты и давления лучше задать свой диапазон.
  const DEFAULT_MAX = { BATTERY: 100, STEP: 10000, CALORIE: 500, DISTANCE: 5, HEART: 200,
    PAI_DAILY: 100, STAND: 12, FAT_BURNING: 30, STRESS: 100, ALTITUDE: 3000, AIR_PRESSURE: 1100 };
  const MODES = ['FLOOR', 'NEAREST'];

  const num = (v, d) => (v !== '' && v !== null && v !== undefined && Number.isFinite(Number(v)) ? Number(v) : d);
  const clamp01 = (v) => Math.max(0, Math.min(1, v));

  function timeRatio(src, d) {
    if (typeof GaugeNeedleModel !== 'undefined') return GaugeNeedleModel.timeRatio(src, d);
    switch (src) {
      case 'SECOND': return d.getSeconds() / 60;
      case 'MINUTE': return (d.getMinutes() + d.getSeconds() / 60) / 60;
      case 'HOUR': return ((d.getHours() % 12) + d.getMinutes() / 60) / 12;
      case 'DAY': return d.getDate() / new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
      case 'WEEKDAY': return (((d.getDay() + 6) % 7) + 1) / 7;
      case 'MONTH': return (d.getMonth() + 1) / 12;
      default: return 0;
    }
  }

  /** Список id кадров (только непустые строки, порядок сохраняется). */
  function frameIds(comp) {
    const f = comp && comp.props && comp.props.frames;
    return Array.isArray(f) ? f.filter((x) => typeof x === 'string' && x) : [];
  }

  /** Нормализованные параметры (значения по умолчанию совпадают с registry.js). */
  function params(comp) {
    const p = (comp && comp.props) || {};
    const source = SOURCES.includes(p.data_source) ? p.data_source : 'NONE';
    const vMin = num(p.value_min, 0);
    const vMaxRaw = num(p.value_max, 0);
    const vMax = vMaxRaw !== 0 ? vMaxRaw : (DEFAULT_MAX[source] || 100);
    return {
      source,
      isSensor: SENSOR_SOURCES.includes(source),
      isNative: NATIVE_SOURCES.includes(source),
      isTime: TIME_SOURCES.includes(source),
      mode: MODES.includes(p.mode) ? p.mode : 'FLOOR',
      vMin, vMax, span: (vMax - vMin) || 1,
      previewPercent: Math.max(0, Math.min(100, num(p.preview_percent, 100))),
      alpha: Math.max(0, Math.min(100, num(p.alpha, 100))),
    };
  }

  /** Индекс кадра для доли 0..1 при n кадрах. n < 1 → -1. */
  function frameIndex(n, ratio, mode) {
    n = Math.floor(Number(n) || 0);
    if (n < 1) return -1;
    if (n === 1) return 0;
    const r = clamp01(Number(ratio) || 0);
    if (mode === 'NEAREST') return Math.min(n - 1, Math.max(0, Math.round(r * (n - 1))));
    return Math.min(n - 1, Math.max(0, Math.floor(r * n)));
  }

  /** Доля для предпросмотра: время — по часам компьютера, датчик/статика — «значение в редакторе». */
  function previewRatio(comp, now) {
    const q = params(comp);
    if (q.isTime) return clamp01(timeRatio(q.source, now || new Date()));
    return clamp01(q.previewPercent / 100);
  }

  /** Какой кадр (id ресурса) показать в редакторе. */
  function previewFrameId(comp, now) {
    const ids = frameIds(comp);
    const idx = frameIndex(ids.length, previewRatio(comp, now), params(comp).mode);
    return idx < 0 ? null : ids[idx];
  }

  /** JS-выражение для поля `type` нативного IMG_LEVEL: первая константа, существующая в прошивке. */
  function nativeTypeExpr(source) {
    const chain = NATIVE_CHAINS[source] || NATIVE_CHAINS.READINESS;
    let expr = `data_type.${chain[chain.length - 1]}`;
    for (let i = chain.length - 2; i >= 0; i--) expr = `(data_type.${chain[i]} !== undefined ? data_type.${chain[i]} : ${expr})`;
    return expr;
  }

  /** JS-выражение для часов: доля → индекс кадра (то же правило, что frameIndex). */
  function indexExpr(n, ratioVar, mode) {
    if (n <= 1) return '0';
    return mode === 'NEAREST'
      ? `Math.round(${ratioVar} * ${n - 1})`
      : `Math.min(${n - 1}, Math.floor(${ratioVar} * ${n}))`;
  }

  return { SOURCES, SENSOR_SOURCES, NATIVE_SOURCES, TIME_SOURCES, DEFAULT_MAX, MODES, nativeTypeExpr, params, frameIds, frameIndex, previewRatio, previewFrameId, timeRatio, indexExpr };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = ImageSetModel;
