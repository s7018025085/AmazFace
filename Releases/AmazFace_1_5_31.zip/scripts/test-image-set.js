// Проверка компонента «Набор картинок по значению»: модель выбора кадра, реестр и экспорт на часы.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.resolve(__dirname, '..');
const ctx = { console, Math, Date, JSON, window: {} };
vm.createContext(ctx);
for (const rel of ['src/util/slug.js', 'src/components/gauge-needle.js', 'src/components/image-set.js', 'src/components/registry.js', 'src/exporter/index-js-exporter.js']) {
  const src = fs.readFileSync(path.join(root, rel), 'utf8');
  vm.runInContext(src + '\n;globalThis.__ex = Object.assign(globalThis.__ex || {}, {' +
    ['REGISTRY', 'exportIndexJs', 'GaugeNeedleModel', 'ImageSetModel'].filter((n) => src.includes(`const ${n}`) || src.includes(`function ${n}`)).join(',') + '});', ctx, { filename: rel });
}
const { REGISTRY, exportIndexJs, ImageSetModel: M } = ctx.__ex;

let failed = 0;
const check = (name, cond, extra) => { if (!cond) { failed++; console.error('FAIL:', name, extra || ''); } else console.log('ok:', name); };
const syntaxOk = (code) => { try { new vm.Script(code.replace(/^import .*$/gm, '')); return true; } catch (e) { return e.message; } };

const N = 10;
const ASSETS = Array.from({ length: N }, (_, i) => ({ id: `b${i}`, name: `bat_${i}.png`, width: 64, height: 32, format: 'PNG', dataUrl: 'data:image/png;base64,AAAA' }));
const MAP = Object.fromEntries(ASSETS.map((a) => [a.id, a.name]));
const ids = (n) => ASSETS.slice(0, n).map((a) => a.id);
const mk = (props, extra) => Object.assign({ id: 's1', defId: 'image_set', x: 100, y: 50, w: 64, h: 32,
  props: Object.assign({ data_source: 'BATTERY', frames: ids(N) }, props) }, extra);
const run = (comps, assets = ASSETS, map = MAP) => exportIndexJs({ device: { w: 480, h: 480 }, components: comps, assets, fonts: [], background: {} }, map, {}, {});

// 1. Реестр
const def = REGISTRY.image_set;
check('реестр: компонент есть, виджет IMAGE_SET', !!def && def.widgetId === 'IMAGE_SET');
const keys = def.properties.map((q) => q.key);
check('реестр: ключи уникальны', new Set(keys).size === keys.length);
check('реестр: есть источник, диапазон, режим, кадры', ['data_source', 'value_min', 'value_max', 'preview_percent', 'mode', 'frames'].every((k) => keys.includes(k)));
check('реестр: frames — список ресурсов', def.properties.find((q) => q.key === 'frames').kind === 'assetlist');
check('реестр: не single (можно несколько наборов)', !def.single);

// 2. Распределение кадров: равные ступени (10 кадров)
const at = (pct, mode) => M.frameIndex(N, pct / 100, mode);
check('ступени: 0% → кадр 1', at(0, 'FLOOR') === 0);
check('ступени: 9% → кадр 1', at(9, 'FLOOR') === 0);
check('ступени: 10% → кадр 2', at(10, 'FLOOR') === 1);
check('ступени: 55% → кадр 6', at(55, 'FLOOR') === 5);
check('ступени: 99% → кадр 10', at(99, 'FLOOR') === 9);
check('ступени: 100% → последний кадр (не выходит за набор)', at(100, 'FLOOR') === 9);
check('ступени: вне 0..100 обрезается', at(-20, 'FLOOR') === 0 && at(250, 'FLOOR') === 9);
check('ступени: каждый кадр используется (по шагу 1%)', new Set(Array.from({ length: 101 }, (_, i) => at(i, 'FLOOR'))).size === N);
// Крайние кадры точно на краях
check('крайние: 0% → первый, 100% → последний', at(0, 'NEAREST') === 0 && at(100, 'NEAREST') === 9);
check('крайние: 1% → первый, 99% → последний', at(1, 'NEAREST') === 0 && at(99, 'NEAREST') === 9);
check('крайние: 50% → ближайший (5)', at(50, 'NEAREST') === 5);
check('граничные: один кадр — всегда он', M.frameIndex(1, 0.9, 'FLOOR') === 0 && M.frameIndex(1, 0, 'NEAREST') === 0);
check('граничные: пустой набор → -1', M.frameIndex(0, 0.5, 'FLOOR') === -1);
check('граничные: «мусор» в доле не ломает', M.frameIndex(5, 'abc', 'FLOOR') === 0 && M.frameIndex(5, NaN, 'NEAREST') === 0);

// 3. Параметры и предпросмотр
check('параметры: «мусорные» значения → по умолчанию', (() => { const q = M.params(mk({ data_source: 'XXX', mode: 'ZZZ', value_max: 'abc' })); return q.source === 'NONE' && q.mode === 'FLOOR'; })());
check('параметры: батарея без value_max → 100', M.params(mk({ value_max: 0 })).vMax === 100);
check('параметры: свои пределы 60…160', (() => { const q = M.params(mk({ data_source: 'HEART', value_min: 60, value_max: 160 })); return q.vMin === 60 && q.vMax === 160 && q.span === 100; })());
check('предпросмотр: по умолчанию 100% → последний кадр', M.previewFrameId(mk({})) === 'b9');
check('предпросмотр: 30% → кадр 4', M.previewFrameId(mk({ preview_percent: 30 })) === 'b3');
check('предпросмотр: время — по часам (30 минут из 60 → кадр 6)', M.previewFrameId(mk({ data_source: 'MINUTE' }), new Date(2026, 0, 1, 10, 30, 0)) === 'b5');
check('предпросмотр: пустой набор → null', M.previewFrameId(mk({ frames: [] })) === null);
check('кадры: пустые/мусорные id отбрасываются, порядок сохраняется', JSON.stringify(M.frameIds(mk({ frames: ['b2', '', null, 'b0'] }))) === '["b2","b0"]');
check('кадры: не массив → пусто', M.frameIds(mk({ frames: '' })).length === 0);

// 4. Экспорт: батарея, 10 кадров
let r = run([mk({})]);
check('экспорт: валидный JS', syntaxOk(r.code) === true, syntaxOk(r.code));
check('экспорт: без ошибок', r.validation && r.validation.errors.length === 0, JSON.stringify(r.validation));
check('экспорт: массив из 10 кадров по порядку', (() => { const m = r.code.match(/const \w+_frames = (\[.*\]);/); if (!m) return false; const a = JSON.parse(m[1]); return a.length === N && a[0] === 'bat_0.png' && a[9] === 'bat_9.png'; })());
check('экспорт: кадр — обычный IMG', /createWidget\(widget\.IMG/.test(r.code));
check('экспорт: батарея читается из датчика и обновляется по _tickSensors', /_battery\.getCurrent\(\)/.test(r.code) && /_tickSensors/.test(r.code));
check('экспорт: формула кадра = min(9, floor(r × 10))', /Math\.min\(9, Math\.floor\(r \* 10\)\)/.test(r.code));
check('экспорт: смена кадра через prop.MORE { src }', /prop\.MORE, \{ src: \w+_frames\[i\] \}/.test(r.code));
check('экспорт: без лишней перерисовки (кадр не менялся)', /if \(i === \w+_cur\) return;/.test(r.code));
check('экспорт: стартовый кадр = значение в редакторе (100% → 9)', /src: \w+_frames\[9\]/.test(r.code));
check('экспорт: значение (v − 0) / 100', /\(v - 0\) \/ 100/.test(r.code));

r = run([mk({ mode: 'NEAREST', preview_percent: 0 })]);
check('экспорт «крайние кадры»: формула round(r × 9), старт — кадр 0', /Math\.round\(r \* 9\)/.test(r.code) && /src: \w+_frames\[0\]/.test(r.code));

r = run([mk({ data_source: 'HEART', value_min: 60, value_max: 160 })]);
check('экспорт: пульс 60…160 и HeartRate', /\(v - 60\) \/ 100/.test(r.code) && /_heartVal/.test(r.code) && /HeartRate/.test(r.code));

// 5. Источники времени и статика
r = run([mk({ data_source: 'SECOND', frames: ids(4) })]);
check('время: секунды → обновление в _tick, формула из 4 кадров', /now\.getSeconds\(\) \/ 60/.test(r.code) && /Math\.floor\(r \* 4\)/.test(r.code) && syntaxOk(r.code) === true);
r = run([mk({ data_source: 'NONE', preview_percent: 50 })]);
check('статика: без обновления, кадр по значению в редакторе (50% → 5)', /src: \w+_frames\[5\]/.test(r.code) && !/_set\(/.test(r.code));
r = run([mk({ frames: ids(1) })]);
check('один кадр: работает, формула — 0', syntaxOk(r.code) === true && r.validation.errors.length === 0);

// 6. Прозрачность и два набора рядом
r = run([mk({ alpha: 50 }), mk({ data_source: 'STEP', frames: ids(3) }, { id: 's2', x: 200 })]);
check('прозрачность 50% → setAlpha(128)', /setAlpha\(128\)/.test(r.code));
check('два набора: валидный JS, уникальные имена, оба датчика', syntaxOk(r.code) === true && (r.code.match(/const \w+_frames = /g) || []).length === 2 && /_step/.test(r.code) && /_battery/.test(r.code));

// 7. Ошибочные случаи не роняют экспорт
r = run([mk({ frames: [] })]);
check('пустой набор: предупреждение, виджета нет, JS валиден', r.validation.warnings.some((w) => /пуст/.test(w)) && !/_frames/.test(r.code) && syntaxOk(r.code) === true);
r = run([mk({ frames: ['b0', 'нет-такого'] })]);
check('потерян кадр: ошибка экспорта (не падение)', r.validation.errors.some((e) => /не найден/.test(e)));


// 8. Остальные датчики: диапазон «от — до» и чтение через @zos/sensor
const sensorCases = [
  ['PAI_DAILY', /_pai\.getToday\(\)/, /new Pai\(\)/, /import \{[^}]*\bPai\b[^}]*\} from '@zos\/sensor'/, 100],
  ['STAND', /_stand\.getCurrent\(\)/, /new Stand\(\)/, /import \{[^}]*\bStand\b[^}]*\} from '@zos\/sensor'/, 12],
  ['FAT_BURNING', /_fatBurning\.getCurrent\(\)/, /new FatBurning\(\)/, /import \{[^}]*\bFatBurning\b[^}]*\} from '@zos\/sensor'/, 30],
  ['STRESS', /\(_stress\.getCurrent\(\) \|\| \{\}\)\.value/, /new Stress\(\)/, /import \{[^}]*\bStress\b[^}]*\} from '@zos\/sensor'/, 100],
  ['ALTITUDE', /_barometer\.getAltitude\(\)/, /new Barometer\(\)/, /import \{[^}]*\bBarometer\b[^}]*\} from '@zos\/sensor'/, 3000],
  ['AIR_PRESSURE', /_barometer\.getAirPressure\(\)/, /new Barometer\(\)/, /import \{[^}]*\bBarometer\b[^}]*\} from '@zos\/sensor'/, 1100],
];
for (const [src, readRe, newRe, impRe, defMax] of sensorCases) {
  const rr = run([mk({ data_source: src, frames: ids(5) })]);
  check(`${src}: читается, датчик создаётся и импортируется`, readRe.test(rr.code) && newRe.test(rr.code) && impRe.test(rr.code) && /_tickSensors/.test(rr.code), rr.code.slice(0, 200));
  check(`${src}: валидный JS без ошибок`, syntaxOk(rr.code) === true && rr.validation.errors.length === 0);
  check(`${src}: макс. по умолчанию ${defMax}`, M.params(mk({ data_source: src, value_max: 0 })).vMax === defMax);
  check(`${src}: считается датчиком с диапазоном`, M.params(mk({ data_source: src })).isSensor === true);
}
check('диапазон: давление 950…1050 → (v - 950) / 100', /\(v - 950\) \/ 100/.test(run([mk({ data_source: 'AIR_PRESSURE', value_min: 950, value_max: 1050 })]).code));
check('диапазон: стресс 20…80 → (v - 20) / 60', /\(v - 20\) \/ 60/.test(run([mk({ data_source: 'STRESS', value_min: 20, value_max: 80 })]).code));
check('два датчика Barometer рядом: один импорт и одно объявление', (() => { const c = run([mk({ data_source: 'ALTITUDE' }), mk({ data_source: 'AIR_PRESSURE' }, { id: 's2' })]).code; return (c.match(/let _barometer = null;/g) || []).length === 1 && syntaxOk(c) === true; })());

// 9. Нативные источники: кадр выбирает прошивка (IMG_LEVEL)
for (const src of ['HYBRID_CHARGE', 'READINESS']) {
  const rr = run([mk({ data_source: src, frames: ids(10), preview_percent: 50 })]);
  check(`${src}: нативный IMG_LEVEL с image_array из 10 кадров`, /createWidget\(widget\.IMG_LEVEL/.test(rr.code) && /image_length: 10/.test(rr.code) && /"bat_9\.png"/.test(rr.code));
  check(`${src}: type = data_type.*, без опроса датчика и без смены кадров кодом`, /type: .*data_type\./.test(rr.code) && !/_frames\[i\]/.test(rr.code) && !/_tickSensors/.test(rr.code));
  check(`${src}: валидный JS без ошибок`, syntaxOk(rr.code) === true && rr.validation.errors.length === 0, JSON.stringify(rr.validation));
  check(`${src}: помечен как непроверенный (предупреждение при экспорте)`, rr.validation.warnings.some((w) => /unverified/.test(w) && new RegExp(`IMAGE_SET \\(${src}\\)`).test(w)), JSON.stringify(rr.validation.warnings));
  check(`${src}: считается нативным (не датчиком)`, M.params(mk({ data_source: src })).isNative === true && M.params(mk({ data_source: src })).isSensor === false);
}
check('HYBRID_CHARGE: цепочка констант как у компонента HybridCharge (с запасным READINESS)', (() => { const e = M.nativeTypeExpr('HYBRID_CHARGE'); return e.includes('data_type.HYBRID_CHARGE') && e.includes('data_type.BIO_CHARGE') && e.endsWith('data_type.READINESS' + ')'.repeat(4)); })());
check('READINESS: явная константа без цепочки', M.nativeTypeExpr('READINESS') === 'data_type.READINESS');
check('нативный: предпросмотр в редакторе по «значению в редакторе»', M.previewFrameId(mk({ data_source: 'READINESS', preview_percent: 0 })) === 'b0');


// 10. Разрешения app.json для новых датчиков (только у набора картинок; обычный TEXT не меняется)
{
  const pctx = { console, Math, Date, JSON, window: {} };
  vm.createContext(pctx);
  for (const rel of ['src/util/slug.js', 'src/components/gauge-needle.js', 'src/components/image-set.js', 'src/components/registry.js']) vm.runInContext(fs.readFileSync(path.join(root, rel), 'utf8'), pctx, { filename: rel });
  const pe = fs.readFileSync(path.join(root, 'src/exporter/project-exporter.js'), 'utf8');
  vm.runInContext(pe.slice(pe.indexOf('const PERMISSION_BY_SOURCE'), pe.indexOf('function loadPreviewImage')) + ';globalThis.__perm = computePermissions;', pctx);
  const perm = (defId, ds) => pctx.__perm({ components: [{ id: 'c', defId, props: { data_source: ds } }] });
  check('разрешения: PAI / стояние / жиросжигание / стресс', perm('image_set', 'PAI_DAILY')[0] === 'data:user.hd.pai' && perm('image_set', 'STAND')[0] === 'data:user.hd.stand'
    && perm('image_set', 'FAT_BURNING')[0] === 'data:user.hd.fat_burning' && perm('image_set', 'STRESS')[0] === 'data:user.hd.stress');
  check('разрешения: высота/давление — barometer, пульс — heart_rate', perm('image_set', 'ALTITUDE')[0] === 'device:os.barometer' && perm('image_set', 'HEART')[0] === 'data:user.hd.heart_rate');
  check('разрешения: нативные источники ничего не требуют', perm('image_set', 'READINESS').length === 0 && perm('image_set', 'HYBRID_CHARGE').length === 0);
  check('разрешения: обычный TEXT с PAI_DAILY не изменился', perm('text', 'PAI_DAILY').length === 0);
}

console.log(failed ? `\n${failed} проверок не прошло` : '\nВсе проверки компонента «Набор картинок по значению» пройдены');
process.exit(failed ? 1 : 0);
