'use strict';
// bridge/github-import.js
//
// Импорт проектов AmazFace из GitHub: только ЧТЕНИЕ (GET). Использует тот же
// GitHub-клиент и те же сохранённые настройки/токен, что и публикация
// (createPublisher передаёт сюда свой `api` и `getToken`). Токен не покидает мост.
//
// Сначала список показывает только папки внутри настроенной папки публикации.
// Содержимое и состояние проекта проверяются только после выбора одной папки.
//
// Безопасность: путь папки и путь файла проверяются и, кроме того, сверяются со
// списком из репозитория — запросить можно только то, что реально лежит в
// найденной папке проекта. Произвольных URL нет: адреса строятся из owner/repo
// сохранённых настроек и sha, полученных от самого GitHub.

const crypto = require('crypto');
const Gh = require('../src/exporter/github-paths.js');
const gitBlobSha = (bytes) => crypto.createHash('sha1').update(`blob ${bytes.length}\0`).update(bytes).digest('hex');

const IMPORT_BRANCH = 'main';
const STATE_FILE_RE = /^(?:.*\.)?watchface\.json$/i;
const MAX_STATE_BYTES = 60 * 1024 * 1024;
const MAX_FILE_BYTES = 95 * 1024 * 1024;
const MAX_TOTAL_BYTES = 250 * 1024 * 1024;
const MAX_FILES = 3000;
const MAX_DEPTH = 12;
const MANIFEST_TTL_MS = 10 * 60 * 1000;
const BLOB_TIMEOUT_MS = 180000;

// В папку проекта не нужно тянуть то, что редактору не требуется:
// установочные пакеты, README, служебный файл публикации, мусор ОС.
const SKIP_FILE_RE = /(^|\/)(device\.zip|README\.md|amazface-publish\.json|\.DS_Store|Thumbs\.db)$|\.zpk$/i;

function createImporter(deps) {
  const { api, getToken, store, GhError } = deps;
  const log = deps.log || (() => {});
  const now = deps.now || (() => Date.now());
  const manifests = new Map(); // repository + dir → { at, files: Map(path → entry) }
  const folderShas = new Map(); // GitHub directory SHA, populated by the shallow folder listing

  // ---- проверка путей ----
  function segmentsOk(segs) {
    return segs.length > 0 && segs.length <= MAX_DEPTH && segs.every((s) =>
      s && s !== '.' && s !== '..' && s.toLowerCase() !== '.git' && s.length <= 255 && !/[\u0000-\u001f\\]/.test(s));
  }
  /** Папка проекта в репозитории: «a/b/c», без «..», «.git», обратных слэшей и абсолютных путей. */
  function cleanRepoDir(dir) {
    if (typeof dir !== 'string' || !dir || dir.startsWith('/') || dir.endsWith('/') || dir.length > 1000) {
      throw new GhError('Недопустимый путь папки проекта.', { code: 'bad_path', status: 400 });
    }
    const segs = dir.split('/');
    if (!segmentsOk(segs)) throw new GhError('Недопустимый путь папки проекта.', { code: 'bad_path', status: 400 });
    return segs.join('/');
  }
  function cleanRelPath(p) {
    if (typeof p !== 'string' || !p || p.startsWith('/') || p.endsWith('/') || p.length > 1000) {
      throw new GhError('Недопустимый путь файла.', { code: 'bad_path', status: 400 });
    }
    const segs = p.split('/');
    if (!segmentsOk(segs)) throw new GhError('Недопустимый путь файла.', { code: 'bad_path', status: 400 });
    return segs.join('/');
  }

  function connection() {
    const cfg = store.read().settings;
    return { cfg };
  }
  const manifestKey = (cfg, dir) => `${cfg.owner}/${cfg.repo}@${IMPORT_BRANCH}:${dir}`;
  async function need() {
    const { cfg } = connection();
    const tok = await getToken();
    if (!cfg || !tok) throw new GhError('GitHub не подключён: откройте «Экспорт → Опубликовать на GitHub» и подключите репозиторий. Те же настройки используются для импорта.', { code: 'not_connected', status: 409 });
    return { cfg, tok };
  }

  function contentsUrl(cfg, dir) {
    const pathPart = dir ? `/contents/${Gh.encodePath(dir)}` : '/contents';
    return `/repos/${cfg.owner}/${cfg.repo}${pathPart}?ref=${encodeURIComponent(IMPORT_BRANCH)}`;
  }

  // ---- дерево только выбранной папки ----
  async function folderTree(cfg, tok, dir) {
    const key = manifestKey(cfg, dir);
    let sha = folderShas.get(key);
    if (!sha) {
      const parent = dir.includes('/') ? dir.slice(0, dir.lastIndexOf('/')) : '';
      const listing = await api('GET', contentsUrl(cfg, parent), { token: tok });
      const found = Array.isArray(listing.json) && listing.json.find((item) => item && item.type === 'dir' && item.path === dir);
      if (!found || !found.sha) throw new GhError('Папка не найдена в репозитории.', { code: 'not_project', status: 404 });
      sha = found.sha;
      folderShas.set(key, sha);
    }
    let res;
    try {
      res = await api('GET', `/repos/${cfg.owner}/${cfg.repo}/git/trees/${encodeURIComponent(sha)}?recursive=1`, { token: tok, timeoutMs: 60000 });
    } catch (e) {
      if (e.code === 'not_found') throw new GhError(`Не удалось прочитать папку «${dir}» из ветки ${IMPORT_BRANCH}.`, { status: 404, code: 'not_project' });
      throw e;
    }
    const json = res.json || {};
    if (json.truncated) throw new GhError('В выбранной папке слишком много файлов: GitHub вернул неполное дерево.', { code: 'too_many_files', status: 413 });
    return Array.isArray(json.tree)
      ? json.tree.filter((t) => t && t.type === 'blob' && typeof t.path === 'string')
        .map((t) => Object.assign({}, t, { path: `${dir}/${t.path}` }))
      : [];
  }

  /** Папки-кандидаты: есть файл .watchface.json. Для каждой — её файлы без вложенных проектов. */
  function groupCandidates(tree) {
    const dirs = new Map(); // dir → { states: [entry] }
    for (const t of tree) {
      const i = t.path.lastIndexOf('/');
      if (i <= 0) continue; // файлы в корне репозитория — не папки проектов
      const dir = t.path.slice(0, i), name = t.path.slice(i + 1);
      if (!STATE_FILE_RE.test(name)) continue;
      if (!segmentsOk(dir.split('/'))) continue;
      if (!dirs.has(dir)) dirs.set(dir, { states: [] });
      dirs.get(dir).states.push(t);
    }
    const byLen = [...dirs.keys()].sort((a, b) => b.length - a.length);
    for (const d of dirs.values()) d.files = [];
    for (const t of tree) {
      const owner = byLen.find((d) => t.path.startsWith(d + '/'));
      if (owner) dirs.get(owner).files.push(t);
    }
    return dirs;
  }

  async function readBlob(cfg, tok, entry, limit) {
    if (typeof entry.size === 'number' && entry.size > limit) {
      throw new GhError(`Файл «${entry.path}» слишком большой (${Math.round(entry.size / 1048576)} МБ).`, { code: 'too_big', status: 413 });
    }
    const res = await api('GET', `/repos/${cfg.owner}/${cfg.repo}/git/blobs/${encodeURIComponent(entry.sha)}`, { token: tok, timeoutMs: BLOB_TIMEOUT_MS });
    const j = res.json || {};
    if (j.encoding !== 'base64' || typeof j.content !== 'string') throw new GhError(`GitHub вернул файл «${entry.path}» в неожиданном виде.`, { code: 'bad_response' });
    const bytes = Buffer.from(j.content, 'base64');
    if (gitBlobSha(bytes) !== entry.sha) throw new GhError(`Файл «${entry.path}» скачался с ошибкой (не совпала контрольная сумма). Повторите.`, { code: 'corrupt_download' });
    return bytes;
  }

  /** Проверяет, что JSON — состояние редактора AmazFace. */
  function inspectState(text) {
    let obj;
    try { obj = JSON.parse(text); } catch (e) { return { ok: false, error: 'Файл состояния повреждён: это не корректный JSON.' }; }
    if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return { ok: false, error: 'Файл состояния повреждён: ожидался объект проекта.' };
    const hasScenes = obj.scenes && typeof obj.scenes === 'object' && obj.scenes.normal && Array.isArray(obj.scenes.normal.components);
    if (!Array.isArray(obj.components) && !hasScenes) return { ok: false, error: 'Файл не похож на состояние редактора AmazFace (нет списка компонентов).' };
    const name = obj.meta && typeof obj.meta.name === 'string' ? obj.meta.name.trim() : '';
    return { ok: true, name };
  }

  // ───────── Список папок ─────────
  async function listProjects() {
    const { cfg, tok } = await need();
    let result;
    try {
      result = await api('GET', contentsUrl(cfg, cfg.folder), { token: tok });
    } catch (e) {
      if (e.code === 'not_found') throw new GhError(`Ветка ${IMPORT_BRANCH} или папка «${cfg.folder || '/'}» не найдены в ${cfg.owner}/${cfg.repo}. Импорт читает только ветку ${IMPORT_BRANCH}.`, { status: 404, code: 'branch_not_found' });
      throw e;
    }
    if (!Array.isArray(result.json)) {
      throw new GhError(`Путь «${cfg.folder || '/'}» в репозитории не является папкой.`, { code: 'not_directory', status: 400 });
    }
    const folders = result.json
      .filter((item) => item && item.type === 'dir' && typeof item.path === 'string' && segmentsOk(item.path.split('/')))
      .map((item) => {
        const dir = cleanRepoDir(item.path);
        if (item.sha) {
          const key = manifestKey(cfg, dir);
          folderShas.set(key, item.sha);
          manifests.delete(key);
        }
        return { dir, folder: item.name || dir.slice(dir.lastIndexOf('/') + 1) };
      })
      .sort((a, b) => a.dir.localeCompare(b.dir));
    log(`Импорт: найдено папок ${folders.length} в ${cfg.owner}/${cfg.repo}@${IMPORT_BRANCH}`);
    return {
      repo: `${cfg.owner}/${cfg.repo}`, branch: IMPORT_BRANCH, root: cfg.folder, projects: folders,
      note: result.json.length >= 1000 ? 'GitHub вернул первые 1000 записей этой папки.' : ''
    };
  }

  // ───────── Манифест файлов выбранной папки ─────────
  async function buildManifest(dir, auth) {
    const { cfg, tok } = auth || await need();
    const cacheKey = manifestKey(cfg, dir);
    const tree = await folderTree(cfg, tok, dir);
    const g = groupCandidates(tree).get(dir);
    if (!g) throw new GhError('Папка не найдена в репозитории или в ней нет файла .watchface.json.', { code: 'not_project', status: 404 });
    if (g.states.length !== 1) throw new GhError('В папке несколько файлов .watchface.json — импорт невозможен.', { code: 'not_project', status: 400 });
    const stateEntry = g.states[0];
    const stateBytes = await readBlob(cfg, tok, stateEntry, MAX_STATE_BYTES);
    const stateInfo = inspectState(stateBytes.toString('utf8'));
    if (!stateInfo.ok) throw new GhError(stateInfo.error, { code: 'bad_state', status: 422 });
    const files = new Map();
    let total = 0;
    for (const t of g.files) {
      const rel = t.path.slice(dir.length + 1);
      if (!segmentsOk(rel.split('/'))) continue;
      const isState = t.path === stateEntry.path;
      if (!isState && SKIP_FILE_RE.test(rel)) continue;
      if (!isState && STATE_FILE_RE.test(rel.split('/').pop())) continue;
      const role = isState ? 'state' : rel === 'project.zip' ? 'project-zip' : 'file';
      files.set(rel, { path: rel, repoPath: t.path, sha: t.sha, size: t.size || 0, role });
      total += t.size || 0;
    }
    if (files.size > MAX_FILES) throw new GhError(`В папке слишком много файлов (${files.size}).`, { code: 'too_big', status: 413 });
    if (total > MAX_TOTAL_BYTES) throw new GhError(`Папка слишком большая (${Math.round(total / 1048576)} МБ).`, { code: 'too_big', status: 413 });
    const manifest = { at: now(), files, total, projectName: stateInfo.name, stateBytes };
    manifests.set(cacheKey, manifest);
    return manifest;
  }

  async function getManifest(dirRaw) {
    const dir = cleanRepoDir(dirRaw);
    const auth = await need();
    const { cfg } = auth;
    const key = manifestKey(cfg, dir);
    let m = manifests.get(key);
    if (!m || now() - m.at > MANIFEST_TTL_MS) m = await buildManifest(dir, auth);
    return {
      dir, total: m.total, projectName: m.projectName,
      files: [...m.files.values()].map((f) => ({ path: f.path, size: f.size, role: f.role }))
    };
  }

  async function getFile(dirRaw, pathRaw) {
    const dir = cleanRepoDir(dirRaw);
    const rel = cleanRelPath(pathRaw);
    const auth = await need();
    const { cfg, tok } = auth;
    const key = manifestKey(cfg, dir);
    let m = manifests.get(key);
    if (!m || now() - m.at > MANIFEST_TTL_MS) m = await buildManifest(dir, auth);
    const entry = m.files.get(rel);
    if (!entry) throw new GhError('Такого файла нет в папке проекта.', { code: 'bad_path', status: 404 });
    if (entry.role === 'state' && m.stateBytes) return m.stateBytes;
    return readBlob(cfg, tok, { path: entry.repoPath, sha: entry.sha, size: entry.size }, entry.role === 'state' ? MAX_STATE_BYTES : MAX_FILE_BYTES);
  }

  return { listProjects, getManifest, getFile, _internals: { cleanRepoDir, cleanRelPath, inspectState, groupCandidates, STATE_FILE_RE, SKIP_FILE_RE } };
}

module.exports = { createImporter, IMPORT_BRANCH };
