// Тап-зона «Фонарик (вкл./выкл.)»: экспорт, поведение в симуляции рантайма и совместимость со старыми проектами.
// Запуск: node scripts/test-flashlight.js
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const fx = require('./export-fixtures.js');

const root = path.resolve(__dirname, '..');
const ex = fx.loadExporter(root);
const { REGISTRY, exportIndexJs, exportIndexJsDual } = ex;

let passed = 0, failed = 0;
const check = (n, c, x) => { if (c) { passed++; console.log('ok: ' + n); } else { failed++; console.log('FAIL: ' + n + (x ? ' — ' + x : '')); } };

const zone = (id, props, geo) => Object.assign({ id, name: id, x: 0, y: 0, w: 120, h: 60, visible: true, locked: false, props }, geo || {});
const withZones = (zones, defId = 'fill_rect', props = { color: '#334455' }) => {
  const c = fx.mk('c1', defId, props, { w: 200, h: 100 });
  c.tapZones = zones;
  return c;
};
const FLASH = { tap_action: 'FLASHLIGHT' };

// Мини-рантайм Zepp OS: выполняет сгенерированный index.js и фиксирует состояние виджетов.
function runWatchface(code) {
  const widgets = [];
  const mkWidget = (type, params) => {
    const w = { type, params, visible: true, alpha: null, props: {} };
    w.setAlpha = (a) => { w.alpha = a; };
    w.setProperty = (k, v) => { if (k === 'VISIBLE') w.visible = !!v; else w.props[k] = v; };
    w.getProperty = () => undefined;
    widgets.push(w);
    return w;
  };
  const proxy = new Proxy({}, { get: (_, k) => String(k) });
  let built = null;
  const body = code.replace(/^import .*$/gm, '');
  const sandbox = {
    console, Math, Date, JSON,
    createWidget: mkWidget, widget: proxy, align: proxy, text_style: proxy, prop: proxy, show_level: proxy, data_type: proxy,
    system_status: proxy, anim_status: proxy, launchApp: () => {}, setInterval: () => 1, clearInterval: () => {},
    Time: function () { this.getTime = () => 0; }, Battery: function () {}, Step: function () {},
    WatchFace: (o) => { built = o; },
  };
  vm.createContext(sandbox);
  vm.runInContext(body, sandbox, { filename: 'index.js' });
  built.build.call({});
  return widgets;
}
const buttons = (ws) => ws.filter((w) => w.type === 'BUTTON');

// 1. Реестр и валидация
{
  const opts = REGISTRY.fill_rect.properties.find((p) => p.key === 'tap_action').options.map((o) => o.value);
  check('реестр: действие FLASHLIGHT добавлено', opts.includes('FLASHLIGHT'));
  check('реестр: прежние действия NONE/METRIC/APP на месте', ['NONE', 'METRIC', 'APP'].every((v) => opts.includes(v)));
  const app = fs.readFileSync(path.join(root, 'src/app.js'), 'utf8');
  check('валидация: FLASHLIGHT допустим', /\['NONE', 'METRIC', 'APP', 'FLASHLIGHT'\]\.includes\(action\)/.test(app));
  const insp = fs.readFileSync(path.join(root, 'src/inspector/inspector.js'), 'utf8');
  check('инспектор: пункт «Фонарик» в списке действий тап-зоны', insp.includes('<option value="FLASHLIGHT"'));
}

// 2. Экспорт одной зоны
let r1, ws1;
{
  r1 = exportIndexJs(fx.project([withZones([zone('tap_001', FLASH, { x: 10, y: 20, w: 100, h: 50 })])]), {}, {}, {});
  const code = r1.code;
  check('экспорт: нет ошибок валидации', r1.validation.errors.length === 0, r1.validation.errors.join('; '));
  check('экспорт: код синтаксически корректен', (() => { try { new vm.Script(code.replace(/^import .*$/gm, '')); return true; } catch (e) { return false; } })());
  check('экспорт: белая заливка на весь экран', /createWidget\(widget\.FILL_RECT, \{[^}]*w: 480[^}]*h: 480[^}]*color: 0xffffff/s.test(code) || /__flash = createWidget\(widget\.FILL_RECT/.test(code));
  check('экспорт: launchApp не подключается без нужды', !/@zos\/router/.test(code));
  ws1 = runWatchface(code);
  const btns = buttons(ws1);
  check('рантайм: две кнопки — зона и «закрыть»', btns.length === 2, String(btns.length));
  const [zoneBtn, closeBtn] = btns;
  const overlay = ws1.find((w) => w.type === 'FILL_RECT' && w.params.w === 480 && w.params.h === 480 && w.params.color === 0xffffff);
  check('рантайм: оверлей создан и в начале скрыт', !!overlay && overlay.visible === false);
  check('рантайм: «закрыть» в начале скрыта и на весь экран', closeBtn.visible === false && closeBtn.params.w === 480 && closeBtn.params.h === 480);
  check('рантайм: оверлей и «закрыть» созданы выше всех виджетов и зон', ws1.indexOf(overlay) > ws1.indexOf(zoneBtn) && ws1.indexOf(closeBtn) > ws1.indexOf(overlay) && ws1.indexOf(closeBtn) === ws1.length - 1);
  check('рантайм: зона в нужных координатах и прозрачна', zoneBtn.params.x === 40 + 10 && zoneBtn.params.y === 60 + 20 && zoneBtn.params.w === 100 && zoneBtn.params.h === 50 && zoneBtn.alpha === 0);
  zoneBtn.params.click_func();
  check('рантайм: тап 1 — белый экран включён', overlay.visible === true && closeBtn.visible === true);
  closeBtn.params.click_func();
  check('рантайм: тап 2 — возврат к циферблату', overlay.visible === false && closeBtn.visible === false);
  zoneBtn.params.click_func();
  check('рантайм: повторный цикл включения работает', overlay.visible === true);
  zoneBtn.params.click_func();
  check('рантайм: тап по самой зоне при включённом фонарике выключает', overlay.visible === false);
}

// 3. Несколько зон фонарика — один общий оверлей
{
  const r = exportIndexJs(fx.project([withZones([zone('a', FLASH), zone('b', FLASH, { x: 100 })])]), {}, {}, {});
  const ws = runWatchface(r.code);
  check('несколько зон: один оверлей и одна кнопка «закрыть»', ws.filter((w) => w.type === 'FILL_RECT' && w.params.w === 480 && w.params.color === 0xffffff).length === 1 && buttons(ws).length === 3);
  const [a, b] = buttons(ws);
  const overlay = ws.find((w) => w.params && w.params.color === 0xffffff && w.params.w === 480);
  a.params.click_func();
  const onA = overlay.visible;
  buttons(ws)[2].params.click_func();
  b.params.click_func();
  check('несколько зон: любая включает, «закрыть» выключает', onA === true && overlay.visible === true);
}

// 4. Смешивание с другими действиями
{
  const c = withZones([zone('m', { tap_action: 'METRIC', tap_metric: 'HR' }), zone('f', FLASH, { x: 130 }), zone('n', { tap_action: 'NONE' }, { x: 5 })]);
  const r = exportIndexJs(fx.project([c]), {}, {}, {});
  check('смесь: системный экран по-прежнему экспортируется', /launchApp\(\{ appId: SYSTEM_APP_HR, native: true \}\)/.test(r.code) && /@zos\/router/.test(r.code));
  check('смесь: NONE по-прежнему не создаёт кнопку', buttons(runWatchface(r.code)).length === 3);
}

// 5. AOD / две сцены: имена не пересекаются, оверлей только в Normal
{
  const normal = [withZones([zone('f', FLASH)])];
  const p = fx.project(normal, [fx.mk('t2', 'text', { data_source: 'TIME', time_format: 'HH:MM', text_size: 60, color: '#888' })]);
  const r = exportIndexJsDual(p, {}, {}, {});
  check('две сцены: код синтаксически корректен', (() => { try { new vm.Script(r.code.replace(/^import .*$/gm, '')); return true; } catch (e) { return false; } })());
  check('две сцены: оверлей привязан к show_level Normal', /show_level: show_level\.ONLY_NORMAL,\s*x: 0, y: 0, w: 480, h: 480, color: 0xffffff/.test(r.code) || /__flash[^=]*= createWidget\(widget\.FILL_RECT, \{\s*show_level: show_level\.ONLY_NORMAL/.test(r.code), r.code.match(/__flash[^\n]*\n[^\n]*/g)?.join(' | '));
  check('две сцены: переменные не объявлены дважды', (r.code.match(/let __flashOn\w*/g) || []).length <= 1);
}

// 6. Совместимость: старые проекты (без FLASHLIGHT) экспортируются без следов фонарика
{
  const old = exportIndexJs(fx.project([withZones([zone('m', { tap_action: 'METRIC', tap_metric: 'SLEEP' }), zone('a', { tap_action: 'APP', tap_app_id: 1, tap_app_url: 'pages/index' })])]), {}, {}, {});
  check('совместимость: в старом проекте нет кода фонарика', !/__flash/.test(old.code));
  const none = exportIndexJs(fx.project([fx.mk('t1', 'text', { data_source: 'NONE', text: 'a', text_size: 30, color: '#fff' })]), {}, {}, {});
  check('совместимость: проект без тап-зон без следов фонарика', !/__flash/.test(none.code));
  check('совместимость: предупреждение про фонарик только когда он используется', !old.validation.warnings.some((w) => /Фонарик/.test(w)) && r1.validation.warnings.some((w) => /Фонарик/.test(w)));
}

// 7. Невидимая зона не создаёт фонарик
{
  const r = exportIndexJs(fx.project([withZones([zone('f', FLASH, { visible: false })])]), {}, {}, {});
  check('скрытая зона не создаёт оверлей', !/__flash/.test(r.code));
}

// 8. Манифест tap-zones.json и сохранение/миграция проекта
{
  const pe = fs.readFileSync(path.join(root, 'src/exporter/project-exporter.js'), 'utf8');
  check('манифест: действие пробрасывается как есть', /action: Object\.assign\(\{ tap_action: 'NONE' \}, zone\.props \|\| \{\}\)/.test(pe));
  const pj = fs.readFileSync(path.join(root, 'src/project/project.js'), 'utf8');
  check('миграция: tap_action существующей зоны не перезаписывается', /if \(!props\.tap_action\) \{/.test(pj));
}

console.log(`\nТесты фонарика: ${passed} прошло, ${failed} упало.`);
process.exit(failed ? 1 : 0);
