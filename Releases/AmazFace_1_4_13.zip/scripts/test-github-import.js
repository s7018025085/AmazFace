// Тесты импорта проектов из GitHub: мост (поддельный GitHub на loopback) и
// клиентская логика (настоящий zip-reader + поддельная файловая система).
// Запуск: node scripts/test-github-import.js
const http = require('node:http');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const vm = require('node:vm');
const { createPublisher, createConfigStore, gitBlobSha } = require('../bridge/github-publisher.js');
const { createGithubRoutes } = require('../bridge/github-routes.js');
const { createFakeGithub, TOKEN, OWNER, REPO } = require('./fake-github.js');
const AmazImport = require('../src/project/github-import.js');

let passed = 0, failed = 0;
function ok(name, cond, extra) {
  if (cond) { passed++; console.log('ok: ' + name); }
  else { failed++; console.log('FAIL: ' + name + (extra ? ' — ' + extra : '')); }
}
const rejects = async (p) => { try { await p; return null; } catch (e) { return e; } };

// ───────── настоящий zip-reader (как в браузере) и простой ZIP «store» ─────────
const zctx = { TextDecoder, Uint8Array, Blob, Response, DecompressionStream };
vm.createContext(zctx);
vm.runInContext(fs.readFileSync(path.join(__dirname, '../src/exporter/zip-reader.js'), 'utf8') + '\nglobalThis.__rz = readZipEntries;', zctx);
const readZipEntries = (b) => zctx.__rz(b);

function makeZip(entries) {
  const locals = [], centrals = [];
  let offset = 0;
  for (const [name, data] of Object.entries(entries)) {
    const nm = Buffer.from(name), d = Buffer.from(data);
    const lh = Buffer.alloc(30); lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt32LE(d.length, 18); lh.writeUInt32LE(d.length, 22); lh.writeUInt16LE(nm.length, 26);
    const ch = Buffer.alloc(46); ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(20, 4); ch.writeUInt16LE(20, 6); ch.writeUInt32LE(d.length, 20); ch.writeUInt32LE(d.length, 24); ch.writeUInt16LE(nm.length, 28); ch.writeUInt32LE(offset, 42);
    locals.push(lh, nm, d); centrals.push(ch, nm);
    offset += 30 + nm.length + d.length;
  }
  const cd = Buffer.concat(centrals);
  const eocd = Buffer.alloc(22); eocd.writeUInt32LE(0x06054b50, 0); eocd.writeUInt16LE(Object.keys(entries).length, 8); eocd.writeUInt16LE(Object.keys(entries).length, 10); eocd.writeUInt32LE(cd.length, 12); eocd.writeUInt32LE(offset, 16);
  return Buffer.concat([...locals, cd, eocd]);
}

// ───────── данные ─────────
const state = (name, comps, assets) => JSON.stringify({
  meta: { name }, device: { targetKey: 'amazfit_balance_2' },
  components: Array.from({ length: comps }, (_, i) => ({ id: 'c' + i })),
  assets: Array.from({ length: assets }, (_, i) => ({ id: 'a' + i, name: 'img' + i, dataUrl: 'data:image/png;base64,AAAA' })),
  scenes: { normal: { components: Array.from({ length: comps }, (_, i) => ({ id: 'c' + i })) } }
});
const HAM_STATE = Buffer.from(state('Hamilton Dial', 2, 1));
const PNG = Buffer.from([0x89, 0x50, 0x4e, 0x47, 1, 2, 3, 4, 5]);
const HAM_ZIP = makeZip({
  'app.json': '{"app":{"appId":1,"appName":"Hamilton Dial"}}',
  'package.json': '{"name":"ham"}',
  'watchface/index.js': 'hmUI.createWidget();',
  'assets/amazfit_balance_2/dial.png': PNG
});
const HAM_DIR = 'watchfaces/Balance2/Hamilton';

function seedRepo(gh) {
  const put = (p, data) => { const bytes = Buffer.from(data); gh.files.set(p, { bytes, sha: gitBlobSha(bytes) }); };
  put(`${HAM_DIR}/Hamilton.watchface.json`, HAM_STATE);
  put(`${HAM_DIR}/project.zip`, HAM_ZIP);
  put(`${HAM_DIR}/Hamilton.zpk`, 'PK-zpk');
  put(`${HAM_DIR}/device.zip`, 'PK-device');
  put(`${HAM_DIR}/README.md`, '# Hamilton');
  put(`${HAM_DIR}/amazface-publish.json`, '{"appId":1}');
  put('watchfaces/Balance2/Broken/Broken.watchface.json', '{not json');
  put('watchfaces/Balance2/WrongShape/WrongShape.watchface.json', '{"foo":1}');
  put('watchfaces/Balance2/NoState/project.zip', 'PK-x');
  put('watchfaces/Balance2/NoState/README.md', 'x');
  put('watchfaces/Other/.watchface.json', state('Other', 0, 0));
  put('watchfaces/Other/.git/config', '[core]');
  put('docs/README.md', 'docs');
  put('README.md', 'root');
}

// ───────── поддельная файловая система (File System Access API) ─────────
function domErr(name) { const e = new Error(name); e.name = name; return e; }
function makeFs() {
  const fsx = { failWrite: null, writes: [] };
  class Dir {
    constructor(name, p) { this.name = name; this.path = p; this.kind = 'directory'; this.kids = new Map(); }
    async getDirectoryHandle(n, o) {
      const k = this.kids.get(n);
      if (k) { if (!(k instanceof Dir)) throw domErr('TypeMismatchError'); return k; }
      if (!(o && o.create)) throw domErr('NotFoundError');
      const d = new Dir(n, this.path + n + '/'); this.kids.set(n, d); return d;
    }
    async getFileHandle(n, o) {
      let k = this.kids.get(n);
      if (k && k instanceof Dir) throw domErr('TypeMismatchError');
      if (!k) { if (!(o && o.create)) throw domErr('NotFoundError'); k = { data: new Uint8Array(0), path: this.path + n }; this.kids.set(n, k); }
      const f = k;
      return { name: n, kind: 'file',
        async getFile() { return { size: f.data.length, async arrayBuffer() { return f.data.buffer.slice(f.data.byteOffset, f.data.byteOffset + f.data.length); } }; },
        async createWritable() { return { async write(d) { if (fsx.failWrite && fsx.failWrite(f.path)) throw new Error('disk full'); fsx.writes.push(f.path); f.data = new Uint8Array(d); }, async close() {} }; } };
    }
    async removeEntry(n, o) {
      const k = this.kids.get(n); if (!k) throw domErr('NotFoundError');
      if (k instanceof Dir && k.kids.size && !(o && o.recursive)) throw domErr('InvalidModificationError');
      this.kids.delete(n);
    }
  }
  fsx.root = new Dir('parent', '');
  fsx.list = (d, pre) => { const out = []; for (const [n, k] of d.kids) { if (k instanceof Dir) out.push(...fsx.list(k, pre + n + '/')); else out.push(pre + n); } return out; };
  return fsx;
}

// ───────── HTTP-помощник ─────────
function makeCall(port) {
  return (method, p, o) => new Promise((resolve, reject) => {
    o = o || {};
    const req = http.request({ host: '127.0.0.1', port, path: p, method, headers: Object.assign({ Host: o.host || ('127.0.0.1:' + port) }, o.headers || {}) }, (res) => {
      const ch = []; res.on('data', (c) => ch.push(c));
      res.on('end', () => { const buf = Buffer.concat(ch); let json = null; try { json = JSON.parse(buf.toString('utf8')); } catch (e) { /* бинарный ответ */ } resolve({ status: res.statusCode, headers: res.headers, buf, json }); });
    });
    req.on('error', reject); req.end();
  });
}

async function main() {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'amazface-import-test-'));
  const gh = createFakeGithub();
  await new Promise((r) => gh.server.listen(0, '127.0.0.1', r));
  const base = 'http://127.0.0.1:' + gh.server.address().port;
  seedRepo(gh);
  const mkPub = (store) => createPublisher({ store, apiBase: base, rawBase: base + '/raw', sleep: () => new Promise((r) => setImmediate(r)), backoffMs: 1, apiTimeoutMs: 3000, retries: 1, maxRateWaitMs: 1000 });
  const store = createConfigStore({ dir: path.join(tmp, 'cfg'), platform: 'linux' });
  const pub = mkPub(store);
  gh.branches.add('develop-not-used'); // ветка из настроек публикации; импорт всё равно читает main
  await pub.connect({ owner: OWNER, repo: REPO, branch: 'develop-not-used', folder: 'watchfaces/Balance2', token: TOKEN });
  const before = gh.requestLog.length;

  // ───── 1. список папок (быстрый, без чтения содержимого) ─────
  let list = await pub.listImportProjects();
  const listed = list.projects.map((p) => p.dir).sort();
  ok('list: показаны только папки внутри папки публикации', JSON.stringify(listed) === JSON.stringify(['Broken', 'Hamilton', 'NoState', 'WrongShape'].map((n) => 'watchfaces/Balance2/' + n)), JSON.stringify(list.projects));
  const ham = list.projects.find((p) => p.dir === HAM_DIR);
  ok('list: у папки есть название и путь', ham && ham.folder === 'Hamilton');
  ok('list: чужая папка вне папки публикации не показывается', !list.projects.some((p) => p.dir === 'watchfaces/Other'));
  ok('list: содержимое папок на этом шаге не читается (ни trees, ни blobs)', !gh.requestLog.slice(before).some((r) => /\/git\/(trees|blobs)\//.test(r)));
  ok('list: используется ветка main, а не ветка из настроек публикации', list.branch === 'main' && list.root === 'watchfaces/Balance2' && !gh.requestLog.slice(before).some((r) => /develop-not-used/.test(r)));
  ok('list: токен не попадает в ответ', !JSON.stringify(list).includes(TOKEN));

  // ───── 2. манифест и файлы ─────
  const man = await pub.getImportManifest(HAM_DIR);
  const paths = man.files.map((f) => f.path).sort();
  ok('manifest: только нужное — состояние и project.zip', JSON.stringify(paths) === JSON.stringify(['Hamilton.watchface.json', 'project.zip']), paths.join());
  ok('manifest: роли файлов размечены', man.files.find((f) => f.path === 'project.zip').role === 'project-zip' && man.files.find((f) => f.path.endsWith('.watchface.json')).role === 'state');
  const manO = await pub.getImportManifest('watchfaces/Other');
  ok('manifest: .git не попадает в список', !manO.files.some((f) => /\.git/.test(f.path)) && manO.files.length === 1);
  ok('manifest: соседние проекты не включаются', !man.files.some((f) => /Broken|Other/.test(f.path)));
  const stateBytes = await pub.getImportFile(HAM_DIR, 'Hamilton.watchface.json');
  ok('file: содержимое совпадает побайтно', Buffer.compare(stateBytes, HAM_STATE) === 0 && Buffer.compare(await pub.getImportFile(HAM_DIR, 'project.zip'), HAM_ZIP) === 0);

  // ───── 3. недопустимые пути ─────
  const reqBefore = gh.requestLog.length;
  for (const d of ['../x', `${HAM_DIR}/../Broken`, '/etc', 'a\\b', 'watchfaces/.git', '', 'watchfaces//Other', `${HAM_DIR}/`]) {
    const e = await rejects(pub.getImportManifest(d));
    ok(`path: папка «${d}» отклонена`, e && e.code === 'bad_path');
  }
  for (const f of ['../../secret', '.git/config', '/etc/passwd', 'a\\b', '', 'README.md', 'device.zip', 'nope.txt']) {
    const e = await rejects(pub.getImportFile(HAM_DIR, f));
    ok(`path: файл «${f}» отклонён`, e && (e.code === 'bad_path'));
  }
  let e = await rejects(pub.getImportManifest('docs'));
  ok('path: папка без .watchface.json недоступна для скачивания', e && e.code === 'not_project');
  ok('path: к GitHub не ушло ни одного запроса с «..» или «.git»', !gh.requestLog.slice(reqBefore).some((r) => /\.\.|\.git\b/.test(r)));

  // ───── 4. ошибки сети и GitHub API ─────
  gh.hooks.get = (sub) => (sub.startsWith('/contents') ? { drop: true } : null);
  e = await rejects(pub.listImportProjects());
  ok('error: обрыв сети → понятная ошибка', e && e.network === true && /Сетев|сервер/.test(e.message));
  gh.hooks.get = (sub) => (sub.startsWith('/contents') ? { status: 403, body: { message: 'API rate limit exceeded' }, headers: { 'retry-after': '3600' } } : null);
  e = await rejects(pub.listImportProjects());
  ok('error: лимит запросов GitHub → понятное сообщение', e && e.code === 'rate_limit' && /ограничил/.test(e.message));
  gh.hooks.get = (sub) => (sub.startsWith('/contents') ? { status: 401, body: { message: 'Bad credentials' } } : null);
  e = await rejects(pub.listImportProjects());
  ok('error: 401 → токен не принят', e && e.code === 'auth');
  gh.hooks.get = null;
  await pub.listImportProjects(); // свежий список сбрасывает кэш манифестов
  gh.hooks.get = (sub) => (sub.startsWith('/git/blobs/') ? { drop: true } : null);
  e = await rejects(pub.getImportFile(HAM_DIR, 'Hamilton.watchface.json'));
  ok('error: обрыв при скачивании файла', e && e.network === true);
  gh.hooks.get = null;
  await pub.listImportProjects(); // свежий список сбрасывает кэш манифестов
  gh.treeTruncated = true;
  e = await rejects(pub.getImportManifest(HAM_DIR));
  ok('manifest: усечённое дерево папки → понятная ошибка', e && e.code === 'too_many_files' && /слишком много файлов/.test(e.message));
  gh.treeTruncated = false;
  gh.branches.delete('main');
  e = await rejects(pub.listImportProjects());
  ok('error: нет ветки main', e && e.code === 'branch_not_found' && /main/.test(e.message));
  gh.branches.add('main');
  const noTok = mkPub(createConfigStore({ dir: path.join(tmp, 'cfg-empty'), platform: 'linux' }));
  e = await rejects(noTok.listImportProjects());
  ok('error: GitHub не подключён → подсказка про настройки публикации', e && e.code === 'not_connected' && /Опубликовать на GitHub/.test(e.message));

  // повреждение при передаче ловится контрольной суммой
  const f0 = gh.files.get(`${HAM_DIR}/Hamilton.watchface.json`);
  gh.hooks.get = null;
  const savedBytes = f0.bytes; f0.bytes = Buffer.from(savedBytes.toString().replace('Hamilton', 'Hamiltoo'));
  e = await rejects(pub.getImportFile(HAM_DIR, 'Hamilton.watchface.json'));
  ok('error: несовпадение контрольной суммы файла обнаруживается', e && e.code === 'corrupt_download');
  f0.bytes = savedBytes;

  // ───── 5. пустой репозиторий ─────
  const saved = new Map(gh.files); gh.files.clear();
  e = await rejects(pub.listImportProjects());
  ok('error: пустой репозиторий → понятная ошибка вместо падения', e && e.code === 'branch_not_found' && /main/.test(e.message));
  for (const [k, v] of saved) gh.files.set(k, v);

  // ───── 6. HTTP-слой моста ─────
  const routes = createGithubRoutes({ store, publisher: pub });
  const bridge = http.createServer((req, res) => { if (routes.matches(req)) return routes.handle(req, res); res.writeHead(404); res.end(); });
  await new Promise((r) => bridge.listen(0, '127.0.0.1', r));
  const call = makeCall(bridge.address().port);
  const KEY = routes.bridgeKey();
  const H = { 'X-AmazFace-Key': KEY };
  let r = await call('GET', '/github/import/projects');
  ok('http: без кода доступа → 401', r.status === 401);
  r = await call('GET', '/github/import/projects', { headers: { 'X-AmazFace-Key': 'x'.repeat(32) } });
  ok('http: неверный код доступа → 401', r.status === 401);
  r = await call('GET', '/github/import/projects', { headers: Object.assign({ Origin: 'https://evil.example' }, H) });
  ok('http: чужой Origin → 403', r.status === 403);
  r = await call('GET', '/github/import/projects', { host: 'evil.example', headers: H });
  ok('http: чужой Host → 403', r.status === 403);
  r = await call('GET', '/github/import/projects', { headers: H });
  ok('http: список папок', r.status === 200 && r.json.projects.length === 4);
  ok('http: токена нет ни в теле, ни в заголовках ответа', !r.buf.toString().includes(TOKEN) && !JSON.stringify(r.headers).includes(TOKEN));
  r = await call('GET', `/github/import/manifest?dir=${encodeURIComponent(HAM_DIR)}`, { headers: H });
  ok('http: манифест', r.status === 200 && r.json.files.length === 2);
  r = await call('GET', `/github/import/file?dir=${encodeURIComponent(HAM_DIR)}&path=project.zip`, { headers: H });
  ok('http: файл отдаётся байтами', r.status === 200 && /octet-stream/.test(r.headers['content-type']) && Buffer.compare(r.buf, HAM_ZIP) === 0);
  r = await call('GET', `/github/import/file?dir=${encodeURIComponent(HAM_DIR)}&path=${encodeURIComponent('../Broken/Broken.watchface.json')}`, { headers: H });
  ok('http: обход каталога через path отклонён', r.status === 400 && r.json.code === 'bad_path');
  r = await call('GET', `/github/import/manifest?dir=${encodeURIComponent('../../etc')}`, { headers: H });
  ok('http: обход каталога через dir отклонён', r.status === 400 && r.json.code === 'bad_path');
  r = await call('GET', '/github/import/manifest', { headers: H });
  ok('http: dir не передан → ошибка пути', r.status === 400 && r.json.code === 'bad_path');
  r = await call('POST', '/github/import/projects', { headers: H });
  ok('http: импорт доступен только методом GET', r.status === 404);

  // ───── 7. мост ничего не публикует ─────
  const writes = gh.requestLog.filter((x) => /^(PUT|POST|PATCH|DELETE) /.test(x));
  ok('safe: за весь импорт на GitHub не было ни одной записи', gh.putCount === 0 && writes.length === 0, writes.join());
  ok('safe: ни одного запроса к raw/произвольным URL', !gh.requestLog.some((x) => /\/raw\//.test(x)));
  bridge.close();

  // ═════════ Клиентская часть ═════════
  const A = AmazImport;
  for (const bad of ['', '/abs', 'C:/x', 'a\\b', 'a//b', '../x', 'a/../b', './a', '.git/config', 'x/.GIT/y']) {
    ok(`client: путь «${bad}» отклонён`, !!(await rejects((async () => A.validateRelPath(bad))())));
  }
  ok('client: нормальный путь принят', A.validateRelPath('assets/amazfit_balance_2/dial.png').length === 3);
  ok('client: имя папки очищается от запрещённых символов', A.safeFolderName('Мой:циф/ферблат?') === 'Мой_циф_ферблат_');
  ok('client: зарезервированные и пустые имена', A.safeFolderName('CON') === '_CON' && A.safeFolderName('...') === 'amazface-project' && A.safeFolderName('', 'Hamilton') === 'Hamilton' && A.safeFolderName('abc. ') === 'abc');
  ok('client: inspectState — корректное состояние', A.inspectState(HAM_STATE.toString()).ok === true && A.inspectState(HAM_STATE.toString()).componentCount === 2 && A.inspectState(HAM_STATE.toString()).assetCount === 1);
  ok('client: inspectState — повреждённый JSON и чужая структура', !A.inspectState('{bad').ok && !A.inspectState('[]').ok && !A.inspectState('{"foo":1}').ok);

  const remote = (dirMap) => ({
    fetchManifest: async () => ({ files: Object.keys(dirMap).map((p) => ({ path: p, size: dirMap[p].length, role: p.endsWith('.watchface.json') ? 'state' : p === 'project.zip' ? 'project-zip' : 'file' })) }),
    fetchFile: async (p) => new Uint8Array(dirMap[p]),
    unzip: readZipEntries
  });

  // успешная сборка и восстановление
  let calls = [];
  let staged = await A.stageImport(Object.assign(remote({ 'Hamilton.watchface.json': HAM_STATE, 'project.zip': HAM_ZIP }), { onProgress: (d, t) => calls.push([d, t]) }));
  const keys = [...staged.files.keys()].sort();
  ok('stage: состояние записывается как amazface.project.json (формат не менялся)', Buffer.compare(Buffer.from(staged.files.get('amazface.project.json')), HAM_STATE) === 0);
  ok('stage: файлы Zepp-проекта и ресурсы восстановлены из project.zip', ['app.json', 'package.json', 'watchface/index.js', 'assets/amazfit_balance_2/dial.png'].every((k) => staged.files.has(k)) && Buffer.compare(Buffer.from(staged.files.get('assets/amazfit_balance_2/dial.png')), PNG) === 0, keys.join());
  ok('stage: нет .zpk, device.zip, README и самого project.zip', !keys.some((k) => /\.zpk$|device\.zip|README|project\.zip|\.watchface\.json$/.test(k)));
  ok('stage: состояние разобрано (компоненты и ресурсы посчитаны)', staged.info.name === 'Hamilton Dial' && staged.info.componentCount === 2 && staged.info.assetCount === 1);
  ok('stage: прогресс доходит до конца', calls.length === 2 && calls[1][0] === 2 && calls[1][1] === 2);

  // повреждённое состояние — остальное даже не скачивается
  const fetched = [];
  e = await rejects(A.stageImport({ fetchManifest: async () => ({ files: [{ path: 'x.watchface.json', role: 'state' }, { path: 'project.zip', role: 'project-zip' }] }), fetchFile: async (p) => { fetched.push(p); return new Uint8Array(Buffer.from('{broken')); }, unzip: readZipEntries }));
  ok('stage: повреждённый .watchface.json → понятная ошибка, остальное не качается', e && e.code === 'bad_state' && /повреждён/.test(e.message) && fetched.length === 1);
  e = await rejects(A.stageImport({ fetchManifest: async () => ({ files: [{ path: 'project.zip', role: 'project-zip' }] }), fetchFile: async () => HAM_ZIP, unzip: readZipEntries }));
  ok('stage: нет .watchface.json → отказ', e && e.code === 'no_state');
  e = await rejects(A.stageImport({ fetchManifest: async () => ({ files: [{ path: '../evil.watchface.json', role: 'state' }] }), fetchFile: async () => HAM_STATE, unzip: readZipEntries }));
  ok('stage: недопустимый путь от моста отклонён', e && e.code === 'bad_path');
  e = await rejects(A.stageImport(Object.assign(remote({ 'Hamilton.watchface.json': HAM_STATE, 'project.zip': makeZip({ 'app.json': '{}', '../evil.txt': 'x' }) }))));
  ok('stage: «../» внутри project.zip отклонён (zip-slip)', e && e.code === 'bad_path');
  staged = await A.stageImport(remote({ 'Hamilton.watchface.json': HAM_STATE, 'project.zip': makeZip({ 'app.json': '{"app":{}}', '.git/config': '[core]', 'amazface.project.json': '{"old":1}', 'watchface/index.js': 'x' }) }));
  ok('stage: .git из архива отбрасывается, состояние из .watchface.json приоритетнее', ![...staged.files.keys()].some((k) => /\.git/.test(k)) && Buffer.compare(Buffer.from(staged.files.get('amazface.project.json')), HAM_STATE) === 0);
  e = await rejects(A.stageImport(remote({ 'Hamilton.watchface.json': HAM_STATE })));
  ok('stage: нет app.json и нечем его создать → отказ', e && e.code === 'no_app_json');
  staged = await A.stageImport(Object.assign(remote({ 'Hamilton.watchface.json': HAM_STATE }), { makeAppJson: () => '{"app":{"appName":"x"}}' }));
  ok('stage: app.json создаётся из состояния, если архива нет', JSON.parse(Buffer.from(staged.files.get('app.json')).toString()).app.appName === 'x');
  e = await rejects(A.stageImport(Object.assign(remote({ 'Hamilton.watchface.json': HAM_STATE, 'project.zip': Buffer.from('not a zip') }))));
  ok('stage: повреждённый project.zip → понятная ошибка', e && e.code === 'bad_zip');
  const net = remote({ 'Hamilton.watchface.json': HAM_STATE, 'project.zip': HAM_ZIP });
  net.fetchFile = async (p) => { if (p === 'project.zip') throw new Error('Локальный мост не отвечает.'); return new Uint8Array(HAM_STATE); };
  e = await rejects(A.stageImport(net));
  ok('stage: сетевая ошибка прерывает импорт без записи на диск', e && /мост не отвечает/.test(e.message));
  const ac = new AbortController(); ac.abort();
  e = await rejects(A.stageImport(Object.assign(remote({ 'Hamilton.watchface.json': HAM_STATE }), { signal: ac.signal })));
  ok('stage: отмена пользователем', e && e.name === 'AbortError');

  // запись: новая папка
  const good = (await A.stageImport(remote({ 'Hamilton.watchface.json': HAM_STATE, 'project.zip': HAM_ZIP }))).files;
  let fsx = makeFs();
  ok('commit: destinationExists — нет папки', (await A.destinationExists(fsx.root, 'Hamilton')) === false && fsx.root.kids.size === 0);
  let dir = await A.commitImport({ parent: fsx.root, name: 'Hamilton', files: good });
  ok('commit: новая папка создана, все файлы на месте', fsx.list(dir, '').sort().join() === [...good.keys()].sort().join());
  ok('commit: содержимое совпадает', Buffer.compare(Buffer.from(dir.kids.get('amazface.project.json').data), HAM_STATE) === 0);
  ok('commit: в импортированной копии нет .git и локального репозитория', !fsx.list(dir, '').some((p) => /(^|\/)\.git(\/|$)/.test(p)));
  ok('commit: временных папок не осталось', [...fsx.root.kids.keys()].join() === 'Hamilton');

  // сбой записи в новую папку — частичная папка не остаётся
  fsx = makeFs(); fsx.failWrite = (p) => p.endsWith('watchface/index.js');
  e = await rejects(A.commitImport({ parent: fsx.root, name: 'Hamilton', files: good }));
  ok('commit: ошибка записи → созданная папка удалена', e && /disk full/.test(e.message) && fsx.root.kids.size === 0);

  // существующая папка: без явного replace ничего не меняется
  fsx = makeFs();
  const old = await fsx.root.getDirectoryHandle('Hamilton', { create: true });
  await (await (await old.getFileHandle('my-notes.txt', { create: true })).createWritable()).write(Buffer.from('MINE'));
  const snapshot = fsx.list(fsx.root, '').join();
  ok('exists: существующая папка обнаруживается', (await A.destinationExists(fsx.root, 'Hamilton')) === true);
  e = await rejects(A.commitImport({ parent: fsx.root, name: 'Hamilton', files: good }));
  ok('exists: без подтверждения замена невозможна, данные нетронуты', e && e.code === 'exists' && fsx.list(fsx.root, '').join() === snapshot);
  e = await rejects(A.commitImport({ parent: fsx.root, name: 'Hamilton', files: good, replace: 'yes' }));
  ok('exists: replace принимается только как строгое true', e && e.code === 'exists' && fsx.list(fsx.root, '').join() === snapshot);
  // отмена замены в интерфейсе = commitImport не вызывается; проверяем, что откат после отказа не нужен
  ok('exists: отмена замены (commit не вызван) оставляет папку как была', fsx.list(fsx.root, '').join() === snapshot && Buffer.from(old.kids.get('my-notes.txt').data).toString() === 'MINE');

  // замена с подтверждением
  dir = await A.commitImport({ parent: fsx.root, name: 'Hamilton', files: good, replace: true });
  ok('replace: старое содержимое заменено новым', fsx.list(dir, '').sort().join() === [...good.keys()].sort().join() && !dir.kids.has('my-notes.txt'));
  ok('replace: временная папка удалена', [...fsx.root.kids.keys()].join() === 'Hamilton');

  // замена: сбой во временной копии — старое цело
  fsx = makeFs();
  const old2 = await fsx.root.getDirectoryHandle('Hamilton', { create: true });
  await (await (await old2.getFileHandle('my-notes.txt', { create: true })).createWritable()).write(Buffer.from('MINE'));
  fsx.failWrite = (p) => p.includes('/watchface/index.js');
  e = await rejects(A.commitImport({ parent: fsx.root, name: 'Hamilton', files: good, replace: true }));
  ok('replace: сбой при подготовке копии → старая папка не тронута, временная удалена', e && fsx.root.kids.has('Hamilton') && old2.kids.has('my-notes.txt') && [...fsx.root.kids.keys()].join() === 'Hamilton');

  // замена: сбой на финальном шаге — полная копия сохранена рядом
  fsx = makeFs();
  await fsx.root.getDirectoryHandle('Hamilton', { create: true });
  let n = 0; fsx.failWrite = (p) => { if (p.startsWith('Hamilton/') && p.endsWith('app.json')) { n++; return true; } return false; };
  e = await rejects(A.commitImport({ parent: fsx.root, name: 'Hamilton', files: good, replace: true }));
  const tmpKeep = [...fsx.root.kids.keys()].find((k) => k.includes(A.TMP_MARK));
  ok('replace: сбой на финальном шаге → понятная ошибка и полная копия сохранена', e && e.code === 'swap_failed' && tmpKeep && fsx.list(fsx.root.kids.get(tmpKeep), '').length === good.size && e.message.includes(tmpKeep));

  // ───── статические гарантии интерфейса ─────
  const ui = fs.readFileSync(path.join(__dirname, '../src/ui/github-import.js'), 'utf8');
  const code = ui.replace(/\/\/.*$/gm, '');
  ok('ui: нет публикации, экспорта и сборки после импорта', !/exportFullProject|exportZpk|startPublish|\/github\/publish|saveToFolder/i.test(code));
  ok('ui: только GET-запросы к мосту', !/method\s*:/i.test(code) && (code.match(/fetch\(/g) || []).length === 1);
  ok('ui: токен GitHub не читается и не сохраняется (в localStorage только код доступа моста)', (code.match(/localStorage\.setItem\(/g) || []).length === 1 && /setItem\(KEY_STORAGE/.test(code) && !/token/i.test(code));
  ok('ui: открытие — существующим механизмом welcome.js', /AmazWelcome\.openFolder/.test(code));
  const html = fs.readFileSync(path.join(__dirname, '../index.html'), 'utf8');
  ok('html: кнопка «Открыть из GitHub» на стартовом экране и скрипты подключены после зависимостей', /id="welcome-github"/.test(html) && html.indexOf('src/project/github-import.js') > html.indexOf('src/project/fs-project.js') && html.indexOf('src/ui/github-import.js') > html.indexOf('src/ui/welcome.js'));

  gh.server.close();
  fs.rmSync(tmp, { recursive: true, force: true });
  console.log(`\nТесты импорта из GitHub: ${passed} прошло, ${failed} упало.`);
  process.exit(failed ? 1 : 0);
}
main().catch((e) => { console.error('TEST CRASH', e); process.exit(2); });
