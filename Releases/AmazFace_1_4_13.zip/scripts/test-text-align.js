// Выравнивание текста в предпросмотре: LEFT/RIGHT/TOP/BOTTOM должны смещать точку привязки к краю рамки.
// Запуск: node scripts/test-text-align.js
const assert = require('node:assert');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const ctx = { console, Map, Promise, Math, Number, String, Object, Array, JSON, Set, Image: function () {}, document: { createElement: () => ({ getContext: () => null }) } };
ctx.window = ctx; ctx.globalThis = ctx;
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(__dirname, '../src/preview/renderer.js'), 'utf8'), ctx);
const R = ctx.WatchfacePreviewRenderer;
assert.ok(R && typeof R.textAnchor === 'function', 'textAnchor экспортируется');

const comp = { x: 100, y: 200, w: 80, h: 40 };
const at = (ah, av, arc) => R.textAnchor(comp, { align_h: ah, align_v: av }, arc);
const eq = (a, x, y, msg) => assert.deepStrictEqual({ x: a.x, y: a.y }, { x, y }, msg);

eq(at('CENTER_H', 'CENTER_V'), 140, 220, 'центр — как раньше');
eq(at('LEFT', 'CENTER_V'), 100, 220, 'LEFT: левый край рамки');
eq(at('RIGHT', 'CENTER_V'), 180, 220, 'RIGHT: правый край рамки');
eq(at('CENTER_H', 'TOP'), 140, 200, 'TOP: верх рамки');
eq(at('CENTER_H', 'BOTTOM'), 140, 240, 'BOTTOM: низ рамки');
eq(at('LEFT', 'TOP'), 100, 200, 'LEFT + TOP: левый верхний угол');
eq(at('RIGHT', 'BOTTOM'), 180, 240, 'RIGHT + BOTTOM: правый нижний угол');
eq(at(undefined, undefined), 140, 220, 'без выравнивания — центр');
eq(at('LEFT', 'TOP', true), 140, 220, 'текст по дуге остаётся в центре');

console.log('Text align tests passed.');
