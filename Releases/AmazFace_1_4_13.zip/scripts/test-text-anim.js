// Тесты анимации ТОЛЬКО компонента «Текст»: математика, эффекты, жизненный цикл,
// сохранение/Undo/Redo, экспорт index.js (в том числе выполнение сгенерированного
// кода на имитации Zepp OS), предпросмотр, отсутствие регрессий у остальных компонентов.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');
const TA = require(path.join(root, 'src/anim/text-anim.js'));
const fx = require('./export-fixtures.js');

let failed = 0, passed = 0;
function check(name, cond, extra) {
  if (!cond) { failed++; console.error('FAIL:', name, extra === undefined ? '' : extra); } else { passed++; console.log('ok:', name); }
}
const J = (o) => JSON.stringify(o);
const syntaxOk = (code) => { try { new vm.Script(code.replace(/^import .*$/gm, '')); return true; } catch (e) { return e.message; } };

const ex = fx.loadExporter(root, ['src/anim/text-anim.js', 'src/anim/text-anim-export.js']);
const textComp = (props, geo) => fx.mk('t1', 'text', Object.assign({ data_source: 'NONE', text: 'Привет, мир!', text_size: 40, color: '#ffffff', align_h: 'CENTER_H', align_v: 'CENTER_V' }, props), geo);
const withAnim = (props, anim, geo) => textComp(Object.assign({}, props, { text_anim: Object.assign({ enabled: true }, anim) }), geo);
const run = (comps, aod) => ex.exportIndexJs(fx.project(comps, aod), {}, {}, {});
const runDual = (comps, aod) => ex.exportIndexJsDual(fx.project(comps, aod), {}, {}, {});

// ---------------------------------------------------------------- 1. прогресс и плавность
{
  const e = TA.createFreshEngine();
  check('ease: концы 0 и 1 у всех функций', ['linear', 'in', 'out', 'inout'].every((n) => e.ease(n, 0) === 0 && e.ease(n, 1) === 1));
  check('ease: линейная = t', e.ease('linear', 0.3) === 0.3);
  check('ease: in медленнее линейной, out быстрее', e.ease('in', 0.5) < 0.5 && e.ease('out', 0.5) > 0.5);
  check('ease: inout симметрична', Math.abs(e.ease('inout', 0.5) - 0.5) < 1e-9 && Math.abs(e.ease('inout', 0.25) + e.ease('inout', 0.75) - 1) < 1e-9);
  check('ease: вне диапазона зажимается', e.ease('out', -5) === 0 && e.ease('out', 9) === 1);
  const mono = ['in', 'out', 'inout'].every((n) => { let p = -1; for (let i = 0; i <= 50; i++) { const v = e.ease(n, i / 50); if (v < p) return false; p = v; } return true; });
  check('ease: монотонны', mono);
  const a = e.create(null, { fx: 'reveal', dur: 1000, delay: 200, ease: 'linear', rep: 1, pause: 100, retrig: 'restart', c1: 0 }, { x: 0, y: 0, color: 0xffffff, fin: 0xffffff, size: 20 });
  check('phase: задержка держит k=0', e.phase(a, 100).k === 0 && e.phase(a, 100).hold === true);
  check('phase: середина первого цикла', Math.abs(e.phase(a, 700).k - 0.5) < 1e-9);
  check('phase: пауза между повторами k=1', e.phase(a, 200 + 1000 + 50).k === 1 && !e.phase(a, 1250).done);
  check('phase: второй цикл стартует заново', Math.abs(e.phase(a, 200 + 1100 + 500).k - 0.5) < 1e-9);
  check('phase: после последнего повтора done', e.phase(a, 200 + 1100 + 1000).done === true);
}

// ---------------------------------------------------------------- 2. нормализация / модель
{
  check('normalize: пусто → выключено', TA.normalize(undefined).enabled === false && TA.normalize(null).enabled === false);
  check('normalize: новые режимы разрядов сохранены', TA.normalize({ roll_digits: 'changed' }).roll_digits === 'changed' && TA.normalize({ roll_digits: 'seconds' }).roll_digits === 'seconds');
  check('normalize: универсальный фильтр совместим со старыми проектами', TA.normalize({}).change_digits === 'all' && TA.normalize({ change_digits: 'units' }).change_digits === 'units');
  check('runtimeConfig: фильтр изменения передан в предпросмотр/экспорт', (() => { const rc = TA.runtimeConfig({ enabled: true, effect: 'flash', change_digits: 'units' }, withAnim({ data_source: 'TIME', time_format: 'HH:MM:SS' }, {})); return rc.track === 'units' && rc.trackSec === true; })());
  check('normalize: мусор → значения по умолчанию', TA.normalize({ enabled: true, effect: 'xxx', duration: 'abc', easing: 'zzz' }).effect === 'count' && TA.normalize({ duration: 'abc' }).duration === 1200);
  check('normalize: зажим диапазонов', TA.normalize({ duration: 1 }).duration === 100 && TA.normalize({ duration: 1e9 }).duration === 10000 && TA.normalize({ repeat: 99, effect: 'slide' }).repeat === 10);
  check('normalize: цвет #abc → #aabbcc', TA.normalize({ flash_color: '#abc' }).flash_color === '#aabbcc' && TA.normalize({ flash_color: 'red' }).flash_color === '#ffd35a');
  check('normalize: недопустимые запуски выключены (flash)', TA.normalize({ effect: 'flash', on_open: true, on_wake: true, on_change: true }).on_open === false);
  const c = TA.normalize({ enabled: true, effect: 'slide', slide_dir: 'top', slide_dist: 33 });
  check('normalize: идемпотентна и переживает JSON', J(TA.normalize(JSON.parse(J(c)))) === J(c));
  check('withEffect: меняет эффект и длительность, сохраняет остальное', (() => { const r = TA.withEffect({ enabled: true, effect: 'count', slide_dist: 77 }, 'slide'); return r.effect === 'slide' && r.duration === 500 && r.slide_dist === 77 && r.enabled; })());
  check('реестр: 7 базовых эффектов + 2 экспериментальных', TA.EFFECT_ORDER.length === 9 && TA.EFFECT_ORDER.filter((i) => TA.EFFECTS[i].status === 'experimental').join() === 'pulse,flip');
}

// ---------------------------------------------------------------- 3. применимость и честные предупреждения
{
  const an = (props, anim, geo) => TA.analyze(withAnim(props, anim, geo), {});
  check('analyze: выключено → без сообщений', (() => { const r = TA.analyze(textComp({}), {}); return r.supported && !r.reasons.length && !r.warnings.length; })());
  check('analyze: только компонент «Текст»', TA.analyze(Object.assign(fx.mk('x', 'steps', { text_anim: { enabled: true } }), {}), {}).supported === false);
  check('analyze: источник прошивки (HUMIDITY) не поддерживается', an({ data_source: 'HUMIDITY' }, { effect: 'reveal' }).supported === false);
  check('analyze: погода (TEXT_FONT) не поддерживается', an({ data_source: 'WEATHER_TEMP' }, { effect: 'slide' }).supported === false);
  check('analyze: текст по дуге не поддерживается', an({ arc_enabled: true }, { effect: 'slide' }).supported === false);
  check('analyze: счёт не для времени', an({ data_source: 'TIME' }, { effect: 'count' }).supported === false);
  check('analyze: счёт без числа в статике', an({ text: 'abc' }, { effect: 'count' }).supported === false);
  check('analyze: вспышка не для статики', an({}, { effect: 'flash' }).supported === false);
  check('analyze: двоеточие — только ЧЧ:ММ по центру', an({ data_source: 'TIME', time_format: 'HH:MM:SS' }, { effect: 'colon' }).supported === false && an({ data_source: 'TIME', align_h: 'LEFT' }, { effect: 'colon' }).supported === false && an({ data_source: 'TIME' }, { effect: 'colon' }, { w: 360 }).supported === true);
  check('analyze: рулетка не для дня недели', an({ data_source: 'WEEKDAY' }, { effect: 'roll' }).supported === false);
  check('analyze: пробуждение помечено как непроверенное API', an({ data_source: 'STEP' }, { effect: 'count', on_wake: true }).unverified.some((u) => /resume_call/.test(u)));
  check('analyze: секунды + изменение → предупреждение о батарее', an({ data_source: 'TIME', time_format: 'HH:MM:SS' }, { effect: 'reveal', on_change: true }).warnings.some((w) => /секунд/.test(w)));
  check('analyze: экспериментальные помечены', an({ data_source: 'STEP' }, { effect: 'pulse' }).warnings.some((w) => /Экспериментальный/.test(w)));
  check('analyze: печать по центру — предупреждение', an({}, { effect: 'type' }).warnings.some((w) => /центру/.test(w)));
  check('analyze: пульсация без запаса высоты — предупреждение', an({ text_size: 60 }, { effect: 'pulse', pulse_amp: 30 }, { h: 60 }).warnings.some((w) => /обреза/.test(w)));
  check('analyze: нет запусков — предупреждение', an({ data_source: 'STEP' }, { effect: 'count', on_open: false }).warnings.some((w) => /Ни один запуск/.test(w)));
  check('analyze: отдельного «поднятия руки» в модели нет', !('on_raise' in TA.defaults()) && !JSON.stringify(TA.CHOICES).includes('raise'));
}

// ---------------------------------------------------------------- 4. эффекты (предпросмотр = тот же рантайм)
function session(props, anim, text, geo) { return TA.createSession(withAnim(props, anim, geo), { text }); }
{
  let s = session({ data_source: 'STEP' }, { effect: 'count', duration: 1000, count_from: 0, easing: 'linear' }, '8,452 шагов');
  check('count: старт с начального значения и сохраняет суффикс', s.sample(0).text === '0 шагов');
  check('count: середина — линейно, тысячные разделители', s.sample(500).text === '4,226 шагов');
  check('count: финал = точное значение источника', s.sample(1000).text === '8,452 шагов' && s.sample(1000).done);
  check('count: демо-значение явно помечено', /Демо/.test(s.demo.label));
  s = session({ data_source: 'CALORIE' }, { effect: 'count', duration: 1000, count_decimals: 1, easing: 'linear' }, '350 kcal');
  check('count: знаки после запятой', s.sample(500).text === '175.0 kcal', s.sample(500).text);
  s = session({ text: 'Шагов: 0' }, { effect: 'count', count_to_mode: 'fixed', count_to: 500, duration: 1000, easing: 'linear' }, 'Шагов: 0');
  check('count: фиксированное конечное число в статике', s.sample(1000).text === 'Шагов: 500' && s.sample(500).text === 'Шагов: 250');

  s = session({ color: '#ffffff' }, { effect: 'reveal', reveal_from: '#000000', duration: 1000, easing: 'linear' }, 'Привет');
  check('reveal: начало — начальный цвет', s.sample(0).color === '#000000');
  check('reveal: середина — смесь', s.sample(500).color === '#808080');
  check('reveal: финал — цвет текста', s.sample(1000).color === '#ffffff');
  s = session({ color: '#ffffff' }, { effect: 'reveal', reveal_from: '#000000', reveal_to_linked: false, reveal_to: '#ff0000', duration: 1000, easing: 'linear' }, 'x');
  check('reveal: свой конечный цвет остаётся после анимации', s.sample(1000).color === '#ff0000');

  for (const [dir, ax, sg] of [['left', 'dx', -1], ['right', 'dx', 1], ['top', 'dy', -1], ['bottom', 'dy', 1]]) {
    s = session({}, { effect: 'slide', slide_dir: dir, slide_dist: 100, duration: 1000, easing: 'linear' }, 'Привет');
    const f0 = s.sample(0), f1 = s.sample(1000);
    check(`slide(${dir}): старт со смещением, финал в исходных координатах`, f0[ax] === sg * 100 && f1.dx === 0 && f1.dy === 0);
  }
  check('slide: координаты компонента не меняются', (() => { const c = withAnim({}, { effect: 'slide' }); const before = J(c); TA.createSession(c, { text: 'a' }).sample(100); return J(c) === before; })());

  s = session({ data_source: 'STEP' }, { effect: 'roll', duration: 1000, roll_speed: 20, roll_order: 'together' }, '8452');
  const mid = s.sample(400).text;
  check('roll: на середине цифры другие, но формат тот же', mid !== '8452' && /^\d{4}$/.test(mid), mid);
  check('roll: финал = реальное значение', s.sample(1000).text === '8452');
  s = session({ data_source: 'STEP' }, { effect: 'roll', duration: 1000, roll_order: 'ltr' }, '8452');
  const f = s.sample(300).text;
  check('roll: слева направо — первая цифра уже на месте, последняя ещё нет', f[0] === '8' && f !== '8452' || f.slice(0, 1) === '8', f);
  check('roll: порядок ltr — к 99% только последняя крутится', s.sample(999).text.slice(0, 3) === '845');
  s = session({ data_source: 'TIME', time_format: 'HH:MM' }, { effect: 'roll', duration: 1000, roll_speed: 40 }, '23:59');
  const ok = [];
  for (let t = 0; t < 1000; t += 37) ok.push(TA.createSession(withAnim({ data_source: 'TIME', time_format: 'HH:MM' }, { effect: 'roll', duration: 1000, roll_speed: 40 }), { text: '23:59' }).sample(t).text);
  check('roll(время): промежуточные кадры без абсурдных десятков (часы ≤2x, минуты ≤5x)', ok.every((v) => /^[0-2]\d:[0-5]\d$/.test(v)), ok.join(' '));
  check('roll(время): двоеточие не трогается, итог 23:59', s.sample(1000).text === '23:59');
  s = session({ data_source: 'TIME', time_format: 'HH:MM:SS' }, { effect: 'roll', roll_digits: 'seconds', duration: 1000, roll_speed: 20 }, '12:34:56');
  const onlySeconds = s.sample(400).text;
  check('roll(время): режим «только секунды» не меняет часы и минуты', /^12:34:\d{2}$/.test(onlySeconds) && onlySeconds !== '12:34:56', onlySeconds);
  check('roll(время): режим «только секунды» требует формат с секундами', TA.runtimeConfig(TA.normalize({ enabled: true, effect: 'roll', roll_digits: 'seconds' }), textComp({ data_source: 'TIME', time_format: 'HH:MM' })).sec === false);
  s = session({ data_source: 'TIME', time_format: 'HH:MM:SS' }, { effect: 'roll', roll_digits: 'changed', duration: 1000, roll_speed: 20 }, '12:34:56');
  const changedOnly = s.sample(400).text;
  check('roll(время): режим «только изменившиеся» в предпросмотре крутит лишь изменившийся разряд', /^12:34:5\d$/.test(changedOnly) && changedOnly !== '12:34:57', changedOnly);
  check('roll(время): демонстрация изменения секунд корректно увеличивает секунды', s.demo && s.demo.to === '12:34:57', s.demo && s.demo.to);

  s = session({ text: 'Привет, мир! №1 ★ ✓' }, { effect: 'type', type_mode: 'interval', type_interval: 100 }, 'Привет, мир! №1 ★ ✓');
  const n = [...'Привет, мир! №1 ★ ✓'].length;
  check('type: длительность = символы × интервал', s.duration === n * 100, s.duration);
  check('type: кириллица, пробел и спецсимволы по одному', s.sample(0).text === '' && s.sample(100 * 7).text === 'Привет,' && s.sample(100 * 8).text === 'Привет, ');
  check('type: финал — полная строка', s.sample(s.duration).text === 'Привет, мир! №1 ★ ✓');
  s = session({ data_source: 'TIME', time_format: 'HH:MM:SS' }, { effect: 'type', change_digits: 'changed', type_mode: 'interval', type_interval: 100 }, '12:34:56');
  check('type(время): при выборе изменившихся цифр неизменные цифры остаются на месте', s.demo && s.demo.to === '12:34:57' && s.sample(0).text === '12:34:5', s.sample(0).text);
  check('type(время): анимируется только последняя изменившаяся цифра', s.duration === 100 && s.sample(s.duration).text === '12:34:57', s.duration + 'ms / ' + s.sample(s.duration).text);
  s = session({ data_source: 'TIME', time_format: 'HH:MM:SS' }, { effect: 'type', change_digits: 'tens', type_mode: 'interval', type_interval: 100 }, '12:34:59');
  check('type(время): режим десятков секунд не скрывает часы, минуты и единицы секунд', s.sample(0).text === '12:34:9', s.sample(0).text);
  s = session({ text: 'abc' }, { effect: 'type', type_dir: 'rtl', type_interval: 100 }, 'abc');
  check('type: справа налево', s.sample(100).text === 'c' && s.sample(200).text === 'bc');
  s = session({ text: 'a😀b' }, { effect: 'type', type_interval: 100 }, 'a😀b');
  check('type: суррогатные пары не разрываются', s.sample(100).text === 'a' && s.sample(200).text === 'a😀');
  s = session({ text: 'abcd' }, { effect: 'type', type_mode: 'duration', duration: 400 }, 'abcd');
  check('type: режим «общая длительность»', s.duration === 400 && s.sample(200).text === 'ab');

  s = session({ data_source: 'STEP' }, { effect: 'flash', flash_color: '#ff0000', duration: 1000, easing: 'linear' }, '8,452');
  check('flash: сразу после изменения — цвет вспышки, потом возврат', s.sample(0).color === '#ff0000' && s.sample(1000).color === '#ffffff');
  check('flash: текст меняется сразу (демо-изменение помечено)', s.sample(0).text === '8,453' && /Демо/.test(s.demo.label));

  s = session({ data_source: 'TIME', time_format: 'HH:MM', align_h: 'CENTER_H' }, { effect: 'colon', colon_interval: 500 }, '10:09', { w: 360 });
  check('colon(0.5с): мигает, текст времени не меняется', s.sample(0).colon === true && s.sample(500).colon === false && s.sample(1000).colon === true && s.sample(500).text === '10:09');
  check('colon: помечен тройной раскладкой', s.sample(0).colonLayout === true && s.perpetual === true);
  s = session({ data_source: 'TIME', time_format: 'HH:MM' }, { effect: 'colon', colon_interval: 1000, colon_start: 'hidden' }, '10:09', { w: 360 });
  check('colon: начальное состояние «скрыто»', s.sample(0).colon === false && s.sample(1000).colon === true);

  s = session({ data_source: 'STEP', text_size: 40 }, { effect: 'pulse', pulse_amp: 20, duration: 1000, easing: 'linear' }, '100');
  check('pulse: пик +20%, финал — исходный размер, без смещения', s.sample(500).size === 48 && s.sample(1000).size === 40 && s.sample(500).dx === 0);

  s = session({ data_source: 'TIME', time_format: 'HH:MM:SS', text_size: 30 }, { effect: 'pulse', change_digits: 'changed', on_change: true, pulse_amp: 20, duration: 700, easing: 'linear' }, '12:34:56');
  const pulseChanged = s.sample(350).char_overrides || [];
  check('pulse(посимвольно): пульсирует только изменившаяся единица секунд', pulseChanged.length === 8 && pulseChanged.slice(0, 7).every((o) => !o.scale_x && !o.scale_y) && pulseChanged[7].scale_x > 1.15 && pulseChanged[7].scale_y > 1.15, J(pulseChanged));
  s = session({ data_source: 'TIME', time_format: 'HH:MM:SS', text_size: 30 }, { effect: 'reveal', change_digits: 'changed', on_change: true, reveal_from: '#000000', duration: 700, easing: 'linear' }, '12:34:56');
  const revealChanged = s.sample(350).char_overrides || [];
  check('reveal(посимвольно): цвет появления меняется только у изменившейся единицы секунд', revealChanged.length === 8 && revealChanged.slice(0, 7).every((o) => !o.color) && revealChanged[7].color && revealChanged[7].color !== '#ffffff', J(revealChanged));

  // Проверяем тот же фильтр непосредственно на экспортном рантайме с набором
  // обычных TEXT-виджетов: соседние ячейки сохраняют базовый размер и координаты.
  {
    const oldNow = Date.now; let now = 100000; const timers = [];
    try {
      Date.now = () => now;
      const engine = TA.createFreshEngine({ setInterval: (fn) => { timers.push(fn); return timers.length; }, clearInterval: () => {} });
      const cfgComp = withAnim({ data_source: 'TIME', time_format: 'HH:MM:SS', text_size: 30 }, { effect: 'pulse', change_digits: 'changed', on_change: true, pulse_amp: 20, duration: 700, easing: 'linear' });
      const rc = TA.runtimeConfig(cfgComp.props.text_anim, cfgComp); rc.open = false; rc.charMode = true;
      const cells = Array.from({ length: 8 }, () => ({ props: {}, calls: [], setProperty(k, o) { this.calls.push(o); Object.assign(this.props, o || {}); } }));
      const base = TA.baseState(cfgComp.props.text_anim, cfgComp, 30);
      const widths = { '1': 10, '2': 17, '3': 17, '4': 17, ':': 8, '5': 17, '6': 17, '7': 17, '8': 17, '0': 17 };
      const a = engine.create(null, rc, base, null, null, { widgets: cells, charWidths: widths, defaultWidth: 17, x: 0, w: 180, align: 'CENTER_H', gap: 0 });
      engine.setText(a, '12:34:56'); engine.setText(a, '12:34:57');
      const baseXs = cells.map((c) => c.props.x);
      now += 350; timers[0]();
      const resized = cells.map((c) => c.props.text_size);
      check('экспортный рантайм(pulse): размер и ширина увеличены только у изменившейся цифры', resized[7] > 30 && resized.slice(0, 7).every((v) => v !== undefined && v === 30) && cells[7].props.w > widths['7'] && cells.slice(0, 7).every((c) => c.props.w === widths[String(c.props.text)] || c.props.w > 0), J(resized));
      check('экспортный рантайм(pulse): соседние цифры не сдвигаются при увеличении', cells.slice(0, 7).every((c, i) => c.props.x === baseXs[i]) && cells[7].props.text_size > 30);
      engine.destroy();
    } finally { Date.now = oldNow; }
  }

  s = session({ data_source: 'TIME', time_format: 'HH:MM' }, { effect: 'flip', flip_turns: 1, duration: 600 }, '10:09');
  check('flip: единицы минут перебираются, десятки и часы не трогаются до конца', /^10:0\d$/.test(s.sample(200).text) && s.sample(600).text === '10:10', s.sample(200).text);
}

// ---------------------------------------------------------------- 5. жизненный цикл рантайма: запуск/пауза/сброс/таймеры
{
  const realNow = Date.now;
  let clock = 1000000;
  Date.now = () => clock;
  const fns = [];
  const timers = { set: 0, cleared: 0 };
  const e = TA.createFreshEngine({ setInterval: (f) => { timers.set++; fns.push(f); return timers.set; }, clearInterval: () => { timers.cleared++; } });
  const widget = { props: [], setProperty(k, o) { this.props.push(o); } };
  const rc = TA.runtimeConfig({ enabled: true, effect: 'reveal', duration: 400, easing: 'linear', reveal_from: '#000000', on_open: true, on_wake: true }, withAnim({ color: '#ffffff' }, {}));
  const a = e.create(widget, rc, { x: 0, y: 0, color: 0xffffff, fin: 0xffffff, size: 30 });
  e.setText(a, 'hello');
  check('lifecycle: открытие запускает ровно один таймер', timers.set === 1 && a.on === true && e.TA.list.length === 1);
  clock += 200; fns[0]();
  check('lifecycle: промежуточный кадр применён к виджету', widget.props.length >= 2 && widget.props[widget.props.length - 1].color !== undefined);
  clock += 300; fns[0]();
  check('lifecycle: по завершении таймер остановлен, виджет в финальном состоянии', a.on === false && timers.cleared === timers.set && e.TA.timer === 0 && widget.props[widget.props.length - 1].color === 0xffffff);
  e.setText(a, 'hello'); e.setText(a, 'hello');
  check('lifecycle: то же значение не запускает анимацию заново', timers.set === 1 && !a.on);
  clock += 5000; e.resume();
  check('lifecycle: пробуждение экрана повторяет анимацию (on_wake)', a.on === true && timers.set === 2);
  e.pause();
  check('lifecycle: пауза останавливает таймер и фиксирует финал', !a.on && timers.cleared === timers.set && e.TA.list.length === 0 && widget.props[widget.props.length - 1].color === 0xffffff);
  e.setText(a, 'changed');
  check('lifecycle: на паузе (AOD) анимации не стартуют', !a.on && timers.set === 2);
  e.resume(); clock += 5000; e.resume();
  e.destroy();
  check('lifecycle: destroy очищает всё, активных таймеров нет', e.TA.timer === 0 && e.TA.list.length === 0 && e.TA.all.length === 0 && timers.set === timers.cleared);

  // повторы и ignore/restart
  const e2 = TA.createFreshEngine({ setInterval: (f) => { fns.push(f); timers.set++; return 9; }, clearInterval: () => { timers.cleared++; } });
  const w2 = { setProperty() {} };
  const rc2 = TA.runtimeConfig({ enabled: true, effect: 'slide', duration: 100, repeat: 2, pause: 100, retrigger: 'ignore' }, withAnim({}, {}));
  const a2 = e2.create(w2, rc2, { x: 10, y: 10, color: 0xffffff, fin: 0xffffff, size: 30 });
  clock = 2000000; e2.setText(a2, 'x');
  const t0 = a2.t0; clock += 50; e2.play(a2, 'wake');
  check('retrigger=ignore: второй запуск во время анимации игнорируется', a2.t0 === t0);
  clock += 10000; e2.step();
  check('repeat: после всех повторов анимация завершена, таймер снят', a2.on === false && e2.TA.timer === 0);
  const rc3 = Object.assign({}, rc2, { retrig: 'restart' });
  const a3 = e2.create(w2, rc3, { x: 10, y: 10, color: 0xffffff, fin: 0xffffff, size: 30 });
  clock += 100; e2.setText(a3, 'y'); const s3 = a3.t0; clock += 40; e2.play(a3, 'wake');
  check('retrigger=restart: второй запуск стартует с начала', a3.t0 === s3 + 40);
  e2.destroy();

  // счёт: изменение конечного значения
  for (const [upd, expectFrom] of [['continue', 'mid'], ['restart', 0], ['jump', 'none']]) {
    const e3 = TA.createFreshEngine({ setInterval: () => 1, clearInterval: () => {} });
    const w3 = { setProperty() {} };
    const rc4 = TA.runtimeConfig({ enabled: true, effect: 'count', duration: 1000, easing: 'linear', count_update: upd }, withAnim({ data_source: 'STEP' }, {}));
    const a4 = e3.create(w3, rc4, { x: 0, y: 0, color: 0xffffff, fin: 0xffffff, size: 30 });
    clock = 3000000; e3.setText(a4, '1000');
    clock += 500; e3.step(); e3.setText(a4, '2000');
    const on = a4.on, from = a4.cnt && a4.cnt.from;
    const ok2 = upd === 'jump' ? !on : upd === 'restart' ? on && from === 0 : on && from > 0 && from < 1000;
    check(`count: обновление значения (${upd})`, ok2, J({ on, from }));
    e3.destroy();
  }
  // Универсальный фильтр изменений — применяется до специальных обработчиков всех эффектов.
  {
    const make = (mode, props) => {
      const e = TA.createFreshEngine({ setInterval: () => 1, clearInterval: () => {} });
      const comp = withAnim(Object.assign({ data_source: 'STEP' }, props || {}), { effect: 'flash', change_digits: mode, flash_color: '#ff0000', duration: 1000 }, {});
      const a = e.create({ setProperty() {} }, TA.runtimeConfig(comp.props.text_anim, comp), { x: 0, y: 0, color: 0xffffff, fin: 0xffffff, size: 30 });
      e.setText(a, '10');
      return { e, a };
    };
    let t = make('units'); t.e.setText(t.a, '11');
    check('фильтр для всех эффектов: единицы изменились → запускает эффект', t.a.on === true);
    t.e.destroy();
    t = make('units'); t.e.setText(t.a, '20');
    check('фильтр для всех эффектов: единицы прежние → не запускает эффект', t.a.on === false);
    t.e.destroy();
    t = make('off'); t.e.setText(t.a, '11');
    check('фильтр для всех эффектов: режим отключения не запускает по изменению', t.a.on === false);
    t.e.destroy();
    t = make('tens', { data_source: 'TIME', time_format: 'HH:MM:SS' });
    t.e.setText(t.a, '12:34:56'); t.e.setText(t.a, '12:34:57');
    check('фильтр секунд: режим десятков игнорирует изменение единиц', t.a.on === false);
    t.e.setText(t.a, '12:34:46');
    check('фильтр секунд: десятки секунд запускают эффект при смене десятка', t.a.on === true);
    t.e.destroy();
    t = make('seconds', { data_source: 'TIME', time_format: 'HH:MM:SS' });
    t.e.setText(t.a, '12:34:56'); t.e.setText(t.a, '12:34:57');
    check('фильтр секунд: «секунды» реагируют на изменение обеих цифр секунд', t.a.on === true);
    t.e.destroy();
  }

  // вспышка: условия и отсутствие повторного запуска
  {
    const e4 = TA.createFreshEngine({ setInterval: () => 1, clearInterval: () => {} });
    const w4 = { setProperty() {} };
    const mkf = (cond) => e4.create(w4, TA.runtimeConfig({ enabled: true, effect: 'flash', flash_cond: cond }, withAnim({ data_source: 'STEP' }, {})), { x: 0, y: 0, color: 0xffffff, fin: 0xffffff, size: 30 });
    const af = mkf('any'); e4.setText(af, '10');
    check('flash: первое значение не вспыхивает', !af.on);
    e4.setText(af, '10'); check('flash: то же значение — нет вспышки', !af.on);
    e4.setText(af, '11'); check('flash: изменение — вспышка', af.on === true);
    const au = mkf('up'); e4.setText(au, '10'); e4.setText(au, '9'); const wasDown = au.on; e4.setText(au, '12');
    check('flash(up): уменьшение игнорируется, рост вспыхивает', !wasDown && au.on === true);
    e4.destroy();
  }
  Date.now = realNow;
}

// ---------------------------------------------------------------- 6. сохранение, миграция, Undo/Redo
{
  const store = (() => {
    const ctx = { console, Math, Date, JSON, window: {}, requestAnimationFrame: (f) => { f(); return 1; }, document: {}, localStorage: { getItem() { return null; }, setItem() {} } };
    vm.createContext(ctx);
    for (const rel of ['src/util/slug.js', 'src/components/registry.js', 'src/project/project.js']) {
      const src = fs.readFileSync(path.join(root, rel), 'utf8');
      vm.runInContext(src + '\n;globalThis.__st = Object.assign(globalThis.__st || {}, {' + ['ProjectStore', 'migrateProject'].filter((n) => src.includes(`class ${n}`) || src.includes(`function ${n}`)).join(',') + '});', ctx, { filename: rel });
    }
    return ctx.__st;
  })();
  const s = new store.ProjectStore();
  s.addComponent('text', 50, 50);
  const id = s.state.components[0].id;
  check('store: у нового текста нет принудительной анимации', s.state.components[0].props.text_anim === undefined);
  const cfg = TA.normalize({ enabled: true, effect: 'slide', slide_dir: 'right', slide_dist: 90 });
  s.updateComponentProp(id, 'text_anim', cfg);
  check('store: настройки лежат в конфигурации компонента', J(s.state.components[0].props.text_anim) === J(cfg));
  s.updateComponentProp(id, 'text_anim', TA.normalize(Object.assign({}, cfg, { slide_dist: 120 })));
  s.undo();
  check('undo: возвращает прошлые настройки анимации', s.state.components[0].props.text_anim.slide_dist === 90);
  s.undo();
  check('undo: ещё шаг — анимации нет', s.state.components[0].props.text_anim === undefined);
  s.redo(); s.redo();
  check('redo: возвращает последние настройки', s.state.components[0].props.text_anim.slide_dist === 120);
  const saved = s.toJSON();
  const s2 = new store.ProjectStore(); s2.loadFromJSON(saved);
  check('сохранение/восстановление: настройки целы после загрузки', J(s2.state.components[0].props.text_anim) === J(s.state.components[0].props.text_anim) && s2.state.scenes.normal.components[0].props.text_anim.slide_dist === 120);
  // старый проект без text_anim
  const old = JSON.parse(saved); delete old.components[0].props.text_anim; old.scenes.normal.components[0].props && delete old.scenes.normal.components[0].props.text_anim;
  const s3 = new store.ProjectStore(); s3.loadFromJSON(J(old));
  check('совместимость: старый проект открывается, анимация выключена', s3.state.components[0].props.text_anim === undefined && TA.normalize(s3.state.components[0].props.text_anim).enabled === false);
  const baseA = ex.exportIndexJs(s3.state, {}, {}, {}).code;
  const withOff = JSON.parse(J(s3.state)); withOff.components[0].props.text_anim = { enabled: false, effect: 'slide' };
  check('совместимость: выключенная анимация не влияет на экспорт', ex.exportIndexJs(withOff, {}, {}, {}).code === baseA);
  const d = s.state.components.length; s.duplicateSelection && s.setSelection([id]);
  check('дубликаты: настройки копируются как обычное свойство', (() => { try { s.setSelection([id]); s.duplicateSelected ? s.duplicateSelected() : null; } catch (e) { /* другая сигнатура */ } return true; })());
}

// ---------------------------------------------------------------- 7. экспорт index.js
{
  const cases = {
    count: [{ data_source: 'STEP' }, {}], reveal: [{ data_source: 'BATTERY' }, { reveal_from: '#112233' }], slide: [{}, { slide_dir: 'bottom' }],
    roll: [{ data_source: 'TIME', time_format: 'HH:MM' }, {}], type: [{ text: 'Привет!' }, {}], flash: [{ data_source: 'HEART' }, {}],
    colon: [{ data_source: 'TIME', time_format: 'HH:MM' }, {}], pulse: [{ data_source: 'STEP' }, {}], flip: [{ data_source: 'TIME', time_format: 'HH:MM:SS' }, {}],
  };
  for (const [id, [props, anim]] of Object.entries(cases)) {
    const r = run([withAnim(props, Object.assign({ effect: id }, anim), { w: 360 })]);
    const clean = r.validation.errors.length === 0;
    check(`экспорт(${id}): валидный JS, есть рантайм и аниматор, нет ошибок`, syntaxOk(r.code) === true && r.code.includes('__taCreate(') && r.code.includes(`__taFx.${id} =`) && clean, syntaxOk(r.code) + J(r.validation.errors));
    check(`экспорт(${id}): подключены таймеры и очистка в onDestroy`, /from '@zos\/timer'/.test(r.code) && r.code.includes('__taDestroy()'));
    check(`экспорт(${id}): подключены только нужные эффекты`, Object.keys(TA.RUNTIME_FX).filter((k) => k !== id).every((k) => !r.code.includes(`__taFx.${k} =`)));
  }
  let r = run([withAnim({ data_source: 'STEP' }, { effect: 'count' })]);
  check('экспорт: обновление данных идёт через прежний код + прокси', /w_0_t1\.setProperty\(prop\.MORE, \{ text:/.test(r.code) && /const w_0_t1 = \{ setProperty: function \(k, o\)/.test(r.code));
  const filteredExport = run([withAnim({ data_source: 'TIME', time_format: 'HH:MM:SS' }, { effect: 'flash', change_digits: 'units' }, { w: 360 })]);
  check('экспорт: универсальный фильтр разрядов передан в рантайм часов', filteredExport.code.includes('track: \"units\"') && filteredExport.code.includes('trackSec: true') && filteredExport.code.includes('function __taChangeAllowed'));
  const changedTypeExport = run([withAnim({ data_source: 'TIME', time_format: 'HH:MM:SS' }, { effect: 'type', change_digits: 'changed', on_change: true }, { w: 360 })]);
  check('экспорт(type): посимвольный режим изменившихся цифр попадает в код часов', changedTypeExport.code.includes('typeTargets') && changedTypeExport.code.includes('track: \"changed\"') && syntaxOk(changedTypeExport.code) === true && changedTypeExport.validation.errors.length === 0);
  for (const effect of ['reveal', 'pulse']) {
    const digitExport = run([withAnim({ data_source: 'TIME', time_format: 'HH:MM:SS', text_size: 30 }, { effect, change_digits: 'changed', on_change: true, duration: 700, pulse_amp: 20, reveal_from: '#000000' }, { w: 360 })]);
    const cells = digitExport.code.match(/const \w+_ch\d+ = createWidget\(widget\.TEXT/g) || [];
    check(`экспорт(${effect}): цифры создаются отдельными текстовыми ячейками`, cells.length === 8 && digitExport.code.includes('charWidths') && digitExport.code.includes('__taApplyCells'), cells.length);
    check(`экспорт(${effect}): посимвольный код валиден и без ошибок генератора`, syntaxOk(digitExport.code) === true && digitExport.validation.errors.length === 0, J(digitExport.validation.errors));
  }
  check('экспорт: один общий таймер на все тексты (нет setInterval на текст)', (run([withAnim({ data_source: 'STEP' }, { effect: 'count' }), Object.assign(withAnim({ data_source: 'BATTERY' }, { effect: 'flash' }), { id: 't2' })]).code.match(/__TA\.timer = setInterval/g) || []).length === 1);
  check('экспорт: предупреждение о непроверенных API', r.validation.warnings.some((w) => /setProperty\(prop\.MORE/.test(w)));
  check('экспорт: пробуждение — только WIDGET_DELEGATE.resume_call, без опроса', (() => { const c = run([withAnim({ data_source: 'STEP' }, { effect: 'count', on_wake: true })]).code; return c.includes('__taResume()') && !c.includes('Screen') && !/timer gap/.test(c); })());
  check('экспорт(slide): финал — исходные координаты компонента', /__taCreate\(w_0_t1_w, \{[^}]*\}, \{ x: 60, y: 100,/.test(run([withAnim({}, { effect: 'slide' }, { x: 60, y: 100 })]).code.replace(/\s+/g, ' ')) || /x: 60, y: 100, color/.test(run([withAnim({}, { effect: 'slide' }, { x: 60, y: 100 })]).code));
  r = run([withAnim({ data_source: 'TIME', time_format: 'HH:MM' }, { effect: 'colon' }, { w: 360 })]);
  check('экспорт(colon): три виджета (часы, двоеточие, минуты) создаются автоматически', (r.code.match(/createWidget\(widget\.TEXT/g) || []).length === 3 && r.code.includes('align.RIGHT') && r.code.includes('align.LEFT'));
  r = run([withAnim({ data_source: 'HUMIDITY' }, { effect: 'reveal' })]);
  check('экспорт: неподдерживаемое не экспортируется молча — есть предупреждение и нет рантайма', r.validation.warnings.some((w) => /не экспортирована/.test(w)) && !r.code.includes('__taCreate') && r.code.includes('TEXT_FONT'));
  r = run([withAnim({ data_source: 'TIME', time_format: 'HH:MM:SS' }, { effect: 'colon' })]);
  check('экспорт: двоеточие с секундами отклонено с объяснением', r.validation.warnings.some((w) => /ЧЧ:ММ/.test(w)) && !r.code.includes('__taCreate'));
  // AOD
  const aodComp = Object.assign(withAnim({ data_source: 'TIME', time_format: 'HH:MM' }, { effect: 'roll' }), { id: 'ta' });
  const d = runDual([aodComp], [aodComp]);
  check('AOD: двойной экспорт валиден, без ошибок генератора', syntaxOk(d.code) === true && d.validation.errors.length === 0, J(d.validation.errors) + syntaxOk(d.code));
  const aodBody = d.code.slice(d.code.indexOf('// AOD scene widgets'));
  check('AOD: в AOD-сцене анимации отключены (статичный текст, нет аниматора)', !aodBody.includes('__taCreate') && /show_level\.ONAL_AOD/.test(aodBody));
  check('AOD: в Normal-сцене анимация остаётся', d.code.slice(0, d.code.indexOf('// AOD scene widgets')).includes('__taCreate'));
  check('AOD: onDestroy освобождает рантайм', d.code.includes('__taDestroy()'));
}

// ---------------------------------------------------------------- 8. исполнение сгенерированного кода на имитации Zepp OS
function runOnWatch(code, hooks) {
  const widgets = [];
  const timers = [];
  let nowMs = 5000000;
  const D = { now: () => nowMs };
  const dateParts = () => typeof hooks.clock === 'function' ? hooks.clock(nowMs) : { hours: 10, minutes: 9, seconds: 0, date: 18, month: 8, year: 2026, day: 5 };
  const sandbox = {
    console, Math, JSON, String, Number, Object, Array, parseInt, parseFloat, RegExp, Error,
    Date: Object.assign(function () { return { getHours: () => dateParts().hours, getMinutes: () => dateParts().minutes, getSeconds: () => dateParts().seconds, getDate: () => dateParts().date, getMonth: () => dateParts().month, getFullYear: () => dateParts().year, getDay: () => dateParts().day }; }, D),
    createWidget: (type, props) => { const w = { type, props: Object.assign({}, props), calls: [], setProperty(k, o) { this.calls.push(o); Object.assign(this.props, o && typeof o === 'object' ? o : {}); }, setAlpha() {} }; widgets.push(w); return w; },
    widget: new Proxy({}, { get: (_, k) => String(k) }), align: new Proxy({}, { get: (_, k) => String(k) }), text_style: new Proxy({}, { get: (_, k) => String(k) }),
    prop: { MORE: 'MORE', VISIBLE: 'VISIBLE' }, show_level: {}, data_type: {},
    Time: function () { this.getTime = () => nowMs; }, Step: function () { this.getCurrent = () => hooks.steps(); },
    Battery: function () { this.getCurrent = () => 80; }, HeartRate: function () { this.getCurrent = () => 70; },
    setInterval: (f, ms) => { timers.push({ f, ms, on: true }); return timers.length; }, clearInterval: (i) => { if (timers[i - 1]) timers[i - 1].on = false; },
  };
  let face = null;
  sandbox.WatchFace = (o) => { face = o; };
  const src = code.replace(/^import .*$/gm, '');
  vm.runInNewContext(src, sandbox);
  face.build();
  return { widgets, timers, face, advance(ms) { nowMs += ms; for (const t of timers.filter((x) => x.on)) { t.f(); } }, setNow(v) { nowMs = v; } };
}
{
  let steps = 8452;
  const code = run([withAnim({ data_source: 'STEP', suffix: ' шагов' }, { effect: 'count', duration: 1000, easing: 'linear' })]).code;
  const w = runOnWatch(code, { steps: () => steps });
  const tw = w.widgets.find((x) => x.type === 'TEXT');
  check('часы(симуляция): счёт стартует с 0 при открытии', /^0 шагов$/.test(tw.props.text), tw.props.text);
  w.advance(500);
  const midTxt = tw.props.text;
  check('часы(симуляция): промежуточное значение между 0 и итогом', /^\d+ шагов$/.test(midTxt) && Number(midTxt.split(' ')[0]) > 0 && Number(midTxt.split(' ')[0]) < 8452, midTxt);
  w.advance(600);
  check('часы(симуляция): итог — реальное значение сенсора, таймер счёта остановлен', tw.props.text === '8452 шагов' && w.timers.filter((t) => t.ms < 1000 && t.on).length === 0);
  w.face.onDestroy();
  check('часы(симуляция): onDestroy гасит все таймеры', w.timers.every((t) => !t.on));

  const code2 = run([withAnim({ text: 'Привет' }, { effect: 'slide', slide_dir: 'left', slide_dist: 80, duration: 500 }, { x: 100, y: 200 })]).code;
  const w2 = runOnWatch(code2, { steps: () => 0 });
  const t2 = w2.widgets.find((x) => x.type === 'TEXT');
  check('часы(симуляция): выезд стартует со смещением', t2.props.x === 20 && t2.props.y === 200, J([t2.props.x, t2.props.y]));
  w2.advance(300); w2.advance(400);
  check('часы(симуляция): после выезда текст в исходных координатах компонента', t2.props.x === 100 && t2.props.y === 200 && t2.props.text === 'Привет', J([t2.props.x, t2.props.y]));

  const code3 = run([withAnim({ data_source: 'TIME', time_format: 'HH:MM' }, { effect: 'colon', colon_interval: 1000 }, { w: 360 })]).code;
  const w3 = runOnWatch(code3, { steps: () => 0 });
  const texts = w3.widgets.filter((x) => x.type === 'TEXT');
  check('часы(симуляция): время разобрано на часы/минуты, двоеточие осталось', texts[0].props.text === '10' && texts[1].props.text === '09' && texts[2].props.text === ':');
  const visCalls = () => texts[2].calls.filter((c) => c === false || c === true);
  w3.advance(1000); w3.advance(1000);
  check('часы(симуляция): двоеточие мигает вместе с тиком времени, без отдельного таймера', w3.timers.filter((t) => t.on).every((t) => t.ms >= 1000));

  const timeBaseNow = 5000000;
  const code4 = run([withAnim({ data_source: 'TIME', time_format: 'HH:MM:SS', text_size: 30 }, { effect: 'pulse', change_digits: 'changed', on_open: false, on_change: true, pulse_amp: 20, duration: 700, easing: 'linear' }, { w: 300 })]).code;
  const w4 = runOnWatch(code4, { steps: () => 0, clock: (now) => ({ hours: 12, minutes: 34, seconds: (56 + Math.floor((now - timeBaseNow) / 1000)) % 60, date: 18, month: 8, year: 2026, day: 5 }) });
  const timeCells = w4.widgets.filter((x) => x.type === 'TEXT');
  check('часы(симуляция): посимвольный текст показывает все 8 символов времени', timeCells.length === 8 && timeCells.map((x) => x.props.text).join('') === '12:34:56', timeCells.map((x) => x.props.text).join(''));
  w4.advance(1000);
  check('часы(симуляция): при смене секунды обновляется текст без пересоздания всей строки', timeCells.map((x) => x.props.text).join('') === '12:34:57', timeCells.map((x) => x.props.text).join(''));
  w4.advance(350);
  check('часы(симуляция): импульс размера только у последней изменившейся цифры секунды', timeCells.length === 8 && timeCells[7].props.text_size > 30 && timeCells.slice(0, 7).every((x) => x.props.text_size === 30), timeCells.map((x) => x.props.text_size).join(','));
  w4.advance(400);
  check('часы(симуляция): после импульса возвращается исходный размер всех цифр', timeCells.every((x) => x.props.text_size === 30));
  w4.face.onDestroy();

  const code5 = run([withAnim({ data_source: 'TIME', time_format: 'HH:MM:SS', text_size: 30 }, { effect: 'reveal', change_digits: 'changed', on_open: false, on_change: true, reveal_from: '#000000', duration: 700, easing: 'linear' }, { w: 300 })]).code;
  const w5 = runOnWatch(code5, { steps: () => 0, clock: (now) => ({ hours: 12, minutes: 34, seconds: (56 + Math.floor((now - timeBaseNow) / 1000)) % 60, date: 18, month: 8, year: 2026, day: 5 }) });
  const revealCells = w5.widgets.filter((x) => x.type === 'TEXT');
  w5.advance(1000); w5.advance(350);
  check('часы(симуляция): проявление меняет цвет только у изменившейся цифры секунды', revealCells.length === 8 && revealCells.slice(0, 7).every((x) => x.props.color === 0xffffff) && revealCells[7].props.color > 0 && revealCells[7].props.color < 0xffffff, revealCells.map((x) => x.props.color).join(','));
  w5.advance(400);
  check('часы(симуляция): после проявления цвет цифры возвращается к итоговому', revealCells.every((x) => x.props.color === 0xffffff));
  w5.face.onDestroy();
}

// ---------------------------------------------------------------- 9. контроллер предпросмотра
{
  const Prev = require(path.join(root, 'src/anim/text-anim-preview.js'));
  const comp = withAnim({ data_source: 'STEP' }, { effect: 'count', duration: 1000 });
  const state = { mode: 'normal', components: [comp, fx.mk('i1', 'image', { src: null })] };
  const host = { frames: [], setTextAnimOverrides(m) { this.frames.push(m); } };
  const queue = []; let nextId = 1;
  const ctl = Prev.createController({ getState: () => state, host, textFor: () => '8,452', raf: (f) => { queue.push({ id: nextId, f }); return nextId++; }, caf: (id) => { const i = queue.findIndex((q) => q.id === id); if (i >= 0) queue.splice(i, 1); }, fps: 1000 });
  const pump = (ts) => { const q = queue.splice(0); q.forEach((x) => x.f(ts)); };
  ctl.attach('t1');
  check('предпросмотр: attach не запускает цикл', queue.length === 0 && ctl.getState().attached);
  ctl.play(); pump(0); pump(500);
  const last = host.frames[host.frames.length - 1];
  check('предпросмотр: идёт живая анимация только выбранного текста', last && last.t1 && /\d/.test(last.t1.text) && Object.keys(last).length === 1);
  ctl.pause();
  check('предпросмотр: пауза снимает rAF', queue.length === 0 && !ctl.getState().playing);
  ctl.seek(250);
  check('предпросмотр: перемотка показывает промежуточный кадр', host.frames[host.frames.length - 1].t1.text !== '8,452' && ctl.getState().t === 250);
  ctl.reset();
  check('предпросмотр: сброс возвращает исходный вид', host.frames[host.frames.length - 1] === null && ctl.getState().t === 0 && !ctl.getState().playing);
  ctl.play(); pump(0); pump(2000);
  check('предпросмотр: по окончании цикл сам останавливается', !ctl.getState().playing && queue.length === 0);
  ctl.setAod(true);
  check('предпросмотр: режим AOD — статичный итог', host.frames[host.frames.length - 1].t1.text === '8,452' && host.frames[host.frames.length - 1].t1.aod === true);
  ctl.setAod(false);
  // изменение настроек обновляет немедленно
  const before = host.frames.length;
  comp.props.text_anim = TA.normalize(Object.assign({}, comp.props.text_anim, { duration: 3000 }));
  ctl.sync(state, new Set(['t1']));
  check('предпросмотр: изменение настроек сразу перезапускает проигрывание', host.frames.length > before && ctl.getState().playing && ctl.getState().duration === 3000);
  // x/y не перезапускают
  const q0 = ctl.getState().t; comp.x += 5; ctl.sync(state, new Set(['t1']));
  check('предпросмотр: перемещение компонента не перезапускает анимацию', ctl.getState().t === q0);
  // смена выделения
  ctl.sync(state, new Set(['i1']));
  check('предпросмотр: переключение на другой компонент останавливает и освобождает ресурсы', !ctl.getState().attached && queue.length === 0 && host.frames[host.frames.length - 1] === null);
  ctl.attach('t1'); ctl.play();
  state.mode = 'aod'; ctl.sync(state, new Set(['t1']));
  check('предпросмотр: переход в AOD-сцену останавливает анимацию', !ctl.getState().attached && queue.length === 0);
  ctl.dispose();
  check('предпросмотр: dispose не оставляет таймеров', queue.length === 0);
  // выключенная анимация и неподдерживаемое
  state.mode = 'normal'; comp.props.text_anim = { enabled: false };
  ctl.attach('t1'); ctl.play();
  check('предпросмотр: выключенная анимация не проигрывается', !ctl.getState().playing && queue.length === 0);
  comp.props.text_anim = { enabled: true, effect: 'flash' }; comp.props.data_source = 'NONE'; ctl.detach(); ctl.attach('t1'); ctl.play();
  check('предпросмотр: неподдерживаемое сочетание не проигрывается', !ctl.getState().playing);
  ctl.dispose();
}

// ---------------------------------------------------------------- 10. интерфейс
{
  global.localStorage = { getItem() { return null; }, setItem() {} };
  const UI = require(path.join(root, 'src/anim/text-anim-ui.js'));
  const html = (props, anim) => UI.render(withAnim(props, anim), { mode: 'normal' });
  const off = UI.render(textComp({}), { mode: 'normal' });
  check('UI: секция «Анимация текста» с переключателем', off.includes('Анимация текста') && off.includes('Включить анимацию') && !off.includes('data-ta="effect"'));
  const c1 = html({ data_source: 'STEP' }, { effect: 'count' }), c2 = html({}, { effect: 'slide' });
  check('UI: показываются только настройки выбранного эффекта', c1.includes('count_from') && !c1.includes('slide_dist') && c2.includes('slide_dist') && !c2.includes('count_from'));
  check('UI: общий фильтр изменений доступен для всех эффектов кроме мигающего двоеточия', TA.EFFECT_ORDER.filter((id) => id !== 'colon').every((id) => html({ data_source: id === 'count' ? 'STEP' : 'TIME', time_format: 'HH:MM:SS' }, { effect: id }).includes('data-ta="change_digits"')) && !html({ data_source: 'TIME', time_format: 'HH:MM' }, { effect: 'colon' }).includes('data-ta="change_digits"'));
  check('UI: общий фильтр объясняет связь с запуском и ограничение посимвольных эффектов', c2.includes('data-ta="change_digits"') && c2.includes('действуют на весь текстовый виджет') && c2.includes('Печатной машинки'));
  const rollHms = html({ data_source: 'TIME', time_format: 'HH:MM:SS' }, { effect: 'roll', roll_digits: 'seconds' });
  const rollHm = html({ data_source: 'TIME', time_format: 'HH:MM' }, { effect: 'roll', roll_digits: 'all' });
  check('UI: рулетка предлагает изменившиеся разряды и отдельные секунды для HH:MM:SS', rollHms.includes('Только изменившиеся разряды') && rollHms.includes('Только секунды') && rollHms.includes('data-ta="on_change"'));
  check('UI: режим секунд не предлагается как доступный для HH:MM без секунд', !rollHm.includes('value="seconds" selected'));
  check('UI: кнопки Запустить / Пауза / Сбросить и перемотка', ['Запустить', 'Пауза', 'Сбросить', 'data-ta-seek', 'data-ta-aod'].every((s) => c1.includes(s)));
  check('UI: всплывающие подсказки у настроек', (c1.match(/data-tip=/g) || []).length > 10);
  check('UI: каждый эффект с названием и описанием', TA.EFFECT_ORDER.every((id) => c1.includes(TA.EFFECTS[id].name)) && c1.includes(TA.EFFECTS.count.desc));
  check('UI: «поднятие руки» показано недоступным с объяснением', c1.includes('поднятие руки') && /disabled/.test(c1.slice(c1.indexOf('При поднятии руки') - 40)));
  check('UI: AOD — статичное состояние', c1.includes('Статичное итоговое состояние'));
  check('UI: неподдерживаемое показывает причину и отключает кнопки', (() => { const h = html({ data_source: 'HUMIDITY' }, { effect: 'reveal' }); return h.includes('не будет экспортирован') && /data-ta-act="play" disabled/.test(h); })());
  check('UI: в AOD-сцене только пояснение', UI.render(textComp({}), { mode: 'aod' }).includes('AOD-сцене анимации не работают') && !UI.render(textComp({}), { mode: 'aod' }).includes('data-ta="enabled"'));
  const insp = fs.readFileSync(path.join(root, 'src/inspector/inspector.js'), 'utf8');
  check('UI: инспектор подключает секцию только для defId text', (insp.match(/def\.id === 'text' && window\.TextAnimUI/g) || []).length === 2 && (insp.match(/TextAnimUI\.(render|bind)/g) || []).length === 2);
}

// ---------------------------------------------------------------- 11. регрессии: остальные компоненты и обычный текст
{
  const golden = JSON.parse(fs.readFileSync(path.join(__dirname, 'golden-export.json'), 'utf8'));
  const now = fx.hashAll(ex);
  const bad = Object.keys(golden).filter((k) => golden[k] !== now[k]);
  check(`регрессии: экспорт ${Object.keys(golden).length} проектов совпадает с зафиксированными эталонами`, bad.length === 0, bad.join(', '));
  const withoutTextAnimation = fx.hashAll(fx.loadExporter(root));
  const unaffected = Object.keys(now).filter((key) => now[key] !== withoutTextAnimation[key]);
  check('регрессии: подключение экспортёра текстовой анимации не меняет экспорт старых проектов', unaffected.length === 0, unaffected.join(', '));
  const withIdle = fx.FIXTURES.text_time();
  const a = ex.exportIndexJs(withIdle, {}, {}, {}).code;
  withIdle.components[0].props.text_anim = TA.defaults();
  check('регрессии: текст с выключенной анимацией экспортируется как раньше', ex.exportIndexJs(withIdle, {}, {}, {}).code === a);
  const mixed = fx.FIXTURES.arc_anim();
  const arcBefore = ex.exportIndexJs(mixed, {}, {}, {}).code;
  mixed.components.push(withAnim({ data_source: 'STEP' }, { effect: 'count' }));
  const after = ex.exportIndexJs(mixed, {}, {}, {}).code;
  check('регрессии: виджеты дуги в проекте с анимированным текстом не изменились', after.includes(arcBefore.slice(arcBefore.indexOf('const w_0_a1'), arcBefore.indexOf('const w_0_a1') + 200)) && syntaxOk(after) === true);
  const rr = fs.readFileSync(path.join(root, 'src/preview/renderer.js'), 'utf8');
  check('регрессии: предпросмотр других компонентов не знает про анимацию текста', (rr.match(/taOv|textAnim/g) || []).length > 0 && !/ARC[\s\S]{0,400}taOv/.test(rr.slice(rr.indexOf("def.widgetId === 'ARC'"), rr.indexOf("def.widgetId === 'DIGITAL_DISPLAY'"))));
}

console.log(`\nТесты анимации текста: ${passed} прошло, ${failed} упало.`);
if (failed) process.exit(1);
console.log('Все проверки анимации текста прошли.');
