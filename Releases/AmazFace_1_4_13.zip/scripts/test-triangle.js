// Проверка компонента «Треугольник»: геометрия (вверх/вниз/влево/вправо, рамка внутри Ш×В),
// запись в реестре, экспорт через CANVAS.drawPoly / strokePoly и предупреждения.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.resolve(__dirname, '..');
const ctx = { console, Math, Date, JSON, window: {} };
vm.createContext(ctx);
const names = ['REGISTRY', 'exportIndexJs', 'TriangleModel', 'AOD_EXPORT_TYPES'];
for (const rel of ['src/util/slug.js', 'src/components/triangle.js', 'src/components/registry.js', 'src/exporter/index-js-exporter.js', 'src/exporter/aod-exporter.js']) {
  const src = fs.readFileSync(path.join(root, rel), 'utf8');
  vm.runInContext(src + '\n;globalThis.__ex = Object.assign(globalThis.__ex || {}, {' +
    names.filter((n) => src.includes(`const ${n}`) || src.includes(`function ${n}`)).join(',') + '});', ctx, { filename: rel });
}
const { REGISTRY, exportIndexJs, TriangleModel, AOD_EXPORT_TYPES } = ctx.__ex;

let failed = 0;
function check(name, cond, extra) { if (!cond) { failed++; console.error('FAIL:', name, extra || ''); } else console.log('ok:', name); }
function syntaxOk(code) { try { new vm.Script(code.replace(/^import .*$/gm, '')); return true; } catch (e) { return e.message; } }

function mk(props, id = 'tri1', box = {}) {
  return { id, defId: 'triangle', x: 100, y: 50, w: 40, h: 34, props: Object.assign({}, props), ...box };
}
function run(comps) {
  const project = { device: { w: 480, h: 480 }, components: comps, assets: [], fonts: [], background: {} };
  return exportIndexJs(project, {}, {}, {});
}
const bbox = (pts) => ({
  x0: Math.min(...pts.map((p) => p.x)), x1: Math.max(...pts.map((p) => p.x)),
  y0: Math.min(...pts.map((p) => p.y)), y1: Math.max(...pts.map((p) => p.y)),
});

// 1. Реестр
const def = REGISTRY.triangle;
check('registry: компонент есть в «Фигуры»', def && def.category === 'Фигуры' && def.widgetId === 'TRIANGLE');
check('registry: есть направление, заливка и рамка', ['direction', 'fill_enabled', 'color', 'stroke_enabled', 'stroke_color', 'stroke_width']
  .every((k) => def.properties.some((p) => p.key === k)));
check('registry: направления вверх/вниз', def.properties.find((p) => p.key === 'direction').options.some((o) => o.value === 'UP')
  && def.properties.find((p) => p.key === 'direction').options.some((o) => o.value === 'DOWN'));
check('registry: цвет рамки скрыт, пока рамка выключена',
  def.properties.find((p) => p.key === 'stroke_color').showIf({ stroke_enabled: false }) === false
  && def.properties.find((p) => p.key === 'stroke_color').showIf({ stroke_enabled: true }) === true);

// 2. Геометрия: вверх и вниз зеркальны
const up = TriangleModel.shape(mk({ direction: 'UP' }));
const down = TriangleModel.shape(mk({ direction: 'DOWN' }));
check('geo UP: вершина сверху по центру, основание снизу',
  JSON.stringify(up.fillPts) === JSON.stringify([{ x: 20, y: 0 }, { x: 40, y: 34 }, { x: 0, y: 34 }]), JSON.stringify(up.fillPts));
check('geo DOWN: основание сверху, вершина снизу по центру',
  JSON.stringify(down.fillPts) === JSON.stringify([{ x: 0, y: 0 }, { x: 40, y: 0 }, { x: 20, y: 34 }]), JSON.stringify(down.fillPts));
const left = TriangleModel.shape(mk({ direction: 'LEFT' }));
const right = TriangleModel.shape(mk({ direction: 'RIGHT' }));
check('geo LEFT: острие слева', left.fillPts.some((p) => p.x === 0 && p.y === 17), JSON.stringify(left.fillPts));
check('geo RIGHT: острие справа', right.fillPts.some((p) => p.x === 40 && p.y === 17), JSON.stringify(right.fillPts));
check('geo: неизвестное направление → вверх', JSON.stringify(TriangleModel.shape(mk({ direction: 'XYZ' })).fillPts) === JSON.stringify(up.fillPts));

// 3. Рамка не должна выходить за Ш×В: контур сдвинут внутрь на половину толщины
for (const dir of ['UP', 'DOWN', 'LEFT', 'RIGHT']) {
  const sw = 6;
  const t = TriangleModel.shape(mk({ direction: dir, stroke_enabled: true, stroke_width: sw }));
  const b = bbox(t.outlinePts);
  // Для miter-соединения внешний край рамки лежит на расстоянии sw/2 / sin(угла/2) от вершин — проверяем
  // консервативно: сам контур (центр линии) строго внутри рамки и не вырожден.
  check(`рамка ${dir}: контур внутри Ш×В`, b.x0 >= 0 && b.y0 >= 0 && b.x1 <= 40 && b.y1 <= 34, JSON.stringify(b));
  check(`рамка ${dir}: контур меньше треугольника без рамки`, (b.x1 - b.x0) < 40 || (b.y1 - b.y0) < 34, JSON.stringify(b));
}
// Заливка под рамкой совпадает с контуром, а без рамки — весь треугольник
const withStroke = TriangleModel.shape(mk({ stroke_enabled: true, stroke_width: 4 }));
check('рамка: заливка = контур (цвет не просвечивает по краю)', JSON.stringify(withStroke.fillPts) === JSON.stringify(withStroke.outlinePts));
// Очень толстая рамка не ломает геометрию (нет NaN, треугольник не вырожден в пустоту)
const fat = TriangleModel.shape(mk({ stroke_enabled: true, stroke_width: 40 }, 'fat', { w: 20, h: 20 }));
check('толстая рамка: без NaN', fat.outlinePts.every((p) => Number.isFinite(p.x) && Number.isFinite(p.y)), JSON.stringify(fat.outlinePts));

// 4. Экспорт: заливка + рамка
let r = run([mk({ direction: 'DOWN', fill_enabled: true, color: '#7fb8ff', stroke_enabled: true, stroke_color: '#ffffff', stroke_width: 3 })]);
check('export: валидный JS', syntaxOk(r.code) === true, syntaxOk(r.code));
check('export: CANVAS на месте компонента', /createWidget\(widget\.CANVAS, \{ x: 100, y: 50, w: 40, h: 34 \}\)/.test(r.code), r.code.match(/widget\.CANVAS.*/)?.[0]);
check('export: заливка drawPoly нужным цветом', /\.drawPoly\(\{ data_array: \[[^\]]+\], color: 0x7fb8ff \}\)/.test(r.code), r.code.match(/drawPoly.*/)?.[0]);
check('export: setPaint с цветом и толщиной рамки', /\.setPaint\(\{ color: 0xffffff, line_width: 3 \}\)/.test(r.code), r.code.match(/setPaint.*/)?.[0]);
check('export: strokePoly', /\.strokePoly\(\{ data_array: \[[^\]]+\], color: 0xffffff \}\)/.test(r.code), r.code.match(/strokePoly.*/)?.[0]);
check('export: контур замкнут (последняя точка = первая)', (() => {
  const m = r.code.match(/strokePoly\(\{ data_array: \[(.+?)\], color/);
  if (!m) return false;
  const pts = m[1].match(/\{ x: -?\d+, y: -?\d+ \}/g);
  return pts.length === 4 && pts[0] === pts[3];
})());
check('export: предупреждение ⚠ про CANVAS-треугольник', r.validation.warnings.some((w) => w.includes('TRIANGLE')));

// 5. Только заливка / только рамка
r = run([mk({ fill_enabled: true, stroke_enabled: false })]);
check('только заливка: drawPoly есть, strokePoly нет', r.code.includes('.drawPoly(') && !r.code.includes('.strokePoly(') && !r.code.includes('.setPaint('));
r = run([mk({ fill_enabled: false, stroke_enabled: true, stroke_width: 2 })]);
check('только рамка: strokePoly есть, drawPoly нет', r.code.includes('.strokePoly(') && !r.code.includes('.drawPoly('));
check('только рамка: валидный JS', syntaxOk(r.code) === true, syntaxOk(r.code));

// 6. Пара «мин / макс»: два независимых треугольника
r = run([
  mk({ direction: 'DOWN', color: '#7fb8ff' }, 'tri_low', { x: 40, y: 200 }),
  mk({ direction: 'UP', color: '#ff9f7f' }, 'tri_high', { x: 40, y: 260 }),
]);
check('пара: два CANVAS', (r.code.match(/widget\.CANVAS/g) || []).length === 2);
check('пара: разные цвета', r.code.includes('0x7fb8ff') && r.code.includes('0xff9f7f'));
check('пара: валидный JS', syntaxOk(r.code) === true, syntaxOk(r.code));
check('пара: нет предупреждения о лимите слоёв', !r.validation.warnings.some((w) => w.includes('3 слоёв')));

// 7. Лимит: больше 3 холстов друг на друге → предупреждение
r = run([1, 2, 3, 4].map((n) => mk({}, `t${n}`)));
check('лимит слоёв: 4 наложенных треугольника → предупреждение', r.validation.warnings.some((w) => w.includes('3 слоёв')), JSON.stringify(r.validation.warnings));
r = run([1, 2, 3].map((n) => mk({}, `t${n}`)));
check('лимит слоёв: 3 наложенных — без предупреждения', !r.validation.warnings.some((w) => w.includes('3 слоёв')));

// 8. Скрытый компонент не экспортируется
r = run([mk({}, 'hid', { visible: false })]);
check('скрытый треугольник не попадает в экспорт', !r.code.includes('drawPoly'));

// 9. AOD
check('AOD: тип shape', AOD_EXPORT_TYPES.TRIANGLE === 'shape');

// 10. Фикс AOD: CANVAS не должен попадать в AOD-сцену ни при каких условиях
{
  const project = { device: { w: 480, h: 480 }, components: [mk({ direction: 'DOWN' })], assets: [], fonts: [], background: {} };
  const aod = exportIndexJs(project, {}, {}, { showLevel: 'ONAL_AOD' });
  check('AOD: CANVAS не генерируется', !/widget\.CANVAS|drawPoly|strokePoly/.test(aod.code));
  check('AOD: валидный JS без треугольника', syntaxOk(aod.code) === true, syntaxOk(aod.code));
  check('AOD: предупреждение о пропущенном треугольнике', aod.validation.warnings.some((w) => w.includes('пропущен в AOD')));
}

// 11. Запекание треугольника в PNG (штатный путь экспорта): подмена на IMG в обеих сценах
{
  const calls = [];
  const mkCanvas = () => {
    const c = { width: 0, height: 0, getContext: () => new Proxy({}, { get: (_, k) => (k === 'canvas' ? c : (...a) => { calls.push(k); }), set: () => true }), toDataURL: () => 'data:image/png;base64,AAAA' };
    return c;
  };
  const vctx = { console, Math, Date, JSON, window: {}, document: { createElement: mkCanvas } };
  vm.createContext(vctx);
  for (const rel of ['src/components/triangle.js', 'src/exporter/project-exporter.js']) {
    const src = fs.readFileSync(path.join(root, rel), 'utf8');
    vm.runInContext(src + '\n;globalThis.__pe = Object.assign(globalThis.__pe || {}, {' + ['TriangleModel', 'prepareTriangleExportProject'].filter((n) => src.includes(`const ${n}`) || src.includes(`function ${n}`)).join(',') + '});', vctx, { filename: rel });
  }
  const prep = vctx.__pe.prepareTriangleExportProject;
  const normalC = [mk({ direction: 'DOWN', stroke_enabled: true }, 'tn')];
  const aodC = [mk({ direction: 'UP' }, 'ta')];
  const proj = { assets: [], components: normalC, scenes: { normal: { components: JSON.parse(JSON.stringify(normalC)) }, aod: { components: aodC } } };
  const out = prep(proj);
  check('запекание: исходный проект не изменён', proj.scenes.aod.components[0].defId === 'triangle' && proj.assets.length === 0);
  check('запекание: Normal и AOD переведены в image', out.scenes.normal.components[0].defId === 'image' && out.scenes.aod.components[0].defId === 'image' && out.components[0].defId === 'image');
  check('запекание: PNG-ассеты созданы с размером Ш×В', out.assets.length === 3 && out.assets.every((a) => a.width === 40 && a.height === 34 && a.format === 'PNG' && a.generated));
  check('запекание: src указывает на ассет', out.scenes.aod.components[0].props.src === out.assets.find((a) => a.generatedFrom === 'ta').id);
  const ex = exportIndexJs({ device: { w: 480, h: 480 }, components: out.scenes.aod.components, assets: out.assets, fonts: [], background: {} }, { [out.assets[2].id]: 'triangle_ta.png' }, {}, { showLevel: 'ONAL_AOD' });
  check('запекание: в AOD-коде IMG, а не CANVAS', /widget\.IMG/.test(ex.code) && !/widget\.CANVAS/.test(ex.code), ex.code.slice(-600));
}

if (failed) { console.error(`\n${failed} проверок не пройдено`); process.exit(1); }
console.log('\nВсе проверки треугольника пройдены.');
