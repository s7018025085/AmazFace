# Tap zones 2.0

## Data model

Tap zones are now independent child objects of a component:

```js
component.tapZones = [
  {
    id: 'tap_001',
    name: 'Тап-зона 1',
    x: 0, y: 0, w: 80, h: 50, // local coordinates of the parent editor box
    visible: true,
    locked: false,
    props: {
      tap_action: 'METRIC',
      tap_metric: 'STATUS'
    }
  }
]
```

The child coordinates are local to the parent. Moving the parent therefore moves the zone automatically without changing the zone's local geometry.

## Editor

- Tap zones have their own layer rows directly under the parent.
- They can be selected independently.
- Mouse drag moves a zone.
- Four corner handles resize a zone.
- Locked/visible state is independent from the parent.
- The zone has no visual fill and does not modify the rendered component.
- The inspector exposes local X/Y/W/H and the tap action.
- Old projects with component-level `tap_action` are migrated into one child zone.

## Export

Only child `tapZones` are exported. Each active zone becomes a transparent `widget.BUTTON` with `setAlpha(0)`. The visual component itself is never replaced or resized to create a hit area.


## Exported project structure

For every visible tap zone with an action other than `NONE`, the generated
`watchface/index.js` contains a real `hmUI.widget.BUTTON` with:

- absolute screen coordinates calculated as `parentRect + local zone x/y`;
- the configured width/height;
- the configured APP or system-screen callback;
- `setAlpha(0)` so the button is invisible.

The full ZIP also contains `tap-zones.json`. It is a machine-readable manifest
of **all** tap zones (including zones with `NONE` action), for both Normal and
AOD scenes. It stores both local child geometry and the resolved absolute
rectangle. The manifest is auxiliary; the watch itself executes the generated
`watchface/index.js`.


## Реальные часы: системные приложения
Для `tap_action: METRIC` экспорт должен вызывать `launchApp` с `native: true`. Без этого системный App ID может не открыть системное приложение на часах.

Список системных экранов — единый `SYSTEM_SCREENS` в `src/components/registry.js`
(инспектор, свойства и экспорт берут его оттуда). Подтверждены документацией
Zepp OS: `SYSTEM_APP_HR`, `SYSTEM_APP_SPO2`, `SYSTEM_APP_CLUB_CARD`; остальные
помечаются в экспорте как unverified, импортируются только реально используемые.


## Действие «Фонарик (вкл./выкл.)»

`tap_action: 'FLASHLIGHT'` — третий вариант действия тап-зоны (рядом с `METRIC` и `APP`). Дополнительных полей нет.

- Тап по зоне — на весь экран показывается белая заливка.
- Повторный тап в любом месте экрана — белый экран скрывается, виден циферблат.

Экспорт: для зоны создаётся обычная прозрачная `BUTTON`; после всех зон один раз на сцену создаются
белый `FILL_RECT` на весь экран и полноэкранная прозрачная `BUTTON` «закрыть» (оба скрыты через
`prop.VISIBLE`, `__flashSet*(on)` переключает их). Они лежат выше всех виджетов и тап-зон. Если в проекте
нет зон с фонариком, в `index.js` ничего не добавляется — экспорт старых проектов не меняется ни на байт.

Ограничения: яркость и автоотключение экрана не меняются; работа скрытой кнопки через `prop.VISIBLE`
отмечена в экспорте как unverified — проверьте на реальных часах. Тест: `npm run test:flashlight`.
