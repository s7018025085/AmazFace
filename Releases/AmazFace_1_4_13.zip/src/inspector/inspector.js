// src/inspector/inspector.js

class Inspector {
  constructor(root, store) {
    // Фон с настройками открывается в редакторе фона (а не в общем редакторе изображений) — см. ImageAssetEditor.openForAsset.
    window.openBackgroundEditorForAsset = (a) => this._openBackgroundEditor(a);
    this.root = root;
    this.store = store;
    // true, пока изменение прилетело из поля ввода самого Inspector:
    // в этот момент перерисовывать панель нельзя — innerHTML пересоздаёт
    // <input>, и фокус слетает после каждой введённой цифры.
    this._selfEdit = false;
    // Дебаунсинг превью премиум типографики: рендер тяжёлый (4× supersampling),
    // поэтому кешируем запрос и выполняем максимум раз в 150мс.
    this._premiumPreviewScheduled = null;
    this._premiumPreviewScheduledData = null;
    this._dragRefreshScheduled = false;
  }

  // Запоминает, какое поле было в фокусе и где стоял курсор, чтобы вернуть
  // их после перерисовки (перерисовка приходит, например, по Enter).
  _captureFocus() {
    const el = document.activeElement;
    if (!el || !this.root.contains(el)) return null;
    const sel = el.dataset && (el.dataset.prop ? `[data-prop="${el.dataset.prop}"]` : el.dataset.field ? `[data-field="${el.dataset.field}"]` : null);
    if (!sel) return null;
    const desc = { sel };
    // selectionStart у input[type=number] в Chrome бросает исключение —
    // сохраняем каретку только для текстовых полей.
    if (el.type === 'text') { desc.start = el.selectionStart; desc.end = el.selectionEnd; }
    return desc;
  }

  _restoreFocus(desc) {
    if (!desc) return;
    const el = this.root.querySelector(desc.sel);
    if (!el || typeof el.focus !== 'function') return;
    el.focus();
    if (desc.start != null && typeof el.setSelectionRange === 'function') {
      try { el.setSelectionRange(desc.start, desc.end); } catch (e) { /* не текстовое поле */ }
    }
  }

  render() {
    if (this._selfEdit) return;
    const focusDesc = this._captureFocus();
    const result = this._render();
    this._restoreFocus(focusDesc);
    // В панели появились новые элементы с data-tip — их нужно привязать
    // к менеджеру подсказок заново (см. src/ui/tooltips.js).
    if (window.tooltipManager) window.tooltipManager.refresh();
    return result;
  }

  _render() {
    const sel = [...this.store.selection];
    if (sel.length === 0) { this.root.innerHTML = `<div class="empty-hint">Выберите компонент, чтобы изменить его свойства.</div>`; return; }
    if (sel.length > 1) { this._renderMulti(sel); return; }

    // Background is a first-class layer, but remains stored in the scene
    // background object so old projects and exports stay compatible.
    if (sel[0] === '__background__') {
      this._renderBackground();
      return;
    }

    const zoneSel = this.store.getTapZoneSelection(sel[0]);
    if (zoneSel) {
      this._renderTapZone(zoneSel.parent, zoneSel.zone);
      return;
    }
    const comp = this.store.state.components.find((c) => c.id === sel[0]);
    if (!comp) { this.root.innerHTML = ''; return; }
    const def = REGISTRY[comp.defId];
    const compat = isApiCompatible(def.apiLevel, this.store.state.apiLevel);

    const rows = [];
    rows.push(`
      <div class="insp-header">
        <input class="insp-name" value="${this._esc(comp.name)}" data-field="name" data-tip="Имя компонента в панели слоёв и в комментарии сгенерированного кода. На сам циферблат не выводится." />
        <div class="insp-id">${comp.id} · ${def.widgetId === 'WEEKDAY_STRIP' ? 'составной' : def.widgetId}</div>
        <div class="api-badge ${compat ? 'ok' : 'bad'}">API ${def.apiLevel}${def.apiLevel.includes('+') ? '' : '+'} ${compat ? '✓' : '⚠ несовместимо с API проекта ' + this.store.state.apiLevel}</div>
        ${def.confidence === 'unverified' ? '<div class="api-badge warn">⚠ Непроверенный набор свойств — сверьтесь с docs.zepp.com перед публикацией</div>' : ''}
      </div>
    `);

    rows.push(`<div class="insp-section-title">Позиция и размер</div>`);
    rows.push(`<div class="insp-grid">`);
    for (const key of ['x', 'y', 'w', 'h']) {
      const isCircle = def.widgetId === 'CIRCLE' || def.widgetId === 'STROKE_CIRCLE';
      if (isCircle) continue;
      rows.push(this._numberField(key, key.toUpperCase(), comp[key]));
    }
    rows.push(`</div>`);
    if (this.store.state.mode === 'aod') {
      rows.push(`<div class="insp-section-title">Трансформация AOD</div>`);
      rows.push(`<div class="insp-grid">`);
      rows.push(this._numberField('rotation', 'ПОВОРОТ °', Number(comp.props.rotation || 0)));
      rows.push(this._numberField('scale', 'МАСШТАБ', Number(comp.props.scale || 1)));
      rows.push(`</div>`);
    }

    const zones = Array.isArray(comp.tapZones) ? comp.tapZones : [];
    rows.push(`<div class="insp-section-title">Тап-зоны <button class="insp-inline-btn" data-act="add-tap-zone">＋ Добавить</button></div>`);
    if (!zones.length) {
      rows.push(`<div class="empty-hint insp-empty-small">Нет дочерних тап-зон. Добавьте зону — она будет отдельным слоем и не изменит сам компонент.</div>`);
    } else {
      rows.push(`<div class="tap-zone-list">${zones.map(z => `
        <button type="button" class="tap-zone-list-item" data-zone-id="${this._escAttr(z.id)}">
          <span>🎯 ${this._esc(z.name || z.id)}</span><small>${Math.round(z.x)}, ${Math.round(z.y)} · ${Math.round(z.w)}×${Math.round(z.h)}</small>
        </button>`).join('')}</div>`);
    }

    const groups = {};
    for (const p of def.properties) {
      if (['x', 'y', 'w', 'h'].includes(p.key)) continue;
      if (String(p.key).startsWith('tap_')) continue; // tap actions live on child zones
      const groupName = p.group || this._groupFor(p.key);
      groups[groupName] = groups[groupName] || [];
      groups[groupName].push(p);
    }


    // Универсальный TEXT с выбором источника данных (data_source): добавляем
    // в группу "Источник данных" поля, специфичные для текущего выбранного
    // источника (DATA_SOURCES[val].fields) — они не входят в def.properties,
    // потому что зависят от значения, выбранного пользователем "на лету".
    let dsNote = null;
    if (def.dataSourceSelectable) {
      const dsVal = comp.props.data_source || 'NONE';
      const dsDef = DATA_SOURCES[dsVal];
      if (dsDef && dsDef.fields && dsDef.fields.length) {
        const groupName = this._groupFor('data_source');
        groups[groupName] = groups[groupName] || [];
        groups[groupName].push(...dsDef.fields);
      }
      if (dsDef && dsVal !== 'NONE') {
        dsNote = (dsDef.confidence === 'unverified' ? '⚠ ' : '') +
          (dsDef.note || '') +
          ' Значение поля «Текст» при этом игнорируется — оно подставляется автоматически из источника данных.';
      }
    }

    for (const [groupName, props] of Object.entries(groups)) {
      rows.push(`<div class="insp-section-title">${groupName}</div>`);
      rows.push(`<div class="insp-grid">`);
      for (const p of props) {
        // Условные поля (showIf): скрываются, пока не выбрана нужная опция.
        if (typeof p.showIf === 'function' && !p.showIf(comp.props || {})) continue;
        rows.push(this._fieldFor(comp, p));
      }
      if (def.widgetId === 'ARC' && groupName === 'Анимация появления' && comp.props.anim_enabled) {
        rows.push(`<div class="field wide"><button type="button" class="insp-inline-btn" data-act="arc-play">▶ Проиграть анимацию в редакторе</button></div>`);
      }
      rows.push(`</div>`);
    }
    if (dsNote) rows.push(`<div class="insp-note">${dsNote}</div>`);

    if (def.widgetId === 'DIGITAL_DISPLAY') rows.push(this._renderPremiumTypography(comp));

    // Анимация — только у компонента «Текст».
    if (def.id === 'text' && window.TextAnimUI) rows.push(window.TextAnimUI.render(comp, { mode: this.store.state.mode }));

    rows.push(`<div class="insp-section-title">Поведение</div>`);
    rows.push(`<div class="insp-grid">`);
    rows.push(`
      <label class="field checkbox" data-tip="Снятая галочка прячет компонент и в редакторе, и при экспорте: он не попадёт в сгенерированный index.js.">
        <input type="checkbox" data-field="visible" ${comp.visible !== false ? 'checked' : ''}>
        Видимый
      </label>
      <label class="field checkbox" data-tip="Заблокированный компонент нельзя двигать и растягивать мышью на холсте — удобно, чтобы не сдвинуть готовый фон или стрелки. Свойства при этом редактируются как обычно.">
        <input type="checkbox" data-field="locked" ${comp.locked ? 'checked' : ''}>
        Заблокирован
      </label>
    `);
    if (def.dataBindable) {
      rows.push(`<div class="field"><label>Источник данных</label><input type="text" value="${def.dataSource}" disabled></div>`);
    } else if (def.dataSourceSelectable) {
      const eff = getEffectiveDataSource(comp, def);
      rows.push(`<div class="field"><label>Эффективный источник данных</label><input type="text" value="${eff || 'нет (статический текст)'}" disabled></div>`);
    }
    rows.push(`</div>`);

    if (def.id === 'time_pointer_second' && (comp.props.motion || 'TICK') === 'SMOOTH') {
      rows.push(`<div class="insp-note">⚠ Плавный ход: штатный TIME_POINTER двигает секундную стрелку скачками,
        поэтому при экспорте она будет создана отдельным виджетом IMG и повёрнута вручную из таймера
        '@zos/timer' (${Number(comp.props.smooth_fps ?? 20)} к/с). Свойство поворота IMG не подтверждено цитатой из
        docs.zepp.com — проверьте результат в симуляторе. Учтите также расход батареи: чем выше частота кадров,
        тем дороже анимация; в AOD-режиме плавный ход обычно недоступен.</div>`);
    }
    if (def.note) rows.push(`<div class="insp-note">${def.note}</div>`);

    this.root.innerHTML = rows.join('');
    if (def.id === 'text' && window.TextAnimUI) window.TextAnimUI.bind(this.root, comp, this.store, window.textAnimController);
    const addZone = this.root.querySelector('[data-act="add-tap-zone"]');
    if (addZone) addZone.onclick = () => this.store.addTapZone(comp.id);
    const arcPlay = this.root.querySelector('[data-act="arc-play"]');
    if (arcPlay) arcPlay.onclick = () => window.dispatchEvent(new CustomEvent('arc-anim-preview', { detail: { id: comp.id } }));
    this.root.querySelectorAll('[data-zone-id]').forEach(el => {
      el.onclick = () => this.store.setSelection([`tapzone:${comp.id}:${el.dataset.zoneId}`]);
    });
    this._bind(comp, def);
  }


  _renderPremiumTypography(comp) {
    const p = comp.props || {};
    const v = (k,d) => p[k] !== undefined ? p[k] : d;
    const color = (k,d) => this._escAttr(v(k,d));
    return `
      <div class="insp-section-title">✨ Премиальная типографика</div>
      <div class="premium-type-card premium-type-compact">
        <div class="premium-type-head"><b>Текст и цифры</b><span>отдельный профессиональный редактор</span></div>
        <div class="premium-type-summary">${this._esc(v('text','12'))} · ${v('text_size',36)} px · ${this._esc(v('font_weight','400'))} · ${this._esc(v('fill_type','solid'))}</div>
        <button type="button" class="premium-open-btn" data-open-premium-typography>✦ Открыть редактор типографики</button>
        <div class="premium-mini-row">
          <label>Цвет <input type="color" data-prop="color" value="${color('color','#ffffff')}"></label>
          <label>Цвет 2 <input type="color" data-prop="gradient_to" value="${color('gradient_to','#555555')}"></label>
          <label>Размер <input type="number" data-prop="text_size" min="4" max="480" value="${v('text_size',36)}"></label>
        </div>
      </div>`;
  }

  _openPremiumTypography(comp) {
    if (!comp) return;
    // Opening the professional typography editor explicitly switches this TEXT
    // into export-as-PNG mode. The editable TEXT object remains in the project;
    // only the exported watchface uses the baked transparent PNG.
    this.store.updateComponentProp(comp.id, 'premium_enabled', true, { silent: true });
    const old = document.querySelector('.premium-typography-modal');
    if (old) old.remove();
    const p = comp.props || {};
    const esc = (v) => this._esc(v == null ? '' : String(v));
    const escAttr = (v) => this._escAttr(v == null ? '' : String(v));
    const val = (k,d) => p[k] !== undefined ? p[k] : d;
    const checked = (k) => val(k,false) ? 'checked' : '';
    const fonts = (this.store.state.fonts || []).map(f => `<option value="${escAttr(f.id)}" ${val('font')===f.id?'selected':''}>${esc(f.name || f.filename || f.id)}</option>`).join('');
    const modal = document.createElement('div');
    modal.className = 'premium-typography-modal';
    this._premiumCharIndex = 0;
    modal.innerHTML = `
      <div class="premium-typo-window">
        <div class="premium-typo-headbar">
          <div><b>✨ Премиальная типографика</b><span>Увеличенный просмотр и точная настройка</span></div>
          <button type="button" data-typo-close>✕</button>
        </div>
        <div class="premium-typo-body">
          <div class="premium-typo-workspace">
            <div class="premium-typo-previews">
              <div class="premium-preview-card">
              <div class="premium-preview-title">Увеличенный просмотр</div>
              <div class="premium-text-stage"><canvas data-typo-text-canvas width="720" height="420"></canvas></div>
              <div class="premium-preview-zoom"><label>Масштаб просмотра <input type="range" data-local="previewZoom" min="50" max="300" value="120"><output data-out="previewZoom">120%</output></label></div>
              </div>
              <div class="premium-preview-card dial-card">
              <div class="premium-preview-title">Как выглядит на циферблате</div>
              <div class="premium-dial-stage"><canvas data-typo-dial-canvas width="480" height="480"></canvas></div>
              <div class="premium-preview-hint">Перетаскивайте текст прямо мышью по циферблату.</div>
            </div>
            </div>
            <div class="premium-typo-controls">
            <div class="premium-control-section"><div class="premium-control-title">Текст</div>
              <div class="premium-control-grid">
                <label>Текст<input type="text" data-p="text" value="${escAttr(val('text','12'))}"></label>
                <label>Шрифт<select data-p="font"><option value="">Системный шрифт</option>${fonts}</select></label>
                <label>Размер, px<input type="number" data-p="text_size" min="4" max="480" step="1" value="${val('text_size',36)}"></label>
                <label>Жирность<select data-p="font_weight"><option value="300">Light</option><option value="400">Regular</option><option value="500">Medium</option><option value="600">Semi Bold</option><option value="700">Bold</option><option value="800">Extra Bold</option><option value="900">Black</option></select></label>
                <label>Начертание<select data-p="font_style"><option value="normal">Обычный</option><option value="italic">Курсив</option><option value="oblique">Наклонный</option></select></label>
                <label>Регистр<select data-p="text_transform"><option value="none">Без изменений</option><option value="uppercase">ВЕРХНИЙ</option><option value="lowercase">нижний</option></select></label>
                <label>Межбуквенное, px<input type="number" data-p="letter_spacing" min="-30" max="80" step="0.5" value="${val('letter_spacing',0)}"></label>
                <label>Высота строки<input type="number" data-p="line_height" min="0.5" max="3" step="0.05" value="${val('line_height',1)}"></label>
                <label>Наклон X °<input type="number" data-p="skew_x" min="-45" max="45" step="0.5" value="${val('skew_x',0)}"></label>
                <label>Наклон Y °<input type="number" data-p="skew_y" min="-45" max="45" step="0.5" value="${val('skew_y',0)}"></label>
                <label>Изгиб текста<input type="number" data-p="warp_bend" min="-100" max="100" value="${val('warp_bend',0)}"></label>
                <label>Кернинг<input type="number" data-p="kerning" min="-30" max="80" step="0.5" value="${val('kerning',0)}"></label>
              </div>
            </div>
            <div class="premium-control-section premium-character-section"><div class="premium-control-title">Символы — точная настройка</div>
              <div class="premium-character-row"><label>Символ<select data-char-select></select></label><button type="button" data-char-reset>Сбросить символ</button></div>
              <div class="premium-control-grid">
                <label>X<input type="number" data-char="x" step="0.5"></label>
                <label>Y<input type="number" data-char="y" step="0.5"></label>
                <label>Масштаб X<input type="number" data-char="scale_x" min="0.1" max="4" step="0.01"></label>
                <label>Масштаб Y<input type="number" data-char="scale_y" min="0.1" max="4" step="0.01"></label>
                <label>Поворот °<input type="number" data-char="rotation" step="0.5"></label>
                <label>Цвет<input type="color" data-char="color"></label>
              </div>
            </div>
            <div class="premium-control-section"><div class="premium-control-title">Положение и форма</div>
              <div class="premium-control-grid">
                <label>X<input type="number" data-p-field="x" value="${comp.x||0}"></label>
                <label>Y<input type="number" data-p-field="y" value="${comp.y||0}"></label>
                <label>Ширина<input type="number" data-p-field="w" min="1" value="${comp.w||200}"></label>
                <label>Высота<input type="number" data-p-field="h" min="1" value="${comp.h||80}"></label>
                <label>Масштаб X<input type="number" data-p="scale_x" min="0.1" max="5" step="0.01" value="${val('scale_x',1)}"></label>
                <label>Масштаб Y<input type="number" data-p="scale_y" min="0.1" max="5" step="0.01" value="${val('scale_y',1)}"></label>
                <label>Поворот °<input type="number" data-p-field="rotation" value="${comp.rotation||0}"></label>
                <label>Прозрачность %<input type="number" data-p="alpha" min="0" max="100" value="${val('alpha',100)}"></label>
                <label>Горизонталь<select data-p="align_h"><option value="LEFT">Слева</option><option value="CENTER_H">По центру</option><option value="RIGHT">Справа</option></select></label>
                <label>Вертикаль<select data-p="align_v"><option value="TOP">Сверху</option><option value="CENTER_V">По центру</option><option value="BOTTOM">Снизу</option></select></label>
              </div>
            </div>
            <div class="premium-control-section"><div class="premium-control-title">Цвет и материал</div>
              <div class="premium-control-grid">
                <label>Материал<select data-p="fill_type"><option value="solid">Обычный цвет</option><option value="gradient">Градиент</option><option value="metallicGold">Металлическое золото</option></select></label>
                <label>Основной цвет<input type="color" data-p="color" value="${escAttr(val('color','#ffffff'))}"></label>
                <label>Цвет 2 / низ<input type="color" data-p="gradient_to" value="${escAttr(val('gradient_to','#555555'))}"></label>
                <label>Цвет боковины<input type="color" data-p="side_color" value="${escAttr(val('side_color','#5a3108'))}"></label>
                <label>Тёмная боковина<input type="color" data-p="side_color_dark" value="${escAttr(val('side_color_dark','#241204'))}"></label>
                <label>Металличность %<input type="number" data-p="metallic" min="0" max="100" value="${val('metallic',90)}"></label>
                <label>Шероховатость %<input type="number" data-p="roughness" min="0" max="100" value="${val('roughness',25)}"></label>
                <label>Отражение %<input type="number" data-p="reflection_opacity" min="0" max="100" value="${val('reflection_opacity',0)}"></label>
                <label>Цвет отражения<input type="color" data-p="reflection_color" value="${escAttr(val('reflection_color','#ffffff'))}"></label>
              </div>
            </div>
            <div class="premium-control-section"><div class="premium-control-title">Объём и свет</div>
              <div class="premium-control-grid">
                <label>Глубина<input type="number" data-p="depth" min="0" max="30" step="0.5" value="${val('depth',0)}"></label>
                <label>Bevel<input type="number" data-p="bevel_size" min="0" max="15" step="0.25" value="${val('bevel_size',0)}"></label>
                <label>Профиль фаски<select data-p="bevel_profile"><option value="soft">Soft</option><option value="hard">Hard</option><option value="deep">Deep</option></select></label>
                <label>Слои экструзии<input type="number" data-p="extrusion_layers" min="1" max="40" value="${val('extrusion_layers',6)}"></label>
                <label>Экструзия X<input type="number" data-p="extrusion_x" step="0.5" value="${val('extrusion_x','')}"></label>
                <label>Экструзия Y<input type="number" data-p="extrusion_y" step="0.5" value="${val('extrusion_y','')}"></label>
                <label>Specular %<input type="number" data-p="specular_opacity" min="0" max="100" value="${val('specular_opacity',0)}"></label>
                <label>Specular blur<input type="number" data-p="specular_blur" min="0" max="20" step="0.5" value="${val('specular_blur',1)}"></label>
                <label>Ширина блика<input type="number" data-p="specular_width" min="0.5" max="20" step="0.5" value="${val('specular_width',2)}"></label>
                <label>Цвет Specular<input type="color" data-p="specular_color" value="${escAttr(val('specular_color','#ffffff'))}"></label>
                <label>Верхний блик %<input type="number" data-p="top_highlight_opacity" min="0" max="100" value="${val('top_highlight_opacity',55)}"></label>
                <label>Свечение<input type="checkbox" data-p="glow_enabled" ${checked('glow_enabled')}></label>
              </div>
            </div>
            <div class="premium-control-section"><div class="premium-control-title">Контур</div>
              <div class="premium-control-grid">
                <label><span>Внешний контур</span><input type="checkbox" data-p="outline_enabled" ${checked('outline_enabled')}></label>
                <label>Ширина<input type="number" data-p="outline_width" min="0.1" max="10" step="0.1" value="${val('outline_width',1.2)}"></label>
                <label>Цвет<input type="color" data-p="outline_color" value="${escAttr(val('outline_color','#1b1006'))}"></label>
                <label>Прозрачность %<input type="number" data-p="outline_opacity" min="0" max="100" value="${val('outline_opacity',90)}"></label>
              </div>
            </div>
            <div class="premium-control-section"><div class="premium-control-title">Тени</div>
              <div class="premium-control-grid">
                <label><span>Drop Shadow</span><input type="checkbox" data-p="drop_shadow_enabled" ${checked('drop_shadow_enabled')}></label>
                <label>Drop Blur<input type="number" data-p="drop_shadow_blur" min="0" max="40" value="${val('drop_shadow_blur',4)}"></label>
                <label><span>Contact Shadow</span><input type="checkbox" data-p="contact_shadow_enabled" ${checked('contact_shadow_enabled')}></label>
                <label>Contact Density<input type="number" data-p="contact_shadow_opacity" min="0" max="100" value="${val('contact_shadow_opacity',45)}"></label>
                <label><span>Cast Shadow</span><input type="checkbox" data-p="cast_shadow_enabled" ${checked('cast_shadow_enabled')}></label>
                <label>Угол света °<input type="number" data-p="cast_shadow_angle" min="0" max="360" value="${val('cast_shadow_angle',135)}"></label>
                <label>Высота света °<input type="number" data-p="cast_shadow_elevation" min="5" max="85" value="${val('cast_shadow_elevation',45)}"></label>
                <label>Длина тени<input type="number" data-p="cast_shadow_distance" min="0" max="100" value="${val('cast_shadow_distance',5)}"></label>
                <label>Мягкость<input type="number" data-p="cast_shadow_blur" min="0" max="40" value="${val('cast_shadow_blur',3)}"></label>
                <label>Плотность<input type="number" data-p="cast_shadow_opacity" min="0" max="100" value="${val('cast_shadow_opacity',42)}"></label>
                <label>Длина тени<input type="number" data-p="cast_shadow_length" min="0" max="150" value="${val('cast_shadow_length',7)}"></label>
                <label>Затухание тени %<input type="number" data-p="cast_shadow_falloff" min="0" max="100" value="${val('cast_shadow_falloff',65)}"></label>
                <label>Contact X<input type="number" data-p="contact_shadow_x" step="0.5" value="${val('contact_shadow_x',1)}"></label>
                <label>Contact Y<input type="number" data-p="contact_shadow_y" step="0.5" value="${val('contact_shadow_y',2)}"></label>
              </div>
            </div>
            <div class="premium-control-section"><div class="premium-control-title">Быстрые стили</div>
              <div class="premium-modal-presets">
                <button data-modal-preset="classic">Classic Gold</button><button data-modal-preset="luxury">Luxury Watch</button><button data-modal-preset="goldGlow">Золотое свечение</button><button data-modal-preset="soviet">Soviet Premium</button><button data-modal-preset="steel">Polished Steel</button><button data-modal-preset="reset">Сбросить эффекты</button>
              </div>
            </div>
          </div>
          </div>
        </div>
        <div class="premium-typo-footer"><span>✓ На часах: готовый PNG · в проекте: редактируемый текст</span><button type="button" data-typo-close class="premium-close-btn">Готово</button></div>
      </div>`;
    document.body.appendChild(modal);

    const setProp = (key, value) => { this.store.updateComponentProp(comp.id, key, value, { silent: true }); this._refreshPremiumPreview(modal, comp); };
    modal.querySelectorAll('[data-p]').forEach(el => {
      const key = el.dataset.p;
      if (el.tagName === 'SELECT') el.value = val(key, el.value);
      const read = () => el.type === 'checkbox' ? el.checked : el.type === 'number' ? Number(el.value) : el.value;
      el.addEventListener('input', () => {
        try {
          this._selfEdit = true;
          setProp(key, read());
        } finally {
          this._selfEdit = false;
        }
      });
      el.addEventListener('change', () => { setProp(key, read()); this.render(); });
    });
    modal.querySelectorAll('[data-p-field]').forEach(el => {
      const key = el.dataset.pField;
      const read = () => Number(el.value);
      el.addEventListener('input', () => {
        try {
          this._selfEdit = true;
          this.store.updateComponent(comp.id, {[key]:read()}, {silent:true}); 
          this._refreshPremiumPreview(modal, comp);
        } finally {
          this._selfEdit = false;
        }
      });
      el.addEventListener('change', () => { this.store.updateComponent(comp.id, {[key]:read()}); this._refreshPremiumPreview(modal, comp); });
    });
    const charSelect=modal.querySelector('[data-char-select]');
    const refreshChars=()=>{
      const txt=String((comp.props||{}).text||'');
      charSelect.innerHTML=[...txt].map((ch,i)=>`<option value="${i}">${i+1}: ${this._esc(ch===' ' ? '␠' : ch)}</option>`).join('');
      if(!txt) charSelect.innerHTML='<option value="0">—</option>';
      charSelect.value=String(Math.min(this._premiumCharIndex,Math.max(0,[...txt].length-1)));
      this._syncCharControls(modal,comp);
    };
    const saveChar=()=>{
      try {
        this._selfEdit = true;
        const idx=Number(charSelect.value||0), props=comp.props||{}; const arr=Array.isArray(props.char_overrides)?JSON.parse(JSON.stringify(props.char_overrides)):[];
        arr[idx]=Object.assign({x:0,y:0,scale_x:1,scale_y:1,rotation:0,color:''},arr[idx]||{});
        modal.querySelectorAll('[data-char]').forEach(el=>{ const k=el.dataset.char; arr[idx][k]=el.type==='color'?el.value:Number(el.value||0); });
        this.store.updateComponentProp(comp.id,'char_overrides',arr,{silent:true}); this._refreshPremiumPreview(modal,comp); this.store.commit();
      } finally {
        this._selfEdit = false;
      }
    };
    charSelect.addEventListener('change',()=>{this._premiumCharIndex=Number(charSelect.value||0);this._syncCharControls(modal,comp);});
    modal.querySelectorAll('[data-char]').forEach(el=>el.addEventListener('input',saveChar));
    modal.querySelector('[data-char-reset]').addEventListener('click',()=>{ const idx=Number(charSelect.value||0), arr=Array.isArray(comp.props?.char_overrides)?JSON.parse(JSON.stringify(comp.props.char_overrides)):[]; arr[idx]={x:0,y:0,scale_x:1,scale_y:1,rotation:0,color:''}; this.store.updateComponentProp(comp.id,'char_overrides',arr,{silent:true}); this._syncCharControls(modal,comp); this._refreshPremiumPreview(modal,comp); this.store.commit(); });

    const presets = {
      classic:{fill_type:'metallicGold',color:'#f6c64a',gradient_to:'#7a4308',depth:2,bevel_size:1,bevel_profile:'soft',outline_enabled:true,outline_width:1,outline_color:'#241507',metallic:92,roughness:24,extrusion_layers:8,top_highlight_opacity:60,glow_enabled:false,cast_shadow_enabled:true,cast_shadow_distance:5,cast_shadow_blur:3,cast_shadow_opacity:38,contact_shadow_enabled:true,contact_shadow_opacity:42,inner_shadow_enabled:true,inner_shadow_opacity:24},
      luxury:{fill_type:'metallicGold',color:'#fff1a8',gradient_to:'#6f3907',depth:3,bevel_size:1.4,bevel_profile:'deep',outline_enabled:true,outline_width:1.2,outline_color:'#2a1606',metallic:96,roughness:18,extrusion_layers:12,specular_opacity:40,reflection_opacity:18,top_highlight_opacity:72,glow_enabled:false,cast_shadow_enabled:true,cast_shadow_distance:7,cast_shadow_blur:4,cast_shadow_opacity:46,contact_shadow_enabled:true,contact_shadow_opacity:48,inner_shadow_enabled:true,inner_shadow_opacity:30},
      goldGlow:{fill_type:'metallicGold',color:'#ffd35a',gradient_to:'#7a3f05',depth:3,bevel_size:1.5,bevel_profile:'soft',outline_enabled:true,outline_width:1.2,outline_color:'#2b1705',metallic:94,roughness:20,extrusion_layers:12,specular_opacity:55,reflection_opacity:25,top_highlight_opacity:82,glow_enabled:true,glow_color:'#ffd34f',glow_opacity:55,glow_blur:10,cast_shadow_enabled:true,cast_shadow_distance:6,cast_shadow_blur:4,cast_shadow_opacity:40,contact_shadow_enabled:true,contact_shadow_opacity:45,inner_shadow_enabled:true,inner_shadow_opacity:28},
      soviet:{fill_type:'metallicGold',color:'#f8d65a',gradient_to:'#71370a',depth:2.5,bevel_size:1,bevel_profile:'hard',outline_enabled:true,outline_width:1,outline_color:'#241406',metallic:90,roughness:30,extrusion_layers:9,top_highlight_opacity:64,glow_enabled:false,cast_shadow_enabled:true,cast_shadow_angle:145,cast_shadow_elevation:42,cast_shadow_distance:6,cast_shadow_blur:3,cast_shadow_opacity:40,contact_shadow_enabled:true,contact_shadow_opacity:44,inner_shadow_enabled:true,inner_shadow_opacity:28},
      steel:{fill_type:'gradient',color:'#f5f7f8',gradient_to:'#4d555b',depth:2,bevel_size:1,bevel_profile:'hard',outline_enabled:true,outline_width:1,outline_color:'#15191d',metallic:95,roughness:22,extrusion_layers:8,specular_opacity:50,reflection_opacity:15,top_highlight_opacity:70,glow_enabled:false,cast_shadow_enabled:true,cast_shadow_distance:5,cast_shadow_blur:3,cast_shadow_opacity:34,contact_shadow_enabled:true,contact_shadow_opacity:40,inner_shadow_enabled:true,inner_shadow_opacity:25},
      reset:{fill_type:'solid',color:'#ffffff',gradient_to:'#555555',depth:0,bevel_size:0,bevel_profile:'soft',outline_enabled:false,outline_width:0,metallic:0,roughness:100,reflection_opacity:0,specular_opacity:0,extrusion_layers:1,extrusion_x:'',extrusion_y:'',top_highlight_opacity:0,glow_enabled:false,cast_shadow_enabled:false,contact_shadow_enabled:false,inner_shadow_enabled:false,char_overrides:[]}
    };
    modal.querySelectorAll('[data-modal-preset]').forEach(btn => btn.onclick = () => { const cfg=presets[btn.dataset.modalPreset]; Object.entries(cfg).forEach(([k,v])=>this.store.updateComponentProp(comp.id,k,v,{silent:true})); this._syncPremiumControls(modal, comp); this._refreshPremiumPreview(modal, comp); this.store.commit(); });
    modal.querySelectorAll('[data-typo-close]').forEach(btn => btn.onclick = () => { this.store.commit(); modal.remove(); this.render(); });
    const zoom=modal.querySelector('[data-local="previewZoom"]');
    zoom.addEventListener('input',()=>{
      try {
        this._selfEdit = true;
        modal.querySelector('[data-out="previewZoom"]').textContent=zoom.value+'%'; 
        this._refreshPremiumPreview(modal,comp);
      } finally {
        this._selfEdit = false;
      }
    });
    refreshChars();
    this._refreshPremiumPreview(modal, comp);
  }

  _syncCharControls(modal, comp) {
    const idx=Number(modal.querySelector('[data-char-select]')?.value||0);
    const o=(comp.props?.char_overrides||[])[idx]||{};
    modal.querySelectorAll('[data-char]').forEach(el=>{const k=el.dataset.char; el.value=o[k]!==undefined?o[k]:(k==='scale_x'||k==='scale_y'?1:k==='color'?'':0);});
  }

  _syncPremiumControls(modal, comp) {
    const p=comp.props||{};
    modal.querySelectorAll('[data-p]').forEach(el=>{const k=el.dataset.p;if(p[k]!==undefined){if(el.type==='checkbox')el.checked=!!p[k];else el.value=p[k];}});
    modal.querySelectorAll('[data-p-field]').forEach(el=>{const k=el.dataset.pField;if(comp[k]!==undefined)el.value=comp[k];});
    this._syncCharControls(modal, comp);
  }

  _refreshPremiumPreview(modal, comp) {
    // Дебаунсинг: очень тяжёлая операция (два полных рендера, один с 4× supersampling).
    // Кешируем запрос и выполняем не чаще чем раз в 150мс (max 6-7 раз в секунду).
    if (this._premiumPreviewScheduled) clearTimeout(this._premiumPreviewScheduled);
    this._premiumPreviewScheduledData = { modal, comp };
    this._premiumPreviewScheduled = setTimeout(() => {
      const { modal: m, comp: c } = this._premiumPreviewScheduledData;
      this._premiumPreviewScheduledData = null;
      this._doRefreshPremiumPreview(m, c);
    }, 150);
  }

  async _doRefreshPremiumPreview(modal, comp) {
    if (!modal || !document.body.contains(modal) || !window.WatchfacePreviewRenderer) return;
    const project=JSON.parse(JSON.stringify(this.store.state));
    const c=project.components.find(x=>x.id===comp.id); if(!c) return;
    const zoom=Number(modal.querySelector('[data-local="previewZoom"]')?.value||120)/100;
    c.x=Math.round((480-(c.w||200))/2); c.y=Math.round((480-(c.h||80))/2);
    const tc=modal.querySelector('[data-typo-text-canvas]');
    await window.WatchfacePreviewRenderer.draw({device:{w:480,h:480,shape:'round'},background:{color:'#070707',alpha:0},components:[c],fonts:project.fonts||[],assets:project.assets||[]},tc,{size:420,highQuality:true});
    tc.style.transform=`scale(${zoom})`;
    const dc=modal.querySelector('[data-typo-dial-canvas]');
    await window.WatchfacePreviewRenderer.draw(project,dc,{size:480,highQuality:false});
    this._bindPremiumDialDrag(modal, comp);
  }

  _bindPremiumDialDrag(modal, comp) {
    const c=modal.querySelector('[data-typo-dial-canvas]'); if(!c || c.dataset.dragBound) return;
    c.dataset.dragBound='1'; let drag=null;
    const pos=e=>{const r=c.getBoundingClientRect();return {x:(e.clientX-r.left)*(480/r.width),y:(e.clientY-r.top)*(480/r.height)}};
    c.addEventListener('pointerdown',e=>{const q=pos(e);if(q.x>=comp.x-20&&q.x<=comp.x+comp.w+20&&q.y>=comp.y-20&&q.y<=comp.y+comp.h+20){drag={q,x:comp.x,y:comp.y};c.setPointerCapture(e.pointerId);c.style.cursor='grabbing';}});
    c.addEventListener('pointermove',e=>{
      if(!drag)return;
      const q=pos(e);
      const newX = Math.round(drag.x+q.x-drag.q.x);
      const newY = Math.round(drag.y+q.y-drag.q.y);
      this.store.updateComponent(comp.id,{x:newX,y:newY},{silent:true});
      // Во время перетаскивания: обновляем позицию без полного рендера превью (слишком дорого).
      // Просто обновляем численные поля и рендерим циферблат.
      const x=modal.querySelector('[data-p-field="x"]'),y=modal.querySelector('[data-p-field="y"]');
      if(x)x.value=newX;
      if(y)y.value=newY;
      // Дебаунсинг полного превью: раз в 150мс обновим оба превью. До тех пор — только циферблат.
      if (!this._dragRefreshScheduled) {
        this._dragRefreshScheduled = true;
        requestAnimationFrame(async ()=>{
          const project=JSON.parse(JSON.stringify(this.store.state));
          const dc=modal.querySelector('[data-typo-dial-canvas]');
          if(dc && window.WatchfacePreviewRenderer) await window.WatchfacePreviewRenderer.draw(project,dc,{size:480,highQuality:false}).catch(()=>{});
          this._dragRefreshScheduled = false;
        });
      }
    });
    c.addEventListener('pointerup',()=>{drag=null;c.style.cursor='grab';this.store.commit();this._refreshPremiumPreview(modal,comp);});
  }

  _renderTapZone(parent, zone) {
    const p = zone.props || {};
    this.root.innerHTML = `
      <div class="insp-header">
        <input class="insp-name" value="${this._esc(zone.name || zone.id)}" data-field="zone-name">
        <div class="insp-id">🎯 ${this._esc(zone.id)} · дочка ${this._esc(parent.name)}</div>
      </div>
      <div class="insp-section-title">Позиция и размер относительно родителя</div>
      <div class="insp-grid">
        ${this._numberField('zx', 'X', zone.x)}
        ${this._numberField('zy', 'Y', zone.y)}
        ${this._numberField('zw', 'ШИРИНА', zone.w)}
        ${this._numberField('zh', 'ВЫСОТА', zone.h)}
      </div>
      <div class="insp-section-title">Действие по тапу</div>
      <div class="insp-grid">
        <div class="field wide"><label>ДЕЙСТВИЕ</label><select data-zone-prop="tap_action">
          <option value="NONE" ${p.tap_action === 'NONE' ? 'selected' : ''}>Ничего</option>
          <option value="METRIC" ${p.tap_action === 'METRIC' ? 'selected' : ''}>Системный экран</option>
          <option value="APP" ${p.tap_action === 'APP' ? 'selected' : ''}>Другое приложение</option>
          <option value="FLASHLIGHT" ${p.tap_action === 'FLASHLIGHT' ? 'selected' : ''}>Фонарик (вкл./выкл.)</option>
        </select></div>
        ${p.tap_action === 'FLASHLIGHT' ? `<div class="field wide"><small>Тап по зоне — белый экран. Повторный тап в любом месте экрана — возврат к циферблату.</small></div>` : ''}
        ${p.tap_action === 'METRIC' ? `<div class="field wide"><label>ЭКРАН</label><select data-zone-prop="tap_metric">${SYSTEM_SCREENS.map(x => `<option value="${x.value}" ${p.tap_metric === x.value ? 'selected' : ''}>${x.label}</option>`).join('')}</select></div>` : ''}
        ${p.tap_action === 'APP' ? `
          <div class="field"><label>APP ID</label><input type="number" data-zone-prop="tap_app_id" value="${Number(p.tap_app_id || 0)}"></div>
          <div class="field wide"><label>URL</label><input type="text" data-zone-prop="tap_app_url" value="${this._escAttr(p.tap_app_url || 'pages/index')}"></div>
        ` : ''}
      </div>
      <div class="insp-section-title">Поведение</div>
      <div class="insp-grid">
        <label class="field checkbox"><input type="checkbox" data-zone-visible ${zone.visible !== false ? 'checked' : ''}> Видимая в редакторе</label>
        <label class="field checkbox"><input type="checkbox" data-zone-locked ${zone.locked ? 'checked' : ''}> Заблокирована</label>
      </div>
      <div class="insp-actions"><button class="btn-danger" data-act="delete-tap-zone">Удалить тап-зону</button></div>
    `;
    this.root.querySelector('[data-field="zone-name"]').onchange = e =>
      this.store.updateTapZone(parent.id, zone.id, { name: e.target.value });
    this.root.querySelectorAll('[data-zone-prop]').forEach(el => el.onchange = () => {
      let value = el.value;
      if (el.type === 'number') value = Number(value) || 0;
      this.store.updateTapZone(parent.id, zone.id, { props: { [el.dataset.zoneProp]: value } });
    });
    [['zx','x'],['zy','y'],['zw','w'],['zh','h']].forEach(([field,key]) => {
      const el = this.root.querySelector(`[data-prop="${field}"]`);
      if (el) el.onchange = () => this.store.updateTapZone(parent.id, zone.id, { [key]: Math.max(key === 'w' || key === 'h' ? 4 : -99999, Number(el.value) || 0) });
    });
    const vis = this.root.querySelector('[data-zone-visible]');
    const lock = this.root.querySelector('[data-zone-locked]');
    vis.onchange = () => this.store.updateTapZone(parent.id, zone.id, { visible: vis.checked });
    lock.onchange = () => this.store.updateTapZone(parent.id, zone.id, { locked: lock.checked });
    this.root.querySelector('[data-act="delete-tap-zone"]').onclick = () => this.store.removeTapZone(parent.id, zone.id);
  }

  _renderBackground() {
    const bg = this.store.state.background || { color: '#000000', imageAssetId: null, alpha: 100 };
    const assets = this.store.state.assets || [];
    const aod = this.store.state.mode === 'aod';
    this.root.innerHTML = `
      <div class="insp-header">
        <div class="insp-name-static">🎨 Фон</div>
        <div class="insp-id">Слой фона · ${aod ? 'AOD' : 'Normal'}</div>
      </div>
      <div class="insp-section-title">Внешний вид</div>
      <div class="insp-grid">
        <div class="field"><label>Цвет</label><input type="color" data-bg="color" value="${this._escAttr(bg.color || '#000000')}"></div>
        <div class="field"><label>Прозрачность</label><input type="number" data-bg="alpha" min="0" max="100" value="${Number(bg.alpha ?? 100)}"></div>
        <div class="field wide"><label>Изображение</label>
          <select data-bg="imageAssetId">
            <option value="">— нет (только цвет) —</option>
            ${assets.filter((a) => !a.bgFrame && !a.weatherIcon).map((a) => `<option value="${this._escAttr(a.id)}" ${bg.imageAssetId === a.id ? 'selected' : ''}>${this._esc(a.name)}</option>`).join('')}
          </select>
        </div>
        <div class="field wide bg-editor-actions">
          <button type="button" class="btn-primary" data-bg-edit="new">🖼 Выбрать и обработать фон</button>
          ${bg.imageAssetId ? '<button type="button" data-bg-edit="current">✎ Редактировать текущий</button>' : ''}
        </div>
      </div>
      <div class="insp-note">Фон можно выбрать, обрезать под круглый циферблат, увеличить/сдвинуть, повернуть, настроить яркость/контраст и автоматически получить PNG 480×480. Прозрачность изображения PNG сохраняется.</div>
      ${aod ? '' : this._bgAnimSectionHtml(bg)}
    `;
    const apply = (key, value) => {
      this.store.state.background = Object.assign({ color: '#000000', imageAssetId: null, alpha: 100 }, this.store.state.background || {}, { [key]: value });
      if (aod && key === 'color') {
        const settings = this.store.getAodSettings();
        settings.background = value;
      }
      this.store.commit();
    };
    this.root.querySelectorAll('[data-bg]').forEach((el) => {
      const key = el.dataset.bg;
      const read = () => key === 'alpha' ? Number(el.value) : el.value;
      el.addEventListener('change', () => apply(key, read()));
      if (el.type === 'number') el.addEventListener('input', () => {
        this._selfEdit = true;
        try {
          this.store.state.background = Object.assign({}, this.store.state.background || {}, { [key]: read() });
          if (aod && key === 'alpha') { /* live editor only */ }
          this.store._emit();
        } finally { this._selfEdit = false; }
      });
    });
    this.root.querySelector('[data-bg-edit="new"]')?.addEventListener('click', () => this._pickBackgroundFile());
    this.root.querySelector('[data-bg-edit="current"]')?.addEventListener('click', () => {
      const id = this.store.state.background?.imageAssetId;
      const a = (this.store.state.assets || []).find(x => x.id === id);
      if (a) this._openBackgroundEditor(a);
    });
    if (!aod) this._bindBgAnim();
  }

  // ---- Покадровая анимация фона (IMG_ANIM, только Normal) ----
  _bgAnimSectionHtml(bg) {
    const a = BgAnim.normalize(bg.anim);
    const playing = !!(window.bgAnimPreview && window.bgAnimPreview.isPlaying());
    const n = a.frames.length;
    return `
      <div class="insp-section-title">Покадровая анимация фона</div>
      <div class="insp-grid">
        <div class="field wide"><label><input type="checkbox" data-ba="enabled" ${a.enabled ? 'checked' : ''}> Включить (только Normal, в AOD фон статичный)</label></div>
        <div class="field wide bg-editor-actions">
          <button type="button" class="btn-primary" data-ba-act="load">🎞 Кадры / видео / GIF…</button>
          ${n ? '<button type="button" data-ba-act="clear">✕ Очистить</button>' : ''}
        </div>
        <div class="field"><label>Видео/GIF: начало, с</label><input type="number" data-bs="start" min="0" step="0.1" value="${this._bgSrc().start}"></div>
        <div class="field"><label>длина, с (0 — целиком)</label><input type="number" data-bs="len" min="0" step="0.1" value="${this._bgSrc().len}"></div>
        <div class="field wide"><label>Кадров: <b>${n}</b>${n === 1 ? ' — нужно минимум 2' : ''}</label></div>
        <div class="field"><label>Кадров/с (1–30)</label><input type="number" data-ba="fps" min="1" max="30" value="${a.fps}"></div>
        <div class="field"><label><input type="checkbox" data-ba="loop" ${a.loop ? 'checked' : ''}> Зациклить</label></div>
        ${a.loop ? '' : `<div class="field"><label>Проходов</label><input type="number" data-ba="repeat" min="1" max="999" value="${a.repeat}"></div>`}
        <div class="field wide bg-editor-actions">
          <button type="button" data-ba-act="${playing ? 'stop' : 'play'}" ${n >= 2 ? '' : 'disabled'}>${playing ? '⏹ Стоп' : '▶ Просмотр'}</button>
        </div>
      </div>
      <div class="insp-note">Выберите <b>один GIF или видео</b> (MP4 H.264, WebM) — он нарежется на кадры с частотой «Кадров/с» из нужного отрезка (начало и длина выше); GIF короче отрезка зациклится. После загрузки кадры можно просматривать на таймлайне под холстом: двигать ползунок, менять масштаб кадров и высоту панели. Либо выберите <b>несколько картинок</b> (PNG/JPEG/WebP): они отсортируются по имени (f2 &lt; f10). Всё приводится к размеру циферблата в PNG. Совет: 2–4 с на 10–15 кадров/с, до ${BgAnim.MAX_FRAMES} кадров — каждый кадр занимает память часов. Экспорт: <code>IMG_ANIM</code> поверх статичного фона; запуск — при пробуждении экрана. ⚠ Параметры <code>IMG_ANIM</code> не подтверждены документацией — проверьте на часах. Браузерный просмотр работу на часах не доказывает.</div>
    `;
  }

  // Параметры нарезки видео/GIF — состояние интерфейса, в проект не пишется.
  _bgSrc() { return this._bgSrcOpts || (this._bgSrcOpts = { start: 0, len: 3 }); }

  _setBgAnim(patch) {
    const bg = this.store.state.background || { color: '#000000', imageAssetId: null, alpha: 100 };
    const next = Object.assign({}, BgAnim.normalize(bg.anim), patch);
    this.store.state.background = Object.assign({}, bg, { anim: next });
    this.store.commit();
  }

  _bindBgAnim() {
    const prev = window.bgAnimPreview;
    this.root.querySelectorAll('[data-ba]').forEach((el) => {
      const key = el.dataset.ba;
      el.addEventListener('change', () => {
        const value = el.type === 'checkbox' ? el.checked : Number(el.value);
        if (prev && prev.isPlaying()) prev.stop();
        this._setBgAnim({ [key]: value });
      });
    });
    this.root.querySelectorAll('[data-bs]').forEach((el) => {
      el.addEventListener('change', () => { this._bgSrc()[el.dataset.bs] = Math.max(0, Number(el.value) || 0); });
    });
    this.root.querySelectorAll('[data-ba-act]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const act = btn.dataset.baAct;
        if (act === 'play') { if (prev) prev.play(); this.render(); }
        else if (act === 'stop') { if (prev) prev.stop(); this.render(); }
        else if (act === 'clear') { await this._clearBgAnimFrames(); }
        else if (act === 'load') { this._pickBgAnimFrames(); }
      });
    });
  }

  async _clearBgAnimFrames() {
    if (window.bgAnimPreview) window.bgAnimPreview.stop();
    const bg = this.store.state.background || {};
    const ids = new Set(BgAnim.normalize(bg.anim).frames);
    // Кадры, созданные этой функцией (asset.bgFrame), удаляются вместе со списком — иначе пакет раздувается.
    this.store.state.assets = (this.store.state.assets || []).filter((a) => !(a.bgFrame && ids.has(a.id)));
    if (bg.imageAssetId && ids.has(bg.imageAssetId)) this.store.state.background = Object.assign({}, bg, { imageAssetId: null });   // не оставляем ссылку на удалённый кадр
    this._setBgAnim({ frames: [], enabled: false });
  }

  // Общий хвост загрузки: кадры (dataUrl) → ресурсы bgf_NNN, старые кадры заменяются.
  _applyBgFrames(frames) {
    const made = frames.map((f, i) => ({ id: makeAssetId(), name: 'bgf_' + String(i).padStart(3, '0'), dataUrl: f.dataUrl, width: f.width, height: f.height, format: 'PNG', size: Math.round(f.dataUrl.length * 0.75), bgFrame: true }));
    const oldIds = new Set(BgAnim.normalize((this.store.state.background || {}).anim).frames);
    this.store.state.assets = (this.store.state.assets || []).filter((a) => !(a.bgFrame && oldIds.has(a.id)));
    const bg0 = this.store.state.background || {};
    if (bg0.imageAssetId && oldIds.has(bg0.imageAssetId)) this.store.state.background = Object.assign({}, bg0, { imageAssetId: null });   // заменённые кадры удалены
    for (const fr of made) this.store.state.assets.push(fr);
    this._setBgAnim({ frames: made.map((x) => x.id), enabled: made.length >= 2 });
  }

  _pickBgAnimFrames() {
    const input = document.createElement('input');
    input.type = 'file';
    input.multiple = true;
    input.accept = 'image/png,image/jpeg,image/webp,image/gif,video/*';
    input.onchange = async () => {
      const list = Array.from(input.files || []);
      if (!list.length) return;
      const dev = this.store.state.device || { w: 480, h: 480 };
      const btn = this.root.querySelector('[data-ba-act="load"]');
      const setBusy = (txt) => { if (btn) { btn.disabled = true; btn.textContent = txt; } };
      try {
        if (window.bgAnimPreview) window.bgAnimPreview.stop();
        // Один GIF или одно видео → нарезка на кадры.
        if (list.length === 1 && (BgAnim.isGif(list[0]) || BgAnim.isVideo(list[0]))) {
          const file = list[0];
          const a = BgAnim.normalize((this.store.state.background || {}).anim);
          const src = this._bgSrc();
          const opts = { fps: a.fps, start: src.start, len: src.len, w: dev.w, h: dev.h, onProgress: (k, n) => setBusy(`Нарезка ${k}/${n}…`) };
          setBusy('Нарезка…');
          const frames = BgAnim.isGif(file) ? await BgAnim.gifFileToFrames(file, opts) : await BgAnim.videoFileToFrames(file, opts);
          this._applyBgFrames(frames);
          return;
        }
        let files = BgAnim.sortFilesNatural(list).filter((f) => /^image\//.test(f.type) && !BgAnim.isGif(f));
        if (!files.length) { alert('Для нарезки выберите один GIF или одно видео; для набора кадров — несколько PNG/JPEG/WebP.'); return; }
        if (files.length > BgAnim.MAX_FRAMES) {
          alert(`Выбрано ${files.length} кадров, максимум ${BgAnim.MAX_FRAMES}. Взяты первые ${BgAnim.MAX_FRAMES}.`);
          files = files.slice(0, BgAnim.MAX_FRAMES);
        }
        const frames = [];
        for (let i = 0; i < files.length; i++) frames.push(await BgAnim.fileToPngFrame(files[i], dev.w, dev.h));
        this._applyBgFrames(frames);
      } catch (e) {
        console.error(e);
        alert('Не удалось загрузить кадры: ' + (e && e.message || e));
        this.render();
      }
    };
    input.click();
  }

  _pickBackgroundFile() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/png,image/jpeg,image/webp';
    input.onchange = () => {
      const file = input.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        const img = new Image();
        img.onload = () => this._openBackgroundEditor({ name: file.name.replace(/\\.(png|jpe?g|webp)$/i, ''), dataUrl: reader.result, width: img.width, height: img.height, format: 'PNG', size: file.size });
        img.src = reader.result;
      };
      reader.readAsDataURL(file);
    };
    input.click();
  }

  _openBackgroundEditor(asset) {
    const modal = document.createElement('div');
    modal.className = 'bg-editor-modal';
    // Параметры по умолчанию (используются и для сброса, и для разметки).
    const DEF = {
      zoom:100, x:0, y:0, rot:0,
      brightness:100, contrast:100, saturation:100, hue:0, gray:0, sepia:0, blur:0, alpha:100,
      edgeFade:0, vignette:0, glass:0, volume:0, glow:0, bloom:0, reflection:0, grain:0,
      scanlines:0, chroma:0, pixelate:0, tint:0, gradient:0, bezel:0,
      tintColor:'#ff8c28', bezelColor:'#c9a24a',
      gradType:'linear', gradAngle:180, gradBlend:'normal', gradC1:'#ff5e62', gradC2:'#ffb347', gradC3:'#5b3cff'
    };
    // [ключ, подпись, min, max, подсказка, ключ цвета]
    const ADJ = [
      ['brightness','Яркость',50,150,'Яркость изображения'],
      ['contrast','Контраст',50,150,'Контраст изображения'],
      ['saturation','Насыщенность',0,200,'Насыщенность цвета'],
      ['hue','Оттенок',-180,180,'Поворот цветового круга, °'],
      ['gray','Ч/Б',0,100,'Чёрно-белое'],
      ['sepia','Сепия',0,100,'Тёплый «старинный» тон'],
      ['blur','Размытие',0,20,'Размытие изображения, px'],
      ['alpha','Прозрачность',0,100,'Непрозрачность изображения, %'],
    ];
    const FX = [
      ['edgeFade','Затух. краёв',0,100,'Плавное растворение краёв круга'],
      ['vignette','Виньетка',0,100,'Затемнение по краям'],
      ['glass','Стекло',0,100,'Блик стекла'],
      ['volume','Объём',0,100,'Объёмное затенение'],
      ['glow','Свечение',0,100,'Мягкий свет из центра'],
      ['bloom','Сияние',0,100,'Bloom: светлые участки «растекаются»'],
      ['reflection','Отражение',0,100,'Дуга-отражение'],
      ['grain','Зерно',0,100,'Плёночное зерно'],
      ['scanlines','Линии',0,100,'Горизонтальные линии как на экране CRT'],
      ['chroma','Аберрация',0,100,'Цветная кайма к краям, как у линзы'],
      ['pixelate','Пиксели',0,100,'Пикселизация (мозаика)'],
      ['tint','Тонировка',0,100,'Окрасить изображение выбранным цветом','tintColor'],
      ['gradient','Градиент',0,100,'Сила градиента (цвета и тип — ниже)'],
      ['bezel','Ободок',0,100,'Кольцо по краю циферблата (толщина)','bezelColor'],
    ];
    const GRAD_PRESETS = [
      { name: 'Закат',  type: 'linear', angle: 180, c: ['#ff5e62', '#ff9966', '#ffd86f'] },
      { name: 'Океан',  type: 'linear', angle: 180, c: ['#00c6ff', '#0072ff', '#001f5c'] },
      { name: 'Неон',   type: 'linear', angle: 135, c: ['#ff00cc', '#7a00ff', '#00e5ff'] },
      { name: 'Аврора', type: 'mirror', angle: 160, c: ['#00ff99', '#00b3ff', '#8a2be2'] },
      { name: 'Золото', type: 'radial', angle: 0,   c: ['#fff1b0', '#c9a24a', '#3a2605'] },
      { name: 'Огонь',  type: 'radial', angle: 0,   c: ['#ffe259', '#ff6a00', '#7a0000'] },
      { name: 'Радуга', type: 'conic',  angle: 0,   c: ['#ff3b3b', '#3bff6a', '#3b6bff'] },
    ];
    const rowHtml = ([k,label,min,max,tip,ck]) => `
      <label class="bgr" title="${tip}"><span class="bgr-l">${label}${ck ? `<input type="color" class="bgr-c" data-kc="${ck}" value="${DEF[ck]}">` : ''}</span>
        <input type="range" data-k="${k}" min="${min}" max="${max}" step="1" value="${DEF[k]}">
        <input type="number" class="bgr-n" data-k="${k}" min="${min}" max="${max}" step="1" value="${DEF[k]}"></label>`;
    modal.innerHTML = `
      <div class="bg-editor-dialog">
        <div class="bg-editor-head"><b>Фон циферблата</b><small>круг 480×480 · PNG</small><button type="button" data-bg-close title="Закрыть">✕</button></div>
        <div class="bg-editor-body">
          <div class="bg-editor-preview"><canvas width="520" height="520"></canvas>
            <div class="bg-editor-drag-hint">Тащите картинку · колесо — масштаб · круг — то, что попадёт в PNG</div>
            <div class="bg-editor-warn" data-bg-warn hidden>⚠ Картинка закрывает круг не полностью — пустое место будет прозрачным</div>
          </div>
          <div class="bg-editor-controls">
            <div class="bg-editor-fitrow">
              <button type="button" data-bg-fit="cover" title="Масштаб, при котором картинка целиком закрывает круг">Заполнить</button>
              <button type="button" data-bg-fit="contain" title="Вписать картинку в круг целиком">Вписать</button>
              <button type="button" data-bg-fit="native" title="Реальный размер: 1 пиксель картинки = 1 пиксель циферблата">1:1</button>
              <label class="chk" title="Показать весь исходный лист, чтобы выбрать нужный фон среди нескольких"><input type="checkbox" data-bg-sheet> Весь лист</label>
            </div>
            <div class="bgt">
              <label><span>Масштаб, %</span><input type="number" data-k="zoom" min="2" max="800" step="1" value="100"></label>
              <label><span>Сдвиг X, px</span><input type="number" data-k="x" step="1" value="0"></label>
              <label><span>Сдвиг Y, px</span><input type="number" data-k="y" step="1" value="0"></label>
              <label><span>Поворот, °</span><input type="number" data-k="rot" min="-180" max="180" step="1" value="0"></label>
            </div>
            <div class="bgsec"><b>Коррекция</b><button type="button" data-bg-reset="adj">↺ Сбросить</button></div>
            <div class="bgg">${ADJ.map(rowHtml).join('')}</div>
            <div class="bgsec"><b>Эффекты фона</b><button type="button" data-bg-reset="fx">↺ Сбросить</button></div>
            <div class="bgg">${FX.map(rowHtml).join('')}</div>
            <div class="bggrad" title="Настройки градиента (работает, когда «Градиент» &gt; 0)">
              <select data-ks="gradType" title="Тип градиента">
                <option value="linear">Линейный</option><option value="mirror">Зеркальный</option><option value="radial">Радиальный</option><option value="conic">Конический</option>
              </select>
              <label class="bgang" title="Угол: 0° — снизу вверх, 90° — слева направо, 180° — сверху вниз (для конического — поворот)">∠ <input type="number" class="bgr-n" data-k="gradAngle" min="0" max="360" step="1" value="180">°</label>
              <select data-ks="gradBlend" title="Режим наложения">
                <option value="normal">Обычное</option><option value="color">Цвет</option><option value="soft">Мягкий свет</option><option value="overlay">Перекрытие</option><option value="screen">Экран</option><option value="multiply">Умножение</option>
              </select>
              <span class="bgcols"><input type="color" data-kc="gradC1" value="${DEF.gradC1}" title="Цвет 1"><input type="color" data-kc="gradC2" value="${DEF.gradC2}" title="Цвет 2"><input type="color" data-kc="gradC3" value="${DEF.gradC3}" title="Цвет 3"></span>
              <select data-grad-preset title="Готовые градиенты">
                <option value="">Пресет…</option>${GRAD_PRESETS.map((g, i) => `<option value="${i}">${g.name}</option>`).join('')}
              </select>
            </div>
            <div class="bge-foot">
              <span class="bge-note">Эффекты применяются внутри круга и запекаются в PNG 480×480.</span>
              <div class="bg-editor-buttons"><button type="button" data-bg-cancel>Отмена</button><button type="button" class="btn-primary" data-bg-apply>Применить фон</button></div>
            </div>
          </div>
        </div>
      </div>`;
    document.body.appendChild(modal);
    const canvas = modal.querySelector('canvas'), ctx = canvas.getContext('2d'); ctx.imageSmoothingEnabled=true; ctx.imageSmoothingQuality='high';
    // Editor-only 20px safety margin around the 480px dial. The blue/white
    // boundary is drawn in this margin, never inside the 480x480 image area.
    const PREVIEW_PAD = 20, DIAL_SIZE = 480;
    const img = new Image(); img.src = asset.dataUrl;
    // Фон с сохранёнными настройками (asset.bg): открываем исходник и восстанавливаем все параметры.
    const savedBg = (typeof AssetBg !== 'undefined' && AssetBg.isBg(asset)) ? AssetBg.params(asset) : null;
    const state = Object.assign({}, DEF, savedBg || {});

    // Actual rendered size of the source image once the "cover" fit and the
    // current zoom are applied. Both the pan clamp and the drawing code need
    // this, so it lives in one place instead of being recomputed (and
    // potentially drifting out of sync) in two places.
    // Масштаб — реальный: 100% = 1 пиксель исходника на 1 пиксель циферблата.
    // (Раньше 100% означало «cover», а смещение было жёстко ограничено так,
    // чтобы картинка всегда закрывала круг — из-за этого для квадратных
    // картинок и больших листов с несколькими фонами двигать было нечего.)
    const getRenderedSize = () => {
      const base = state.zoom / 100;
      return { base, w: img.naturalWidth * base, h: img.naturalHeight * base };
    };
    const coverZoom = () => Math.max(DIAL_SIZE / img.naturalWidth, DIAL_SIZE / img.naturalHeight) * 100;
    const containZoom = () => Math.min(DIAL_SIZE / img.naturalWidth, DIAL_SIZE / img.naturalHeight) * 100;
    // Свободное перемещение: центр картинки может уйти не дальше, чем нужно,
    // чтобы любой её край дошёл до противоположного края круга.
    const getMaxOffset = () => {
      const { w, h } = getRenderedSize();
      return { mx: w / 2 + DIAL_SIZE / 2, my: h / 2 + DIAL_SIZE / 2 };
    };
    const fmtNum = (k, v) => k === 'zoom' ? Math.round(v * 10) / 10 : Math.round(v);
    // Записать значения состояния во все поля (кроме того, что сейчас редактируется).
    const syncInputs = (force) => modal.querySelectorAll('[data-k]').forEach((el) => {
      if (!force && el === document.activeElement) return;
      const v = state[el.dataset.k]; if (v !== undefined) el.value = fmtNum(el.dataset.k, v);
    });
    const clampPan = () => {
      const { mx, my } = getMaxOffset();
      state.x = Math.max(-mx, Math.min(mx, state.x));
      state.y = Math.max(-my, Math.min(my, state.y));
    };
    // Масштаб предпросмотра: в обычном режиме 1:1, в режиме «Весь лист» —
    // уменьшаем так, чтобы вся картинка (с учётом поворота) поместилась.
    let sheetView = false;
    const getView = () => {
      if (!sheetView || !img.naturalWidth) return 1;
      // Зависит только от размера картинки (не от сдвига), поэтому при
      // перетаскивании картинка идёт строго за курсором.
      const { w, h } = getRenderedSize();
      const r = state.rot * Math.PI / 180, c = Math.abs(Math.cos(r)), sn = Math.abs(Math.sin(r));
      const ex = (w * c + h * sn) / 2, ey = (w * sn + h * c) / 2;
      return Math.min(1, 250 / Math.max(DIAL_SIZE / 2, ex, ey));
    };

    // Отрисовка вынесена в AssetBg.paint (src/assets/asset-bg.js): ею же фон запекается при
    // сохранении проекта, поэтому в PNG попадает ровно то, что видно в этом окне.
    // Рисует ТОЛЬКО содержимое циферблата 480×480 (без кольца границы) в targetCtx.
    const drawContent = (targetCtx, padX, padY) => AssetBg.paint(targetCtx, img, state, padX, padY);

    const draw = () => {
      if (img.naturalWidth) { clampPan(); syncInputs(); }
      ctx.clearRect(0, 0, 520, 520);
      const v = getView();
      const cx = 240, cy = 240, dialR = 240;
      ctx.save();
      // координаты циферблата -> холст предпросмотра (центр круга в 260,260)
      ctx.translate(260, 260); ctx.scale(v, v); ctx.translate(-240, -240);

      // Исходник целиком, затемнённый, — и за пределами круга тоже, чтобы было
      // видно, что именно обрезается и где лежат остальные фоны листа.
      if (img.naturalWidth) {
        const { w, h } = getRenderedSize();
        ctx.save();
        ctx.translate(240 + state.x, 240 + state.y);
        ctx.rotate(state.rot * Math.PI / 180);
        ctx.globalAlpha = 0.32;
        ctx.drawImage(img, -w / 2, -h / 2, w, h);
        ctx.restore();
        // рамка исходного листа
        ctx.save();
        ctx.translate(240 + state.x, 240 + state.y);
        ctx.rotate(state.rot * Math.PI / 180);
        ctx.strokeStyle = 'rgba(255,255,255,.35)'; ctx.lineWidth = 1 / v; ctx.setLineDash([6 / v, 4 / v]);
        ctx.strokeRect(-w / 2, -h / 2, w, h);
        ctx.restore();
      }

      // Реальное содержимое циферблата (то же, что уйдёт в PNG) — внутри круга.
      drawContent(ctx, 0, 0);

      // Граница круга — только на предпросмотре, в экспорт не попадает.
      ctx.beginPath(); ctx.arc(cx, cy, dialR + 0.5 / v, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(100, 190, 255, 0.95)'; ctx.lineWidth = 2 / v; ctx.stroke();
      ctx.beginPath(); ctx.arc(cx, cy, dialR + 3 / v, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.22)'; ctx.lineWidth = 1 / v; ctx.stroke();
      ctx.restore();

      // Предупреждение, если круг закрыт картинкой не полностью.
      const warn = modal.querySelector('[data-bg-warn]');
      if (warn && img.naturalWidth) {
        const { w, h } = getRenderedSize();
        const r = state.rot * Math.PI / 180, c = Math.cos(r), sn = Math.sin(r);
        // точки на окружности круга в системе координат картинки
        let outside = false;
        for (let i = 0; i < 24 && !outside; i++) {
          const a = i / 24 * Math.PI * 2;
          const dx = Math.cos(a) * dialR - state.x, dy = Math.sin(a) * dialR - state.y;
          const ix = dx * c + dy * sn, iy = -dx * sn + dy * c;
          if (Math.abs(ix) > w / 2 || Math.abs(iy) > h / 2) outside = true;
        }
        warn.hidden = !outside;
      }
    };
    let dragBg = false, dragStart = null;
    canvas.style.cursor = 'grab'; canvas.style.touchAction = 'none';
    // Pointer events + захват указателя: перетаскивание не обрывается, когда
    // курсор выходит за пределы холста.
    canvas.addEventListener('pointerdown', (e) => {
      if (e.button !== 0) return;
      dragBg = true; dragStart = { x: e.clientX, y: e.clientY, sx: state.x, sy: state.y };
      canvas.style.cursor = 'grabbing';
      try { canvas.setPointerCapture(e.pointerId); } catch (_) {}
      e.preventDefault();
    });
    canvas.addEventListener('pointermove', (e) => {
      if (!dragBg) return;
      // Холст 520×520 на экране растянут по CSS, плюс режим «Весь лист» его
      // уменьшает (v) — поэтому делим на оба коэффициента, и картинка идёт
      // ровно за курсором.
      const rect = canvas.getBoundingClientRect();
      const k = (canvas.width / rect.width) / getView();
      state.x = dragStart.sx + (e.clientX - dragStart.x) * k;
      state.y = dragStart.sy + (e.clientY - dragStart.y) * k;
      draw();
    });
    const endDrag = () => { dragBg = false; canvas.style.cursor = 'grab'; };
    canvas.addEventListener('pointerup', endDrag);
    canvas.addEventListener('pointercancel', endDrag);

    const setZoom = (z, anchor) => {
      const nz = Math.max(2, Math.min(800, z));
      const k = nz / state.zoom;
      if (anchor) {
        // масштаб вокруг точки под курсором: она остаётся на месте
        const qx = anchor.x - 240, qy = anchor.y - 240;
        state.x = qx + (state.x - qx) * k; state.y = qy + (state.y - qy) * k;
      } else { state.x *= k; state.y *= k; }
      state.zoom = nz;
      draw();
    };
    canvas.addEventListener('wheel', (e) => {
      e.preventDefault();
      const rect = canvas.getBoundingClientRect();
      const v = getView();
      const px = (e.clientX - rect.left) * (canvas.width / rect.width);
      const py = (e.clientY - rect.top) * (canvas.height / rect.height);
      // «Весь лист»: картинка неподвижна, меняется размер круга (масштаб вокруг центра круга).
      // Обычный вид: масштаб вокруг точки под курсором.
      setZoom(state.zoom * (e.deltaY < 0 ? 1.1 : 1 / 1.1), sheetView ? null : { x: (px - 260) / v + 240, y: (py - 260) / v + 240 });
    }, { passive: false });

    const sheetCb = modal.querySelector('[data-bg-sheet]');
    sheetCb.onchange = () => { sheetView = sheetCb.checked; draw(); };
    modal.querySelectorAll('[data-bg-fit]').forEach((btn) => btn.onclick = () => {
      const mode = btn.dataset.bgFit;
      state.zoom = mode === 'cover' ? coverZoom() : mode === 'contain' ? containZoom() : 100;
      state.x = 0; state.y = 0; draw();
    });
    let initialJson = '';
    img.onload = () => {
      // Начальное состояние: картинка заполняет круг (как раньше). Большой лист
      // с несколькими фонами открываем сразу в режиме «Весь лист».
      if (!savedBg) state.zoom = coverZoom();
      initialJson = JSON.stringify(state);
      if (!savedBg && Math.max(img.naturalWidth, img.naturalHeight) > DIAL_SIZE * 1.25) { sheetView = true; sheetCb.checked = true; }
      syncExtras(); syncInputs(true);
      draw();
    };
    const clampKey = (k, v) => {
      const el = modal.querySelector(`input[type=number][data-k="${k}"]`);
      const lo = el && el.min !== '' ? Number(el.min) : -Infinity, hi = el && el.max !== '' ? Number(el.max) : Infinity;
      return Math.max(lo, Math.min(hi, v));
    };
    modal.querySelectorAll('[data-k]').forEach(el => {
      el.addEventListener('input', () => {
        if (el.value === '' || el.value === '-' || !isFinite(Number(el.value))) return; // пользователь ещё печатает
        state[el.dataset.k] = clampKey(el.dataset.k, Number(el.value));
        draw();
      });
      el.addEventListener('change', () => { if (el.value === '' || !isFinite(Number(el.value))) state[el.dataset.k] = DEF[el.dataset.k]; draw(); syncInputs(true); });
      // Колесо над полем — тонкая подстройка (Shift — крупнее).
      if (el.type === 'number') el.addEventListener('wheel', (e) => {
        if (document.activeElement !== el) return;
        e.preventDefault();
        const step = (e.deltaY < 0 ? 1 : -1) * (e.shiftKey ? 10 : 1);
        state[el.dataset.k] = clampKey(el.dataset.k, state[el.dataset.k] + step);
        draw(); syncInputs(true);
      }, { passive: false });
    });
    modal.querySelectorAll('[data-kc]').forEach(el => el.addEventListener('input', () => { state[el.dataset.kc] = el.value; draw(); }));
    const GRAD_KEYS = ['gradType', 'gradAngle', 'gradBlend', 'gradC1', 'gradC2', 'gradC3'];
    const syncExtras = () => {
      modal.querySelectorAll('[data-ks]').forEach(el => { el.value = state[el.dataset.ks]; });
      modal.querySelectorAll('[data-kc]').forEach(el => { el.value = state[el.dataset.kc]; });
    };
    modal.querySelectorAll('[data-ks]').forEach(el => el.addEventListener('change', () => { state[el.dataset.ks] = el.value; draw(); }));
    modal.querySelector('[data-grad-preset]').addEventListener('change', (e) => {
      const g = GRAD_PRESETS[Number(e.target.value)]; e.target.value = '';
      if (!g) return;
      state.gradType = g.type; state.gradAngle = g.angle; [state.gradC1, state.gradC2, state.gradC3] = g.c;
      if (!state.gradient) state.gradient = 80;
      syncExtras(); syncInputs(true); draw();
    });
    const resetKeys = (rows) => {
      if (rows === FX) { GRAD_KEYS.forEach(k => { state[k] = DEF[k]; }); syncExtras(); }
      for (const r of rows) {
        state[r[0]] = DEF[r[0]];
        if (r[5]) { state[r[5]] = DEF[r[5]]; const ce = modal.querySelector(`[data-kc="${r[5]}"]`); if (ce) ce.value = DEF[r[5]]; }
      }
      syncInputs(true); draw();
    };
    modal.querySelector('[data-bg-reset="adj"]').onclick = () => resetKeys(ADJ);
    modal.querySelector('[data-bg-reset="fx"]').onclick = () => resetKeys(FX);
    const close=()=>modal.remove();
    modal.querySelector('[data-bg-close]').onclick=close;
    modal.querySelector('[data-bg-cancel]').onclick=close;
    // «Применить»: исходная картинка остаётся в проекте как есть, а все настройки сохраняются
    // отдельно (asset.bg). PNG 480×480 строится при сохранении проекта в Zepp-файлы
    // (AssetBg.bakeProject) и в runtime-кэш предпросмотра.
    modal.querySelector('[data-bg-apply]').onclick=async()=>{
      const bgMeta = { v: AssetBg.VERSION, params: Object.assign({}, state) };
      const useAsBackground = (id) => {
        this.store.state.background = Object.assign({ color: '#000000', imageAssetId: null, alpha: 100 }, this.store.state.background || {}, { imageAssetId: id, alpha: 100 });
        this.store.commit();
      };
      try {
        if (savedBg) {
          // Правим тот же ресурс: новые копии фонов не плодятся, исходник не трогаем.
          if (JSON.stringify(state) !== initialJson) {
            asset.bg = bgMeta; // объект лежит в store.state.assets — обновляем «на месте» + кэш предпросмотра
            await AssetBg.refreshAll([asset]);
            this.store.replaceAsset(asset.id, { bg: bgMeta });
          }
          useAsBackground(asset.id); close(); return;
        }
        const unchanged = JSON.stringify(state)===initialJson && img.naturalWidth===480 && img.naturalHeight===480;
        // Ничего не менялось и картинка уже 480×480 — оставляем как обычный ресурс (без настроек и перекодирования).
        const out={id:makeAssetId(),name:`${asset.name || 'background'}-480`,dataUrl:asset.dataUrl,width:img.naturalWidth,height:img.naturalHeight,format:'PNG',size:asset.size};
        if(!unchanged){
          out.name=`${asset.name || 'background'}-bg`;
          out.bg=bgMeta;
          await AssetBg.refreshAll([out]); // кэш готов до добавления — предпросмотр не мигает сырой картинкой
        }
        this.store.addAsset(out);
        useAsBackground(out.id); close();
      } catch (e) {
        console.error(e);
        alert('Не удалось применить фон: ' + (e && e.message || e));
      }
    };
  }

  _renderMulti(ids) {
    const comps = ids.map((id) => this.store.state.components.find((c) => c.id === id)).filter(Boolean);
    const sameDef = comps.length > 0 && comps.every((c) => c.defId === comps[0].defId);
    const typeNote = !comps.length ? '' : sameDef
      ? `одинаковый тип: ${this._esc((REGISTRY[comps[0].defId] || {}).name || comps[0].defId)}`
      : 'разные типы — показаны только общие свойства';
    this.root.innerHTML = `
      <div class="insp-header"><div class="insp-id">${ids.length} компонентов выбрано${typeNote ? ` · ${typeNote}` : ''}</div></div>
      <div class="insp-section-title">Выравнивание</div>
      <div class="align-row">
        <button data-align="left">⯇ Слева</button>
        <button data-align="center-h">По центру X</button>
        <button data-align="right">Справа ⯈</button>
      </div>
      <div class="align-row">
        <button data-align="top">⯅ Сверху</button>
        <button data-align="center-v">По центру Y</button>
        <button data-align="bottom">Снизу ⯆</button>
      </div>
      <div class="insp-section-title">Распределение</div>
      <div class="align-row">
        <button data-align="dist-h">По горизонтали</button>
        <button data-align="dist-v">По вертикали</button>
      </div>
      <div class="insp-section-title">Слой</div>
      <div class="align-row">
        <button data-layer="top">На передний план</button>
        <button data-layer="bottom">На задний план</button>
      </div>
      ${this._multiPropsHtml(comps)}
    `;
    this.root.querySelectorAll('[data-align]').forEach((btn) => {
      btn.onclick = () => this._align(ids, btn.dataset.align);
    });
    this.root.querySelectorAll('[data-layer]').forEach((btn) => {
      btn.onclick = () => { for (const id of ids) this.store.moveLayer(id, btn.dataset.layer); };
    });
    this._bindMulti(comps);
  }

  // ---- Групповое редактирование свойств ----------------------------------
  // Свойство считается «общим», если оно есть у всех выбранных компонентов с
  // тем же ключом и типом поля. Для компонентов одного типа это все свойства.

  _defaultFor(comp, key) {
    const def = REGISTRY[comp.defId];
    const p = def && def.properties.find((q) => q.key === key);
    return p ? p.default : undefined;
  }

  // Значение свойства у всех выбранных: { mixed, value }.
  _multiValue(comps, key) {
    const vals = comps.map((c) => {
      const v = c.props ? c.props[key] : undefined;
      return v !== undefined ? v : this._defaultFor(c, key);
    });
    const first = JSON.stringify(vals[0]);
    const mixed = vals.some((v) => JSON.stringify(v) !== first);
    return { mixed, value: vals[0] };
  }

  _multiSharedProps(comps) {
    const defs = comps.map((c) => REGISTRY[c.defId]);
    if (!defs.length || defs.some((d) => !d)) return [];
    const sameDef = comps.every((c) => c.defId === comps[0].defId);
    const kinds = ['number', 'color', 'text', 'select', 'checkbox', 'font', 'asset', 'weathericon'];
    const list = defs[0].properties.filter((p) => {
      if (['x', 'y', 'w', 'h'].includes(p.key) || String(p.key).startsWith('tap_')) return false;
      if (!kinds.includes(p.kind)) return false;
      if (sameDef) return true;
      return defs.every((d) => d.properties.some((q) => q.key === p.key && q.kind === p.kind &&
        (p.kind !== 'select' || JSON.stringify(q.options) === JSON.stringify(p.options))));
    });
    // Поля источника данных зависят от выбранного значения data_source —
    // добавляем их, только если у всех оно одинаковое.
    if (defs.every((d) => d.dataSourceSelectable)) {
      const dsVals = new Set(comps.map((c) => c.props.data_source || 'NONE'));
      if (dsVals.size === 1) {
        const dsDef = DATA_SOURCES[[...dsVals][0]];
        if (dsDef && dsDef.fields) {
          for (const f of dsDef.fields) if (!list.some((q) => q.key === f.key)) list.push(f);
        }
      }
    }
    return list;
  }

  _multiPropsHtml(comps) {
    if (comps.length < 2) return '';
    const rows = [];
    const num = (field, label, min) => `<div class="field"><label>${label}</label><input type="number" data-mfield="${field}" ${min != null ? `min="${min}"` : ''}></div>`;
    const chk = (field, label) => `<label class="field checkbox"><input type="checkbox" data-mfield="${field}"> ${label}</label>`;
    rows.push(`<div class="insp-section-title">Общие свойства (применяются ко всем)</div>`);
    rows.push(`<div class="insp-grid">${num('w', 'W', 1)}${num('h', 'H', 1)}</div>`);

    const groups = {};
    for (const p of this._multiSharedProps(comps)) {
      if (typeof p.showIf === 'function' && !comps.every((c) => { try { return p.showIf(c.props || {}); } catch (e) { return true; } })) continue;
      const g = p.group || this._groupFor(p.key);
      (groups[g] = groups[g] || []).push(p);
    }
    for (const [g, props] of Object.entries(groups)) {
      rows.push(`<div class="insp-section-title">${g}</div><div class="insp-grid">`);
      for (const p of props) {
        const mv = this._multiValue(comps, p.key);
        // defId '__multi__' — чтобы не включалась одиночная разметка градиента
        const ref = { defId: '__multi__', props: { [p.key]: mv.mixed ? undefined : mv.value } };
        rows.push(this._fieldFor(ref, p));
      }
      rows.push(`</div>`);
    }
    rows.push(`<div class="insp-section-title">Поведение</div><div class="insp-grid">${chk('visible', 'Видимый')}${chk('locked', 'Заблокирован')}</div>`);
    return rows.join('');
  }

  _bindMulti(comps) {
    const store = this.store;
    const ids = comps.map((c) => c.id);
    const root = this.root;

    // В групповом режиме нельзя редактировать ресурс/шрифт «одного» компонента.
    root.querySelectorAll('[data-edit-asset], .font-upload').forEach((n) => n.remove());

    const markMixed = (el) => {
      if (el.type === 'checkbox') el.indeterminate = true;
      else if (el.tagName === 'SELECT') {
        const o = document.createElement('option');
        o.value = ''; o.textContent = '— разные —'; o.disabled = true; o.hidden = true;
        el.insertBefore(o, el.firstChild);
        el.selectedIndex = 0;
      } else if (el.type === 'color') { el.classList.add('mixed'); el.title = 'У выбранных разные значения'; }
      else { el.value = ''; el.placeholder = '— разные —'; }
    };

    // Начальные значения полей позиции/поведения.
    root.querySelectorAll('[data-mfield]').forEach((el) => {
      const f = el.dataset.mfield;
      const vals = comps.map((c) => (f === 'visible' ? c.visible !== false : f === 'locked' ? !!c.locked : Math.round(c[f])));
      const mixed = vals.some((v) => v !== vals[0]);
      if (el.type === 'checkbox') { el.checked = !!vals[0]; if (mixed) markMixed(el); }
      else if (mixed) markMixed(el); else el.value = vals[0];
    });
    // Помечаем свойства, у которых значения расходятся.
    root.querySelectorAll('[data-prop]').forEach((el) => {
      if (this._multiValue(comps, el.dataset.prop).mixed) {
        if (el.classList.contains('icon-picker')) el.querySelectorAll('.icon-opt').forEach((b) => b.classList.remove('active'));
        else markMixed(el);
      }
    });

    const readValue = (el) => (el.type === 'checkbox' ? el.checked : el.type === 'number' ? Number(el.value) : el.value);
    const isEmpty = (el) => el.type === 'number' && el.value === '';
    const applyAll = (kind, key, value) => {
      for (const id of ids) {
        if (kind === 'field') store.updateComponent(id, { [key]: value }, { silent: true });
        else store.updateComponentProp(id, key, value, { silent: true });
      }
    };
    const bindEl = (el, kind, key) => {
      el.addEventListener('change', () => {
        if (isEmpty(el)) return;
        applyAll(kind, key, readValue(el));
        store.commit();
      });
      if (el.type === 'text' || el.type === 'number') {
        el.addEventListener('input', () => {
          if (isEmpty(el)) return;
          this._selfEdit = true;
          try { applyAll(kind, key, readValue(el)); }
          finally { this._selfEdit = false; }
        });
      }
    };
    root.querySelectorAll('[data-mfield]').forEach((el) => bindEl(el, 'field', el.dataset.mfield));
    root.querySelectorAll('[data-prop]').forEach((el) => {
      if (el.classList.contains('icon-picker')) {
        el.querySelectorAll('.icon-opt').forEach((btn) => {
          btn.onclick = () => { applyAll('prop', el.dataset.prop, btn.dataset.icon); store.commit(); };
        });
        return;
      }
      bindEl(el, 'prop', el.dataset.prop);
    });
  }

  _align(ids, mode) {
    const comps = ids.map((id) => this.store.state.components.find((c) => c.id === id)).filter(Boolean);
    if (!comps.length) return;
    if (mode === 'left') { const v = Math.min(...comps.map((c) => c.x)); comps.forEach((c) => c.x = v); }
    if (mode === 'right') { const v = Math.max(...comps.map((c) => c.x + c.w)); comps.forEach((c) => c.x = v - c.w); }
    if (mode === 'top') { const v = Math.min(...comps.map((c) => c.y)); comps.forEach((c) => c.y = v); }
    if (mode === 'bottom') { const v = Math.max(...comps.map((c) => c.y + c.h)); comps.forEach((c) => c.y = v - c.h); }
    if (mode === 'center-h') { const cx = this.store.state.device.w / 2; comps.forEach((c) => c.x = cx - c.w / 2); }
    if (mode === 'center-v') { const cy = this.store.state.device.h / 2; comps.forEach((c) => c.y = cy - c.h / 2); }
    if (mode === 'dist-h' && comps.length > 2) {
      comps.sort((a, b) => a.x - b.x);
      const first = comps[0], last = comps[comps.length - 1];
      const span = (last.x) - (first.x);
      const step = span / (comps.length - 1);
      comps.forEach((c, i) => { if (i > 0 && i < comps.length - 1) c.x = first.x + step * i; });
    }
    if (mode === 'dist-v' && comps.length > 2) {
      comps.sort((a, b) => a.y - b.y);
      const first = comps[0], last = comps[comps.length - 1];
      const span = (last.y) - (first.y);
      const step = span / (comps.length - 1);
      comps.forEach((c, i) => { if (i > 0 && i < comps.length - 1) c.y = first.y + step * i; });
    }
    this.store.commit();
  }

  _groupFor(key) {
    if (key.startsWith('tap_')) return 'Открытие по тапу';
    if (key === 'data_source' || /^(time_|ampm_|date_|weekday_|battery_|step_|heart_|calorie_|distance_|weather_|hour_|minute_|second_|day_|month_|year_)/.test(key)) return 'Источник данных';
    if (['color', 'text_size', 'fit_bounds', 'fit_min_size', 'align_h', 'align_v', 'text_style', 'font'].includes(key)) return 'Типографика';
    if (['text', 'format', 'prefix', 'suffix', 'unit'].includes(key)) return 'Содержимое';
    if (['src'].includes(key)) return 'Изображение';
    if (['center_x', 'center_y', 'radius', 'start_angle', 'end_angle', 'line_width'].includes(key)) return 'Форма';
    if (['alpha'].includes(key)) return 'Внешний вид';
    if (key.startsWith('pos_') || key.startsWith('center')) return 'Точка опоры';
    if (key === 'path' || key === 'cover_path') return 'Изображение стрелки';
    if (['motion', 'smooth_fps', 'smooth_step_deg'].includes(key)) return 'Ход стрелки';
    return 'Свойства';
  }

  _numberField(key, label, value) {
    const tip = hintForProperty({ key });
    return `<div class="field"${tip ? ` data-tip="${this._escAttr(tip)}"` : ''}><label>${label}</label><input type="number" data-field="${key}" value="${Math.round(value)}"></div>`;
  }

  _fieldFor(comp, p) {
    const val = comp.props[p.key];
    // Подсказка к свойству (см. PROPERTY_HINTS в registry.js). Вешаем её на
    // контейнер поля, чтобы всплывала и при наведении на подпись, и при
    // переходе в поле с клавиатуры.
    const tip = hintForProperty(p);
    const T = tip ? ` data-tip="${this._escAttr(tip)}"` : '';
    switch (p.kind) {
      case 'number':
        return `<div class="field"${T}><label>${p.label}${p.confidence === 'unverified' ? ' ⚠' : ''}</label><input type="number" data-prop="${p.key}" value="${val ?? p.default ?? 0}" ${p.min !== undefined ? `min="${p.min}"` : ''} ${p.max !== undefined ? `max="${p.max}"` : ''}></div>`;
      case 'color':
        if (p.key === 'color' && (comp.defId === 'fill_rect' || comp.defId === 'circle')) {
          const g = comp.props.gradient || {};
          return `<div class="field"${T}><label>${p.label}</label><input type="color" data-prop="${p.key}" value="${val || p.default || '#ffffff'}"></div>
            <div class="field checkbox"><input type="checkbox" data-gradient-enable ${g.enabled ? 'checked' : ''}> Градиент</div>
            <div class="field"><label>Цвет 2</label><input type="color" data-gradient-to value="${g.to || '#000000'}"></div>
            <div class="field"><label>Тип</label><select data-gradient-type><option value="linear" ${g.type !== 'radial' ? 'selected':''}>Линейный</option><option value="radial" ${g.type === 'radial' ? 'selected':''}>Радиальный</option></select></div>`;
        }
        return `<div class="field"${T}><label>${p.label}</label><input type="color" data-prop="${p.key}" value="${val || p.default || '#ffffff'}"></div>`;
      case 'text':
        return `<div class="field wide"${T}><label>${p.label}</label><input type="text" data-prop="${p.key}" value="${this._esc(val ?? p.default ?? '')}"></div>`;
      case 'select': {
        // options: массив строк ИЛИ массив { value, label } — второй вариант
        // нужен, когда машинное значение (TICK/SMOOTH) не годится как подпись.
        const opts = p.options.map((o) => (typeof o === 'object' ? o : { value: o, label: o }));
        const cur = val ?? p.default;
        const wide = opts.some((o) => String(o.label).length > 18) ? ' wide' : '';
        return `<div class="field${wide}"${T}><label>${p.label}${p.confidence === 'unverified' ? ' ⚠' : ''}</label><select data-prop="${p.key}">${opts.map((o) => `<option value="${o.value}" ${cur === o.value ? 'selected' : ''}>${this._esc(o.label)}</option>`).join('')}</select></div>`;
      }
      case 'checkbox': {
        const checked = val !== undefined ? !!val : !!p.default;
        return `<label class="field checkbox"${T}><input type="checkbox" data-prop="${p.key}" ${checked ? 'checked' : ''}> ${p.label}${p.confidence === 'unverified' ? ' ⚠' : ''}</label>`;
      }
      case 'font':
        return this._fontField(comp, p, val, T);
      case 'asset':
        return this._assetField(p, val, T);
      case 'weathericon': {
        const curIcon = normalizeWeatherIconId(val) || p.default;
        const proj = this.store.state;
        const own = (w) => WeatherIcons.assetFor(proj, w.id);
        const mark = (w) => (own(w) ? `<img class="icon-opt-img" src="${own(w).dataUrl}" alt="">` : w.glyph);
        return `<div class="field wide"${T}><label>${p.label} (29 состояний)</label><div class="icon-picker" data-prop="${p.key}">${WEATHER_ICON_SET.map((w) => `<button type="button" class="icon-opt ${curIcon === w.id ? 'active' : ''}" data-icon="${w.id}" title="${this._escAttr(w.label)}">${mark(w)} ${this._esc(w.label)}</button>`).join('')}</div>
          <button type="button" class="wi-open-btn" data-open-weather-set title="Загрузить свои иконки и посмотреть, какая куда назначена">☀ Свои иконки погоды… (${WeatherIcons.customCount(proj)}/${WEATHER_ICON_SET.length})</button></div>`;
      }
      default:
        return '';
    }
  }

  _fontField(comp, p, val, tipAttr = '') {
    const fonts = this.store.state.fonts || [];
    const options = fonts.map((f) => `<option value="${this._escAttr(f.id)}" ${val === f.id ? 'selected' : ''}>${this._esc(f.name)}</option>`).join('');
    return `<div class="field wide font-field"${tipAttr}>
      <label>${p.label}</label>
      <select data-prop="${p.key}">
        <option value="" ${!val ? 'selected' : ''}>Системный шрифт</option>
        ${options}
      </select>
      <label class="btn-file font-upload">＋ Добавить файл шрифта
        <input type="file" accept=".ttf,.otf,.woff,.woff2,font/ttf,font/otf,font/woff,font/woff2" hidden data-font-upload>
      </label>
    </div>`;
  }

  _assetField(p, val, tipAttr = '') {
    const assets = this.store.state.assets;
    return `<div class="field wide asset-prop-field"${tipAttr}><label>${p.label}</label>
      <div class="asset-prop-row"><select data-prop="${p.key}">
        <option value="">— нет —</option>
        ${assets.filter((a) => !a.weatherIcon).map((a) => `<option value="${a.id}" ${val === a.id ? 'selected' : ''}>${this._esc(a.name)}</option>`).join('')}
      </select><button type="button" data-edit-asset="${this._escAttr(val || '')}" title="Обрезать / удалить фон / эффекты">✎</button></div>
    </div>`;
  }

  _bind(comp, def) {
    this.root.querySelectorAll('[data-field]').forEach((el) => {
      const field = el.dataset.field;
      const readValue = () => (el.type === 'number' ? Number(el.value) : el.type === 'checkbox' ? el.checked : el.value);
      el.addEventListener('change', () => {
        if (this.store.state.mode === 'aod' && (field === 'rotation' || field === 'scale')) this.store.updateComponentProp(comp.id, field, readValue());
        else this.store.updateComponent(comp.id, { [field]: readValue() });
      });
      if (el.type === 'number' || el.type === 'text') {
        el.addEventListener('input', () => {
          this._selfEdit = true;
          try {
            if (this.store.state.mode === 'aod' && (field === 'rotation' || field === 'scale')) this.store.updateComponentProp(comp.id, field, readValue(), { silent: true });
            else this.store.updateComponent(comp.id, { [field]: readValue() }, { silent: true });
          }
          finally { this._selfEdit = false; }
        });
      }
    });
    this.root.querySelectorAll('[data-prop]').forEach((el) => {
      if (el.classList.contains('icon-picker')) return;
      const key = el.dataset.prop;
      const readValue = () => {
        if (el.type === 'checkbox') return el.checked;
        if (el.type === 'number') return Number(el.value);
        return el.value;
      };
      if (def.id === 'weekday_strip' && key === 'layout') {
        el.addEventListener('change', () => {
          const current = this.store.state.components.find((c) => c.id === comp.id);
          if (!current) return;
          const nextLayout = readValue();
          const wasVertical = ['ARC_LEFT', 'ARC_RIGHT'].includes(current.props.layout);
          const isVertical = ['ARC_LEFT', 'ARC_RIGHT'].includes(nextLayout);
          current.props.layout = nextLayout;
          if (wasVertical !== isVertical) {
            const cx = current.x + current.w / 2, cy = current.y + current.h / 2;
            [current.w, current.h] = [current.h, current.w];
            current.x = Math.max(0, Math.round(cx - current.w / 2));
            current.y = Math.max(0, Math.round(cy - current.h / 2));
          }
          this.store.commit();
        });
        return;
      }
      const commit = () => this.store.updateComponentProp(comp.id, key, readValue());
      el.addEventListener('change', commit);
      if (el.type === 'text' || el.type === 'number') el.addEventListener('input', () => {
        // Холст и слои обновляются вживую, а сам Inspector пропускает эту
        // перерисовку (_selfEdit), иначе поле теряет фокус на каждом символе.
        this._selfEdit = true;
        try { this.store.updateComponentProp(comp.id, key, readValue(), { silent: true }); }
        finally { this._selfEdit = false; }
      });
    });
    this.root.querySelectorAll('[data-edit-asset]').forEach((btn) => {
      btn.onclick = () => {
        const id = btn.dataset.editAsset;
        const a = this.store.state.assets.find(x => x.id === id);
        if (!a || typeof ImageAssetEditor === 'undefined') return;
        ImageAssetEditor.openForAsset(this.store, a, { title: 'Редактор ресурса' });
      };
    });
    this.root.querySelectorAll('[data-open-weather-set]').forEach((btn) => { btn.onclick = () => WeatherIcons.openDialog(this.store); });
    this.root.querySelectorAll('.icon-picker').forEach((wrap) => {
      const key = wrap.dataset.prop;
      wrap.querySelectorAll('.icon-opt').forEach((btn) => {
        btn.onclick = () => this.store.updateComponentProp(comp.id, key, btn.dataset.icon);
      });
    });
        this.root.querySelectorAll('[data-open-premium-typography]').forEach(btn => { btn.onclick = () => this._openPremiumTypography(comp); });
this.root.querySelectorAll('[data-typo-preset]').forEach((btn) => {
      btn.onclick = () => {
        const kind=btn.dataset.typoPreset;
        const presets={
          classic:{fill_type:'metallicGold',color:'#f6c64a',gradient_to:'#7a4308',depth:2,bevel_size:1,scale_x:1,scale_y:1,top_highlight_opacity:60,drop_shadow_enabled:false,contact_shadow_enabled:true,contact_shadow_opacity:42,cast_shadow_enabled:true,cast_shadow_angle:135,cast_shadow_elevation:45,cast_shadow_distance:5,cast_shadow_blur:3,cast_shadow_opacity:38,inner_shadow_enabled:true,inner_shadow_opacity:24},
          luxury:{fill_type:'metallicGold',color:'#fff1a8',gradient_to:'#6f3907',depth:3,bevel_size:1.4,scale_x:1,scale_y:1,top_highlight_opacity:72,drop_shadow_enabled:false,contact_shadow_enabled:true,contact_shadow_opacity:48,cast_shadow_enabled:true,cast_shadow_angle:135,cast_shadow_elevation:45,cast_shadow_distance:7,cast_shadow_blur:4,cast_shadow_opacity:46,inner_shadow_enabled:true,inner_shadow_opacity:30},
          soviet:{fill_type:'metallicGold',color:'#f8d65a',gradient_to:'#71370a',depth:2.5,bevel_size:1,scale_x:1,scale_y:1,top_highlight_opacity:64,drop_shadow_enabled:false,contact_shadow_enabled:true,contact_shadow_opacity:44,cast_shadow_enabled:true,cast_shadow_angle:145,cast_shadow_elevation:42,cast_shadow_distance:6,cast_shadow_blur:3,cast_shadow_opacity:40,inner_shadow_enabled:true,inner_shadow_opacity:28},
          steel:{fill_type:'gradient',color:'#f5f7f8',gradient_to:'#4d555b',depth:2,bevel_size:1,scale_x:1,scale_y:1,top_highlight_opacity:70,drop_shadow_enabled:false,contact_shadow_enabled:true,contact_shadow_opacity:40,cast_shadow_enabled:true,cast_shadow_angle:135,cast_shadow_elevation:45,cast_shadow_distance:5,cast_shadow_blur:3,cast_shadow_opacity:34,inner_shadow_enabled:true,inner_shadow_opacity:25},
          reset:{fill_type:'solid',color:'#ffffff',gradient_to:'#555555',depth:0,bevel_size:0,top_highlight_opacity:0,drop_shadow_enabled:false,contact_shadow_enabled:false,cast_shadow_enabled:false,inner_shadow_enabled:false}
        };
        const cfg=presets[kind]; if(!cfg) return;
        Object.entries(cfg).forEach(([k,v])=>this.store.updateComponentProp(comp.id,k,v,{silent:true}));
        this.store.commit();
      };
    });

    this.root.querySelectorAll('[data-font-upload]').forEach((input) => {
      input.addEventListener('change', () => {
        const file = input.files && input.files[0];
        if (!file) return;
        const ext = (file.name.match(/\.[^.]+$/) || [''])[0].toLowerCase();
        if (!['.ttf','.otf','.woff','.woff2'].includes(ext)) {
          alert('Поддерживаются TTF, OTF, WOFF и WOFF2.');
          input.value = '';
          return;
        }
        const reader = new FileReader();
        reader.onload = async () => {
          const id = makeFontId();
          const family = `ProjectFont_${id.replace(/[^a-zA-Z0-9_]/g, '_')}`;
          const font = { id, name: file.name.replace(/\.[^.]+$/, ''), filename: file.name, ext, dataUrl: reader.result, size: file.size, cssFamily: family };
          this.store.addFont(font);
          if (typeof registerProjectFont === 'function') await registerProjectFont(font);
          this.store.updateComponentProp(comp.id, 'font', id);
        };
        reader.readAsDataURL(file);
      });
    });
  }

  _esc(s) { return String(s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;'); }

  // Для data-tip: подсказки содержат кавычки и угловые скобки (<= 20 px и т.п.).
  _escAttr(s) { return this._esc(s == null ? '' : s).replace(/\n/g, ' '); }
}
