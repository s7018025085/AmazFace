// src/app.js

const store = new ProjectStore();

const paletteEl = document.getElementById('palette');
const canvasRoot = document.getElementById('canvas-root');
const layersRoot = document.getElementById('layers-root');
const inspectorRoot = document.getElementById('inspector-root');
const assetsRoot = document.getElementById('assets-root');
const apiSelect = document.getElementById('api-level-select');
const projectNameEl = document.getElementById('project-name');

const canvasEditor = new CanvasEditor(canvasRoot, store);
// Раз в секунду обновляем ТОЛЬКО текст «живых» виджетов (время/дата/AM-PM/день
// недели), а не пересобираем DOM всей сцены: полный render() каждую секунду
// пересоздавал узлы всех компонентов, ронял фокус и грузил браузер на больших
// макетах. См. CanvasEditor.tickLiveText().
setInterval(() => canvasEditor.tickLiveText(), 1000);

// «Живое время»: на холсте время/дата идут по реальным часам, поэтому эффекты текста
// (тень, объём, градиент, анимация) видно на тех же цифрах, что будут на часах.
// Переключатель запоминается в браузере; на экспорт и PNG-превью не влияет.
const LIVE_TIME_KEY = 'amazface-live-time';
const liveTimeBtn = document.getElementById('act-live-time');
function readLiveTimePref() { try { return localStorage.getItem(LIVE_TIME_KEY) !== '0'; } catch (e) { return true; } }
function applyLiveTime(on) {
  canvasEditor.setLiveTime(on);
  if (liveTimeBtn) { liveTimeBtn.classList.toggle('active', on); liveTimeBtn.setAttribute('aria-pressed', String(on)); }
  if (window.textAnimController) window.textAnimController.sync(store.state, store.selection);
}
liveTimeBtn?.addEventListener('click', () => {
  const on = !canvasEditor.liveTime;
  try { localStorage.setItem(LIVE_TIME_KEY, on ? '1' : '0'); } catch (e) { /* не критично */ }
  applyLiveTime(on);
});
setInterval(() => {
  if (!canvasEditor.liveTime) return;
  if (window.textAnimController) window.textAnimController.sync(store.state, store.selection);
  canvasEditor.tickLiveRaster();
}, 250);
const layers = new LayersPanel(layersRoot, store);

// Сворачиваемые секции боковых панелей (кроме «Ресурсов» — ими управляет
// AssetManager). Панель «Слои» по умолчанию свёрнута: список нужен не всегда,
// а в развёрнутом виде он отодвигает «Свойства» вниз. Состояние запоминается
// в localStorage, поэтому развёрнутая панель такой и останется.
function initCollapsibleSections(defaults) {
  document.querySelectorAll('.panel-title.collapsible[data-section]').forEach((title) => {
    const section = title.dataset.section;
    if (section === 'resources') return;
    const content = document.querySelector(`.collapsible-content[data-section="${section}"]`);
    const btn = title.querySelector('.toggle-btn');
    if (!content || !btn) return;

    const apply = (collapsed) => {
      content.classList.toggle('collapsed', collapsed);
      btn.textContent = collapsed ? '▶' : '▼';
    };
    const key = `${section}-collapsed`;
    const saved = localStorage.getItem(key);
    apply(saved === null ? !!(defaults && defaults[section]) : saved === 'true');

    title.addEventListener('click', () => {
      const collapsed = !content.classList.contains('collapsed');
      apply(collapsed);
      localStorage.setItem(key, String(collapsed));
    });
  });
}
initCollapsibleSections({ layers: true });
const inspector = new Inspector(inspectorRoot, store);
const assetManager = new AssetManager(assetsRoot, store);
const projectSettings = new ProjectSettings(document.getElementById('project-settings-root'), store);

// Экранирует текст для безопасной вставки в HTML-атрибут (data-tip, title).
function escAttr(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;')
    .replace(/"/g, '&quot;')
    .replace(/</g, '&lt;');
}

// Собирает полный текст подсказки для компонента палитры: описание +
// техническая справка (widget id, мин. API, статус проверки, источник данных).
function paletteTooltipFor(def, compat) {
  const parts = [];
  parts.push(def.description || def.name);
  parts.push(def.widgetId === 'WEEKDAY_STRIP'
    ? `Составной компонент · Мин. API: ${def.apiLevel}+ · динамическая рамка не подтверждена документацией.`
    : `Виджет: hmUI.widget.${def.widgetId} · Мин. API: ${def.apiLevel}+ · ${def.confidence === 'unverified' ? '⚠ не полностью подтверждено документацией' : '✓ подтверждено docs.zepp.com'}.`);
  if (def.dataBindable) parts.push(`Источник данных: ${def.dataSource} (фиксированный).`);
  if (def.dataSourceSelectable) parts.push('Источник данных выбирается в Inspector после добавления на холст (по умолчанию — статический текст).');
  if (!compat) parts.push(`⚠ Недоступно при текущем уровне API проекта — требуется API ${def.apiLevel}+.`);
  return parts.join(' ');
}

const COMPONENT_ICONS = {
  text:'T', digital_display:'▦', time_hm:'◷', time_hms:'◴', image:'▧', rect:'□', circle:'○', line:'╱', arc:'⌒', polygon:'◇', triangle:'▲',
  weather_icon:'☁', weather_temp:'°', weather_temp_low:'↓°', weather_temp_high:'↑°', weather:'☀', analog_hand:'↗', analog_hour:'↗', analog_minute:'↗', analog_second:'↗',
  battery:'▰', heart_rate:'♥', step:'♟', calorie:'🔥', distance:'↔', altitude:'⛰', air_pressure:'⌁',
  step_target:'🎯', cal_target:'🎯', pai_daily:'P', pai_weekly:'P', stand:'▥', stand_target:'🎯',
  humidity:'💧', uvi:'☀', aqi:'AQ', fat_burning:'🔥', fat_burning_target:'🎯', sun_current:'◐', sun_rise:'↑', sun_set:'↓',
  wind:'≋', stress:'◉', spo2:'O₂', body_temp:'🌡', floor:'▥', alarm_clock:'⏰', count_down:'⌛', stop_watch:'⏱',
  sleep:'☾', training_load:'⚡', vo2max:'V₂', recovery_time:'↻', month_run_times:'🏃', month_run_distance:'↔', readiness:'✓',
  date:'D', weekday:'W', weekday_strip:'▤', hour:'H', minute:'M', second:'S', day:'D', month:'M', year:'Y', ampm:'A'
};

function componentIcon(def) {
  if (COMPONENT_ICONS[def.id]) return COMPONENT_ICONS[def.id];
  const n = String(def.name || '').toLowerCase();
  if (n.includes('погода')) return '☁';
  if (n.includes('текст')) return 'T';
  if (n.includes('время')) return '◷';
  if (n.includes('стрел')) return '↗';
  if (n.includes('данн')) return '◉';
  if (n.includes('фигур')) return '□';
  return '•';
}

function renderPalette() {
  const byCat = listByCategory();
  paletteEl.innerHTML = CATEGORIES.map((cat) => `
    <div class="palette-cat">
      <div class="palette-cat-title">${cat}</div>
      <div class="palette-items">
        ${byCat[cat].map((def) => {
          const compat = isApiCompatible(def.apiLevel, store.state.apiLevel);
          return `<button class="palette-item ${compat ? '' : 'disabled'}" draggable="true"
              data-def="${def.id}" data-tip="${escAttr(paletteTooltipFor(def, compat))}">
            <span class="palette-item-icon" aria-hidden="true">${componentIcon(def)}</span>
            <span class="palette-item-content">
              <span class="palette-item-name">${def.name}</span>
              <span class="palette-item-api">API ${def.apiLevel}+${def.confidence === 'unverified' ? ' · ⚠' : ''}</span>
            </span>
          </button>`;
        }).join('')}
      </div>
    </div>
  `).join('');

  paletteEl.querySelectorAll('.palette-item').forEach((btn) => {
    if (btn.classList.contains('disabled')) { btn.addEventListener('click', (e) => e.preventDefault()); return; }
    btn.addEventListener('dblclick', () => {
      const def = REGISTRY[btn.dataset.def];
      if (def?.id === 'weekday_strip') {
        store.addComponent(btn.dataset.def, Math.max(0, Math.round((store.state.device.w - def.defaultSize.w) / 2)), Math.max(0, Math.round((store.state.device.h - def.defaultSize.h) / 2)));
      } else store.addComponent(btn.dataset.def, 140, 140);
    });
    btn.addEventListener('dragstart', (e) => {
      e.dataTransfer.setData('text/plain', btn.dataset.def);
    });
  });

  // Палитра перерисовывается через innerHTML при каждом renderAll(), поэтому
  // новые кнопки нужно заново привязать к менеджеру подсказок (tooltips.js).
  if (window.tooltipManager) window.tooltipManager.refresh();
}

canvasRoot.addEventListener('dragover', (e) => e.preventDefault());
canvasRoot.addEventListener('drop', (e) => {
  e.preventDefault();
  const defId = e.dataTransfer.getData('text/plain');
  if (!defId || !REGISTRY[defId]) return;
  const frameRect = canvasEditor.frame.getBoundingClientRect();
  const x = (e.clientX - frameRect.left) / canvasEditor.zoom;
  const y = (e.clientY - frameRect.top) / canvasEditor.zoom;
  store.addComponent(defId, Math.max(0, Math.round(x)), Math.max(0, Math.round(y)));
});

// ---- Validation strip ----
// Единственная точка валидации проекта. Раньше renderValidation() вызывал
// validateProject(), но такой функции в Designer не было. Из-за ReferenceError
// выполнение app.js останавливалось прямо во время первого renderAll(): после
// этого не навешивались обработчики «Новый», «Открыть» и «Демо».
function validateProject(project) {
  const errors = [];
  const warnings = [];
  const p = project || {};

  if (!p.meta || !p.meta.name) warnings.push('У проекта нет названия.');
  if (!p.device || !Number.isFinite(Number(p.device.w)) || !Number.isFinite(Number(p.device.h))) {
    errors.push('Не задан корректный размер устройства.');
  }
  if (!Array.isArray(p.components)) errors.push('Поле components должно быть массивом.');
  if (!Array.isArray(p.assets)) errors.push('Поле assets должно быть массивом.');
  if (!Array.isArray(p.fonts)) errors.push('Поле fonts должно быть массивом.');

  const assets = new Set((p.assets || []).map(a => a && a.id).filter(Boolean));
  const fonts = new Set((p.fonts || []).map(f => f && f.id).filter(Boolean));

  for (const c of (p.components || [])) {
    if (!c || !c.defId) { errors.push('Обнаружен компонент без defId.'); continue; }
    const def = REGISTRY[c.defId];
    if (!def) { errors.push(`Неизвестный компонент: ${c.defId}.`); continue; }
    if (!Number.isFinite(Number(c.x)) || !Number.isFinite(Number(c.y)) ||
        !Number.isFinite(Number(c.w)) || !Number.isFinite(Number(c.h))) {
      errors.push(`Некорректные координаты или размер компонента ${c.id || c.defId}.`);
    }
    const props = c.props || {};
    if (props.font && !fonts.has(props.font)) {
      errors.push(`Компонент ${c.id || c.defId} ссылается на отсутствующий шрифт ${props.font}.`);
    }
    if (def.widgetId === 'IMG' && props.src && !assets.has(props.src)) {
      warnings.push(`Изображение компонента ${c.id || c.defId} не найдено среди ресурсов.`);
    }
    if (def.widgetId === 'TIME_POINTER' && props.path && !assets.has(props.path)) {
      warnings.push(`Ресурс стрелки компонента ${c.id || c.defId} не найден среди ресурсов.`);
    }

    // Tap zones are exported as independent transparent BUTTON widgets.
    // Validate their geometry/action here so a broken zone cannot silently
    // disappear from the generated watchface/index.js.
    if (c.tapZones != null && !Array.isArray(c.tapZones)) {
      errors.push(`Тап-зоны компонента ${c.id || c.defId} должны быть массивом.`);
    }
    for (const z of (Array.isArray(c.tapZones) ? c.tapZones : [])) {
      if (!z || !z.id) {
        errors.push(`У компонента ${c.id || c.defId} есть тап-зона без id.`);
        continue;
      }
      for (const key of ['x', 'y', 'w', 'h']) {
        if (!Number.isFinite(Number(z[key]))) {
          errors.push(`Тап-зона ${c.id || c.defId}/${z.id}: некорректное поле ${key}.`);
        }
      }
      if (Number(z.w) <= 0 || Number(z.h) <= 0) {
        errors.push(`Тап-зона ${c.id || c.defId}/${z.id}: ширина и высота должны быть больше 0.`);
      }
      const action = z.props?.tap_action || 'NONE';
      if (!['NONE', 'METRIC', 'APP', 'FLASHLIGHT'].includes(action)) {
        errors.push(`Тап-зона ${c.id || c.defId}/${z.id}: неизвестное действие ${action}.`);
      }
      if (action === 'APP' && !Number(z.props?.tap_app_id)) {
        warnings.push(`Тап-зона ${c.id || c.defId}/${z.id}: не задан App ID — зона попадёт в экспорт, но действие APP работать не будет.`);
      }
    }
  }

  // Normal/AOD are persisted separately. Validate both scenes even when the
  // editor is currently displaying only one of them, otherwise a broken AOD
  // component can pass validation and fail later during Zeus build.
  for (const [sceneName, scene] of Object.entries(p.scenes || {})) {
    if (!scene || !Array.isArray(scene.components)) continue;
    for (const c of scene.components) {
      if (!c || !c.defId) { errors.push(`Сцена ${sceneName}: компонент без defId.`); continue; }
      const def = REGISTRY[c.defId];
      if (!def) { errors.push(`Сцена ${sceneName}: неизвестный компонент ${c.defId}.`); continue; }
      const props = c.props || {};
      if (!Number.isFinite(Number(c.x)) || !Number.isFinite(Number(c.y)) ||
          !Number.isFinite(Number(c.w)) || !Number.isFinite(Number(c.h))) {
        errors.push(`Сцена ${sceneName}: некорректные координаты или размер ${c.id || c.defId}.`);
      }
      if (props.font && !fonts.has(props.font)) {
        errors.push(`Сцена ${sceneName}: компонент ${c.id || c.defId} ссылается на отсутствующий шрифт ${props.font}.`);
      }
      if (def.widgetId === 'IMG' && props.src && !assets.has(props.src) && !String(props.src).startsWith('weather')) {
        warnings.push(`Сцена ${sceneName}: изображение ${c.id || c.defId} не найдено среди ресурсов.`);
      }
      if (def.widgetId === 'TIME_POINTER' && props.path && !assets.has(props.path)) {
        warnings.push(`Сцена ${sceneName}: ресурс стрелки ${c.id || c.defId} не найден.`);
      }
    }
    if (scene.background?.imageAssetId && !assets.has(scene.background.imageAssetId)) {
      warnings.push(`Сцена ${sceneName}: фоновое изображение ${scene.background.imageAssetId} не найдено.`);
    }
  }

  if (p.background && p.background.imageAssetId && !assets.has(p.background.imageAssetId)) {
    warnings.push(`Фоновое изображение ${p.background.imageAssetId} не найдено среди ресурсов.`);
  }
  if (p.device && !p.device.targetKey) {
    warnings.push('У устройства не задан targetKey — экспорт полного проекта потребует ручной настройки.');
  }
  return { errors, warnings };
}

function renderPreflightDialog(result) {
  const dlg = document.getElementById('diagnostic-dialog');
  const summary = document.getElementById('diagnostic-summary');
  const list = document.getElementById('diagnostic-list');
  const raw = document.getElementById('diagnostic-raw');
  if (!dlg || !summary || !list) return;
  const esc = (t) => String(t ?? '').replace(/[&<>]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
  const errors = result?.errors || [];
  const warnings = result?.warnings || [];
  summary.innerHTML = `<b>${errors.length ? '❌ Сборка заблокирована' : '✅ Проверка пройдена'}</b> · ${errors.length} ошибок · ${warnings.length} предупреждений`;
  const details = result?.diagnostics || [];
  list.innerHTML = details.length ? details.map((d, i) => `
    <div class="diagnostic-item ${d.severity === 'error' ? 'error' : 'warn'}">
      <div><b>${d.severity === 'error' ? 'Ошибка' : 'Предупреждение'} ${i + 1}</b> · <code>${esc(d.code)}</code>${d.line ? ` · строка ${d.line}` : ''}${d.scene ? ` · ${esc(d.scene)}` : ''}</div>
      <div class="diagnostic-message">${esc(d.message)}</div>
      ${d.detail ? `<div class="diagnostic-detail">${esc(d.detail)}</div>` : ''}
    </div>`).join('') : '<div class="diagnostic-empty">Проблем не обнаружено.</div>';
  if (raw) {
    raw.textContent = JSON.stringify(result, null, 2);
    raw.hidden = true;
  }
  if (typeof dlg.showModal === 'function') dlg.showModal(); else dlg.setAttribute('open','');
}

async function runFullPreflight(showDialog = true) {
  const status = document.getElementById('preflight-status');
  if (status) status.textContent = 'Проверяю проект и generated index.js…';
  try {
    const result = runDesignerPreflight(store.state);
    if (status) status.textContent = result.ok ? `✓ Готово: ошибок нет${result.warnings.length ? `, предупреждений ${result.warnings.length}` : ''}` : `❌ Найдено ошибок: ${result.errors.length}`;
    if (showDialog) renderPreflightDialog(result);
    renderValidation();
    return result;
  } catch (e) {
    const result = { ok: false, errors: [`Внутренняя ошибка диагностики: ${e?.stack || e?.message || e}`], warnings: [], diagnostics: [] };
    if (status) status.textContent = '❌ Ошибка диагностики';
    if (showDialog) renderPreflightDialog(result);
    return result;
  }
}

document.getElementById('act-preflight')?.addEventListener('click', () => runFullPreflight(true));
document.getElementById('diagnostic-close')?.addEventListener('click', () => document.getElementById('diagnostic-dialog')?.close());

const validationEl = document.getElementById('validation-strip');
function renderValidation() {
  const { errors, warnings } = validateProject(store.state);
  if (errors.length === 0 && warnings.length === 0) {
    validationEl.innerHTML = '<span class="valid-ok">✓ Проблем не обнаружено</span>';
    return;
  }
  const escV = (t) => String(t).replace(/[&<>]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
  validationEl.innerHTML = `
    <div class="validation-summary">
      <b>Проверка проекта:</b> ${errors.length ? `<span class="valid-error">${errors.length} ошибок</span>` : '<span class="valid-ok">ошибок нет</span>'} · ${warnings.length ? `<span class="valid-warn">${warnings.length} предупреждений</span>` : 'предупреждений нет'}
      ${(errors.length || warnings.length) ? '<button type="button" class="validation-details-btn">Подробно</button>' : ''}
    </div>
    ${(errors.length || warnings.length) ? `<details class="validation-details"><summary>Показать диагностику</summary>${errors.map((e,i)=>`<div class="validation-item error"><b>Ошибка ${i+1}.</b> ${escV(e)}</div>`).join('')}${warnings.map((w,i)=>`<div class="validation-item warn"><b>Предупреждение ${i+1}.</b> ${escV(w)}</div>`).join('')}</details>` : ''}`;
  const db=validationEl.querySelector('.validation-details-btn');
  const det=validationEl.querySelector('.validation-details');
  if(db&&det) db.onclick=()=>{det.open=!det.open;};
}

const sceneNormalBtn = document.getElementById('scene-normal');
const sceneAodBtn = document.getElementById('scene-aod');
const aodPanel = document.getElementById('aod-panel');
const aodStatus = document.getElementById('aod-status');

function syncAodControls() {
  if (!aodPanel) return;
  const active = store.state.mode === 'aod';
  aodPanel.hidden = !active;
  document.body.classList.toggle('aod-mode', active);
  sceneNormalBtn?.classList.toggle('active', !active);
  sceneAodBtn?.classList.toggle('active', active);
  if (!active) { if (aodStatus) aodStatus.hidden = true; return; }
  const st = store.getAodSettings();
  const set = (id, val) => { const el=document.getElementById(id); if(el && document.activeElement!==el) el.value=val; };
  set('aod-bg', st.background || '#000000');
  set('aod-brightness', st.brightness ?? 100);
  set('aod-test-time', st.testTime || '10:10');
  set('aod-test-date', st.testDate || '');
  set('aod-battery', st.sensorValues?.battery ?? 85);
  set('aod-steps', st.sensorValues?.steps ?? 8452);
  set('aod-heart', st.sensorValues?.heart ?? 72);
  const sec=document.getElementById('aod-show-seconds'); if(sec) sec.checked=!!st.showSeconds;
  document.querySelectorAll('[data-aod-preview]').forEach(b=>b.classList.toggle('active', b.dataset.aodPreview === (st.previewMode || 'AOD')));
  if (aodStatus) {
    const cfg=buildAodConfig(store.state);
    aodStatus.hidden=false;
    aodStatus.innerHTML=`<b>AOD Studio</b><br>Объектов: ${store.state.components.length}. Экспортируемых: ${cfg.objects.filter(o=>o.exportable).length}. Runtime AOD попадёт в ZIP циферблата; отдельный aod-config.json служит для редактирования.`;
  }
}

function updateAodSettingFromUi() {
  if (store.state.mode !== 'aod') return;
  const sensorValues = {
    battery: Number(document.getElementById('aod-battery')?.value || 0),
    steps: Number(document.getElementById('aod-steps')?.value || 0),
    heart: Number(document.getElementById('aod-heart')?.value || 0)
  };
  store.updateAodSettings({
    background: document.getElementById('aod-bg')?.value || '#000000',
    brightness: Number(document.getElementById('aod-brightness')?.value || 100),
    testTime: document.getElementById('aod-test-time')?.value || '10:10',
    testDate: document.getElementById('aod-test-date')?.value || '',
    showSeconds: !!document.getElementById('aod-show-seconds')?.checked,
    sensorValues
  });
}

sceneNormalBtn?.addEventListener('click',()=>store.switchScene('normal'));
sceneAodBtn?.addEventListener('click',()=>store.switchScene('aod'));
function createAodSubset(kind) {
  const existingAod = store.state.mode === 'aod' ? store.state.components : (store.state.scenes?.aod?.components || []);
  if (existingAod.length && !confirm('Заменить существующую AOD-сцену выбранными элементами Normal?')) return;

  const filter = (c) => {
    const def = REGISTRY[c.defId];
    if (!def) return false;
    if (kind === 'images') return def.widgetId === 'IMG';
    if (kind === 'hands') return def.widgetId === 'TIME_POINTER';
    if (kind === 'text') return def.widgetId === 'TEXT' || !!def.dataSource || !!c.props?.data_source;
    return true;
  };

  const count = store.createAodFromNormal({ filter });
  if (aodStatus) {
    aodStatus.hidden = false;
    aodStatus.innerHTML = `<b>AOD Studio</b><br>Перенесено из Normal: <strong>${count}</strong> объектов.`;
  }
  renderAll();
}
document.getElementById('aod-from-normal')?.addEventListener('click',()=>createAodSubset('all'));
document.getElementById('aod-from-images')?.addEventListener('click',()=>createAodSubset('images'));
document.getElementById('aod-from-hands')?.addEventListener('click',()=>createAodSubset('hands'));
document.getElementById('aod-from-text')?.addEventListener('click',()=>createAodSubset('text'));
document.getElementById('aod-clear')?.addEventListener('click',()=>{
  if(confirm('Очистить только AOD-сцену? Normal останется без изменений.')) store.clearAod();
});
document.getElementById('aod-export')?.addEventListener('click', async (ev)=>{
  const button = ev.currentTarget;
  if (button?.disabled) return;
  if (store.state.mode !== 'aod') {
    alert('Сначала откройте сцену AOD, затем экспортируйте её.');
    return;
  }
  const aodComponents = store.state.scenes?.aod?.components || [];
  if (aodComponents.filter(c => c?.defId !== 'time_pointer_second').length === 0) {
    alert('Сцена AOD пустая. Добавьте элементы или скопируйте их из Normal.');
    return;
  }
  if (button) button.disabled = true;
  try {
    store._saveActiveScene();
    const result = await withBusyOverlay(
      'Экспортирую циферблат с AOD…',
      'Встраиваю Normal и AOD в watchface/index.js',
      () => exportFullProject(store.state)
    );
    if (!result?.blob) throw new Error('Экспортёр не вернул ZIP-проект.');
    const url = URL.createObjectURL(result.blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${latinSlug(store.state.meta.name, 'watchface')}-AOD.zip`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    const warnings = result.validation?.warnings || [];
    alert(`Создан ZIP циферблата с runtime AOD. Предупреждений: ${warnings.length}.\n\nУстановите этот ZIP через Zeus CLI. Один файл aod-config.json не устанавливает AOD на часы.`);
  } catch (err) {
    alert(`Не удалось экспортировать циферблат с AOD: ${err?.message || err}`);
  } finally {
    if (button) button.disabled = false;
  }
});
['aod-bg','aod-brightness','aod-test-time','aod-test-date','aod-battery','aod-steps','aod-heart','aod-show-seconds'].forEach(id=>{
  document.getElementById(id)?.addEventListener('change', updateAodSettingFromUi);
});
document.querySelectorAll('[data-aod-preview]').forEach(btn=>btn.addEventListener('click',()=>{
  if(store.state.mode!=='aod') return;
  store.updateAodSettings({previewMode:btn.dataset.aodPreview});
}));

// Предпросмотр анимации текста: один контроллер, один rAF-цикл только во время воспроизведения.
window.textAnimController = TextAnimPreview.createController({
  getState: () => store.state,
  host: canvasEditor,
  textFor: (c) => WatchfacePreviewRenderer.textFor(c, REGISTRY[c.defId], true, canvasEditor.liveTime && store.state.mode !== 'aod'),
  raf: (fn) => requestAnimationFrame(fn),
  caf: (id) => cancelAnimationFrame(id),
});
window.addEventListener('beforeunload', () => window.textAnimController.dispose());

// Предпросмотр покадровой анимации фона: один setInterval только пока идёт воспроизведение.
window.bgAnimPreview = BgAnim.createPreview({ getState: () => store.state, host: canvasEditor });
window.addEventListener('beforeunload', () => window.bgAnimPreview.dispose());
window.bgAnimTimeline = new BgAnimTimeline(document.getElementById('bg-anim-timeline'), {
  getState: () => store.state, preview: window.bgAnimPreview,
});

function renderAll() {
  if (store.state.mode === 'aod' && window.bgAnimPreview.isPlaying()) window.bgAnimPreview.stop();
  window.textAnimController.sync(store.state, store.selection);
  canvasEditor.render();
  window.bgAnimTimeline.render();
  layers.render();
  inspector.render();
  assetManager.render();
  projectSettings.render();
  apiSelect.value = store.state.apiLevel;
  projectNameEl.value = store.state.meta.name;
  renderPalette();
  renderValidation();
  syncAodControls();
}

store.subscribe(renderAll);
renderAll();
applyLiveTime(readLiveTimePref());

apiSelect.addEventListener('change', () => {
  store.state.apiLevel = apiSelect.value;
  store.commit();
});

projectNameEl.addEventListener('change', () => {
  store.state.meta.name = projectNameEl.value || 'AmazFace Watch Face';
  store.commit();
});



// ---- Zeus Developer Bridge (пошаговая панель) + QR Preview ----
// Панель сама проверяет окружение (локальный мост → Zeus CLI → вход в аккаунт),
// показывает чек-лист и ОДНУ главную кнопку, которая меняется по ходу работы:
// Запустить Bridge → Подключиться → Установить на часы.
const ZEUS_BRIDGE = 'http://127.0.0.1:17865';
const Z = { server:null, env:null, st:null, checking:false, busy:false, msg:'', msgKind:'', loginTimer:null, loginSince:0, loginOverride:false, uiLog:'', pollTimer:null };
const zEl = (id) => document.getElementById(id);
const zEsc = (t) => String(t ?? '').replace(/[&<>"]/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
function zeusLog(message, details) {
  const line = `[${new Date().toLocaleTimeString()}] ${message}${details === undefined ? '' : '\n' + (typeof details === 'string' ? details : JSON.stringify(details, null, 2))}\n`;
  Z.uiLog += line; console.info('[AmazFace Zeus Bridge]', message, details === undefined ? '' : details);
  zeusRenderLog();
}
function zeusRenderLog() {
  const log = zEl('zeus-log'); if (!log) return;
  const proc = Z.st?.log ? `\n--- Журнал Zeus CLI ---\n${Z.st.log}` : '';
  const text = Z.uiLog + proc;
  if (log.textContent !== text) { const atEnd = log.scrollTop + log.clientHeight >= log.scrollHeight - 30; log.textContent = text; if (atEnd) log.scrollTop = log.scrollHeight; }
}
// Понятная подсказка по типовым ошибкам из журнала.
function zeusFriendlyHint() {
  const t = (Z.st?.log || '') + '\n' + Z.uiLog;
  if (/No connectable online App or Simulator/i.test(t)) return 'Zeus не видит телефон. В Zepp App откройте: Профиль → Режим разработчика → «+» → Bridge — и оставьте этот экран открытым. Затем нажмите «Подключиться» ещё раз.';
  if (/not\s*log(?:ged)?\s*in|please.*login|unauthori[sz]ed|未登录/i.test(Z.st?.log || '')) return 'Похоже, вход в Zeus не выполнен. Нажмите «Войти в Zeus» и повторите.';
  return '';
}
async function zeusFetchJson(path, opts) {
  const r = await fetch(`${ZEUS_BRIDGE}${path}`, Object.assign({ cache: 'no-store' }, opts || {}));
  const raw = await r.text(); let j; try { j = JSON.parse(raw); } catch { j = { raw }; }
  if (!r.ok) throw new Error(j.error || `HTTP ${r.status}`);
  return j;
}
async function zeusCheckEnv(manual) {
  if (Z.checking) return; Z.checking = true; if (manual) { Z.msg = ''; } zeusRender();
  try {
    Z.env = await zeusFetchJson('/env'); Z.server = true;
    zeusLog('Проверка окружения', { zeus: Z.env.zeus, version: Z.env.zeusVersion, loggedIn: Z.env.loggedIn, user: Z.env.user, status: Z.env.statusRaw });
  } catch (e) { Z.server = false; Z.env = null; }
  Z.checking = false; zeusRender();
  if (Z.server) zeusPoll();
}
async function zeusPoll() {
  clearTimeout(Z.pollTimer);
  try { Z.st = await zeusFetchJson('/status'); Z.server = true; } catch { Z.server = false; Z.st = null; }
  zeusRender();
  const dlg = zEl('zeus-dialog');
  if (Z.server && Z.st?.running && dlg?.open) Z.pollTimer = setTimeout(zeusPoll, 800);
}
// Вычисляет, на каком этапе пользователь, и что ему делать дальше.
function zeusModel() {
  const e = Z.env, st = Z.st || {}, rows = [];
  const loggedIn = e ? (e.loggedIn === true || (e.loggedIn === null && Z.loginOverride)) : false;
  const row = (state, title, detail) => rows.push({ state, title, detail });
  row(Z.server === null ? 'wait' : Z.server ? 'ok' : 'bad', 'Локальный мост AmazFace', Z.server === null ? 'Проверяю…' : Z.server ? 'Работает (127.0.0.1:17865)' : 'Не запущен');
  row(!Z.server ? 'idle' : e?.zeus ? 'ok' : 'bad', 'Zeus CLI установлен', !Z.server ? 'Сначала запустите мост' : e?.zeus ? `Найден${e.zeusVersion ? ' · версия ' + e.zeusVersion : ''}` : 'Не найден в PATH');
  row(!e?.zeus ? 'idle' : loggedIn ? 'ok' : e.loggedIn === false ? 'bad' : 'warn', 'Вход в аккаунт Zeus', !e?.zeus ? 'Сначала установите Zeus CLI' : e.loggedIn === true ? `Выполнен${e.user ? ' · ' + e.user : ''}` : loggedIn ? 'Отмечено вручную' : e.loggedIn === false ? 'Не выполнен' : 'Не удалось определить статус');
  const ready = Z.server && e?.zeus && loggedIn;
  let bState = 'idle', bDetail = 'Станет доступно после проверок выше';
  if (ready) {
    if (st.installFinished) { bState = st.installSucceeded ? 'ok' : 'bad'; bDetail = st.installSucceeded ? 'Циферблат установлен на часы' : 'Установка не удалась'; }
    else if (st.installRequested) { bState = 'wait'; bDetail = 'Идёт установка…'; }
    else if (st.running && st.mode === 'bridge' && st.connected) { bState = 'ok'; bDetail = 'Телефон подключён'; }
    else if (st.running && st.mode === 'bridge' && st.connectRequested) { bState = 'wait'; bDetail = 'Жду ответа телефона…'; }
    else if (st.running && st.mode === 'bridge') { bState = 'warn'; bDetail = 'Bridge запущен, телефон ещё не подключён'; }
    else { bState = 'idle'; bDetail = 'Bridge не запущен'; }
  }
  row(bState, 'Телефон и часы', bDetail);

  // Главное действие
  let main = null, hint = '', extra = null;
  if (Z.server === false) {
    main = { id: 'recheck', label: 'Проверить снова' };
    hint = 'Запустите на компьютере файл <code>bridge\\start-zeus-bridge.bat</code> и оставьте чёрное окно открытым. Оно связывает редактор с Zeus.';
  } else if (Z.server && !e?.zeus) {
    main = { id: 'recheck', label: 'Проверить снова' };
    hint = 'Установите Zeus CLI командой ниже (нужен Node.js), затем <b>перезапустите мост</b> (закройте и снова откройте <code>start-zeus-bridge.bat</code>) — иначе он не увидит новый PATH.';
    extra = { copy: 'npm install -g @zeppos/zeus-cli' };
  } else if (Z.server && e && !loggedIn) {
    if (Z.loginTimer) { main = { id: 'wait', label: 'Жду завершения входа…', disabled: true }; hint = 'Войдите в аккаунт Zepp в открывшемся окне/браузере. Статус обновится сам.'; }
    else { main = { id: 'login', label: 'Войти в Zeus' }; hint = e.loggedIn === false ? 'Нужно войти один раз под тем же аккаунтом Zepp, что и на телефоне. Откроется окно <code>zeus login</code>.' : 'Zeus не сообщил статус входа понятным образом (подробности — в журнале). Нажмите «Войти в Zeus» или, если уже входили, подтвердите вручную.'; if (e.loggedIn === null) extra = { skip: true }; }
  } else if (ready) {
    if (st.installFinished && st.installSucceeded) { main = { id: 'start', label: 'Установить ещё раз' }; hint = 'Готово! Циферблат на часах. Если вы изменили дизайн — установите заново.'; }
    else if (st.installFinished) { main = { id: 'start', label: 'Попробовать снова' }; hint = 'Установка не удалась — причина в журнале ниже.'; }
    else if (st.installRequested) { const ph = { building: 'сборка проекта', 'device-prompt': 'выбор устройства (отвечаю автоматически)', installing: 'передача на часы' }; main = { id: 'wait', label: 'Устанавливаю…', disabled: true }; hint = 'Этап: ' + (ph[st.installPhase] || 'выполняется') + '. Не закрывайте окно.'; }
    else if (st.running && st.mode === 'bridge' && st.connected) { main = { id: 'install', label: 'Установить на часы' }; hint = 'Всё подключено. Нажмите — циферблат соберётся и отправится на часы.'; }
    else if (st.running && st.mode === 'bridge' && st.connectRequested) { main = { id: 'wait', label: 'Подключаюсь…', disabled: true }; hint = 'Убедитесь, что в Zepp App открыт экран Bridge (Профиль → Режим разработчика → «+» → Bridge).'; }
    else if (st.running && st.mode === 'bridge') { main = { id: 'connect', label: 'Подключиться к телефону' }; hint = 'Сначала на телефоне: <b>Zepp App → Профиль → Режим разработчика → «+» → Bridge</b>, затем нажмите кнопку.'; }
    else { main = { id: 'start', label: 'Запустить Bridge' }; hint = 'Редактор проверит проект, соберёт циферблат и запустит Zeus Bridge. Потом понадобится подключить телефон.'; }
  }
  if (Z.busy && main && !main.disabled) main = { ...main, disabled: true };
  return { rows, main, hint, extra, ready };
}
function zeusRender() {
  const root = zEl('zeus-checklist'); if (!root) return;
  const m = zeusModel(), icon = { ok: '✓', bad: '✕', warn: '!', wait: '…', idle: '•' };
  root.innerHTML = m.rows.map((r) => `<li class="zeus-row is-${r.state}"><span class="zeus-ic">${icon[r.state]}</span><span class="zeus-rt"><b>${zEsc(r.title)}</b><small>${zEsc(r.detail)}</small></span></li>`).join('');
  const act = zEl('zeus-action');
  if (act) {
    const stNow = Z.st || {};
    const kind = m.main && m.ready && stNow.installFinished && stNow.installSucceeded ? 'ok' : '';
    let html = '';
    if (m.hint) html += `<p class="zeus-hint">${m.hint}</p>`;
    if (m.extra?.copy) html += `<div class="zeus-copy"><code>${zEsc(m.extra.copy)}</code><button type="button" data-zeus-act="copy" data-copy="${zEsc(m.extra.copy)}">Копировать</button></div>`;
    if (Z.msg) html += `<p class="zeus-msg ${Z.msgKind}">${zEsc(Z.msg)}</p>`;
    const fh = zeusFriendlyHint(); if (fh && !Z.msg) html += `<p class="zeus-msg bad">${zEsc(fh)}</p>`;
    const btns = [];
    if (m.main) btns.push(`<button type="button" class="${m.main.id === 'recheck' || m.main.id === 'wait' ? 'btn-secondary' : 'btn-primary'} zeus-main ${kind}" data-zeus-act="${m.main.id}" ${m.main.disabled ? 'disabled' : ''}>${zEsc(m.main.label)}</button>`);
    if (m.extra?.skip) btns.push(`<button type="button" class="btn-secondary" data-zeus-act="skip">Я уже вошёл — продолжить</button>`);
    if (m.ready && Z.st?.running) btns.push(`<button type="button" class="btn-secondary" data-zeus-act="stop">■ Остановить</button>`);
    if (Z.server) btns.push(`<button type="button" class="btn-ghost" data-zeus-act="recheck" ${Z.checking ? 'disabled' : ''}>${Z.checking ? 'Проверяю…' : '↻ Перепроверить'}</button>`);
    html += `<div class="zeus-btnrow">${btns.join('')}</div>`;
    act.innerHTML = html;
  }
  zeusRenderLog();
}
function zeusSetMsg(text, kind) { Z.msg = text || ''; Z.msgKind = kind || ''; zeusRender(); }
function zeusLoginWatch() {
  clearInterval(Z.loginTimer); Z.loginSince = Date.now();
  Z.loginTimer = setInterval(async () => {
    if (Date.now() - Z.loginSince > 3 * 60 * 1000 || !zEl('zeus-dialog')?.open) { clearInterval(Z.loginTimer); Z.loginTimer = null; zeusRender(); return; }
    try { const e = await zeusFetchJson('/env'); Z.env = e; if (e.loggedIn === true) { clearInterval(Z.loginTimer); Z.loginTimer = null; zeusSetMsg('Вход выполнен ✓', 'ok'); return; } } catch {}
    zeusRender();
  }, 4000);
  zeusRender();
}
async function zeusLogin() {
  try { const j = await zeusFetchJson('/zeus/login', { method: 'POST' }); zeusLog('Открыто окно входа', j); zeusLoginWatch(); }
  catch (e) { zeusSetMsg('Не удалось открыть вход: ' + e.message, 'bad'); }
}
function confirmIssuesForZeus(errors) {return confirm(`Сборка остановлена диагностикой. Найдено ${errors.length} ошибок.\n\n${errors.map((e,i)=>`[${i+1}] ${e}`).join('\n\n')}\n\nПродолжить несмотря на ошибки?`);}
function zeusDeviceHeader() { return String(store.state.device?.name || 'Amazfit Balance 2').replace(/\s*\(.*$/, '').replace(/[^\x20-\x7e]/g, ''); }
// Общая подготовка: проверка проекта → экспорт → ZIP.
async function zeusBuildZip(title) {
  zeusLog('Проверяю проект перед сборкой.');
  const preflight = await runFullPreflight(false);
  if (!preflight.ok) { renderPreflightDialog(preflight); throw new Error('Проверка проекта не пройдена. Смотри окно диагностики.'); }
  const result = await withBusyOverlay(title, 'Собираю текущий проект для Zeus', () => exportFullProject(store.state));
  if (!result?.blob) throw new Error('Экспорт не вернул ZIP проекта.');
  const errors = result.validation?.errors || [];
  if (errors.length && !confirmIssuesForZeus(errors)) throw new Error('Запуск отменён: в проекте найдены ошибки.');
  return result.blob;
}
async function zeusStartBridge() {
  Z.busy = true; zeusSetMsg('Готовлю проект…', '');
  try {
    const blob = await zeusBuildZip('Подготавливаю установку…');
    zeusLog('Отправляю проект в локальный мост.');
    const j = await zeusFetchJson('/bridge/start', { method: 'POST', headers: { 'Content-Type': 'application/zip', 'X-Project-Name': latinSlug(store.state.meta.name, 'watchface'), 'X-Device-Name': zeusDeviceHeader() }, body: await blob.arrayBuffer() });
    zeusLog('Bridge запущен', j); Z.msg = '';
  } catch (e) { zeusLog('ОШИБКА запуска Bridge: ' + (e?.message || e)); Z.msg = 'Не удалось запустить Bridge: ' + (e?.message || e); Z.msgKind = 'bad'; }
  Z.busy = false; await zeusPoll();
}
async function zeusBridgeCommand(action) {
  Z.busy = true; zeusSetMsg('', '');
  try { const j = await zeusFetchJson(`/bridge/${action}`, { method: 'POST' }); zeusLog(j.message || 'Команда отправлена.'); Z.msg = ''; }
  catch (e) { zeusLog('ОШИБКА: ' + e.message); Z.msg = e.message; Z.msgKind = 'bad'; }
  Z.busy = false; await zeusPoll();
}
async function zeusRunPreview() {
  if (Z.busy) return; Z.busy = true; zeusSetMsg('Готовлю проект для QR Preview…', '');
  try {
    const blob = await zeusBuildZip('Подготавливаю Zeus Preview…');
    const j = await zeusFetchJson('/preview', { method: 'POST', headers: { 'Content-Type': 'application/zip', 'X-Project-Name': latinSlug(store.state.meta.name, 'watchface'), 'X-Device-Name': zeusDeviceHeader() }, body: await blob.arrayBuffer() });
    zeusLog(j.message || 'Передано в Zeus.'); Z.msg = 'QR Preview запущен — QR-код смотрите в журнале ниже.'; Z.msgKind = 'ok';
  } catch (e) { zeusLog('ОШИБКА: ' + e.message); Z.msg = e.message; Z.msgKind = 'bad'; }
  Z.busy = false; await zeusPoll();
}
function zeusOpenDialog() {
  const dlg = zEl('zeus-dialog'); if (!dlg) return;
  if (typeof dlg.showModal === 'function') dlg.showModal(); else dlg.setAttribute('open', '');
  Z.msg = ''; Z.loginOverride = false; Z.server = null; Z.env = null; zeusRender();
  zeusCheckEnv(false);
}
document.getElementById('act-zeus-preview')?.addEventListener('click', zeusOpenDialog);
// Кнопки находятся в <dialog> после <script src="src/app.js"> — используем делегирование событий.
document.addEventListener('click', (ev) => {
  const btn = ev.target instanceof Element ? ev.target.closest('[data-zeus-act],#zeus-run,#zeus-copy-log') : null;
  if (!btn || btn.disabled) return;
  if (btn.id === 'zeus-run') return void zeusRunPreview();
  if (btn.id === 'zeus-copy-log') { navigator.clipboard?.writeText(zEl('zeus-log')?.textContent || '').then(() => { btn.textContent = 'Скопировано ✓'; setTimeout(() => btn.textContent = 'Копировать журнал', 1500); }).catch(() => {}); return; }
  switch (btn.dataset.zeusAct) {
    case 'recheck': zeusCheckEnv(true); break;
    case 'login': zeusLogin(); break;
    case 'skip': Z.loginOverride = true; zeusRender(); break;
    case 'start': zeusStartBridge(); break;
    case 'connect': zeusBridgeCommand('connect'); break;
    case 'install': zeusBridgeCommand('install'); break;
    case 'stop': (async () => { try { await fetch(`${ZEUS_BRIDGE}/stop`, { method: 'POST' }); } catch {} await zeusPoll(); })(); break;
    case 'copy': navigator.clipboard?.writeText(btn.dataset.copy || '').then(() => { btn.textContent = 'Скопировано ✓'; setTimeout(() => btn.textContent = 'Копировать', 1500); }).catch(() => {}); break;
  }
});
zEl('zeus-dialog')?.addEventListener('close', () => { clearInterval(Z.loginTimer); Z.loginTimer = null; clearTimeout(Z.pollTimer); });

// ---- Heavy-operation progress overlay ----
function setBusyOverlay(title = 'Подождите…', text = 'Выполняется операция') {
  const overlay = document.getElementById('busy-overlay');
  const titleEl = document.getElementById('busy-title');
  const textEl = document.getElementById('busy-text');
  if (!overlay) return;
  if (titleEl) titleEl.textContent = title;
  if (textEl) textEl.textContent = text;
  overlay.hidden = false;
  document.body.classList.add('is-busy');
}
function clearBusyOverlay() {
  const overlay = document.getElementById('busy-overlay');
  if (!overlay) return;
  overlay.hidden = true;
  document.body.classList.remove('is-busy');
}
async function withBusyOverlay(title, text, task) {
  setBusyOverlay(title, text);
  // Give the browser one paint frame so the spinner appears before CPU-heavy export starts.
  await new Promise(resolve => { let done=false; const fin=()=>{ if(!done){done=true;resolve();} }; try { requestAnimationFrame(() => requestAnimationFrame(fin)); } catch(e) {} setTimeout(fin, 120); });
  try { return await task(); }
  finally { clearBusyOverlay(); }
}

// ---- Toolbar actions ----
document.getElementById('act-undo').onclick = () => store.undo();
document.getElementById('act-redo').onclick = () => store.redo();
document.getElementById('act-dup').onclick = () => store.duplicateComponents([...store.selection]);
document.getElementById('act-del').onclick = () => confirmRemoveComponents(store, [...store.selection]);

document.getElementById('act-new').onclick = () => {
  if (confirm('Создать новый проект? Несохранённые изменения будут потеряны.')) store.newProject();
};

document.getElementById('act-save').onclick = async () => {
  try {
    store.state.preview = store.state.preview || {};
    store.state.preview.dataUrl = await withBusyOverlay('Сохраняю проект…', 'Генерация превью циферблата', () => buildPreviewDataUrl(store.state, 324));
    store.state.preview.width = 324;
    store.state.preview.height = 324;
    store.state.preview.handsTime = '10:10';
  } catch (e) { console.warn('Preview generation failed:', e); }
  store._saveActiveScene();
  const blob = new Blob([store.toJSON()], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  // Имя файла всегда латиницей: кириллические названия транслитерируются
  // (см. src/util/slug.js), иначе файл неудобно передавать в Zeus CLI/git/архивы.
  a.download = `${latinSlug(store.state.meta.name, 'watchface')}.watchface.json`;
  a.click();
};

document.getElementById('act-export-project-zip')?.addEventListener('click', async (e) => {
  const button = e.currentTarget;
  if (button.disabled) return;
  button.disabled = true;
  try {
    store._saveActiveScene();
    const { blob } = await withBusyOverlay(
      'Собираю ZIP-проект…',
      'Готовлю файлы проекта Zepp OS',
      () => exportFullProject(store.state)
    );
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${latinSlug(store.state.meta.name, 'watchface')}-project.zip`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  } catch (err) {
    alert(`Не удалось собрать ZIP-проект: ${err.message || err}`);
  } finally {
    button.disabled = false;
  }
});

document.getElementById('act-open').addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    try { store.loadFromJSON(reader.result); }
    catch (err) { alert('Не удалось загрузить проект: ' + err.message); }
  };
  reader.readAsText(file);
  e.target.value = '';
});

// ---- Background is edited from the Layers panel ----
// The old standalone background controls were intentionally removed.
// Selecting the "Фон" layer opens its color/image/opacity properties in Inspector.

// ---- Demo watch face ----
document.getElementById('act-demo').onclick = () => {
  if (!confirm('Заменить текущие компоненты демо-макетом?')) return;
  store.state.components = [];
  store.state.nextIndex = {};
  const cx = store.state.device.w / 2;
  const add = (defId, x, y, patch = {}) => {
    const idx = (store.state.nextIndex[defId] || 0) + 1;
    store.state.nextIndex[defId] = idx;
    const def = REGISTRY[defId];
    const props = {};
    for (const p of def.properties) if (p.default !== undefined) props[p.key] = p.default;
    Object.assign(props, patch.props || {});
    store.state.components.push({
      id: `${defId}_${String(idx).padStart(3, '0')}`, defId, name: def.name,
      x, y, w: patch.w ?? def.defaultSize.w, h: patch.h ?? def.defaultSize.h,
      visible: true, locked: false, props,
    });
  };
  add('time_hm', cx - 150, 150, { w: 300, h: 100, props: { text_size: 84, color: '#ffffff', align_h: 'CENTER_H', align_v: 'CENTER_V' } });
  add('date_full', cx - 110, 250, { w: 220, h: 36, props: { text_size: 26, color: '#aeb6c2', align_h: 'CENTER_H', align_v: 'CENTER_V', format: 'DD MMM' } });
  add('weather_icon', cx - 90, 300, { w: 48, h: 48, props: { src: 'sunny' } });
  add('weather_temp', cx - 30, 305, { w: 90, h: 40, props: { text_size: 30, color: '#ffffff', align_h: 'LEFT', align_v: 'CENTER_V', unit: '°C' } });
  add('heart_rate', cx - 60, 360, { w: 120, h: 34, props: { text_size: 26, color: '#ff5c7a', align_h: 'CENTER_H', align_v: 'CENTER_V', prefix: '♥ ' } });
  add('steps', cx - 90, 400, { w: 180, h: 34, props: { text_size: 24, color: '#8fd3ff', align_h: 'CENTER_H', align_v: 'CENTER_V', suffix: ' шагов' } });
  add('battery', cx - 40, 440, { w: 80, h: 30, props: { text_size: 22, color: '#8bffb0', align_h: 'CENTER_H', align_v: 'CENTER_V', suffix: '%' } });
  store.commit();
};

// keep palette compatibility in sync visually (re-render already handled by subscribe)
