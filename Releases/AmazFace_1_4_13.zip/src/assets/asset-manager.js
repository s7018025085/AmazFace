// src/assets/asset-manager.js

class AssetManager {
  constructor(root, store) {
    this.root = root;
    this.store = store;
    this.root.innerHTML = `
      <div class="asset-toolbar">
        <label class="btn-file" style="flex: 1;">Загрузить PNG
          <input type="file" accept="image/png,image/jpeg" multiple hidden>
        </label>
        <button type="button" class="btn-weather-set" title="Свой набор иконок погоды (29 состояний, русские названия)">☀ Иконки погоды</button>
      </div>
      <div class="asset-list"></div>
    `;
    this.root.querySelector('input[type=file]').addEventListener('change', (e) => this._onUpload(e.target.files));
    this.list = this.root.querySelector('.asset-list');
    this.root.querySelector('.btn-weather-set').addEventListener('click', () => WeatherIcons.openDialog(this.store));
    
    // Collapsible toggle
    const title = document.querySelector('[data-section="resources"]');
    if (title) {
      title.addEventListener('click', (e) => {
        if (e.target.classList.contains('toggle-btn')) {
          this.toggleResources();
        }
      });
    }
    
    // Load saved state
    const collapsed = localStorage.getItem('resources-collapsed');
    if (collapsed === 'true') {
      this.collapseResources();
    }
  }
  
  toggleResources() {
    const content = document.querySelector('[data-section="resources"].collapsible-content');
    const btn = document.querySelector('[data-section="resources"] .toggle-btn');
    if (content.classList.contains('collapsed')) {
      content.classList.remove('collapsed');
      btn.textContent = '▼';
      localStorage.setItem('resources-collapsed', 'false');
    } else {
      content.classList.add('collapsed');
      btn.textContent = '▶';
      localStorage.setItem('resources-collapsed', 'true');
    }
  }
  
  collapseResources() {
    const content = document.querySelector('[data-section="resources"].collapsible-content');
    const btn = document.querySelector('[data-section="resources"] .toggle-btn');
    if (content) {
      content.classList.add('collapsed');
      btn.textContent = '▶';
    }
  }

  _onUpload(files) {
    for (const file of files) {
      if (!/image\/(png|jpeg)/.test(file.type)) {
        alert(`Неподдерживаемый формат: ${file.name}. Ресурсы циферблата Zepp OS должны быть PNG.`);
        continue;
      }
      const reader = new FileReader();
      reader.onload = () => {
        const img = new Image();
        img.onload = () => {
          this.store.addAsset({
            id: makeAssetId(),
            name: file.name.replace(/\.(png|jpe?g)$/i, ''),
            dataUrl: reader.result,
            width: img.width,
            height: img.height,
            format: file.type.includes('png') ? 'PNG' : 'JPEG',
            size: file.size,
          });
        };
        img.src = reader.result;
      };
      reader.readAsDataURL(file);
    }
  }

  render() {
    const assets = this.store.state.assets.filter((a) => !a.bgFrame && !a.weatherIcon);   // кадры анимации фона управляются из инспектора фона
    if (assets.length === 0) { this.list.innerHTML = `<div class="empty-hint">Пока нет ресурсов. Загрузите PNG, чтобы использовать как изображение или фон.</div>`; return; }
    this.list.innerHTML = assets.map((a) => `
      <div class="asset-card" data-id="${a.id}">
        <img src="${AssetBg.url(a)}" alt="${a.name}">
        <div class="asset-meta">
          <input class="asset-name" value="${a.name}" data-id="${a.id}">
          <div class="asset-sub">${a.width}×${a.height} · ${a.format} · ${(a.size / 1024).toFixed(1)} KB${AssetBg.isBg(a) ? ' · фон (настройки отдельно, 480×480 при экспорте)' : ''}</div>
        </div>
        <div class="asset-actions"><button class="asset-edit" data-id="${a.id}" title="Редактор ресурса (изображение / стрелка)">✎</button><button class="asset-arrow" data-id="${a.id}" title="Открыть в режиме стрелки">↗</button><button class="asset-del" data-id="${a.id}" title="Удалить">✕</button></div>
      </div>
    `).join('');
    // Обе кнопки открывают один и тот же редактор; ↗ принудительно включает режим стрелки.
    const openEditor = (btn, mode, title) => {
      btn.onclick = () => {
        const a = this.store.state.assets.find(x => x.id === btn.dataset.id);
        if (!a || typeof ImageAssetEditor === 'undefined') return;
        ImageAssetEditor.openForAsset(this.store, a, { mode, title });
      };
    };
    this.list.querySelectorAll('.asset-edit').forEach((btn) => openEditor(btn, undefined, 'Редактор ресурса'));
    this.list.querySelectorAll('.asset-arrow').forEach((btn) => openEditor(btn, 'arrow', 'Редактор ресурса'));
    this.list.querySelectorAll('.asset-del').forEach((btn) => {
      btn.onclick = () => this.store.removeAsset(btn.dataset.id);
    });
    this.list.querySelectorAll('.asset-name').forEach((input) => {
      input.onchange = () => this.store.renameAsset(input.dataset.id, input.value);
    });
  }
}
