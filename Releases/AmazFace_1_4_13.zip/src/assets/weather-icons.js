// src/assets/weather-icons.js
//
// Свой набор иконок погоды. В Zepp OS иконку погоды выбирает прошивка по индексу 0..28
// (IMG_LEVEL + data_type.WEATHER_CURRENT), поэтому набор — это 29 «слотов». Каждый слот
// можно заполнить своим PNG; незаполненные слоты получают запасной вариант
// (см. resolveIndex). Если ни один слот не заполнен — работает прежний набор-заглушка.
//
// Хранение: обычные ресурсы проекта (store.state.assets) с пометкой
// `weatherIcon: '<id состояния>'`. Такие ресурсы скрыты из общего списка «Ресурсы»
// и не попадают в корень assets/ при экспорте — их кладут в assets/.../weather/.
// Зависимости (глобальные): WEATHER_ICON_SET, WEATHER_ICON_FILES (экспортёр),
// makeAssetId, drawWeatherIcon (project-exporter.js — только для заглушек).

const WeatherIcons = (() => {
  // Запасные слоты: ночные варианты → дневные, остальные → «Неизвестно» (25).
  const NIGHT_BASE = { 26: 0, 27: 1, 28: 3 };
  const UNKNOWN_INDEX = 25;

  const norm = (s) => String(s || '').toLowerCase().replace(/ё/g, 'е')
    .replace(/\.(png|jpe?g)$/i, '').replace(/[^a-z0-9а-я]+/g, '_').replace(/^_+|_+$/g, '');

  const set = () => (typeof WEATHER_ICON_SET !== 'undefined' ? WEATHER_ICON_SET : []);
  const isIcon = (a) => !!(a && a.weatherIcon);

  function assetFor(project, condId) {
    return (project.assets || []).find((a) => a.weatherIcon === condId) || null;
  }
  function customCount(project) {
    return set().filter((w) => assetFor(project, w.id)).length;
  }
  function missing(project) {
    return set().filter((w) => !assetFor(project, w.id));
  }

  // Что реально попадёт в слот index при экспорте.
  // source: 'own' — своя иконка; 'fallback' — запасная своя иконка из другого слота;
  // 'generated' — встроенная заглушка (рисуется кодом).
  function resolveIndex(project, index) {
    const w = set()[index];
    if (!w) return { asset: null, source: 'generated', fromIndex: index };
    const own = assetFor(project, w.id);
    if (own) return { asset: own, source: 'own', fromIndex: index };
    if (customCount(project) > 0) {
      const chain = [];
      if (NIGHT_BASE[index] !== undefined) chain.push(NIGHT_BASE[index]);
      chain.push(UNKNOWN_INDEX);
      for (const i of chain) {
        const a = set()[i] && assetFor(project, set()[i].id);
        if (a) return { asset: a, source: 'fallback', fromIndex: i };
      }
    }
    return { asset: null, source: 'generated', fromIndex: index };
  }

  // PNG dataURL для файла слота index (для экспортёров).
  function dataUrlFor(project, index, size = 64) {
    const r = resolveIndex(project, index);
    if (r.asset && r.asset.dataUrl) return r.asset.dataUrl;
    return drawWeatherIcon(index, size).toDataURL('image/png');
  }

  // Ресурс, который нужно показать в превью редактора для состояния condId.
  function previewAsset(project, condId) {
    const w = set().find((x) => x.id === normalizeWeatherIconId(condId));
    if (!w) return null;
    return resolveIndex(project, w.index).asset;
  }

  // ---- распознавание слота по имени файла ----
  const RU = () => set().map((w) => ({ w, key: norm(w.label) }));
  // Название состояния в имени файла (английский id или русское название).
  function matchText(fileName) {
    const n = norm(fileName);
    if (!n) return -1;
    // 1) английский id как отдельное слово/словосочетание (длинные id — первыми)
    const byLen = [...set()].sort((a, b) => b.id.length - a.id.length);
    for (const w of byLen) {
      if (new RegExp(`(^|_)${w.id}(_|$)`).test(n)) return w.index;
    }
    // 2) русское название (длинные — первыми)
    for (const { w, key } of RU().sort((a, b) => b.key.length - a.key.length)) {
      if (key && (n === key || n.includes(key))) return w.index;
    }
    return -1;
  }
  // Номер слота в начале имени: «07», «7_что-то».
  function matchNumber(fileName) {
    const m = norm(fileName).match(/^(\d{1,2})(?:_|$)/);
    return m && Number(m[1]) <= 28 ? Number(m[1]) : -1;
  }
  // Название надёжнее номера: у чужих наборов нумерация своя.
  function matchFileName(fileName) {
    const t = matchText(fileName);
    return t >= 0 ? t : matchNumber(fileName);
  }

  const natCmp = (a, b) => a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' });

  // ---- чтение файла → PNG ----
  function fileToPng(file) {
    return new Promise((resolve, reject) => {
      const fr = new FileReader();
      fr.onerror = () => reject(new Error(`Не удалось прочитать файл ${file.name}`));
      fr.onload = () => {
        const img = new Image();
        img.onerror = () => reject(new Error(`Файл ${file.name} не является изображением`));
        img.onload = () => {
          // Всегда сохраняем как PNG (JPEG в weather/*.png не годится). Размер не меняем.
          const c = document.createElement('canvas');
          c.width = img.naturalWidth || img.width; c.height = img.naturalHeight || img.height;
          c.getContext('2d').drawImage(img, 0, 0);
          const dataUrl = c.toDataURL('image/png');
          resolve({ dataUrl, width: c.width, height: c.height, size: Math.round((dataUrl.length - 22) * 0.75) });
        };
        img.src = fr.result;
      };
      fr.readAsDataURL(file);
    });
  }

  function putIcon(store, w, png) {
    store.state.assets = (store.state.assets || []).filter((a) => a.weatherIcon !== w.id);
    store.state.assets.push({
      id: makeAssetId(), name: `weather_${w.index}_${w.id}`, dataUrl: png.dataUrl,
      width: png.width, height: png.height, format: 'PNG', size: png.size, weatherIcon: w.id,
    });
  }

  async function setOne(store, condId, file) {
    const w = set().find((x) => x.id === condId);
    if (!w) return;
    putIcon(store, w, await fileToPng(file));
    store.commit();
  }

  function clearOne(store, condId) {
    store.state.assets = (store.state.assets || []).filter((a) => a.weatherIcon !== condId);
    store.commit();
  }

  function clearAll(store) {
    store.state.assets = (store.state.assets || []).filter((a) => !isIcon(a));
    store.commit();
  }

  // Пачка файлов → слоты.
  // mode 'name' — по имени файла (английское/русское название или номер), остальные —
  //               по порядку в свободные слоты;
  // mode 'order' — строго по порядку имён файлов, начиная со слота 0.
  async function distribute(store, files, mode) {
    const list = [...files].filter((f) => /image\/(png|jpeg)/.test(f.type) || /\.(png|jpe?g)$/i.test(f.name)).sort(natCmp);
    const report = { total: list.length, byName: 0, byOrder: 0, skipped: [], errors: [] };
    const slots = set();
    const target = new Map();    // index → file
    const rest = [];
    if (mode === 'order') {
      list.forEach((f, i) => { if (i < slots.length) target.set(i, f); else report.skipped.push(f.name); });
      report.byOrder = target.size;
    } else {
      // Два прохода: сначала по названию, потом по номеру, чтобы «03.png» не вытеснил «sunny.png».
      const pending = [];
      for (const f of list) {
        const idx = matchText(f.name);
        if (idx >= 0 && !target.has(idx)) { target.set(idx, f); report.byName++; } else pending.push(f);
      }
      for (const f of pending) {
        const idx = matchNumber(f.name);
        if (idx >= 0 && !target.has(idx)) { target.set(idx, f); report.byName++; } else rest.push(f);
      }
      const project = store.state;
      const free = slots.filter((w) => !target.has(w.index) && !assetFor(project, w.id));
      rest.forEach((f, i) => {
        if (i < free.length) { target.set(free[i].index, f); report.byOrder++; } else report.skipped.push(f.name);
      });
    }
    for (const [idx, f] of target) {
      try { putIcon(store, slots[idx], await fileToPng(f)); } catch (e) { report.errors.push(e.message); }
    }
    store.commit();
    return report;
  }

  // ---- диалог ----
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  let dlg = null;

  function openDialog(store) {
    if (dlg) { dlg.remove(); dlg = null; }
    dlg = document.createElement('div');
    dlg.className = 'wi-overlay';
    dlg.innerHTML = `
      <div class="wi-dialog" role="dialog" aria-label="Иконки погоды">
        <div class="wi-head">
          <b>Иконки погоды</b>
          <span class="wi-count"></span>
          <button type="button" class="wi-close" title="Закрыть">✕</button>
        </div>
        <div class="wi-bulk">
          <label class="btn-file">Загрузить пачкой…
            <input type="file" class="wi-bulk-input" accept="image/png,image/jpeg" multiple hidden>
          </label>
          <select class="wi-mode" title="Как распределять файлы по слотам">
            <option value="name">по имени файла, остальные — по порядку</option>
            <option value="order">строго по порядку (по алфавиту, со слота 0)</option>
          </select>
          <button type="button" class="wi-clear-all">Очистить всё</button>
        </div>
        <div class="wi-report"></div>
        <div class="wi-grid"></div>
        <div class="wi-foot">Пустой слот на часах заменяется: ночные — дневными вариантами, остальные — иконкой «Неизвестно»;
          если нет и её — встроенной заглушкой. Файлы сохраняются в PNG, размер не меняется.</div>
      </div>`;
    document.body.appendChild(dlg);

    const grid = dlg.querySelector('.wi-grid');
    const report = dlg.querySelector('.wi-report');
    const close = () => { if (dlg) { dlg.remove(); dlg = null; } unsub && unsub(); };
    let unsub = null;
    dlg.querySelector('.wi-close').onclick = close;
    dlg.addEventListener('mousedown', (e) => { if (e.target === dlg) close(); });

    const render = () => {
      const project = store.state;
      dlg.querySelector('.wi-count').textContent = `загружено ${customCount(project)} из ${set().length}`;
      grid.innerHTML = set().map((w) => {
        const own = assetFor(project, w.id);
        const r = resolveIndex(project, w.index);
        let thumb, sub;
        if (own) {
          thumb = `<img src="${own.dataUrl}" alt="">`; sub = `${own.width}×${own.height}`;
        } else if (r.source === 'fallback') {
          thumb = `<img class="wi-dim" src="${r.asset.dataUrl}" alt="">`;
          sub = `пусто → как «${esc(set()[r.fromIndex].label)}»`;
        } else {
          thumb = `<span class="wi-dim">${esc(w.glyph)}</span>`; sub = 'пусто → заглушка';
        }
        return `<div class="wi-slot ${own ? 'has' : ''}" data-id="${w.id}">
          <div class="wi-thumb">${thumb}</div>
          <div class="wi-meta"><div class="wi-name">${w.index}. ${esc(w.label)}</div>
            <div class="wi-sub">${esc(w.id)} · ${sub}</div></div>
          <label class="btn-file wi-up" title="Загрузить иконку в этот слот">↑
            <input type="file" accept="image/png,image/jpeg" hidden data-id="${w.id}">
          </label>
          <button type="button" class="wi-del" data-id="${w.id}" ${own ? '' : 'disabled'} title="Очистить слот">✕</button>
        </div>`;
      }).join('');
      grid.querySelectorAll('input[type=file]').forEach((inp) => {
        inp.onchange = async () => {
          const f = inp.files && inp.files[0];
          if (!f) return;
          try { await setOne(store, inp.dataset.id, f); } catch (e) { report.textContent = e.message; }
        };
      });
      grid.querySelectorAll('.wi-del').forEach((b) => { b.onclick = () => clearOne(store, b.dataset.id); });
    };

    dlg.querySelector('.wi-bulk-input').onchange = async (e) => {
      const files = e.target.files;
      if (!files || !files.length) return;
      const mode = dlg.querySelector('.wi-mode').value;
      report.textContent = 'Загружаю…';
      const r = await distribute(store, files, mode);
      const parts = [`Файлов: ${r.total}`];
      if (mode === 'name') parts.push(`по имени: ${r.byName}`, `по порядку: ${r.byOrder}`); else parts.push(`размещено: ${r.byOrder}`);
      if (r.skipped.length) parts.push(`не поместилось: ${r.skipped.length} (${r.skipped.slice(0, 3).join(', ')}${r.skipped.length > 3 ? '…' : ''})`);
      if (r.errors.length) parts.push(`ошибки: ${r.errors.join('; ')}`);
      report.textContent = parts.join(' · ') + '. Проверьте слоты и при необходимости замените вручную.';
      e.target.value = '';
    };
    dlg.querySelector('.wi-clear-all').onclick = () => {
      if (customCount(store.state) && confirm('Удалить все загруженные иконки погоды?')) clearAll(store);
    };

    // Таблица перерисовывается при любых изменениях проекта (кроме момента, когда диалог закрыт).
    unsub = store.subscribe(() => { if (dlg) render(); });
    render();
  }

  return {
    assetFor, customCount, missing, resolveIndex, dataUrlFor, previewAsset, matchFileName,
    setOne, clearOne, clearAll, distribute, openDialog, isIcon,
  };
})();

if (typeof window !== 'undefined') window.WeatherIcons = WeatherIcons;
if (typeof module !== 'undefined' && module.exports) module.exports = WeatherIcons;
