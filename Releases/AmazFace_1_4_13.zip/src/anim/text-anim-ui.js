// src/anim/text-anim-ui.js
//
// Сворачиваемая секция «Анимация текста» в инспекторе. Показывается только для
// компонента «Текст». Рисует только настройки выбранного эффекта; все значения
// пишутся в comp.props.text_anim через store.updateComponentProp (поэтому Undo/Redo,
// сохранение и дубликаты работают как у любых других свойств).
(function (root) {
  'use strict';
  const TA = root.TextAnim;
  const LS_KEY = 'amazface.textanim.open';
  let controller = null;
  let unsub = null;

  const esc = (s) => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  function isOpen() { try { return localStorage.getItem(LS_KEY) !== '0'; } catch (e) { return true; } }
  function setOpen(v) { try { localStorage.setItem(LS_KEY, v ? '1' : '0'); } catch (e) { /* noop */ } }

  // ---- мелкие генераторы разметки -----------------------------------------
  const tipAttr = (tip) => (tip ? ` data-tip="${esc(tip)}"` : '');
  function num(cfg, key, label, tip, opt) {
    opt = opt || {};
    const r = TA.NUM_RANGE[key] || [0, 100000];
    return `<div class="field"${tipAttr(tip)}><label>${label}</label><input type="number" data-ta="${key}" value="${esc(cfg[key])}" min="${opt.min != null ? opt.min : r[0]}" max="${opt.max != null ? opt.max : r[1]}" step="${opt.step || 1}"></div>`;
  }
  function sel(cfg, key, label, options, tip, numeric) {
    const o = options.map((x) => `<option value="${esc(x.value)}" ${String(cfg[key]) === String(x.value) ? 'selected' : ''} ${x.disabled ? 'disabled' : ''}>${esc(x.label)}</option>`).join('');
    return `<div class="field wide"${tipAttr(tip)}><label>${label}</label><select data-ta="${key}"${numeric ? ' data-num="1"' : ''}>${o}</select></div>`;
  }
  function color(cfg, key, label, tip) {
    return `<div class="field"${tipAttr(tip)}><label>${label}</label><input type="color" data-ta="${key}" value="${esc(cfg[key])}"></div>`;
  }
  function check(cfg, key, label, tip, disabled) {
    return `<label class="field checkbox"${tipAttr(tip)}><input type="checkbox" data-ta="${key}" ${cfg[key] ? 'checked' : ''} ${disabled ? 'disabled' : ''}> ${label}</label>`;
  }

  // ---- настройки конкретного эффекта --------------------------------------
  function effectSettings(cfg, comp, info) {
    const kind = info.kind;
    switch (cfg.effect) {
      case 'count': {
        const out = [
          num(cfg, 'count_from', 'Начальное значение', 'С какого числа начинается счёт. Обычно 0.', { min: -1000000000, max: 1000000000 }),
          sel(cfg, 'count_decimals', 'Знаков после запятой', [{ value: -1, label: 'Как в значении' }, { value: 0, label: '0' }, { value: 1, label: '1' }, { value: 2, label: '2' }, { value: 3, label: '3' }], 'Сколько знаков показывать, пока число «накручивается». Итоговое значение всегда показывается в своём обычном формате.', true),
        ];
        if (kind === 'none') {
          out.push(sel(cfg, 'count_to_mode', 'Конечное значение', [{ value: 'source', label: 'Число из текста' }, { value: 'fixed', label: 'Задать своё число' }], 'Для статического текста можно считать до числа из самого текста или до заданного числа.'));
          if (cfg.count_to_mode === 'fixed') out.push(num(cfg, 'count_to', 'Конечное число', 'До какого числа считать. Оно же останется на экране.', { min: -1000000000, max: 1000000000 }));
        } else {
          out.push(`<div class="field wide ta-static" data-tip="Конечное значение — всегда актуальное значение датчика на часах. Вымышленные данные не используются."><label>Конечное значение</label><div class="ta-val">Актуальное значение датчика</div></div>`);
        }
        out.push(sel(cfg, 'count_update', 'Если значение изменилось', [{ value: 'continue', label: 'Плавно дойти до нового' }, { value: 'restart', label: 'Начать счёт заново' }, { value: 'jump', label: 'Сразу показать новое' }], 'Что делать, когда датчик выдал новое значение (например, прибавились шаги).'));
        return out.join('');
      }
      case 'reveal':
        return check(cfg, 'reveal_transparent', 'Начинать с прозрачного', 'Текст плавно проявляется из полной прозрачности сразу в конечный цвет. Начальный цвет не нужен.')
          + (cfg.reveal_transparent ? '' : color(cfg, 'reveal_from', 'Начальный цвет', 'С какого цвета начинается. Для «проявления» выберите цвет фона.'))
          + check(cfg, 'reveal_to_linked', 'Конечный = цвет текста', 'Анимация придёт к цвету, заданному у компонента в поле «Цвет».')
          + (cfg.reveal_to_linked ? '' : color(cfg, 'reveal_to', 'Конечный цвет', 'Цвет, в котором текст останется после анимации.'));
      case 'slide':
        return sel(cfg, 'slide_dir', 'Откуда выезжает', [{ value: 'left', label: 'Слева' }, { value: 'right', label: 'Справа' }, { value: 'top', label: 'Сверху' }, { value: 'bottom', label: 'Снизу' }], 'Сторона, с которой текст приезжает на своё место. Сохранённые координаты компонента не меняются.')
          + num(cfg, 'slide_dist', 'Расстояние, px', 'На сколько пикселей текст смещён в начале анимации.');
      case 'roll': {
        const props = (comp && comp.props) || {};
        const hasTimeSeconds = props.data_source === 'TIME' && TA.timeInfo(props).seconds;
        const digitOptions = [
          { value: 'all', label: 'Все разряды' },
          { value: 'changed', label: 'Только изменившиеся разряды' },
        ];
        if (hasTimeSeconds) {
          digitOptions.push(
            { value: 'seconds', label: 'Только секунды' },
            { value: 'tens', label: 'Только десятки секунд' },
            { value: 'units', label: 'Только единицы секунд' }
          );
        } else {
          if (cfg.roll_digits === 'seconds') digitOptions.push({ value: 'seconds', label: 'Только секунды (нужен формат ЧЧ:ММ:СС)', disabled: true });
          digitOptions.push(
            { value: 'tens', label: 'Только предпоследний разряд' },
            { value: 'units', label: 'Только последний разряд' }
          );
        }
        digitOptions.push({ value: 'off', label: 'Отключено' });
        return num(cfg, 'roll_speed', 'Скорость перебора, смен/с', 'Сколько раз в секунду меняются цифры. Больше — быстрее мелькание, но дороже по батарее.')
          + sel(cfg, 'roll_dir', 'Направление', [{ value: 'up', label: 'Вверх (0→9)' }, { value: 'down', label: 'Вниз (9→0)' }], 'В какую сторону перебираются цифры.')
          + sel(cfg, 'roll_order', 'Порядок разрядов', [{ value: 'together', label: 'Все одновременно' }, { value: 'ltr', label: 'По очереди слева направо' }], 'Выберите, крутятся ли цифры одновременно или последовательно.')
          + sel(cfg, 'roll_digits', 'Какие разряды анимировать', digitOptions, '«Только изменившиеся» анимирует цифры, которые отличаются от предыдущего значения. «Только секунды» доступно для источника «Время» с форматом ЧЧ:ММ:СС.');
      }
      case 'type':
        return sel(cfg, 'type_mode', 'Скорость задаётся', [{ value: 'interval', label: 'Интервалом между символами' }, { value: 'duration', label: 'Общей длительностью' }], 'Либо фиксированная пауза между символами, либо вся строка за заданное время.')
          + (cfg.type_mode === 'interval' ? num(cfg, 'type_interval', 'Интервал, мс', 'Пауза между появлением символов.') : '')
          + sel(cfg, 'type_dir', 'Направление', [{ value: 'ltr', label: 'Слева направо' }, { value: 'rtl', label: 'Справа налево' }], 'С какого края появляются символы.');
      case 'flash':
        return color(cfg, 'flash_color', 'Цвет вспышки', 'Акцентный цвет, в который текст окрашивается в момент изменения.')
          + sel(cfg, 'flash_cond', 'Когда вспыхивать', [{ value: 'any', label: 'При любом изменении' }, { value: 'up', label: 'Только при росте числа' }, { value: 'down', label: 'Только при уменьшении числа' }], 'Условие запуска. Если значение не изменилось, вспышки нет.');
      case 'colon':
        return sel(cfg, 'colon_interval', 'Интервал мигания', [{ value: 1000, label: 'Раз в секунду (экономно)' }, { value: 500, label: '0,5 с (отдельный таймер)' }, { value: 250, label: '0,25 с (отдельный таймер)' }], 'При «раз в секунду» мигание идёт вместе с обновлением времени и не требует своего таймера. Более частое мигание заметно тратит батарею.', true)
          + sel(cfg, 'colon_start', 'Начальное состояние', [{ value: 'visible', label: 'Видно' }, { value: 'hidden', label: 'Скрыто' }], 'Каким двоеточие бывает в момент запуска циферблата.');
      case 'pulse':
        return num(cfg, 'pulse_amp', 'Амплитуда, %', 'На сколько процентов текст увеличивается в пике. Рамка компонента не меняется — оставьте запас по высоте.');
      case 'flip':
        return num(cfg, 'flip_turns', 'Полных оборотов', 'Сколько раз единицы минут проходят все цифры 0–9 перед остановкой на новом значении.');
      default: return '';
    }
  }

  // ---- основная разметка ---------------------------------------------------
  function render(comp, ctx) {
    ctx = ctx || {};
    const info = TA.analyze(comp, { mode: ctx.mode || 'normal' });
    const cfg = info.cfg;
    const fx = TA.EFFECTS[cfg.effect];
    const open = isOpen();
    const h = [];
    h.push(`<div class="insp-section-title ta-title" data-ta-toggle role="button" tabindex="0" aria-expanded="${open}" data-tip="Анимация текста: эффекты появления и изменения для этого текстового компонента. Настройки хранятся в проекте и попадают в index.js.">${open ? '▼' : '▶'} Анимация текста${cfg.enabled ? ' <span class="ta-on">вкл</span>' : ''}</div>`);
    h.push(`<div class="ta-body" ${open ? '' : 'hidden'}>`);
    if (ctx.mode === 'aod') {
      h.push('<div class="insp-note">В AOD-сцене анимации не работают (экран почти не обновляется): здесь всегда показывается итоговое состояние текста. Настройте анимацию в сцене Normal.</div></div>');
      return h.join('');
    }
    h.push(check(cfg, 'enabled', 'Включить анимацию', 'Включает анимацию для этого текста. Выключено — текст экспортируется как обычно.'));
    if (cfg.enabled) {
      const opts = TA.EFFECT_ORDER.map((id) => {
        const e = TA.EFFECTS[id];
        return `<option value="${id}" ${cfg.effect === id ? 'selected' : ''}>${e.icon} ${esc(e.name)}${e.status === 'experimental' ? ' (экспериментально)' : ''}</option>`;
      }).join('');
      h.push(`<div class="field wide" data-tip="Выберите эффект. Под списком — краткое описание."><label>Эффект</label><select data-ta="effect">${opts}</select></div>`);
      h.push(`<div class="ta-desc">${esc(fx.desc)}${fx.status === 'experimental' ? ' <b class="ta-exp">⚗ экспериментальный</b>' : ''}</div>`);
      for (const r of info.reasons) h.push(`<div class="ta-msg ta-bad">⛔ ${esc(r)} Эффект не будет экспортирован.</div>`);
      for (const w of info.warnings) h.push(`<div class="ta-msg ta-warn">⚠ ${esc(w)}</div>`);

      // предпросмотр
      h.push('<div class="insp-section-title">Предпросмотр на холсте</div>');
      h.push(`<div class="ta-preview${info.supported ? '' : ' ta-disabled'}">
        <div class="ta-btns">
          <button type="button" class="insp-inline-btn" data-ta-act="play" ${info.supported ? '' : 'disabled'} data-tip="Проиграть анимацию выбранного текста на холсте с самого начала.">▶ Запустить</button>
          <button type="button" class="insp-inline-btn" data-ta-act="pause" ${info.supported ? '' : 'disabled'} data-tip="Остановить на текущем кадре. Потом можно перемотать ползунком.">⏸ Пауза</button>
          <button type="button" class="insp-inline-btn" data-ta-act="reset" ${info.supported ? '' : 'disabled'} data-tip="Остановить и вернуть текст к обычному виду.">↺ Сбросить</button>
        </div>
        <div class="ta-timeline"><input type="range" min="0" max="1000" value="0" data-ta-seek ${info.supported ? '' : 'disabled'} data-tip="Перемотка по времени анимации: покажет любой промежуточный кадр."><span data-ta-time>0.00 / 0.00 с</span></div>
        <label class="field checkbox" data-tip="Показывает, как текст выглядит в AOD: статичное итоговое состояние без анимации."><input type="checkbox" data-ta-aod> Показать как в AOD</label>
        <div class="ta-demo" data-ta-demo></div>
        <div class="ta-note">Это предпросмотр в браузере. Он не доказывает, что эффект так же сработает на часах — проверьте в симуляторе или на устройстве.</div>
      </div>`);

      // Универсальный фильтр изменения. Он доступен для всех эффектов кроме
      // самостоятельного мигания двоеточия, которое не реагирует на цифры.
      if (cfg.effect !== 'colon') {
        const props = (comp && comp.props) || {};
        const hasSeconds = props.data_source === 'TIME' && TA.timeInfo(props).seconds;
        const trackOptions = [
          { value: 'all', label: 'Любое изменение текста' },
          { value: 'changed', label: 'Только изменение цифр' },
        ];
        if (hasSeconds) {
          trackOptions.push(
            { value: 'seconds', label: 'Изменение секунд (две цифры)' },
            { value: 'tens', label: 'Изменение десятков секунд' },
            { value: 'units', label: 'Изменение единиц секунд' }
          );
        } else {
          if (cfg.change_digits === 'seconds') trackOptions.push({ value: 'seconds', label: 'Изменение секунд (нужен формат ЧЧ:ММ:СС)', disabled: true });
          trackOptions.push(
            { value: 'tens', label: 'Изменение десятков последнего числа' },
            { value: 'units', label: 'Изменение единиц последнего числа' }
          );
        }
        trackOptions.push({ value: 'off', label: 'Не запускать при изменении' });
        h.push(`<div class="insp-section-title">Условие запуска по разрядам</div><div class="insp-grid">${sel(cfg, 'change_digits', 'Какие изменения учитывать', trackOptions, 'Для «Рулетки цифр» и «Печатной машинки» можно анимировать только изменившиеся цифры. Для «Проявления» и «Пульсации размера» выбранные цифры получают независимые цвет/размер; в экспортируемом циферблате для них создаются отдельные текстовые виджеты. «Выезд» и «Вспышка» по-прежнему действуют на весь текстовый виджет.')}</div>`);
      }

      // настройки эффекта
      h.push(`<div class="insp-section-title">Настройки эффекта</div><div class="insp-grid">${effectSettings(cfg, comp, info)}</div>`);

      // общие
      const common = [];
      if (fx.uses.indexOf('dur') >= 0) common.push(num(cfg, 'duration', 'Длительность, мс', 'Сколько миллисекунд длится один проход анимации.', { step: 50 }));
      if (fx.uses.indexOf('delay') >= 0) common.push(num(cfg, 'delay', 'Задержка, мс', 'Пауза перед стартом после срабатывания запуска.', { step: 50 }));
      if (fx.uses.indexOf('ease') >= 0) common.push(sel(cfg, 'easing', 'Плавность', TA.EASINGS, 'Как меняется скорость: равномерно, с разгоном, с торможением или мягко в начале и в конце.'));
      if (common.length) h.push(`<div class="insp-section-title">Время и плавность</div><div class="insp-grid">${common.join('')}</div>`);

      // запуск и повторение
      const run = [];
      if (fx.triggers.indexOf('open') >= 0) run.push(check(cfg, 'on_open', 'При открытии циферблата', 'Запускать при запуске циферблата.'));
      if (fx.triggers.indexOf('wake') >= 0) run.push(check(cfg, 'on_wake', 'При пробуждении экрана ⚠', 'Повторять, когда экран включается снова (событие возврата на циферблат). Не проверено на всех прошивках.'));
      if (fx.triggers.indexOf('change') >= 0) run.push(check(cfg, 'on_change', cfg.effect === 'roll' ? 'При изменении текста/времени' : 'При изменении текста', cfg.effect === 'roll' ? 'Запускать рулетку при обновлении значения. Для времени с секундами это происходит каждую секунду и расходует батарею; режим разрядов можно настроить выше.' : 'Запускать заново, когда содержимое текста действительно изменилось. Если значение то же — анимации нет.'));
      if (fx.triggers.indexOf('wake') >= 0) {
        run.push(`<label class="field checkbox ta-unavail" data-tip="В Zepp OS нет отдельного надёжного события «поднятие руки». Когда подъём руки включает экран, срабатывает запуск «При пробуждении экрана». Подмена постоянным опросом не используется."><input type="checkbox" disabled> При поднятии руки — недоступно</label>`);
      }
      if (fx.uses.indexOf('rep') >= 0) {
        run.push(num(cfg, 'repeat', 'Повторить ещё раз', '0 — выполнить один раз. Бесконечного повтора нет: он держал бы таймер и батарею.'));
        if (cfg.repeat > 0) run.push(num(cfg, 'pause', 'Пауза между, мс', 'Пауза между повторами.', { step: 100 }));
      }
      if (fx.triggers.length) run.push(sel(cfg, 'retrigger', 'Если запуск уже идёт', [{ value: 'restart', label: 'Начать с начала' }, { value: 'ignore', label: 'Игнорировать новый запуск' }], 'Что делать, если новый запуск пришёл до окончания текущей анимации.'));
      if (run.length) h.push(`<div class="insp-section-title">Запуск и повторение</div><div class="insp-grid">${run.join('')}</div>`);
      if (!fx.triggers.length && cfg.effect !== 'colon') h.push('<div class="ta-note">Этот эффект запускается сам при изменении времени.</div>');

      // AOD
      h.push(`<div class="insp-section-title">Поведение в AOD</div>
        <div class="insp-grid"><div class="field wide" data-tip="В AOD экран почти не обновляется, поэтому анимации там отключены: показывается итоговое значение, таймеры останавливаются.">
        <label>В режиме AOD</label><select data-ta="aod" disabled><option>Статичное итоговое состояние</option></select></div></div>`);
      if (info.unverified.length) h.push('<div class="ta-note">⚠ Для работы на часах используются API Zepp OS, не подтверждённые документацией полностью — подробности появятся в предупреждениях экспорта.</div>');
    }
    h.push('</div>');
    return h.join('');
  }

  function fmtTime(ms) { return (Math.max(0, ms) / 1000).toFixed(2); }

  function bind(rootEl, comp, store, ctl) {
    if (unsub) { unsub(); unsub = null; }
    controller = ctl || controller;
    const title = rootEl.querySelector('[data-ta-toggle]');
    if (!title) return;
    const open = isOpen();
    if (store.state.mode === 'aod') { if (controller) controller.detach(); return; }

    const toggle = () => {
      const now = !isOpen();
      setOpen(now);
      if (!now && controller) controller.detach();
      store._emit();
    };
    title.addEventListener('click', toggle);
    title.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(); } });

    const current = () => {
      const c = store.state.components.find((x) => x.id === comp.id);
      return TA.normalize(c && c.props && c.props.text_anim);
    };
    const save = (cfg) => store.updateComponentProp(comp.id, 'text_anim', cfg);

    rootEl.querySelectorAll('[data-ta]').forEach((el) => {
      el.addEventListener('change', () => {
        const key = el.dataset.ta;
        const cur = current();
        let value = el.type === 'checkbox' ? el.checked : (el.type === 'number' || el.dataset.num ? Number(el.value) : el.value);
        if (key === 'effect') { save(TA.withEffect(cur, value)); return; }
        if (key === 'enabled' && value && !(store.state.components.find((x) => x.id === comp.id).props || {}).text_anim) {
          // Первое включение: подбираем разумный эффект под источник данных.
          const kind = TA.sourceKind((comp.props || {}).data_source);
          const eff = kind === 'sensor' ? 'count' : kind === 'time' ? 'roll' : 'type';
          save(Object.assign(TA.withEffect(cur, eff), { enabled: true }));
          return;
        }
        save(TA.normalize(Object.assign({}, cur, { [key]: value })));
      });
    });

    if (!open || !controller) return;
    controller.attach(comp.id);
    const play = rootEl.querySelector('[data-ta-act="play"]');
    const pause = rootEl.querySelector('[data-ta-act="pause"]');
    const reset = rootEl.querySelector('[data-ta-act="reset"]');
    const seek = rootEl.querySelector('[data-ta-seek]');
    const timeEl = rootEl.querySelector('[data-ta-time]');
    const demoEl = rootEl.querySelector('[data-ta-demo]');
    const aodEl = rootEl.querySelector('[data-ta-aod]');
    if (play) play.onclick = () => controller.restart();
    if (pause) pause.onclick = () => controller.pause();
    if (reset) reset.onclick = () => controller.reset();
    if (seek) seek.oninput = () => { const s = controller.getState(); controller.seek((Number(seek.value) / 1000) * s.duration); };
    if (aodEl) aodEl.onchange = () => controller.setAod(aodEl.checked);
    const paint = (s) => {
      if (!seek || !seek.isConnected) return;
      if (s.duration) seek.value = String(Math.round((s.t / s.duration) * 1000));
      if (timeEl) timeEl.textContent = fmtTime(s.t) + ' / ' + fmtTime(s.duration) + ' с' + (s.perpetual ? ' (цикл)' : '');
      if (demoEl) demoEl.textContent = s.demo ? '🧪 ' + s.demo : '';
      if (pause) pause.textContent = s.playing ? '⏸ Пауза' : '⏸ Пауза';
      if (aodEl) aodEl.checked = !!s.aod;
    };
    paint(controller.getState());
    unsub = controller.subscribe(paint);
  }

  function dispose() { if (unsub) { unsub(); unsub = null; } }

  const api = { render, bind, dispose, isOpen, effectSettings };
  root.TextAnimUI = api;
  if (root !== globalThis) globalThis.TextAnimUI = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
