// src/anim/text-anim.js
//
// Анимация ТОЛЬКО для компонента «Текст» (defId === 'text').
// Здесь живёт всё, что не зависит ни от DOM, ни от генератора кода:
//   • реестр эффектов (EFFECTS) и общая модель настроек (defaults / normalize);
//   • проверка применимости (analyze) — честные предупреждения для редактора и экспорта;
//   • ЕДИНЫЙ исходник рантайма (RUNTIME_CORE + RUNTIME_FX): расчёт прогресса,
//     функции плавности и сами эффекты. Он выполняется в предпросмотре через
//     new Function(...) и дословно вставляется в index.js — поэтому математика
//     предпросмотра и часов совпадает по построению;
//   • сессия предпросмотра (createSession) — чистая функция «время → кадр».
//
// Файл — классический скрипт (без модулей), как и весь проект; в Node тот же
// файл подключается через require() для тестов.
(function (root) {
  'use strict';

  const SCHEMA = 1;

  // ---------------------------------------------------------------------------
  // Источники данных текста → «род» источника
  // ---------------------------------------------------------------------------
  const TIME_SOURCES = ['TIME', 'AMPM', 'DATE', 'WEEKDAY', 'HOUR', 'MINUTE', 'SECOND', 'DAY', 'MONTH', 'YEAR'];
  const SENSOR_SOURCES = ['BATTERY', 'STEP', 'HEART', 'CALORIE', 'DISTANCE', 'ALTITUDE', 'AIR_PRESSURE'];

  // 'none' — статический текст; 'time' — время/дата; 'sensor' — датчики, которые
  // экспортёр читает сам; 'native' — значение подставляет прошивка (TEXT_FONT):
  // приложение его не видит, поэтому анимировать такой текст нельзя.
  function sourceKind(source) {
    const s = source || 'NONE';
    if (s === 'NONE') return 'none';
    if (TIME_SOURCES.indexOf(s) >= 0) return 'time';
    if (SENSOR_SOURCES.indexOf(s) >= 0) return 'sensor';
    return 'native';
  }

  // ---------------------------------------------------------------------------
  // Плавность
  // ---------------------------------------------------------------------------
  const EASINGS = [
    { value: 'linear', label: 'Линейная', tip: 'Равномерное изменение от начала до конца.' },
    { value: 'in', label: 'Ускорение в начале', tip: 'Медленный старт, затем всё быстрее.' },
    { value: 'out', label: 'Замедление в конце', tip: 'Быстрый старт, плавное торможение у конечного значения.' },
    { value: 'inout', label: 'Плавное начало и завершение', tip: 'Мягкий разгон и мягкое торможение.' },
  ];

  // ---------------------------------------------------------------------------
  // Реестр эффектов
  //   kinds     — для каких источников данных эффект имеет смысл
  //   uses      — какие общие настройки показывать
  //   triggers  — какие запуски допустимы (open — при открытии, wake — при пробуждении
  //               экрана, change — при изменении текста)
  //   dur       — длительность по умолчанию
  //   status    — 'stable' | 'experimental'
  // ---------------------------------------------------------------------------
  const EFFECTS = {
    count: {
      id: 'count', name: 'Счёт до значения', icon: '🔢', status: 'stable',
      desc: 'Число плавно «накручивается» от начального значения до конечного — шаги, калории, пульс, заряд.',
      kinds: ['sensor', 'none'], kindHint: 'Работает с датчиками и с числом в статическом тексте. Для времени используйте «Рулетку цифр».',
      uses: ['dur', 'delay', 'ease', 'rep'], triggers: ['open', 'wake'], dur: 1200,
    },
    reveal: {
      id: 'reveal', name: 'Проявление', icon: '🌅', status: 'stable',
      desc: 'Цвет текста плавно меняется от начального к конечному (например, из цвета фона — «проявляется»).',
      kinds: ['time', 'sensor', 'none'], uses: ['dur', 'delay', 'ease', 'rep'], triggers: ['open', 'wake', 'change'], dur: 800,
    },
    slide: {
      id: 'slide', name: 'Выезд', icon: '➡️', status: 'stable',
      desc: 'Текст выезжает с заданной стороны на своё обычное место. Координаты компонента не меняются.',
      kinds: ['time', 'sensor', 'none'], uses: ['dur', 'delay', 'ease', 'rep'], triggers: ['open', 'wake', 'change'], dur: 500,
    },
    roll: {
      id: 'roll', name: 'Рулетка цифр', icon: '🎰', status: 'stable',
      desc: 'Цифры быстро перебираются и останавливаются на настоящем значении — работает для времени, даты и чисел.',
      kinds: ['time', 'sensor', 'none'], kindHint: 'Нужны цифры в тексте (время, дата, число).',
      uses: ['dur', 'delay', 'rep'], triggers: ['open', 'wake', 'change'], dur: 900,
    },
    type: {
      id: 'type', name: 'Печатная машинка', icon: '⌨️', status: 'stable',
      desc: 'Символы строки появляются по одному. Кириллица, латиница, пробелы и спецсимволы поддерживаются.',
      kinds: ['time', 'sensor', 'none'], uses: ['delay', 'rep'], triggers: ['open', 'wake', 'change'], dur: 1000,
    },
    flash: {
      id: 'flash', name: 'Вспышка при изменении', icon: '⚡', status: 'stable',
      desc: 'Когда значение реально меняется, цвет текста на миг становится акцентным и возвращается обратно.',
      kinds: ['time', 'sensor'], kindHint: 'Нужен меняющийся текст (время или датчик). Статический текст не меняется — вспышки не будет.',
      uses: ['dur', 'ease'], triggers: [], dur: 600,
    },
    colon: {
      id: 'colon', name: 'Мигающее двоеточие', icon: '⏱', status: 'stable',
      desc: 'Двоеточие во времени ЧЧ:ММ мигает. Время при этом остаётся прежним.',
      kinds: ['time'], kindHint: 'Только для источника «Время» в формате ЧЧ:ММ.',
      uses: [], triggers: [], dur: 1000,
    },
    pulse: {
      id: 'pulse', name: 'Пульсация размера', icon: '💓', status: 'experimental',
      desc: 'Размер текста кратко увеличивается и возвращается обратно. Экспериментальный эффект.',
      kinds: ['time', 'sensor', 'none'], uses: ['dur', 'delay', 'ease', 'rep'], triggers: ['open', 'wake', 'change'], dur: 700,
    },
    flip: {
      id: 'flip', name: 'Переворот цифр минут', icon: '🗓', status: 'experimental',
      desc: 'При смене минуты единицы минут «перелистываются» по цифрам, как на табло. Экспериментальный эффект.',
      kinds: ['time'], kindHint: 'Только для источника «Время» (ЧЧ:ММ или ЧЧ:ММ:СС).',
      uses: ['dur'], triggers: [], dur: 600,
    },
  };
  const EFFECT_ORDER = ['count', 'reveal', 'slide', 'roll', 'type', 'flash', 'colon', 'pulse', 'flip'];

  // ---------------------------------------------------------------------------
  // Модель настроек (хранится в comp.props.text_anim; плоский объект)
  // ---------------------------------------------------------------------------
  function defaults() {
    return {
      v: SCHEMA, enabled: false, effect: 'count',
      // общие
      duration: 1200, delay: 0, easing: 'out',
      repeat: 0, pause: 500, retrigger: 'restart',
      on_open: true, on_wake: false, on_change: false,
      // Универсальный фильтр изменений для всех эффектов. Старые проекты сохраняют
      // прежнее поведение: любое изменение текста считается поводом для запуска.
      change_digits: 'all',
      aod: 'static',
      // счёт
      count_from: 0, count_to_mode: 'source', count_to: 1000, count_decimals: -1, count_update: 'continue',
      // проявление
      reveal_from: '#000000', reveal_transparent: false, reveal_to: '#ffffff', reveal_to_linked: true,
      // выезд
      slide_dir: 'left', slide_dist: 60,
      // рулетка
      roll_speed: 20, roll_dir: 'up', roll_order: 'together', roll_digits: 'all',
      // печатная машинка
      type_mode: 'interval', type_interval: 80, type_dir: 'ltr',
      // вспышка
      flash_color: '#ffd35a', flash_cond: 'any',
      // двоеточие
      colon_interval: 1000, colon_start: 'visible',
      // пульсация
      pulse_amp: 12,
      // переворот минут
      flip_turns: 1,
    };
  }

  const CHOICES = {
    easing: EASINGS.map((e) => e.value),
    retrigger: ['restart', 'ignore'],
    aod: ['static'],
    count_to_mode: ['source', 'fixed'],
    count_update: ['continue', 'restart', 'jump'],
    slide_dir: ['left', 'right', 'top', 'bottom'],
    roll_dir: ['up', 'down'],
    roll_order: ['together', 'ltr'],
    roll_digits: ['all', 'changed', 'seconds', 'tens', 'units', 'off'],
    change_digits: ['all', 'changed', 'seconds', 'tens', 'units', 'off'],
    type_mode: ['interval', 'duration'],
    type_dir: ['ltr', 'rtl'],
    flash_cond: ['any', 'up', 'down'],
    colon_interval: [250, 500, 1000],
    colon_start: ['visible', 'hidden'],
    count_decimals: [-1, 0, 1, 2, 3],
  };

  const NUM_RANGE = {
    duration: [100, 10000], delay: [0, 5000], repeat: [0, 10], pause: [0, 5000],
    count_from: [-1000000000, 1000000000], count_to: [-1000000000, 1000000000],
    slide_dist: [4, 480], roll_speed: [4, 60], type_interval: [20, 1000],
    pulse_amp: [2, 30], flip_turns: [0, 3],
  };

  function clampNum(v, lo, hi, fallback) {
    const n = Number(v);
    if (!Number.isFinite(n)) return fallback;
    return Math.max(lo, Math.min(hi, n));
  }
  function normHex(v, fallback) {
    let s = String(v == null ? '' : v).trim();
    if (/^#[0-9a-fA-F]{3}$/.test(s)) s = '#' + s.slice(1).split('').map((c) => c + c).join('');
    return /^#[0-9a-fA-F]{6}$/.test(s) ? s.toLowerCase() : fallback;
  }

  // Приводит произвольный объект (старый проект, ручная правка JSON, undo) к
  // полной валидной конфигурации. Отсутствующая конфигурация = «выключено».
  function normalize(raw) {
    const d = defaults();
    if (!raw || typeof raw !== 'object') return d;
    const o = {};
    o.v = SCHEMA;
    o.enabled = raw.enabled === true;
    o.effect = EFFECTS[raw.effect] ? raw.effect : d.effect;
    for (const key of Object.keys(NUM_RANGE)) {
      const [lo, hi] = NUM_RANGE[key];
      o[key] = clampNum(raw[key], lo, hi, d[key]);
    }
    o.duration = Math.round(o.duration); o.delay = Math.round(o.delay);
    o.repeat = Math.round(o.repeat); o.pause = Math.round(o.pause);
    o.type_interval = Math.round(o.type_interval); o.roll_speed = Math.round(o.roll_speed);
    o.slide_dist = Math.round(o.slide_dist); o.pulse_amp = Math.round(o.pulse_amp); o.flip_turns = Math.round(o.flip_turns);
    for (const key of Object.keys(CHOICES)) {
      const list = CHOICES[key];
      const cand = typeof list[0] === 'number' ? Number(raw[key]) : raw[key];
      o[key] = list.indexOf(cand) >= 0 ? cand : d[key];
    }
    o.reveal_from = normHex(raw.reveal_from, d.reveal_from);
    o.reveal_to = normHex(raw.reveal_to, d.reveal_to);
    o.reveal_to_linked = raw.reveal_to_linked !== false;
    o.reveal_transparent = raw.reveal_transparent === true;
    o.flash_color = normHex(raw.flash_color, d.flash_color);
    o.on_open = raw.on_open !== undefined ? raw.on_open === true : d.on_open;
    o.on_wake = raw.on_wake === true;
    o.on_change = raw.on_change === true;
    // Триггеры, которые эффекту не подходят, принудительно выключаются.
    const fx = EFFECTS[o.effect];
    if (fx.triggers.indexOf('open') < 0) o.on_open = false;
    if (fx.triggers.indexOf('wake') < 0) o.on_wake = false;
    if (fx.triggers.indexOf('change') < 0) o.on_change = false;
    if (fx.uses.indexOf('rep') < 0) o.repeat = 0;
    return o;
  }

  // Конфигурация эффекта «по умолчанию» при выборе в списке: сбрасывает
  // длительность и запуск к разумным значениям эффекта, остальные настройки
  // (в том числе параметры других эффектов) сохраняются.
  function withEffect(cfg, effectId) {
    const fx = EFFECTS[effectId];
    if (!fx) return normalize(cfg);
    const next = Object.assign({}, normalize(cfg), { effect: effectId, duration: fx.dur });
    next.on_open = fx.triggers.indexOf('open') >= 0;
    next.on_wake = false;
    next.on_change = false;
    if (effectId === 'type') next.duration = 1000;
    if (effectId === 'count') next.easing = 'out';
    return normalize(next);
  }

  function hexToInt(hex) {
    const h = normHex(hex, '#ffffff').slice(1);
    return parseInt(h, 16);
  }
  function intToHex(n) {
    return '#' + ('000000' + ((Number(n) >>> 0) & 0xffffff).toString(16)).slice(-6);
  }

  // ---------------------------------------------------------------------------
  // Время/дата: формат и маска цифр рулетки
  // ---------------------------------------------------------------------------
  function timeInfo(props) {
    const p = props || {};
    const fmt = String(p.time_format || 'HH:MM');
    return {
      format: fmt,
      h12: fmt.indexOf('hh') === 0,
      seconds: /:SS$/i.test(fmt),
      leading: p.time_leading_zero !== false,
      separator: p.time_separator === undefined || p.time_separator === null ? ':' : String(p.time_separator),
    };
  }

  // Максимальная цифра для каждой позиции цифр строки. null → любая (0–9).
  // Нужна, чтобы промежуточные кадры рулетки времени не выглядели абсурдно
  // (например, десятки минут не выходили за 5). Итог всегда равен реальному значению.
  function digitMask(props) {
    const p = props || {};
    const src = p.data_source || 'NONE';
    const h12 = (f) => String(f || 'HH').indexOf('hh') === 0;
    switch (src) {
      case 'TIME': {
        const ti = timeInfo(p);
        if (!ti.leading) return null;
        const m = [ti.h12 ? 1 : 2, 9, 5, 9];
        if (ti.seconds) m.push(5, 9);
        return m;
      }
      case 'HOUR': return p.hour_leading_zero === false ? null : [h12(p.hour_format) ? 1 : 2, 9];
      case 'MINUTE': return p.minute_leading_zero === false ? null : [5, 9];
      case 'SECOND': return p.second_leading_zero === false ? null : [5, 9];
      case 'DAY': return p.day_leading_zero === false ? null : [3, 9];
      case 'MONTH': return String(p.month_format || 'MM') === 'MM' ? [1, 9] : null;
      case 'YEAR': return String(p.year_format || 'YYYY') === 'YY' ? [9, 9] : [9, 9, 9, 9];
      case 'DATE': {
        const f = String(p.date_format || 'DD.MM.YYYY');
        const m = [];
        let i = 0;
        while (i < f.length) {
          if (f.substr(i, 4) === 'YYYY') { m.push(9, 9, 9, 9); i += 4; }
          else if (f.substr(i, 4) === 'MMMM') { i += 4; }
          else if (f.substr(i, 3) === 'MMM') { i += 3; }
          else if (f.substr(i, 2) === 'DD') { m.push(3, 9); i += 2; }
          else if (f.substr(i, 2) === 'MM') { m.push(1, 9); i += 2; }
          else i += 1;
        }
        return m.length ? m : null;
      }
      default: return null;
    }
  }

  // ---------------------------------------------------------------------------
  // Проверка применимости: что можно проиграть/экспортировать и о чём честно
  // предупредить. Используется и интерфейсом, и экспортёром.
  // ---------------------------------------------------------------------------
  const API_NOTE = 'Текст: изменение color / x / y / text_size через setProperty(prop.MORE, {...}) — подтверждение в документации Zepp OS неполное, проверьте на часах или в симуляторе';
  const ALPHA_NOTE = 'Текст: плавная прозрачность через setAlpha() у виджета TEXT — подтверждение в документации Zepp OS неполное, проверьте на часах или в симуляторе';
  const WAKE_NOTE = 'Текст: повтор анимации при пробуждении экрана через WIDGET_DELEGATE.resume_call — проверьте на часах (отдельного события «поднятие руки» нет)';

  function hasDigits(s) { return /\d/.test(String(s == null ? '' : s)); }

  function analyze(comp, ctx) {
    ctx = ctx || {};
    const props = (comp && comp.props) || {};
    const cfg = normalize(props.text_anim);
    const res = {
      enabled: cfg.enabled, effect: cfg.effect, cfg, kind: sourceKind(props.data_source),
      supported: true, reasons: [], warnings: [], unverified: [], needsDelegate: false, colonLayout: false,
    };
    if (!cfg.enabled) return res;
    const block = (msg) => { res.supported = false; res.reasons.push(msg); };

    if (!comp || comp.defId !== 'text') { block('Анимация доступна только компоненту «Текст».'); return res; }
    const fx = EFFECTS[cfg.effect];
    const kind = res.kind;
    const src = props.data_source || 'NONE';

    if (kind === 'native') {
      block('Значение этого источника данных подставляет сама прошивка (TEXT_FONT) — приложение не видит момент и значение обновления, поэтому анимировать такой текст нельзя.');
      return res;
    }
    if (props.arc_enabled) {
      block('«Текст по дуге» запекается в PNG при экспорте — анимировать его нельзя. Отключите текст по дуге.');
      return res;
    }
    if (fx.kinds.indexOf(kind) < 0) {
      block(fx.kindHint || 'Эффект не подходит для выбранного источника данных.');
      return res;
    }

    const staticText = String(props.text == null ? '' : props.text);
    const ti = timeInfo(props);

    if (cfg.effect === 'count' && kind === 'none' && !hasDigits(staticText)) block('В тексте нет числа: счёту нечего считать. Впишите число или выберите датчик.');
    if (cfg.effect === 'roll') {
      if (kind === 'none' && !hasDigits(staticText)) block('В тексте нет цифр для рулетки.');
      if (src === 'WEEKDAY' || src === 'AMPM') block('У выбранного источника нет цифр — рулетка ничего не покажет.');
    }
    if (cfg.effect === 'colon') {
      if (src !== 'TIME') block('Мигающее двоеточие работает только с источником «Время».');
      else if (ti.seconds) block('Мигающее двоеточие поддерживает только формат ЧЧ:ММ (без секунд).');
      else if (ti.separator !== ':') block('Мигающее двоеточие работает только с разделителем «:».');
      else if ((props.align_h || 'CENTER_H') !== 'CENTER_H') block('Для мигающего двоеточия выберите выравнивание по X «CENTER_H»: время собирается вокруг двоеточия в центре рамки.');
      else if (Number(comp.w) < Math.round(Number(props.text_size || 36) * 0.38) + 40) block('Рамка текста слишком узкая для мигающего двоеточия — увеличьте ширину.');
      else {
        res.colonLayout = true;
        res.warnings.push('Для двоеточия время собирается из трёх текстовых виджетов (часы, двоеточие, минуты) — их создаёт экспорт, вручную ничего делать не нужно. Расстояние вокруг двоеточия фиксировано (≈0,38 от размера шрифта), поэтому вид может чуть отличаться от обычного текста.');
      }
    }
    if (cfg.effect === 'flip') {
      if (src !== 'TIME') block('Переворот минут работает только с источником «Время».');
    }
    if (!res.supported) return res;

    // --- честные предупреждения -------------------------------------------
    if (fx.status === 'experimental') res.warnings.push('Экспериментальный эффект: надёжность на часах не подтверждена, проверьте результат перед публикацией.');
    const everySecond = kind === 'time' && (src === 'SECOND' || (src === 'TIME' && ti.seconds));
    const changeCycles = cfg.effect === 'flash' || cfg.on_change;
    if (everySecond && changeCycles) res.warnings.push('Текст меняется каждую секунду — анимация будет запускаться каждую секунду. Это заметно расходует батарею; лучше убрать секунды или запуск по изменению.');
    if (everySecond && cfg.effect === 'roll' && !cfg.on_change) { /* нормальный сценарий: рулетка при открытии */ }
    if (props.text_style === 'SCROLL' || props.text_style === 'WRAP') res.warnings.push('Для стиля текста «' + props.text_style + '» поведение анимации не проверялось.');
    if (cfg.effect === 'type' && (props.align_h || 'CENTER_H') === 'CENTER_H') res.warnings.push('При выравнивании по центру текст при печати «растёт» в обе стороны. Для ровной печати выберите выравнивание «LEFT» (или «RIGHT» для печати справа налево).');
    if (cfg.effect === 'pulse') {
      const size = Number(props.text_size || 36), h = Number(comp.h || 0);
      if (h > 0 && size * (1 + cfg.pulse_amp / 100) > h) res.warnings.push('При пульсации текст может выйти за высоту рамки (' + h + ' px) и обрезаться — увеличьте высоту компонента или уменьшите амплитуду.');
    }
    if (cfg.effect === 'slide') {
      const dist = cfg.slide_dist, cx = Number(comp.x || 0), cy = Number(comp.y || 0), W = Number(comp.w || 0), H = Number(comp.h || 0);
      const off = cfg.slide_dir === 'left' ? cx - dist < 0 : cfg.slide_dir === 'right' ? cx + W + dist > 480 : cfg.slide_dir === 'top' ? cy - dist < 0 : cy + H + dist > 480;
      if (off) res.warnings.push('Начальное смещение выводит часть текста за край экрана — в начале анимации он будет частично не виден (так и задумано, если это нужный эффект).');
    }
    const trig = fx.triggers.length ? (cfg.on_open || cfg.on_wake || cfg.on_change) : true;
    if (!trig) res.warnings.push('Ни один запуск не включён — анимация не запустится. Включите «При открытии циферблата» или другой запуск.');
    if (cfg.on_wake) { res.needsDelegate = true; res.unverified.push(WAKE_NOTE); }
    if (cfg.effect === 'colon') res.needsDelegate = true;
    if (cfg.effect === 'count' && kind === 'sensor' && cfg.count_to_mode === 'fixed') { /* для датчиков конечное значение всегда из источника */ }
    res.unverified.push(API_NOTE);
    if (cfg.effect === 'reveal' && cfg.reveal_transparent) res.unverified.push(ALPHA_NOTE);
    return res;
  }

  // ---------------------------------------------------------------------------
  // Единый рантайм: исходник выполняется в предпросмотре и вставляется в index.js.
  // ES5-подобный стиль (var, function): без шаблонных строк и без повторного
  // объявления одной переменной в одной области видимости — экспортёр проверяет
  // это статически.
  // ---------------------------------------------------------------------------
  const RUNTIME_CORE = String.raw`
// ---- Анимация текста (AmazFace): общий рантайм --------------------------------
var __TA = { list: [], all: [], timer: 0, paused: false };
var __taFx = {};
function __taClamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }
function __taEase(name, t) {
  t = __taClamp(t, 0, 1);
  if (name === 'in') return t * t * t;
  if (name === 'out') { var u = 1 - t; return 1 - u * u * u; }
  if (name === 'inout') return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
  return t;
}
function __taMix(c1, c2, t) {
  var r = Math.round(((c1 >> 16) & 255) * (1 - t) + ((c2 >> 16) & 255) * t);
  var g = Math.round(((c1 >> 8) & 255) * (1 - t) + ((c2 >> 8) & 255) * t);
  var b = Math.round((c1 & 255) * (1 - t) + (c2 & 255) * t);
  return (r << 16) | (g << 8) | b;
}
function __taChars(s) {
  var out = [], i = 0, n, c;
  s = String(s == null ? '' : s);
  n = s.length;
  while (i < n) {
    c = s.charCodeAt(i);
    if (c >= 0xD800 && c <= 0xDBFF && i + 1 < n) { out.push(s.substr(i, 2)); i += 2; }
    else { out.push(s.charAt(i)); i += 1; }
  }
  return out;
}
function __taParseNum(s) {
  var m = /-?\d[\d,]*(?:\.\d+)?/.exec(String(s == null ? '' : s));
  if (!m) return null;
  var tok = m[0], clean = tok.replace(/,/g, ''), dot = clean.indexOf('.');
  return { pre: String(s).slice(0, m.index), post: String(s).slice(m.index + tok.length), val: parseFloat(clean), dec: dot >= 0 ? clean.length - dot - 1 : 0, sep: tok.indexOf(',') >= 0 };
}
function __taFmtNum(n, dec, sep) {
  var s = Math.abs(n).toFixed(dec), parts;
  if (sep) { parts = s.split('.'); parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ','); s = parts.join('.'); }
  return (n < 0 && parseFloat(s.replace(/,/g, '')) !== 0 ? '-' : '') + s;
}
function __taGroups(s) {
  var out = [], re = /\d+/g, m;
  s = String(s == null ? '' : s);
  while ((m = re.exec(s)) !== null) out.push({ i: m.index, s: m[0] });
  return out;
}
function __taPhase(a, el) {
  var c = a.cfg, d = c.delay || 0, dur = Math.max(1, a.durOv || c.dur), n = c.rep || 0, gap = c.pause || 0, t, cyc, rep, q, k;
  if (a.perp) return { k: 0, e: 0, ms: Math.max(0, el), rep: 0, done: false, hold: false };
  if (el < d) return { k: 0, e: __taEase(c.ease, 0), ms: 0, rep: 0, done: false, hold: true };
  t = el - d; cyc = dur + gap;
  if (t >= n * cyc + dur) return { k: 1, e: 1, ms: dur, rep: n, done: true, hold: false };
  rep = Math.floor(t / cyc); q = t - rep * cyc; k = q >= dur ? 1 : q / dur;
  return { k: k, e: __taEase(c.ease, k), ms: q >= dur ? dur : q, rep: rep, done: false, hold: false };
}
function __taFinal(a) {
  var s = { text: a.text, color: a.base.fin, x: a.base.x, y: a.base.y, size: a.base.size, vis: true, alpha: 255 }, fx = __taFx[a.cfg.fx];
  if (fx.final) fx.final(a, s);
  return s;
}
function __taSample(a, el) {
  var ph = __taPhase(a, el), s = __taFinal(a), fx = __taFx[a.cfg.fx], o, key;
  if (ph.done) return { s: s, done: true, ph: ph };
  o = fx.frame(a, ph.k, ph);
  for (key in o) { if (Object.prototype.hasOwnProperty.call(o, key)) s[key] = o[key]; }
  return { s: s, done: false, ph: ph };
}
function __taAlpha(target, v) {
  var wd = target;
  if (!wd) return;
  try { wd.setAlpha(v); } catch (e) {}
}
function __taApply(a, s) {
  var o = {}, any = false, L = a.last, cut, tx = s.text, rest;
  if (a.cellLayout) {
    __taApplyCells(a, s);
    a.last = { text: tx, text2: null, color: s.color, x: s.x, y: s.y, size: s.size, vis: s.vis, alpha: s.alpha };
    return;
  }
  if (a.w2) {
    cut = tx.indexOf(a.cfg.sep);
    rest = cut >= 0 ? tx.slice(cut + a.cfg.sep.length) : '';
    if (cut >= 0) tx = tx.slice(0, cut);
    if (rest !== L.text2) { try { a.w2.setProperty(prop.MORE, { text: rest }); } catch (e1) {} L.text2 = rest; }
  }
  if (tx !== L.text) { o.text = tx; any = true; }
  if (s.color !== L.color) { o.color = s.color; any = true; }
  if (s.x !== L.x) { o.x = s.x; any = true; }
  if (s.y !== L.y) { o.y = s.y; any = true; }
  if (s.size !== L.size) { o.text_size = s.size; any = true; }
  if (a.c && s.vis !== L.vis) { try { a.c.setProperty(prop.VISIBLE, s.vis); } catch (e2) {} }
  if (s.alpha !== L.alpha && s.alpha !== undefined) {
    __taAlpha(a.w, s.alpha); __taAlpha(a.w2, s.alpha); __taAlpha(a.c, s.alpha);
  }
  a.last = { text: tx, text2: L.text2, color: s.color, x: s.x, y: s.y, size: s.size, vis: s.vis, alpha: s.alpha };
  if (any && a.w) { try { a.w.setProperty(prop.MORE, o); } catch (e3) {} }
}
function __taShow(a) { __taApply(a, __taFinal(a)); }
// Условия повторного запуска эффектов при изменении исходного текста.
// Для «Проявления» и «Пульсации размера» посимвольный режим дополнительно
// ограничивает сами стили изменившимися разрядами; остальные эффекты фильтруют запуск целиком.
function __taChangeAllowed(a, oldText, newText) {
  var mode = a.cfg.track || 'all', oldD, newD, i, off;
  if (mode === 'all') return true;
  if (mode === 'off') return false;
  oldD = String(oldText == null ? '' : oldText).replace(/[^0-9]/g, '');
  newD = String(newText == null ? '' : newText).replace(/[^0-9]/g, '');
  if (mode === 'changed') return oldD !== newD;
  if (mode === 'seconds' && !a.cfg.trackSec) return false;
  if (mode === 'units') off = 1;
  else if (mode === 'tens') off = 2;
  else if (mode === 'seconds') {
    for (i = 1; i <= 2; i++) {
      if (oldD.charAt(oldD.length - i) !== newD.charAt(newD.length - i)) return true;
    }
    return false;
  } else return true;
  if (oldD.length < off || newD.length < off) return false;
  return oldD.charAt(oldD.length - off) !== newD.charAt(newD.length - off);
}
// Определяет только цифры, которым разрешено анимироваться в посимвольных режимах.
function __taCharTargets(a, why) {
  var cur = __taChars(a.text), old = __taChars(a.prevText || ''), mode = a.cfg.track || 'all';
  var digits = [], target = {}, i, idx, off;
  for (i = 0; i < cur.length; i++) if (cur[i] >= '0' && cur[i] <= '9') digits.push(i);
  if (why === 'open') {
    if (mode === 'seconds' && a.cfg.trackSec) {
      off = Math.max(0, digits.length - 2);
      for (i = off; i < digits.length; i++) target[digits[i]] = true;
    } else if (mode === 'tens' || mode === 'units') {
      off = mode === 'tens' ? digits.length - 2 : digits.length - 1;
      if (off >= 0) target[digits[off]] = true;
    } else if (mode === 'changed') {
      for (i = 0; i < digits.length; i++) target[digits[i]] = true;
    }
    return target;
  }
  if (why !== 'update' && why !== 'wake') return target;
  if (mode === 'seconds') {
    if (!a.cfg.trackSec) return target;
    off = Math.max(0, digits.length - 2);
    for (i = off; i < digits.length; i++) { idx = digits[i]; if (old[idx] !== cur[idx]) target[idx] = true; }
  } else if (mode === 'tens' || mode === 'units') {
    off = mode === 'tens' ? digits.length - 2 : digits.length - 1;
    if (off >= 0) { idx = digits[off]; if (old[idx] !== cur[idx]) target[idx] = true; }
  } else {
    for (i = 0; i < digits.length; i++) { idx = digits[i]; if (old[idx] !== cur[idx]) target[idx] = true; }
  }
  return target;
}
function __taApplyCells(a, s) {
  var l = a.cellLayout, ws = l.widgets, chars = __taChars(s.text), n = ws.length;
  var count = Math.min(chars.length, n), gap = Number(l.gap || 0), total = 0, start, x, cellX, i, ch, col, size, o, prev, w, cw, scale, renderW, al, widths = [];
  // La anchura de composición siempre usa la métrica base para que una pulsación
  // no empuje las cifras vecinas. Solo se ensancha la celda animada, simétricamente.
  for (i = 0; i < count; i++) {
    ch = chars[i]; cw = Math.max(1, Number((l.charWidths && l.charWidths[ch]) || l.defaultWidth || 1));
    widths[i] = cw; total += cw;
  }
  if (count > 1) total += gap * (count - 1);
  if (l.align === 'LEFT') start = Number(l.x || 0);
  else if (l.align === 'RIGHT') start = Number(l.x || 0) + Number(l.w || 0) - total;
  else start = Number(l.x || 0) + Number(l.w || 0) / 2 - total / 2;
  x = start;
  if (!a.cellLast) a.cellLast = [];
  for (i = 0; i < n; i++) {
    ch = i < count ? chars[i] : '';
    cw = i < count ? widths[i] : Math.max(1, Number(l.defaultWidth || 1));
    col = s.charColors && s.charColors[i] != null ? s.charColors[i] : s.color;
    size = s.charSizes && s.charSizes[i] != null ? s.charSizes[i] : s.size;
    scale = a.base.size > 0 ? Math.max(1, Number(size || a.base.size) / a.base.size) : 1;
    renderW = Math.max(cw, Math.ceil(cw * scale));
    cellX = x - (renderW - cw) / 2;
    prev = a.cellLast[i] || { text: null, color: null, size: null, x: null, w: null, alpha: 255 };
    al = s.charAlphas && s.charAlphas[i] != null ? s.charAlphas[i] : (s.alpha == null ? 255 : s.alpha);
    o = {};
    if (ch !== prev.text) o.text = ch;
    if (col !== prev.color) o.color = col;
    if (size !== prev.size) o.text_size = size;
    if (Math.round(cellX) !== prev.x) o.x = Math.round(cellX);
    if (renderW !== prev.w) o.w = renderW;
    w = ws[i];
    if (Object.keys(o).length && w) { try { w.setProperty(prop.MORE, o); } catch (e) {} }
    if (al !== prev.alpha) __taAlpha(w, al);
    a.cellLast[i] = { text: ch, color: col, size: size, x: Math.round(cellX), w: renderW, alpha: al };
    x += cw + gap;
  }
}

function __taEnsure() {
  var ms = 1000, i;
  if (__TA.timer || !__TA.list.length) return;
  for (i = 0; i < __TA.list.length; i++) { if (__TA.list[i].step < ms) ms = __TA.list[i].step; }
  __TA.timer = setInterval(__taStep, Math.max(30, ms));
}
function __taDrop(a) {
  var i = __TA.list.indexOf(a);
  if (i >= 0) __TA.list.splice(i, 1);
  if (!__TA.list.length && __TA.timer) { clearInterval(__TA.timer); __TA.timer = 0; }
}
function __taStep() {
  var now = Date.now(), keep = [], i, a, r, fx;
  for (i = 0; i < __TA.list.length; i++) {
    a = __TA.list[i];
    r = __taSample(a, now - a.t0);
    fx = __taFx[a.cfg.fx];
    if (r.done) { a.on = false; if (fx.done) fx.done(a); __taShow(a); }
    else { __taApply(a, r.s); keep.push(a); }
  }
  __TA.list = keep;
  if (!keep.length && __TA.timer) { clearInterval(__TA.timer); __TA.timer = 0; }
}
function __taBegin(a, why) {
  var fx = __taFx[a.cfg.fx];
  a.durOv = 0;
  if (fx.init) fx.init(a, why);
  a.t0 = Date.now(); a.on = true; a.why = why;
}
function __taPlay(a, why) {
  var r;
  if (__TA.paused) return;
  if (a.on && a.cfg.retrig === 'ignore') return;
  __taBegin(a, why);
  r = __taSample(a, 0);
  __taApply(a, r.s);
  if (__TA.list.indexOf(a) < 0) __TA.list.push(a);
  __taEnsure();
}
function __taStop(a) { a.on = false; __taDrop(a); __taShow(a); }
function __taSetText(a, text) {
  var c = a.cfg, fx = __taFx[c.fx], old = a.text, changed;
  text = text == null ? '' : String(text);
  changed = text !== old;
  a.prevText = old;
  a.text = text;
  if (fx.live) { fx.live(a, old, text, changed); return; }
  if (!a.opened) {
    if (fx.can && !fx.can(a)) { __taShow(a); return; }
    a.opened = true;
    if (c.open) __taPlay(a, 'open'); else __taShow(a);
    return;
  }
  if (!changed) { if (!a.on) __taShow(a); return; }
  // Применяется одинаково ко всем эффектам с обработчиком изменения (в том числе
  // count/flash/flip, у которых специальная обработка обновления значения).
  // При проигнорированном изменении сразу показываем новое значение без старого кадра.
  if (!__taChangeAllowed(a, old, text)) { if (a.on) __taStop(a); else __taShow(a); return; }
  if (fx.onChange) { fx.onChange(a, old, text); return; }
  if (c.change && (!fx.can || fx.can(a))) { __taPlay(a, 'update'); return; }
  if (!a.on) __taShow(a);
}
function __taCreate(w, cfg, base, w2, cw, cellLayout) {
  var fx = __taFx[cfg.fx];
  var a = { w: w, w2: w2 || null, c: cw || null, cellLayout: cellLayout || null, cellLast: [], charMode: !!cfg.charMode || !!cellLayout, charTargets: null, cfg: cfg, base: base, text: '', prevText: '', t0: 0, on: false, opened: false, why: '', durOv: 0, perp: !!(fx.perp && cfg.iv < 1000), blink: 0, cnt: null, curV: null, fl: null, step: 50, last: { text: null, text2: null, color: base.fin, x: base.x, y: base.y, size: base.size, vis: true, alpha: 255 } };
  a.step = fx.step ? fx.step(cfg) : 50;
  __TA.all.push(a);
  return a;
}
function __taPause() {
  var i, a;
  __TA.paused = true;
  if (__TA.timer) { clearInterval(__TA.timer); __TA.timer = 0; }
  __TA.list = [];
  for (i = 0; i < __TA.all.length; i++) { a = __TA.all[i]; a.on = false; __taShow(a); }
}
function __taResume() {
  var now = Date.now(), i, a, fx;
  __TA.paused = false;
  for (i = 0; i < __TA.all.length; i++) {
    a = __TA.all[i]; fx = __taFx[a.cfg.fx];
    if (!a.opened) continue;
    if (fx.resume) { fx.resume(a); continue; }
    if (a.cfg.wake && now - a.t0 > 800) __taPlay(a, 'wake');
  }
}
function __taDestroy() {
  if (__TA.timer) { clearInterval(__TA.timer); __TA.timer = 0; }
  __TA.list = []; __TA.all = []; __TA.paused = false;
}
`;

  const RUNTIME_FX = {
    count: String.raw`{
  step: function () { return 50; },
  can: function (a) { return !!__taParseNum(a.text); },
  init: function (a, why) {
    var c = a.cfg, p = __taParseNum(a.text), from = c.from;
    if (!p) { a.cnt = null; return; }
    if (why === 'update' && a.curV !== null) from = a.curV;
    a.cnt = { p: p, from: from, to: c.fixed ? c.to : p.val };
  },
  frame: function (a, k, ph) {
    var n = a.cnt, v;
    if (!n) return {};
    v = n.from + (n.to - n.from) * ph.e;
    a.curV = v;
    return { text: n.p.pre + __taFmtNum(v, a.cfg.dec >= 0 ? a.cfg.dec : n.p.dec, n.p.sep) + n.p.post };
  },
  final: function (a, s) {
    var p = __taParseNum(a.text);
    if (a.cfg.fixed && p) s.text = p.pre + __taFmtNum(a.cfg.to, a.cfg.dec >= 0 ? a.cfg.dec : p.dec, p.sep) + p.post;
  },
  done: function (a) {
    var p = __taParseNum(a.text);
    a.curV = a.cfg.fixed ? a.cfg.to : (p ? p.val : null);
  },
  onChange: function (a, old, text) {
    var c = a.cfg;
    if (!__taParseNum(text) || c.upd === 'jump') { __taStop(a); return; }
    __taPlay(a, c.upd === 'restart' ? 'restart' : 'update');
  }
}`,
    reveal: String.raw`{
  step: function () { return 50; },
  init: function (a, why) { if (a.charMode) a.charTargets = __taCharTargets(a, why); },
  frame: function (a, k, ph) {
    var colors, alphas, ch, i, al;
    if (a.cfg.ta) {
      // «Из прозрачного»: цвет сразу конечный, меняется только прозрачность 0 → 255.
      al = Math.round(255 * ph.e);
      if (a.charMode) {
        alphas = []; ch = __taChars(a.text);
        for (i = 0; i < ch.length; i++) alphas[i] = a.charTargets && a.charTargets[i] ? al : 255;
        return { charAlphas: alphas };
      }
      return { alpha: al };
    }
    if (a.charMode) {
      colors = []; ch = __taChars(a.text);
      for (i = 0; i < ch.length; i++) colors[i] = a.charTargets && a.charTargets[i] ? __taMix(a.cfg.c1, a.base.fin, ph.e) : null;
      return { charColors: colors };
    }
    return { color: __taMix(a.cfg.c1, a.base.fin, ph.e) };
  }
}`,
    slide: String.raw`{
  step: function () { return 40; },
  frame: function (a, k, ph) {
    var c = a.cfg, o = (1 - ph.e) * c.dist, dx = 0, dy = 0;
    if (c.dir === 'left') dx = -o; else if (c.dir === 'right') dx = o; else if (c.dir === 'top') dy = -o; else dy = o;
    return { x: Math.round(a.base.x + dx), y: Math.round(a.base.y + dy) };
  }
}`,
    roll: String.raw`{
  step: function (c) { return Math.max(30, Math.min(100, Math.round(1000 / Math.max(1, c.speed)))); },
  can: function (a) { return /\d/.test(a.text); },
  frame: function (a, k, ph) {
    var c = a.cfg, ch = __taChars(a.text), prevChars = __taChars(a.prevText || ''), idx = [], prev = [], q, n, tick, sg, w, mx, v, stopK;
    for (q = 0; q < ch.length; q++) { if (ch[q] >= '0' && ch[q] <= '9') idx.push(q); }
    for (q = 0; q < prevChars.length; q++) { if (prevChars[q] >= '0' && prevChars[q] <= '9') prev.push(prevChars[q]); }
    n = idx.length;
    if (!n) return {};
    tick = Math.floor((ph.ms / 1000) * c.speed);
    sg = c.dir === 'down' ? -1 : 1;
    for (w = 0; w < n; w++) {
      if (c.digits === 'off' ||
          (c.digits === 'seconds' && (!c.sec || w < n - 2)) ||
          (c.digits === 'tens' && w !== n - 2) ||
          (c.digits === 'units' && w !== n - 1) ||
          (c.digits === 'changed' && prev.length === n && prev[w] === ch[idx[w]])) continue;
      stopK = c.order === 'ltr' ? (w + 1) / n : 1;
      if (k >= stopK) continue;
      mx = (c.mask && c.mask[w] !== undefined && c.mask[w] !== null) ? c.mask[w] : 9;
      v = (((tick * sg + w * 3) % (mx + 1)) + (mx + 1)) % (mx + 1);
      ch[idx[w]] = String(v);
    }
    return { text: ch.join('') };
  }
}`,
    type: String.raw`{
  step: function (c) { return Math.max(30, Math.min(80, c.tint)); },
  init: function (a, why) {
    var ch = __taChars(a.text), old = __taChars(a.prevText || ''), mode = a.cfg.track || 'all';
    var digitIdx = [], targets = [], i, d, oldChar, changed;
    a.typeTargets = null;
    if (why === 'update' && mode !== 'all' && mode !== 'off') {
      for (i = 0; i < ch.length; i++) if (ch[i] >= '0' && ch[i] <= '9') digitIdx.push(i);
      for (i = 0; i < digitIdx.length; i++) {
        d = digitIdx[i]; oldChar = d < old.length ? old[d] : '';
        changed = oldChar !== ch[d];
        if (mode === 'changed' && changed) targets.push(d);
        else if (mode === 'seconds' && a.cfg.trackSec && i >= digitIdx.length - 2 && changed) targets.push(d);
        else if (mode === 'tens' && i === digitIdx.length - 2 && changed) targets.push(d);
        else if (mode === 'units' && i === digitIdx.length - 1 && changed) targets.push(d);
      }
      a.typeTargets = targets;
    }
    a.durOv = a.cfg.tmode === 'interval' ? Math.max(1, (a.typeTargets ? a.typeTargets.length : ch.length)) * a.cfg.tint : 0;
  },
  frame: function (a, k) {
    var ch = __taChars(a.text), n = ch.length, cnt, out, i, idx, visible;
    if (a.typeTargets) {
      n = a.typeTargets.length; cnt = Math.min(n, Math.floor(k * n)); out = ch.slice();
      for (i = 0; i < n; i++) {
        visible = a.cfg.tdir === 'rtl' ? i >= n - cnt : i < cnt;
        if (!visible) out[a.typeTargets[i]] = '';
      }
      return { text: out.join('') };
    }
    cnt = Math.min(n, Math.floor(k * n));
    return { text: a.cfg.tdir === 'rtl' ? ch.slice(n - cnt).join('') : ch.slice(0, cnt).join('') };
  }
}`,
    flash: String.raw`{
  step: function () { return 50; },
  onChange: function (a, old, text) {
    var c = a.cfg, go = true, n1, n2;
    if (c.cond === 'up' || c.cond === 'down') {
      n1 = __taParseNum(old); n2 = __taParseNum(text);
      go = !!(n1 && n2) && (c.cond === 'up' ? n2.val > n1.val : n2.val < n1.val);
    }
    __taShow(a);
    if (go) __taPlay(a, 'change');
  },
  frame: function (a, k, ph) { return { color: __taMix(a.cfg.fc, a.base.fin, ph.e) }; }
}`,
    colon: String.raw`{
  perp: true,
  step: function (c) { return c.iv; },
  live: function (a, old, text, changed) {
    var c = a.cfg, vis;
    a.opened = true;
    if (__TA.paused) { __taShow(a); return; }
    if (c.iv >= 1000) {
      a.blink = a.blink + 1;
      vis = (((a.blink - 1) % 2) === 0) === (c.cstart === 'visible');
      __taApply(a, { text: text, color: a.base.fin, x: a.base.x, y: a.base.y, size: a.base.size, vis: vis });
    } else if (!a.on) {
      __taPlay(a, 'open');
    } else {
      __taApply(a, { text: text, color: a.base.fin, x: a.base.x, y: a.base.y, size: a.base.size, vis: a.last.vis });
    }
  },
  resume: function (a) { if (a.cfg.iv < 1000) __taPlay(a, 'open'); },
  frame: function (a, k, ph) {
    var c = a.cfg, on = (Math.floor(ph.ms / c.iv) % 2) === 0;
    return { vis: on === (c.cstart === 'visible') };
  }
}`,
    pulse: String.raw`{
  step: function () { return 50; },
  init: function (a, why) { if (a.charMode) a.charTargets = __taCharTargets(a, why); },
  frame: function (a, k, ph) {
    var sizes, ch, i, peak;
    peak = Math.max(1, Math.round(a.base.size * (1 + (a.cfg.amp / 100) * Math.sin(Math.PI * ph.e))));
    if (a.charMode) {
      sizes = []; ch = __taChars(a.text);
      for (i = 0; i < ch.length; i++) sizes[i] = a.charTargets && a.charTargets[i] ? peak : null;
      return { charSizes: sizes };
    }
    return { size: peak };
  }
}`,
    flip: String.raw`{
  step: function () { return 60; },
  can: function (a) { return __taGroups(a.text).length > 1; },
  onChange: function (a, old, text) {
    var g1 = __taGroups(old), g2 = __taGroups(text), s1, s2, u1, u2;
    if (g1.length < 2 || g2.length < 2 || g1[1].s === g2[1].s) { if (!a.on) __taShow(a); return; }
    s1 = g1[1].s; s2 = g2[1].s;
    u1 = parseInt(s1.charAt(s1.length - 1), 10); u2 = parseInt(s2.charAt(s2.length - 1), 10);
    a.fl = { u1: u1, steps: ((u2 - u1 + 10) % 10) + a.cfg.turns * 10, oldTens: s1.slice(0, s1.length - 1) };
    if (a.fl.steps < 1) { a.fl = null; __taShow(a); return; }
    __taPlay(a, 'update');
  },
  frame: function (a, k) {
    var f = a.fl, g, grp, j, tens;
    if (!f) return {};
    g = __taGroups(a.text);
    if (g.length < 2) return {};
    grp = g[1];
    j = Math.min(f.steps, Math.floor(k * (f.steps + 1)));
    tens = j >= f.steps ? grp.s.slice(0, grp.s.length - 1) : f.oldTens;
    return { text: a.text.slice(0, grp.i) + tens + String((f.u1 + j) % 10) + a.text.slice(grp.i + grp.s.length) };
  }
}`,
  };

  // Исходник рантайма для заданного набора эффектов (для index.js — только нужные).
  function runtimeSource(effectIds) {
    const ids = (effectIds && effectIds.length ? effectIds : Object.keys(RUNTIME_FX)).filter((id) => RUNTIME_FX[id]);
    const lines = [RUNTIME_CORE.replace(/^\n/, '')];
    for (const id of ids) lines.push('__taFx.' + id + ' = ' + RUNTIME_FX[id] + ';');
    return lines.join('\n') + '\n';
  }

  // ---------------------------------------------------------------------------
  // Конфигурация рантайма (то, что уходит в index.js и в предпросмотр)
  // ---------------------------------------------------------------------------
  function charModeEnabled(c, p) {
    const mode = c && c.change_digits;
    const source = (p && p.data_source) || 'NONE';
    const numericModes = ['changed', 'seconds', 'tens', 'units'];
    const supportedSources = ['NONE', 'TIME', 'DATE', 'HOUR', 'MINUTE', 'SECOND', 'DAY', 'MONTH', 'YEAR', 'BATTERY', 'STEP', 'HEART', 'CALORIE', 'DISTANCE', 'ALTITUDE', 'AIR_PRESSURE'];
    if (!c || (c.effect !== 'reveal' && c.effect !== 'pulse') || numericModes.indexOf(mode) < 0) return false;
    if (supportedSources.indexOf(source) < 0) return false;
    if (source === 'NONE' && String((p && p.text) || '').length > 24) return false;
    return true;
  }
  function runtimeConfig(cfg, comp) {
    const c = normalize(cfg);
    const p = (comp && comp.props) || {};
    const fx = EFFECTS[c.effect];
    const rc = {
      fx: c.effect, dur: c.duration, delay: c.delay, ease: c.easing,
      rep: c.repeat, pause: c.pause, retrig: c.retrigger,
      open: c.on_open, wake: c.on_wake, change: c.on_change,
      track: c.change_digits, trackSec: p.data_source === 'TIME' && timeInfo(p).seconds,
      charMode: charModeEnabled(c, p),
    };
    if (c.effect === 'count') {
      Object.assign(rc, { from: c.count_from, to: c.count_to, fixed: c.count_to_mode === 'fixed' && sourceKind(p.data_source) === 'none', dec: c.count_decimals, upd: c.count_update });
    } else if (c.effect === 'reveal') {
      rc.c1 = hexToInt(c.reveal_from);
      if (c.reveal_transparent) rc.ta = 1;
    } else if (c.effect === 'slide') {
      Object.assign(rc, { dir: c.slide_dir, dist: c.slide_dist });
    } else if (c.effect === 'roll') {
      Object.assign(rc, { speed: c.roll_speed, dir: c.roll_dir, order: c.roll_order, sec: p.data_source === 'TIME' && timeInfo(p).seconds });
      if (c.roll_digits !== 'all') rc.digits = c.roll_digits;
      const mask = digitMask(p);
      if (mask) rc.mask = mask;
    } else if (c.effect === 'type') {
      Object.assign(rc, { tmode: c.type_mode, tint: c.type_interval, tdir: c.type_dir });
    } else if (c.effect === 'flash') {
      Object.assign(rc, { fc: hexToInt(c.flash_color), cond: c.flash_cond });
    } else if (c.effect === 'colon') {
      Object.assign(rc, { iv: c.colon_interval, cstart: c.colon_start, sep: ':' });
    } else if (c.effect === 'pulse') {
      rc.amp = c.pulse_amp;
    } else if (c.effect === 'flip') {
      rc.turns = c.flip_turns;
    }
    if (fx && fx.triggers.indexOf('open') < 0) rc.open = false;
    return rc;
  }

  // Базовое состояние виджета: цвет после анимации (fin) у «Проявления» — конечный цвет.
  function baseState(cfg, comp, size) {
    const c = normalize(cfg);
    const p = (comp && comp.props) || {};
    const color = hexToInt(p.color || '#ffffff');
    const fin = c.effect === 'reveal' && !c.reveal_to_linked ? hexToInt(c.reveal_to) : color;
    return { x: Math.round(Number(comp.x || 0)), y: Math.round(Number(comp.y || 0)), color: color, fin: fin, size: Math.round(Number(size || p.text_size || 36)) };
  }

  // Литерал JS: числа-цвета (c1, fc, fin, color) — в hex, остальное — как JSON.
  function jsLiteral(value, key) {
    if (value === null || value === undefined) return 'null';
    if (Array.isArray(value)) return '[' + value.map((v) => jsLiteral(v, key)).join(', ') + ']';
    if (typeof value === 'object') {
      return '{ ' + Object.keys(value).map((k) => k + ': ' + jsLiteral(value[k], k)).join(', ') + ' }';
    }
    if (typeof value === 'number') {
      if (key === 'c1' || key === 'fc' || key === 'fin' || key === 'color') return '0x' + ('000000' + (value >>> 0).toString(16)).slice(-6);
      return String(value);
    }
    return JSON.stringify(value);
  }

  // ---------------------------------------------------------------------------
  // Движок для предпросмотра: тот же исходник, но без устройства
  // ---------------------------------------------------------------------------
  const PROP = { MORE: 'more', VISIBLE: 'visible' };
  let _engineCache = null;
  function createEngine() {
    if (_engineCache) return _engineCache;
    const src = runtimeSource() + '\nreturn { TA: __TA, fx: __taFx, create: __taCreate, setText: __taSetText, begin: __taBegin, sample: __taSample, phase: __taPhase, final: __taFinal, parseNum: __taParseNum, fmtNum: __taFmtNum, ease: __taEase, mix: __taMix, chars: __taChars, groups: __taGroups, destroy: __taDestroy, pause: __taPause, resume: __taResume, step: __taStep, play: __taPlay };';
    const timers = { set: 0, cleared: 0 };
    const sI = function () { timers.set++; return timers.set; };
    const cI = function () { timers.cleared++; };
    const fn = new Function('prop', 'setInterval', 'clearInterval', src);
    _engineCache = fn(PROP, sI, cI);
    _engineCache.timers = timers;
    return _engineCache;
  }
  // Свежий движок (свои __TA/таймеры) — для тестов и независимых сессий.
  function createFreshEngine(timerApi) {
    const src = runtimeSource() + '\nreturn { TA: __TA, fx: __taFx, create: __taCreate, setText: __taSetText, begin: __taBegin, sample: __taSample, phase: __taPhase, final: __taFinal, parseNum: __taParseNum, fmtNum: __taFmtNum, ease: __taEase, mix: __taMix, chars: __taChars, groups: __taGroups, destroy: __taDestroy, pause: __taPause, resume: __taResume, step: __taStep, play: __taPlay };';
    const t = timerApi || {};
    const state = { set: 0, cleared: 0, fns: [] };
    const sI = t.setInterval || function (f) { state.set++; state.fns.push(f); return state.set; };
    const cI = t.clearInterval || function () { state.cleared++; };
    const eng = new Function('prop', 'setInterval', 'clearInterval', src)(PROP, sI, cI);
    eng.timers = state;
    return eng;
  }

  // Демонстрационные «следующие» значения для эффектов, которым нужно изменение.
  function demoNext(text, kind, props, changeDigits) {
    const s = String(text == null ? '' : text);
    const m = /(-?\d+)(\D*)$/.exec(s);
    if (kind === 'time') {
      if (props && props.data_source === 'TIME' && timeInfo(props).seconds) {
        const hs = /(\d{1,2})([^\d]+)(\d{2})([^\d]+)(\d{2})(.*)$/.exec(s);
        if (hs) {
          const secStep = changeDigits === 'tens' ? 10 : 1;
          const sec = (parseInt(hs[5], 10) + secStep) % 60;
          const min = parseInt(hs[3], 10), hour = parseInt(hs[1], 10);
          const pad = (n, w) => ('00' + n).slice(-w);
          return s.slice(0, hs.index) + (hs[1].length === 2 ? pad(hour, 2) : String(hour)) + hs[2] + pad(min, 2) + hs[4] + pad(sec, 2) + hs[6];
        }
      }
      const g = /(\d{1,2})([^\d]+)(\d{2})(.*)$/.exec(s);
      if (g) {
        let mm = (parseInt(g[3], 10) + (changeDigits === 'tens' ? 10 : 1)) % 60, hh = parseInt(g[1], 10);
        if (mm === 0) hh = (hh + 1) % 24;
        const pad = (n, w) => ('00' + n).slice(-w);
        return s.slice(0, g.index) + (g[1].length === 2 ? pad(hh, 2) : String(hh)) + g[2] + pad(mm, 2) + g[4];
      }
    }
    if (m) {
      const v = parseInt(m[1], 10) + (changeDigits === 'tens' ? 10 : 1);
      return s.slice(0, m.index) + String(v) + m[2];
    }
    return s;
  }

  function overrideFrom(state, base, extra) {
    const out = Object.assign({
      text: state.text, color: intToHex(state.color), dx: state.x - base.x, dy: state.y - base.y,
      size: state.size, colon: state.vis,
    }, extra || {});
    if (state.alpha != null && state.alpha < 255) out.alpha = state.alpha / 255;
    if (Array.isArray(state.charColors) || Array.isArray(state.charSizes) || Array.isArray(state.charAlphas)) {
      const chars = Array.from(String(state.text == null ? '' : state.text));
      out.char_overrides = chars.map((ch, i) => {
        const o = {};
        if (state.charColors && state.charColors[i] != null) o.color = intToHex(state.charColors[i]);
        if (state.charAlphas && state.charAlphas[i] != null && state.charAlphas[i] < 255) o.alpha = state.charAlphas[i] / 255;
        if (state.charSizes && state.charSizes[i] != null && base.size > 0) {
          const scale = state.charSizes[i] / base.size;
          o.scale_x = scale; o.scale_y = scale;
        }
        return o;
      });
    }
    return out;
  }

  // Сессия предпросмотра: чистая функция «прошедшее время → кадр». Не создаёт
  // таймеров; воспроизведением времени управляет text-anim-preview.js.
  //   opts.text    — текущее содержимое текста в редакторе (то, что видно на холсте)
  //   opts.aod     — показать как в AOD (статичный финал)
  function createSession(comp, opts) {
    opts = opts || {};
    const info = analyze(comp, { mode: 'normal' });
    const cfg = info.cfg;
    const p = (comp && comp.props) || {};
    const size = opts.size || Number(p.text_size || 36);
    const base = baseState(cfg, comp, size);
    const session = {
      info, cfg, base, effect: cfg.effect, perpetual: false, duration: 0, demo: null,
      sample: null, frames: 0,
    };
    if (!cfg.enabled || !info.supported) {
      session.sample = function () { return null; };
      return session;
    }
    const eng = createFreshEngine();
    const rc = runtimeConfig(cfg, comp);
    const fxDef = EFFECTS[cfg.effect];
    const baseText = String(opts.text == null ? '' : opts.text);
    const kind = info.kind;
    // В предпросмотре эффект запускается явной кнопкой, независимо от выбранных триггеров.
    const changeScenario = cfg.effect === 'flash' || cfg.effect === 'flip' || (cfg.effect === 'roll' && cfg.roll_digits === 'changed') || (cfg.effect !== 'colon' && cfg.change_digits !== 'all');
    const rcPlay = Object.assign({}, rc, { open: !changeScenario && cfg.effect !== 'colon', change: changeScenario ? true : rc.change, retrig: 'restart' });
    const hook = { setProperty: function () {} };
    const a = eng.create(hook, rcPlay, base, info.colonLayout ? hook : null, info.colonLayout ? hook : null);
    session._a = a; session._eng = eng;

    if (changeScenario) {
      const next = demoNext(baseText, kind, p, cfg.change_digits);
      eng.setText(a, baseText);
      eng.setText(a, next);
      session.demo = { from: baseText, to: next, label: 'Демо: значение меняется «' + baseText + '» → «' + next + '» (на часах — реальные изменения)' };
    } else {
      eng.setText(a, baseText);
      if (!a.on && !changeScenario) { // для обычного предпросмотра запускаем принудительно; сценарий изменения не подменяем открытием
        eng.begin(a, 'open');
      }
      if (cfg.effect === 'count' && kind === 'sensor') session.demo = { label: 'Демо-значение датчика взято из предпросмотра редактора; на часах будет реальное.' };
    }
    session.perpetual = !!a.perp || cfg.effect === 'colon';
    const fullRun = () => {
      const dur = Math.max(1, a.durOv || rc.dur);
      return (rc.delay || 0) + dur + (rc.rep || 0) * (dur + (rc.pause || 0));
    };
    session.duration = session.perpetual ? Math.max(2000, (rc.iv || 1000) * 4) : (cfg.effect === 'flip' ? Math.max(1, fullRun()) : fullRun());
    session.sample = function (elapsedMs) {
      const el = Math.max(0, Number(elapsedMs) || 0);
      if (opts.aod) return overrideFrom(eng.final(a), base, { done: true, aod: true });
      if (cfg.effect === 'colon' && !a.perp) {
        // режим «раз в секунду»: имитируем смену состояния каждую секунду
        const vis = (Math.floor(el / 1000) % 2 === 0) === (cfg.colon_start === 'visible');
        const st = eng.final(a); st.vis = vis;
        return overrideFrom(st, base, { done: false, colonLayout: true });
      }
      const r = eng.sample(a, el);
      session.frames++;
      return overrideFrom(r.s, base, { done: r.done, hold: !!(r.ph && r.ph.hold), colonLayout: !!info.colonLayout });
    };
    session.finalState = function () { return overrideFrom(eng.final(a), base, { done: true, aod: true, colonLayout: !!info.colonLayout }); };
    session.dispose = function () { try { eng.destroy(); } catch (e) { /* noop */ } };
    return session;
  }

  // ---------------------------------------------------------------------------
  // Данные для экспорта (генерация кода — в text-anim-export.js)
  // ---------------------------------------------------------------------------
  const api = {
    SCHEMA, EFFECTS, EFFECT_ORDER, EASINGS, CHOICES, NUM_RANGE, TIME_SOURCES, SENSOR_SOURCES,
    RUNTIME_CORE, RUNTIME_FX,
    sourceKind, defaults, normalize, withEffect, hexToInt, intToHex, normHex,
    timeInfo, digitMask, analyze, runtimeSource, runtimeConfig, baseState, jsLiteral,
    createEngine, createFreshEngine, createSession, demoNext, API_NOTE, WAKE_NOTE,
  };
  root.TextAnim = api;
  if (root !== globalThis) globalThis.TextAnim = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
