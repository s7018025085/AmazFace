// src/components/triangle.js
// Геометрия компонента «Треугольник» — ЕДИНАЯ для предпросмотра, редактора и экспорта,
// чтобы то, что видно в редакторе, совпадало с тем, что рисуется на часах.
//
// На часах отдельного виджета-треугольника нет. Экспорт строит его через
// hmUI.widget.CANVAS (API_LEVEL 3.0): заливка — canvas.drawPoly({ data_array, color }),
// рамка — canvas.setPaint({ color, line_width }) + canvas.strokePoly({ data_array }).
// Координаты вершин — внутри холста (0,0 — левый верхний угол компонента).
//
// Рамка рисуется по центру линии контура. Чтобы треугольник не вылезал за свой
// размер Ш×В (иначе рамка выходила бы за выделение), контур сдвигается внутрь
// на половину толщины: треугольник пропорционально уменьшается к центру вписанной
// окружности. При угловом соединении «miter» внешний край рамки ложится ровно на
// границу Ш×В. Как именно strokePoly соединяет углы на часах, документация не
// указывает — поэтому у рамки стоит ⚠.
//
// Классический <script> (как и остальные файлы проекта); в Node подключается через vm.

const TriangleModel = (() => {
  const DIRECTIONS = ['UP', 'DOWN', 'LEFT', 'RIGHT'];

  const normDirection = (d) => (DIRECTIONS.includes(d) ? d : 'UP');

  /** Три вершины треугольника, вписанного в рамку w×h (локальные координаты). */
  function baseVertices(direction, w, h) {
    switch (normDirection(direction)) {
      case 'DOWN':  return [{ x: 0, y: 0 }, { x: w, y: 0 }, { x: w / 2, y: h }];
      case 'LEFT':  return [{ x: w, y: 0 }, { x: w, y: h }, { x: 0, y: h / 2 }];
      case 'RIGHT': return [{ x: 0, y: 0 }, { x: 0, y: h }, { x: w, y: h / 2 }];
      default:      return [{ x: w / 2, y: 0 }, { x: w, y: h }, { x: 0, y: h }]; // UP
    }
  }

  const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);

  /** Сжимает треугольник к центру вписанной окружности так, чтобы внутренний радиус уменьшился на inset. */
  function shrink(v, inset) {
    if (!(inset > 0)) return v.map((p) => ({ x: p.x, y: p.y }));
    const [A, B, C] = v;
    const a = dist(B, C), b = dist(C, A), c = dist(A, B);
    const per = a + b + c;
    if (per <= 0) return v.map((p) => ({ x: p.x, y: p.y }));
    const area = Math.abs((B.x - A.x) * (C.y - A.y) - (C.x - A.x) * (B.y - A.y)) / 2;
    const r = (2 * area) / per; // радиус вписанной окружности
    if (r <= 0) return v.map((p) => ({ x: p.x, y: p.y }));
    const I = { x: (a * A.x + b * B.x + c * C.x) / per, y: (a * A.y + b * B.y + c * C.y) / per };
    // Не даём рамке «съесть» весь треугольник: минимум — крошечная точка в центре.
    const k = Math.max(0.02, (r - inset) / r);
    return v.map((p) => ({ x: I.x + (p.x - I.x) * k, y: I.y + (p.y - I.y) * k }));
  }

  const roundPts = (pts) => pts.map((p) => ({ x: Math.round(p.x), y: Math.round(p.y) }));

  /**
   * Нормализованные параметры компонента (значения по умолчанию такие же, как в registry.js).
   * Возвращает плоский объект, чтобы renderer/canvas/exporter не дублировали разбор props.
   */
  function params(comp) {
    const p = (comp && comp.props) || {};
    const w = Math.max(1, Math.round(Number(comp && comp.w) || 1));
    const h = Math.max(1, Math.round(Number(comp && comp.h) || 1));
    return {
      w, h,
      direction: normDirection(p.direction),
      fill: p.fill_enabled !== false,
      color: p.color || '#3366ff',
      stroke: !!p.stroke_enabled,
      strokeColor: p.stroke_color || '#ffffff',
      strokeWidth: Math.max(1, Math.min(40, Math.round(Number(p.stroke_width) || 3))),
    };
  }

  /**
   * Вершины для рисования (округлены до целых, как и уйдут на часы).
   *  - outline: путь рамки (середина линии, сдвинут внутрь на половину толщины);
   *  - fill: заливка. Под рамкой заливается тот же внутренний контур, чтобы цвет заливки
   *    не просвечивал по краю рамки; без рамки — весь треугольник.
   */
  function shape(comp) {
    const q = params(comp);
    const base = baseVertices(q.direction, q.w, q.h);
    const inner = q.stroke ? shrink(base, q.strokeWidth / 2) : base;
    return { ...q, fillPts: roundPts(inner), outlinePts: roundPts(inner) };
  }

  /** Замкнутый массив точек для data_array (последняя точка повторяет первую — как в примере docs.zepp.com). */
  const closed = (pts) => pts.concat([pts[0]]).map((p) => ({ x: p.x, y: p.y }));

  return { DIRECTIONS, normDirection, baseVertices, shrink, params, shape, closed };
})();

// Для Node-тестов (в браузере module не определён).
if (typeof module !== 'undefined' && module.exports) module.exports = TriangleModel;
