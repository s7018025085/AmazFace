// src/components/registry.js
// Internal registry of Zepp OS Watch Face components (hmUI.widget.*).
// Built from ZEPP_API_COMPONENTS.md. DO NOT invent properties not listed here.

const API_LEVELS = ['3.0', '3.5', '4.0', '4.2'];

function apiLevelIndex(level) {
  return API_LEVELS.indexOf(level);
}

function isApiCompatible(componentApiLevel, projectApiLevel) {
  const need = apiLevelIndex(componentApiLevel);
  const have = apiLevelIndex(projectApiLevel);
  return have >= need;
}

// Property field descriptors used by the Inspector to render the right control.
// kind: 'number' | 'color' | 'text' | 'select' | 'checkbox' | 'asset' | 'textarea' | 'weathericon'
const P = (key, kind, opts = {}) => ({ key, kind, ...opts });

const commonGeometry = [
  P('x', 'number', { label: 'X', unit: 'пикс' }),
  P('y', 'number', { label: 'Y', unit: 'пикс' }),
  P('w', 'number', { label: 'Ш', unit: 'пикс' }),
  P('h', 'number', { label: 'В', unit: 'пикс' }),
];

const alignH = ['LEFT', 'CENTER_H', 'RIGHT'];
const alignV = ['TOP', 'CENTER_V', 'BOTTOM'];

const CATEGORIES = [
  'Текст и время', 'Данные', 'Погода', 'Фигуры', 'Холст', 'Изображение', 'Аналоговые стрелки',
];

// ---------------------------------------------------------------------------
// DATA_SOURCES — каталог источников "живых" данных для универсального TEXT
// (см. поле data_source у компонента `text`). Соответствует подсистеме
// hmUI.data_type / @zos/sensor, описанной в ZEPP_API_COMPONENTS.md.
// Точные имена констант hmUI.data_type.* нигде не выдумываются: экспортёр
// (index-js-exporter.js) вставляет явный TODO-комментарий со ссылкой на
// docs.zepp.com вместо угадывания — это сознательное решение проекта.
//
// confidence: 'confirmed' — источник/механизм подтверждён документацией;
//             'unverified' — работает по аналогии/форумным данным, сверьте
//             перед публикацией (в UI помечается значком ⚠).
// ---------------------------------------------------------------------------
const DATA_SOURCES = {
  NONE: {
    label: 'Нет — статический текст',
    confidence: 'confirmed', apiLevel: '3.0',
    note: null,
    fields: [],
  },
  TIME: {
    label: 'Время (часы : минуты [: секунды])',
    confidence: 'confirmed', apiLevel: '3.0',
    note: 'Обновляется через setInterval() из @zos/timer (раз в секунду). Отдельного виджета TIME в hmUI нет — под капотом это TEXT + служебный код автообновления, генерируемый экспортёром.',
    fields: [
      P('time_format', 'select', { label: 'Формат', options: ['HH:MM', 'hh:MM', 'HH:MM:SS', 'hh:MM:SS'], default: 'HH:MM' }),
      P('time_leading_zero', 'checkbox', { label: 'Ведущий ноль у часов', default: true }),
      P('time_separator', 'text', { label: 'Разделитель ЧЧ / ММ / СС', default: ':' }),
    ],
  },
  AMPM: {
    label: 'AM / PM',
    confidence: 'confirmed', apiLevel: '3.0',
    note: 'Обновляется тем же тиком, что и TIME (setInterval из @zos/timer).',
    fields: [
      P('ampm_case', 'select', { label: 'Регистр', options: ['AM/PM', 'am/pm'], default: 'AM/PM' }),
    ],
  },
  DATE: {
    label: 'Дата',
    confidence: 'unverified', apiLevel: '3.0',
    note: 'Готового формат-виджета даты в hmUI нет — Designer генерирует helper-функцию форматирования поверх системного Date().',
    fields: [
      P('date_format', 'select', {
        label: 'Формат',
        options: ['DD.MM.YYYY', 'DD/MM', 'DD MMM', 'MMM DD', 'YYYY-MM-DD', 'DD MMMM'],
        default: 'DD.MM.YYYY',
      }),
      P('date_locale', 'select', { label: 'Язык названий месяцев', options: ['EN', 'RU'], default: 'EN', confidence: 'unverified' }),
    ],
  },
  WEEKDAY: {
    label: 'День недели',
    confidence: 'unverified', apiLevel: '3.0',
    note: 'Название дня — helper-функция на базе Date().getDay(), не отдельный hmUI-виджет.',
    fields: [
      P('weekday_format', 'select', { label: 'Формат', options: [{ value: 'EEE', label: 'Короткий (2 буквы)' }, { value: 'EEE3', label: '3 буквы' }, { value: 'EEEE', label: 'Полностью' }], default: 'EEE' }),
      P('weekday_locale', 'select', { label: 'Язык', options: ['EN', 'RU'], default: 'EN', confidence: 'unverified' }),
    ],
  },
  HOUR: {
    label: 'Часы (отдельно)',
    confidence: 'confirmed', apiLevel: '3.0',
    note: 'Тот же механизм, что и «Время» (TEXT + setInterval из @zos/timer), но выводит только часы — удобно, если часы и минуты нужно стилизовать по отдельности (разный цвет/размер/позиция).',
    fields: [
      P('hour_format', 'select', { label: 'Формат', options: ['HH', 'hh'], default: 'HH' }),
      P('hour_leading_zero', 'checkbox', { label: 'Ведущий ноль', default: true }),
    ],
  },
  MINUTE: {
    label: 'Минуты (отдельно)',
    confidence: 'confirmed', apiLevel: '3.0',
    note: 'TEXT, обновляемый раз в секунду через setInterval — выводит только минуты.',
    fields: [
      P('minute_leading_zero', 'checkbox', { label: 'Ведущий ноль', default: true }),
    ],
  },
  SECOND: {
    label: 'Секунды (отдельно)',
    confidence: 'confirmed', apiLevel: '3.0',
    note: 'TEXT, обновляемый раз в секунду через setInterval — выводит только секунды. Учитывайте влияние частого обновления на батарею.',
    fields: [
      P('second_leading_zero', 'checkbox', { label: 'Ведущий ноль', default: true }),
    ],
  },
  DAY: {
    label: 'День месяца (отдельно)',
    confidence: 'unverified', apiLevel: '3.0',
    note: 'Тот же механизм, что и «Дата» (helper поверх Date(), не отдельный hmUI-виджет) — только число месяца.',
    fields: [
      P('day_leading_zero', 'checkbox', { label: 'Ведущий ноль', default: true }),
    ],
  },
  MONTH: {
    label: 'Месяц (отдельно)',
    confidence: 'unverified', apiLevel: '3.0',
    note: 'Число или название месяца — helper-функция на базе Date().getMonth(), не отдельный hmUI-виджет.',
    fields: [
      P('month_format', 'select', { label: 'Формат', options: ['MM', 'M', 'MMM', 'MMMM'], default: 'MM' }),
      P('month_locale', 'select', { label: 'Язык названия', options: ['EN', 'RU'], default: 'EN', confidence: 'unverified' }),
    ],
  },
  YEAR: {
    label: 'Год (отдельно)',
    confidence: 'unverified', apiLevel: '3.0',
    note: 'Helper-функция на базе Date().getFullYear(), не отдельный hmUI-виджет.',
    fields: [
      P('year_format', 'select', { label: 'Формат', options: ['YYYY', 'YY'], default: 'YYYY' }),
    ],
  },
  BATTERY: {
    label: 'Заряд батареи',
    confidence: 'unverified', apiLevel: '3.0',
    note: 'Значение — new Battery().getCurrent() из @zos/sensor. Точное имя hmUI.data_type.BATTERY не подтверждено цитируемой таблицей документации — при экспорте вставляется TODO со ссылкой на docs.zepp.com вместо угадывания.',
    fields: [
      P('prefix', 'text', { label: 'Префикс', default: '' }),
      P('suffix', 'text', { label: 'Суффикс', default: '%' }),
      P('battery_low_threshold', 'number', {
        label: 'Порог "разряжен", %', default: 15, min: 0, max: 100, confidence: 'unverified',
      }),
    ],
  },
  STEP: {
    label: 'Шаги',
    confidence: 'unverified', apiLevel: '3.0',
    note: 'Значение — new Step().getCurrent() из @zos/sensor.',
    fields: [
      P('prefix', 'text', { label: 'Префикс', default: '' }),
      P('suffix', 'text', { label: 'Суффикс', default: '' }),
      P('step_thousands_sep', 'checkbox', { label: 'Разделитель тысяч (1 000)', default: false }),
    ],
  },
  HEART: {
    label: 'Пульс',
    confidence: 'unverified', apiLevel: '3.0',
    note: '«До 3 символов» подтверждено на официальной странице Watchface Design. Значение — new HeartRate().getCurrent().',
    fields: [
      P('prefix', 'text', { label: 'Префикс', default: '♥ ' }),
      P('suffix', 'text', { label: 'Суффикс', default: '' }),
      P('heart_min_valid', 'number', {
        label: 'Мин. валидное значение (иначе "--")', default: 30, min: 0, max: 250, confidence: 'unverified',
      }),
    ],
  },
  CALORIE: {
    label: 'Калории',
    confidence: 'confirmed', apiLevel: '3.0',
    note: 'Значение — new Calorie().getCurrent() из @zos/sensor (ккал). Отдельный датчик Calorie, не метод Step.',
    fields: [
      P('prefix', 'text', { label: 'Префикс', default: '' }),
      P('suffix', 'text', { label: 'Суффикс', default: ' kcal' }),
      P('calorie_decimals', 'select', { label: 'Знаков после запятой', options: ['0', '1'], default: '0' }),
    ],
  },
  DISTANCE: {
    label: 'Дистанция',
    confidence: 'unverified', apiLevel: '3.0',
    note: 'Значение — new Distance().getCurrent() из @zos/sensor. Сам метод документирован, а вот единица возвращаемого значения в документации не указана — принята за метры (⚠).',
    fields: [
      P('prefix', 'text', { label: 'Префикс', default: '' }),
      P('suffix', 'text', { label: 'Суффикс', default: ' km' }),
      P('distance_unit', 'select', { label: 'Единица', options: ['km', 'mi'], default: 'km', confidence: 'unverified' }),
      P('distance_decimals', 'select', { label: 'Знаков после запятой', options: ['0', '1', '2'], default: '2' }),
    ],
  },
  ALTITUDE: {
    label: 'Высота над уровнем моря',
    confidence: 'confirmed', apiLevel: '3.0',
    note: 'Данные Barometer.getAltitude() из @zos/sensor. Значение в метрах. Требует разрешение device:os.barometer.',
    fields: [
      P('prefix', 'text', { label: 'Префикс', default: '' }),
      P('suffix', 'text', { label: 'Суффикс', default: ' м' }),
      P('altitude_decimals', 'select', { label: 'Знаков после запятой', options: ['0', '1'], default: '0' }),
    ],
  },
  AIR_PRESSURE: {
    label: 'Атмосферное давление',
    confidence: 'confirmed', apiLevel: '3.0',
    note: 'Данные Barometer.getAirPressure() из @zos/sensor. Значение в hPa. Требует разрешение device:os.barometer.',
    fields: [
      P('prefix', 'text', { label: 'Префикс', default: '' }),
      P('suffix', 'text', { label: 'Суффикс', default: ' hPa' }),
      P('pressure_decimals', 'select', { label: 'Знаков после запятой', options: ['0', '1'], default: '0' }),
    ],
  },
  STEP_TARGET: {
    label: 'Цель шагов', confidence: 'confirmed', apiLevel: '3.0',
    note: 'Нативные данные циферблата: hmUI.data_type.STEP_TARGET.',
    fields: [P('native_show_unit','checkbox',{label:'Показывать единицу',default:true})],
  },
  CAL_TARGET: {
    label: 'Цель калорий', confidence: 'confirmed', apiLevel: '3.0',
    note: 'Нативные данные циферблата: hmUI.data_type.CAL_TARGET.',
    fields: [P('native_show_unit','checkbox',{label:'Показывать единицу',default:true})],
  },
  PAI_DAILY: {
    label: 'PAI за сегодня', confidence: 'confirmed', apiLevel: '3.0',
    note: 'Нативные данные циферблата: hmUI.data_type.PAI_DAILY.',
    fields: [P('native_show_unit','checkbox',{label:'Префикс/единица от часов',default:false})],
  },
  PAI_WEEKLY: {
    label: 'PAI за неделю', confidence: 'confirmed', apiLevel: '3.0',
    note: 'Нативные данные циферблата: hmUI.data_type.PAI_WEEKLY.',
    fields: [P('native_show_unit','checkbox',{label:'Префикс/единица от часов',default:false})],
  },
  STAND: {
    label: 'Активность стоя', confidence: 'confirmed', apiLevel: '3.0',
    note: 'Количество часов стояния: hmUI.data_type.STAND.',
    fields: [P('native_show_unit','checkbox',{label:'Показывать единицу',default:true})],
  },
  STAND_TARGET: {
    label: 'Цель стояния', confidence: 'confirmed', apiLevel: '3.0',
    note: 'Целевое количество часов стояния: hmUI.data_type.STAND_TARGET.',
    fields: [P('native_show_unit','checkbox',{label:'Показывать единицу',default:true})],
  },
  HUMIDITY: {
    label: 'Влажность', confidence: 'confirmed', apiLevel: '3.0',
    note: 'Влажность из системных данных циферблата: hmUI.data_type.HUMIDITY.',
    fields: [P('native_show_unit','checkbox',{label:'Показывать единицу',default:true})],
  },
  UVI: {
    label: 'УФ-индекс', confidence: 'confirmed', apiLevel: '3.0',
    note: 'Ультрафиолетовый индекс: hmUI.data_type.UVI.',
    fields: [P('native_show_unit','checkbox',{label:'Показывать единицу',default:true})],
  },
  AQI: {
    label: 'Качество воздуха (AQI)', confidence: 'confirmed', apiLevel: '3.0',
    note: 'AQI доступен только в китайском регионе согласно документации Zepp OS; на других регионах может быть недоступен.',
    fields: [P('native_show_unit','checkbox',{label:'Показывать единицу',default:true})],
  },
  FAT_BURNING: {
    label: 'Время жиросжигания', confidence: 'confirmed', apiLevel: '3.0',
    note: 'Время жиросжигания в минутах: hmUI.data_type.FAT_BURNING.',
    fields: [P('native_show_unit','checkbox',{label:'Показывать единицу',default:true})],
  },
  FAT_BURNING_TARGET: {
    label: 'Цель жиросжигания', confidence: 'confirmed', apiLevel: '3.0',
    note: 'Целевое время жиросжигания: hmUI.data_type.FAT_BURNING_TARGET.',
    fields: [P('native_show_unit','checkbox',{label:'Показывать единицу',default:true})],
  },
  SUN_CURRENT: {
    label: 'До восхода / заката', confidence: 'confirmed', apiLevel: '3.0',
    note: 'Системное значение hmUI.data_type.SUN_CURRENT.',
    fields: [],
  },
  SUN_RISE: {
    label: 'Восход солнца', confidence: 'confirmed', apiLevel: '3.0',
    note: 'Время восхода: hmUI.data_type.SUN_RISE.',
    fields: [],
  },
  SUN_SET: {
    label: 'Закат солнца', confidence: 'confirmed', apiLevel: '3.0',
    note: 'Время заката: hmUI.data_type.SUN_SET.',
    fields: [],
  },
  WIND: {
    label: 'Сила ветра', confidence: 'confirmed', apiLevel: '3.0',
    note: 'Сила ветра: hmUI.data_type.WIND.',
    fields: [P('native_show_unit','checkbox',{label:'Показывать единицу',default:true})],
  },
  STRESS: {
    label: 'Стресс', confidence: 'confirmed', apiLevel: '3.0',
    note: 'Физический уровень стресса: hmUI.data_type.STRESS.',
    fields: [P('native_show_unit','checkbox',{label:'Показывать единицу',default:true})],
  },
  SPO2: {
    label: 'Кислород крови (SpO₂)', confidence: 'confirmed', apiLevel: '3.0',
    note: 'Уровень кислорода крови: hmUI.data_type.SPO2. Доступность зависит от устройства и измерения.',
    fields: [P('native_show_unit','checkbox',{label:'Показывать единицу',default:true})],
  },
  BODY_TEMP: {
    label: 'Температура тела', confidence: 'confirmed', apiLevel: '3.0',
    note: 'Температура поверхности тела: hmUI.data_type.BODY_TEMP. Доступность зависит от устройства.',
    fields: [P('native_show_unit','checkbox',{label:'Показывать единицу',default:true})],
  },
  FLOOR: {
    label: 'Этажи', confidence: 'confirmed', apiLevel: '3.0',
    note: 'Количество пройденных этажей: hmUI.data_type.FLOOR.',
    fields: [P('native_show_unit','checkbox',{label:'Показывать единицу',default:true})],
  },
  ALARM_CLOCK: { label:'Будильник', confidence:'confirmed', apiLevel:'3.0', note:'Системное время будильника: hmUI.data_type.ALARM_CLOCK.', fields:[] },
  COUNT_DOWN: { label:'Таймер обратного отсчёта', confidence:'confirmed', apiLevel:'3.0', note:'Системный обратный отсчёт: hmUI.data_type.COUNT_DOWN.', fields:[] },
  STOP_WATCH: { label:'Секундомер', confidence:'confirmed', apiLevel:'3.0', note:'Системный секундомер: hmUI.data_type.STOP_WATCH.', fields:[] },
  SLEEP: { label:'Сон', confidence:'confirmed', apiLevel:'3.0', note:'Системные данные сна: hmUI.data_type.SLEEP.', fields:[] },
  TRAINING_LOAD: { label:'Тренировочная нагрузка', confidence:'confirmed', apiLevel:'3.0', note:'Тренировочная нагрузка: hmUI.data_type.TRAINING_LOAD.', fields:[] },
  VO2MAX: { label:'VO₂ max', confidence:'confirmed', apiLevel:'3.0', note:'Максимальное потребление кислорода: hmUI.data_type.VO2MAX.', fields:[] },
  RECOVERY_TIME: { label:'Время восстановления', confidence:'confirmed', apiLevel:'3.0', note:'Полное время восстановления: hmUI.data_type.RECOVERY_TIME.', fields:[] },
  MONTH_RUN_TIMES: { label:'Пробежки за месяц', confidence:'confirmed', apiLevel:'3.0', note:'Количество уличных пробежек за месяц: hmUI.data_type.MONTH_RUN_TIMES.', fields:[] },
  MONTH_RUN_DISTANCE: { label:'Пробег за месяц', confidence:'confirmed', apiLevel:'3.0', note:'Дистанция уличного бега за месяц: hmUI.data_type.MONTH_RUN_DISTANCE.', fields:[] },
  READINESS: { label:'Готовность', confidence:'confirmed', apiLevel:'3.0', note:'Физическая и ментальная готовность: hmUI.data_type.READINESS.', fields:[] },
  WEATHER_TEMP: {
    label: 'Погода: температура',
    confidence: 'confirmed', apiLevel: '3.0',
    note: 'Нативная привязка циферблата к hmUI.data_type.WEATHER_CURRENT / WEATHER_LOW / WEATHER_HIGH. Текущее значение берётся самим Zepp OS из синхронизированной погоды.',
    fields: [
      P('weather_temp_source', 'select', {
        label: 'Что показывать', options: [
          { value: 'CURRENT', label: 'Сейчас' },
          { value: 'HIGH', label: 'Сегодня: макс.' },
          { value: 'LOW', label: 'Сегодня: мин.' },
          { value: 'D1_HIGH', label: 'Завтра: макс. ⚠' },
          { value: 'D1_LOW', label: 'Завтра: мин. ⚠' },
          { value: 'D2_HIGH', label: 'Послезавтра: макс. ⚠' },
          { value: 'D2_LOW', label: 'Послезавтра: мин. ⚠' },
        ], default: 'CURRENT',
      }),
      P('weather_unit', 'select', { label: 'Единица', options: ['°C', '°F'], default: '°C' }),
      P('weather_show_degree', 'checkbox', { label: 'Показывать значок °', default: true }),
    ],
  },
};

// Общий набор свойств для «Температура: мин./макс. сегодня» — те же поля, что у weather_temp,
// но источник (LOW/HIGH) задан заранее. Меняется в Inspector, как и у обычной температуры.
function weatherTempPresetProps(source, color) {
  return [
    ...commonGeometry,
    P('text_size', 'number', { label: 'Размер шрифта', default: 32, min: 8, max: 140 }),
    P('color', 'color', { label: 'Цвет', default: color }),
    P('align_h', 'select', { label: 'Выравнивание по X', options: alignH, default: 'CENTER_H' }),
    P('align_v', 'select', { label: 'Выравнивание по Y', options: alignV, default: 'CENTER_V' }),
    P('weather_temp_source', 'select', { label: 'Что показывать', options: [
        { value: 'CURRENT', label: 'Сейчас' },
        { value: 'HIGH', label: 'Сегодня: макс.' },
        { value: 'LOW', label: 'Сегодня: мин.' },
        { value: 'D1_HIGH', label: 'Завтра: макс. ⚠' },
        { value: 'D1_LOW', label: 'Завтра: мин. ⚠' },
        { value: 'D2_HIGH', label: 'Послезавтра: макс. ⚠' },
        { value: 'D2_LOW', label: 'Послезавтра: мин. ⚠' },
      ], default: source }),
    P('unit', 'select', { label: 'Единица', options: ['°C', '°F'], default: '°C' }),
    P('weather_show_degree', 'checkbox', { label: 'Показывать значок °', default: true }),
  ];
}

const REGISTRY = {
  digital_display: {
    id: 'digital_display', name: 'Цифровое табло', category: 'Текст и время',
    widgetId: 'DIGITAL_DISPLAY', apiLevel: '3.0', confidence: 'confirmed',
    description: 'Динамическое цифровое табло: при экспорте каждый символ формата превращается в отдельный прозрачный PNG с полной типографикой TEXT, а на часах обновляется только набор IMG.',
    properties: [
      ...commonGeometry,
      P('data_source', 'select', { label: 'Источник данных', options: [
        { value: 'TIME', label: 'Время' }, { value: 'DATE', label: 'Дата' },
        { value: 'HOUR', label: 'Часы' }, { value: 'MINUTE', label: 'Минуты' },
        { value: 'SECOND', label: 'Секунды' }, { value: 'DAY', label: 'День' },
        { value: 'MONTH', label: 'Месяц' }, { value: 'YEAR', label: 'Год' },
        { value: 'BATTERY', label: 'Батарея' }, { value: 'STEP', label: 'Шаги' },
        { value: 'HEART', label: 'Пульс' }, { value: 'CALORIE', label: 'Калории' },
        { value: 'DISTANCE', label: 'Расстояние' }, { value: 'ALTITUDE', label: 'Высота' },
        { value: 'AIR_PRESSURE', label: 'Давление' }
      ], default: 'TIME' }),
      P('format', 'select', { label: 'Формат', options: ['HH:MM','HH:MM:SS','hh:MM','hh:MM:SS','DD','MM','YYYY','DD.MM','DD/MM','DD.MM.YYYY','YYYY-MM-DD','DD MMM','MMM DD','DD MMMM',{ value: 'EEE', label: 'День недели — коротко (Пн / Mon)' },{ value: 'EEE3', label: 'День недели — 3 буквы (ПОН / MON)' },{ value: 'EEEE', label: 'День недели — полностью' },'HH','SS','0000','00000'], default: 'HH:MM' }),
      P('date_locale', 'select', { label: 'Язык даты / месяца', options: [{ value: 'RU', label: 'Русский' }, { value: 'EN', label: 'English' }], default: 'RU' }),
      P('weekday_locale', 'select', { label: 'Язык дня недели', options: [{ value: 'RU', label: 'Русский' }, { value: 'EN', label: 'English' }], default: 'RU' }),
      P('separator', 'select', { label: 'Разделитель', options: [':', '.', ' ', ''], default: ':' }),
      P('digit_width', 'number', { label: 'Ширина цифры', default: 64, min: 8, max: 240 }),
      P('digit_height', 'number', { label: 'Высота цифры', default: 70, min: 8, max: 240 }),
      P('separator_width', 'number', { label: 'Ширина разделителя', default: 20, min: 4, max: 120 }),
      P('spacing', 'number', { label: 'Расстояние', default: 5, min: 0, max: 80 }),
      P('text_size', 'number', { label: 'Размер шрифта', default: 64, min: 4, max: 480 }),
      P('color', 'color', { label: 'Цвет', default: '#ffd35a' }),
      P('align_h', 'select', { label: 'Выравнивание по X', options: alignH, default: 'CENTER_H' }),
      P('align_v', 'select', { label: 'Выравнивание по Y', options: alignV, default: 'CENTER_V' }),
      P('font', 'font', { label: 'Шрифт', optional: true }),
    ],
    dataBindable: false, dataSourceSelectable: false,
    defaultSize: { w: 220, h: 80 },
  },

  text: {
    id: 'text', name: 'Текст', category: 'Текст и время',
    widgetId: 'TEXT', apiLevel: '3.0', confidence: 'confirmed',
    description: 'Универсальный текстовый виджет hmUI.widget.TEXT. По умолчанию — статичная надпись, но через поле «Источник данных» можно превратить его в live-текст (время, дата, батарея, пульс, шаги, погода и т.д.) с тонкими настройками формата под конкретный источник — не создавая для этого отдельный специализированный компонент.',
    properties: [
      ...commonGeometry,
      P('text', 'text', { label: 'Текст (если источник данных = "Нет")', default: 'Привет' }),
      P('data_source', 'select', { label: 'Источник данных', options: Object.entries(DATA_SOURCES).map(([value, def]) => ({ value, label: def.label })), default: 'NONE' }),
      P('text_size', 'number', { label: 'Размер шрифта', default: 36, min: 8, max: 160 }),
      P('fit_bounds', 'checkbox', { label: 'Вместить в границы (авто-размер)', default: false }),
      P('fit_min_size', 'number', { label: 'Мин. размер при вмещении', default: 8, min: 4, max: 160 }),
      P('arc_enabled', 'checkbox', { label: 'Текст по дуге (статический или день недели)', default: false }),
      P('arc_radius', 'number', { label: 'Радиус дуги, px', default: 150, min: 20, max: 600 }),
      P('arc_bottom', 'checkbox', { label: 'Дуга снизу (читается по низу круга)', default: false }),
      P('color', 'color', { label: 'Цвет', default: '#ffffff' }),
      P('align_h', 'select', { label: 'Выравнивание по X', options: alignH, default: 'CENTER_H' }),
      P('align_v', 'select', { label: 'Выравнивание по Y', options: alignV, default: 'CENTER_V' }),
      P('text_style', 'select', { label: 'Стиль', options: ['NONE', 'WRAP', 'SCROLL'], default: 'NONE', confidence: 'unverified' }),
      P('font', 'font', { label: 'Шрифт', optional: true }),
    ],
    dataBindable: false,
    dataSourceSelectable: true,
    defaultSize: { w: 200, h: 50 },
  },

  time_hm: {
    id: 'time_hm', name: 'Время (ЧЧ:ММ)', category: 'Текст и время',
    widgetId: 'TEXT', apiLevel: '3.0', confidence: 'confirmed',
    description: 'Готовый пресет: TEXT, жёстко привязанный к времени в формате ЧЧ:ММ. Для более гибких настроек (разделитель, ведущий ноль, добавление секунд) используйте компонент «Текст» с источником данных «Время».',
    properties: [
      ...commonGeometry,
      P('text_size', 'number', { label: 'Размер шрифта', default: 72, min: 8, max: 200 }),
      P('color', 'color', { label: 'Цвет', default: '#ffffff' }),
      P('align_h', 'select', { label: 'Выравнивание по X', options: alignH, default: 'CENTER_H' }),
      P('align_v', 'select', { label: 'Выравнивание по Y', options: alignV, default: 'CENTER_V' }),
      P('format', 'select', { label: 'Формат', options: ['HH:MM', 'hh:MM'], default: 'HH:MM' }),
    ],
    dataBindable: true, dataSource: 'TIME',
    defaultSize: { w: 300, h: 100 },
  },

  time_hms: {
    id: 'time_hms', name: 'Время (ЧЧ:ММ:СС)', category: 'Текст и время',
    widgetId: 'TEXT', apiLevel: '3.0', confidence: 'confirmed',
    description: 'Готовый пресет времени с секундами. Требует более частого тика (раз в секунду) — учитывайте влияние на батарею. Гибкая версия — компонент «Текст» → источник данных «Время».',
    properties: [
      ...commonGeometry,
      P('text_size', 'number', { label: 'Размер шрифта', default: 48, min: 8, max: 200 }),
      P('color', 'color', { label: 'Цвет', default: '#ffffff' }),
      P('align_h', 'select', { label: 'Выравнивание по X', options: alignH, default: 'CENTER_H' }),
      P('align_v', 'select', { label: 'Выравнивание по Y', options: alignV, default: 'CENTER_V' }),
      P('format', 'select', { label: 'Формат', options: ['HH:MM:SS', 'hh:MM:SS'], default: 'HH:MM:SS' }),
    ],
    dataBindable: true, dataSource: 'TIME',
    defaultSize: { w: 320, h: 70 },
  },

  ampm: {
    id: 'ampm', name: 'AM/PM', category: 'Текст и время',
    widgetId: 'TEXT', apiLevel: '3.0', confidence: 'confirmed',
    description: 'Небольшой TEXT, показывающий только AM или PM — используйте рядом с 12-часовым временем (формат hh:MM).',
    properties: [
      ...commonGeometry,
      P('text_size', 'number', { label: 'Размер шрифта', default: 24, min: 8, max: 100 }),
      P('color', 'color', { label: 'Цвет', default: '#ffffff' }),
      P('align_h', 'select', { label: 'Выравнивание по X', options: alignH, default: 'CENTER_H' }),
      P('align_v', 'select', { label: 'Выравнивание по Y', options: alignV, default: 'CENTER_V' }),
    ],
    dataBindable: true, dataSource: 'AMPM',
    defaultSize: { w: 80, h: 40 },
  },

  date_full: {
    id: 'date_full', name: 'Дата', category: 'Текст и время',
    widgetId: 'TEXT', apiLevel: '3.0', confidence: 'unverified',
    description: 'TEXT с датой, обновляемой раз в минуту. ⚠ Формат дат в Zepp OS реализуется вручную через Date() — Designer генерирует helper, а не использует "магический" виджет даты.',
    properties: [
      ...commonGeometry,
      P('text_size', 'number', { label: 'Размер шрифта', default: 28, min: 8, max: 120 }),
      P('color', 'color', { label: 'Цвет', default: '#ffffff' }),
      P('align_h', 'select', { label: 'Выравнивание по X', options: alignH, default: 'CENTER_H' }),
      P('align_v', 'select', { label: 'Выравнивание по Y', options: alignV, default: 'CENTER_V' }),
      P('format', 'select', {
        label: 'Формат',
        options: ['DD.MM.YYYY', 'DD MMM', 'MMM DD', 'DD/MM'],
        default: 'DD.MM.YYYY',
      }),
      P('date_locale', 'select', { label: 'Язык названий месяцев', options: ['EN', 'RU'], default: 'EN', confidence: 'unverified' }),
    ],
    dataBindable: true, dataSource: 'DATE',
    defaultSize: { w: 220, h: 40 },
  },

  weekday: {
    id: 'weekday', name: 'День недели', category: 'Текст и время',
    widgetId: 'TEXT', apiLevel: '3.0', confidence: 'unverified',
    description: 'TEXT с названием дня недели (Mon/Monday и т.п.). ⚠ Не отдельный hmUI-виджет — форматирование на стороне JS.',
    properties: [
      ...commonGeometry,
      P('text_size', 'number', { label: 'Размер шрифта', default: 24, min: 8, max: 100 }),
      P('color', 'color', { label: 'Цвет', default: '#ffffff' }),
      P('align_h', 'select', { label: 'Выравнивание по X', options: alignH, default: 'CENTER_H' }),
      P('align_v', 'select', { label: 'Выравнивание по Y', options: alignV, default: 'CENTER_V' }),
      P('format', 'select', { label: 'Формат', options: [{ value: 'EEE', label: 'Короткий (2 буквы)' }, { value: 'EEE3', label: '3 буквы' }, { value: 'EEEE', label: 'Полностью' }], default: 'EEE' }),
      P('weekday_locale', 'select', { label: 'Язык', options: ['EN', 'RU'], default: 'EN', confidence: 'unverified' }),
    ],
    dataBindable: true, dataSource: 'WEEKDAY',
    defaultSize: { w: 120, h: 36 },
  },

  weekday_strip: {
    id: 'weekday_strip', name: 'Неделя (7 дней)', category: 'Текст и время',
    widgetId: 'WEEKDAY_STRIP', apiLevel: '3.0', confidence: 'unverified',
    description: 'Строка из семи дней с маркером текущего дня. Экспортируется как семь подписей и программно переключаемая рамка/плашка.',
    properties: [
      ...commonGeometry,
      P('layout', 'select', { label: 'Расположение', options: [{ value: 'LINE', label: 'В строку' }, { value: 'ARC_TOP', label: 'Дуга сверху' }, { value: 'ARC_BOTTOM', label: 'Дуга снизу' }, { value: 'ARC_LEFT', label: 'Дуга слева' }, { value: 'ARC_RIGHT', label: 'Дуга справа' }], default: 'LINE', group: 'Расположение' }),
      P('arc_depth', 'number', { label: 'Глубина дуги', unit: 'пикс', default: 24, min: 0, max: 160, group: 'Расположение', showIf: (p) => ['ARC', 'ARC_TOP', 'ARC_BOTTOM', 'ARC_LEFT', 'ARC_RIGHT'].includes(p.layout) }),
      P('week_start', 'select', { label: 'Первый день', options: [{ value: 'MONDAY', label: 'Понедельник' }, { value: 'SUNDAY', label: 'Воскресенье' }], default: 'MONDAY', group: 'Подписи' }),
      P('weekday_locale', 'select', { label: 'Язык', options: ['RU', 'EN'], default: 'RU', group: 'Подписи' }),
      P('weekday_format', 'select', { label: 'Подписи', options: [{ value: 'EEE', label: '2–3 знака' }, { value: 'EEE3', label: '3 знака' }, { value: 'EEEE', label: 'Полностью' }], default: 'EEE', group: 'Подписи' }),
      P('text_size', 'number', { label: 'Размер текста', unit: 'пикс', default: 20, min: 8, max: 72, group: 'Подписи' }),
      P('text_color', 'color', { label: 'Цвет текста', default: '#ffffff', group: 'Подписи' }),
      P('container_style', 'select', { label: 'Фон и контур блока', options: [{ value: 'NONE', label: 'Без оформления' }, { value: 'FILL', label: 'Заливка' }, { value: 'FRAME', label: 'Рамка' }, { value: 'FILL_FRAME', label: 'Заливка + рамка' }], default: 'NONE', group: 'Оформление компонента' }),
      P('container_color', 'color', { label: 'Цвет заливки блока', default: '#000000', group: 'Оформление компонента', showIf: (p) => ['FILL', 'FILL_FRAME'].includes(p.container_style) }),
      P('container_border_color', 'color', { label: 'Цвет рамки блока', default: '#ffffff', group: 'Оформление компонента', showIf: (p) => ['FRAME', 'FILL_FRAME'].includes(p.container_style) }),
      P('container_alpha', 'number', { label: 'Прозрачность блока', unit: '%', default: 100, min: 0, max: 100, group: 'Оформление компонента', showIf: (p) => p.container_style !== 'NONE' }),
      P('container_radius', 'number', { label: 'Скругление углов', unit: 'пикс', default: 8, min: 0, max: 120, group: 'Оформление компонента', showIf: (p) => p.container_style !== 'NONE' }),
      P('container_line_width', 'number', { label: 'Толщина рамки', unit: 'пикс', default: 2, min: 1, max: 12, group: 'Оформление компонента', showIf: (p) => ['FRAME', 'FILL_FRAME'].includes(p.container_style) }),
      P('marker_style', 'select', { label: 'Вид маркера', options: [{ value: 'FRAME', label: 'Рамка' }, { value: 'FILL', label: 'Плашка' }, { value: 'FILL_FRAME', label: 'Плашка + рамка' }, { value: 'UNDERLINE', label: 'Подчёркивание' }, { value: 'DOT', label: 'Точка' }, { value: 'NONE', label: 'Без маркера' }], default: 'FRAME', group: 'Маркер' }),
      P('active_text_color', 'color', { label: 'Цвет текста активного дня', default: '#ffffff', group: 'Маркер' }),
      P('marker_color', 'color', { label: 'Цвет плашки / маркера', default: '#ff3158', group: 'Маркер', showIf: (p) => p.marker_style !== 'NONE' }),
      P('marker_alpha', 'number', { label: 'Прозрачность', unit: '%', default: 100, min: 0, max: 100, group: 'Маркер', showIf: (p) => p.marker_style !== 'NONE' }),
      P('marker_border_color', 'color', { label: 'Цвет рамки', default: '#ffffff', group: 'Маркер', showIf: (p) => p.marker_style === 'FILL_FRAME' }),
      P('marker_pad_x', 'number', { label: 'Отступ по X', unit: 'пикс', default: 4, min: 0, max: 40, group: 'Маркер', showIf: (p) => ['FRAME', 'FILL', 'FILL_FRAME'].includes(p.marker_style) }),
      P('marker_pad_y', 'number', { label: 'Отступ по Y', unit: 'пикс', default: 3, min: 0, max: 40, group: 'Маркер', showIf: (p) => ['FRAME', 'FILL', 'FILL_FRAME'].includes(p.marker_style) }),
      P('marker_width', 'number', { label: 'Ширина (0 — авто)', unit: 'пикс', default: 0, min: 0, max: 200, group: 'Маркер', showIf: (p) => ['FRAME', 'FILL', 'FILL_FRAME'].includes(p.marker_style) }),
      P('marker_height', 'number', { label: 'Высота (0 — авто)', unit: 'пикс', default: 0, min: 0, max: 120, group: 'Маркер', showIf: (p) => ['FRAME', 'FILL', 'FILL_FRAME'].includes(p.marker_style) }),
      P('marker_radius', 'number', { label: 'Скругление', unit: 'пикс', default: 8, min: 0, max: 60, group: 'Маркер', showIf: (p) => ['FRAME', 'FILL', 'FILL_FRAME'].includes(p.marker_style) }),
      P('marker_line_width', 'number', { label: 'Толщина линии', unit: 'пикс', default: 2, min: 1, max: 12, group: 'Маркер', showIf: (p) => ['FRAME', 'FILL_FRAME', 'UNDERLINE'].includes(p.marker_style) }),
      P('marker_dot_size', 'number', { label: 'Размер точки', unit: 'пикс', default: 7, min: 2, max: 30, group: 'Маркер', showIf: (p) => p.marker_style === 'DOT' }),
      P('preview_weekday', 'select', { label: 'Показать в редакторе', options: [{ value: 'AUTO', label: 'Сегодня' }, { value: '1', label: 'Понедельник' }, { value: '2', label: 'Вторник' }, { value: '3', label: 'Среда' }, { value: '4', label: 'Четверг' }, { value: '5', label: 'Пятница' }, { value: '6', label: 'Суббота' }, { value: '0', label: 'Воскресенье' }], default: 'AUTO', group: 'Проверка' }),
    ],
    defaultSize: { w: 420, h: 56 },
    note: 'Поддерживаются дуги сверху, снизу, слева и справа. При выборе боковой дуги блок автоматически становится вертикальным, при возврате к строке или верхней/нижней дуге — горизонтальным. День на часах определяется автоматически; «Показать в редакторе» — только режим проверки.',
  },

  time_hour: {
    id: 'time_hour', name: 'Часы (ЧЧ)', category: 'Текст и время',
    widgetId: 'TEXT', apiLevel: '3.0', confidence: 'confirmed',
    description: 'Отдельный TEXT только с часами — удобно, когда часы и минуты стилизуются по-разному (свой цвет/размер/позиция для каждого). Тот же механизм автообновления, что и «Время».',
    properties: [
      ...commonGeometry,
      P('text_size', 'number', { label: 'Размер шрифта', default: 72, min: 8, max: 200 }),
      P('color', 'color', { label: 'Цвет', default: '#ffffff' }),
      P('align_h', 'select', { label: 'Выравнивание по X', options: alignH, default: 'CENTER_H' }),
      P('align_v', 'select', { label: 'Выравнивание по Y', options: alignV, default: 'CENTER_V' }),
      P('hour_format', 'select', { label: 'Формат', options: ['HH', 'hh'], default: 'HH' }),
      P('hour_leading_zero', 'checkbox', { label: 'Ведущий ноль', default: true }),
    ],
    dataBindable: true, dataSource: 'HOUR',
    defaultSize: { w: 150, h: 100 },
  },

  time_minute: {
    id: 'time_minute', name: 'Минуты (ММ)', category: 'Текст и время',
    widgetId: 'TEXT', apiLevel: '3.0', confidence: 'confirmed',
    description: 'Отдельный TEXT только с минутами — используйте вместе с «Часы (ЧЧ)», если нужно развести их по холсту или стилизовать по-разному.',
    properties: [
      ...commonGeometry,
      P('text_size', 'number', { label: 'Размер шрифта', default: 72, min: 8, max: 200 }),
      P('color', 'color', { label: 'Цвет', default: '#ffffff' }),
      P('align_h', 'select', { label: 'Выравнивание по X', options: alignH, default: 'CENTER_H' }),
      P('align_v', 'select', { label: 'Выравнивание по Y', options: alignV, default: 'CENTER_V' }),
      P('minute_leading_zero', 'checkbox', { label: 'Ведущий ноль', default: true }),
    ],
    dataBindable: true, dataSource: 'MINUTE',
    defaultSize: { w: 150, h: 100 },
  },

  time_second: {
    id: 'time_second', name: 'Секунды (СС)', category: 'Текст и время',
    widgetId: 'TEXT', apiLevel: '3.0', confidence: 'confirmed',
    description: 'Отдельный TEXT только с секундами. Требует посекундного тика — учитывайте влияние на батарею.',
    properties: [
      ...commonGeometry,
      P('text_size', 'number', { label: 'Размер шрифта', default: 48, min: 8, max: 200 }),
      P('color', 'color', { label: 'Цвет', default: '#ffffff' }),
      P('align_h', 'select', { label: 'Выравнивание по X', options: alignH, default: 'CENTER_H' }),
      P('align_v', 'select', { label: 'Выравнивание по Y', options: alignV, default: 'CENTER_V' }),
      P('second_leading_zero', 'checkbox', { label: 'Ведущий ноль', default: true }),
    ],
    dataBindable: true, dataSource: 'SECOND',
    defaultSize: { w: 100, h: 70 },
  },

  date_day: {
    id: 'date_day', name: 'День (ДД)', category: 'Текст и время',
    widgetId: 'TEXT', apiLevel: '3.0', confidence: 'unverified',
    description: 'Отдельный TEXT только с числом месяца. ⚠ Как и «Дата» — форматирование на стороне JS, не отдельный hmUI-виджет.',
    properties: [
      ...commonGeometry,
      P('text_size', 'number', { label: 'Размер шрифта', default: 28, min: 8, max: 120 }),
      P('color', 'color', { label: 'Цвет', default: '#ffffff' }),
      P('align_h', 'select', { label: 'Выравнивание по X', options: alignH, default: 'CENTER_H' }),
      P('align_v', 'select', { label: 'Выравнивание по Y', options: alignV, default: 'CENTER_V' }),
      P('day_leading_zero', 'checkbox', { label: 'Ведущий ноль', default: true }),
    ],
    dataBindable: true, dataSource: 'DAY',
    defaultSize: { w: 80, h: 40 },
  },

  date_month: {
    id: 'date_month', name: 'Месяц (ММ)', category: 'Текст и время',
    widgetId: 'TEXT', apiLevel: '3.0', confidence: 'unverified',
    description: 'Отдельный TEXT только с месяцем (числом или названием). ⚠ Форматирование на стороне JS, не отдельный hmUI-виджет.',
    properties: [
      ...commonGeometry,
      P('text_size', 'number', { label: 'Размер шрифта', default: 28, min: 8, max: 120 }),
      P('color', 'color', { label: 'Цвет', default: '#ffffff' }),
      P('align_h', 'select', { label: 'Выравнивание по X', options: alignH, default: 'CENTER_H' }),
      P('align_v', 'select', { label: 'Выравнивание по Y', options: alignV, default: 'CENTER_V' }),
      P('month_format', 'select', { label: 'Формат', options: ['MM', 'M', 'MMM', 'MMMM'], default: 'MM' }),
      P('month_locale', 'select', { label: 'Язык названия', options: ['EN', 'RU'], default: 'EN', confidence: 'unverified' }),
    ],
    dataBindable: true, dataSource: 'MONTH',
    defaultSize: { w: 100, h: 40 },
  },

  date_year: {
    id: 'date_year', name: 'Год (ГГГГ)', category: 'Текст и время',
    widgetId: 'TEXT', apiLevel: '3.0', confidence: 'unverified',
    description: 'Отдельный TEXT только с годом. ⚠ Форматирование на стороне JS, не отдельный hmUI-виджет.',
    properties: [
      ...commonGeometry,
      P('text_size', 'number', { label: 'Размер шрифта', default: 28, min: 8, max: 120 }),
      P('color', 'color', { label: 'Цвет', default: '#ffffff' }),
      P('align_h', 'select', { label: 'Выравнивание по X', options: alignH, default: 'CENTER_H' }),
      P('align_v', 'select', { label: 'Выравнивание по Y', options: alignV, default: 'CENTER_V' }),
      P('year_format', 'select', { label: 'Формат', options: ['YYYY', 'YY'], default: 'YYYY' }),
    ],
    dataBindable: true, dataSource: 'YEAR',
    defaultSize: { w: 120, h: 40 },
  },

  battery: {
    id: 'battery', name: 'Заряд батареи', category: 'Данные',
    widgetId: 'TEXT', apiLevel: '3.0', confidence: 'unverified',
    description: 'TEXT, привязанный к new Battery() из @zos/sensor. ⚠ Точное имя константы hmUI.data_type.BATTERY не подтверждено — при экспорте генерируется TODO-комментарий вместо угадывания.',
    properties: [
      ...commonGeometry,
      P('text_size', 'number', { label: 'Размер шрифта', default: 28, min: 8, max: 120 }),
      P('color', 'color', { label: 'Цвет', default: '#ffffff' }),
      P('align_h', 'select', { label: 'Выравнивание по X', options: alignH, default: 'CENTER_H' }),
      P('align_v', 'select', { label: 'Выравнивание по Y', options: alignV, default: 'CENTER_V' }),
      P('suffix', 'text', { label: 'Суффикс', default: '%' }),
    ],
    dataBindable: true, dataSource: 'BATTERY',
    defaultSize: { w: 100, h: 36 },
  },

  steps: {
    id: 'steps', name: 'Шаги', category: 'Данные',
    widgetId: 'TEXT', apiLevel: '3.0', confidence: 'unverified',
    description: 'TEXT, привязанный к new Step() из @zos/sensor. ⚠ Точное имя hmUI.data_type.STEP не подтверждено цитируемым фрагментом документации.',
    properties: [
      ...commonGeometry,
      P('text_size', 'number', { label: 'Размер шрифта', default: 28, min: 8, max: 120 }),
      P('color', 'color', { label: 'Цвет', default: '#ffffff' }),
      P('align_h', 'select', { label: 'Выравнивание по X', options: alignH, default: 'CENTER_H' }),
      P('align_v', 'select', { label: 'Выравнивание по Y', options: alignV, default: 'CENTER_V' }),
      P('suffix', 'text', { label: 'Суффикс', default: ' шагов' }),
    ],
    dataBindable: true, dataSource: 'STEP',
    defaultSize: { w: 150, h: 36 },
  },

  heart_rate: {
    id: 'heart_rate', name: 'Пульс', category: 'Данные',
    widgetId: 'TEXT', apiLevel: '3.0', confidence: 'unverified',
    description: 'TEXT, привязанный к new HeartRate() из @zos/sensor. «До 3 символов» подтверждено официальной страницей Watchface Design.',
    properties: [
      ...commonGeometry,
      P('text_size', 'number', { label: 'Размер шрифта', default: 28, min: 8, max: 120 }),
      P('color', 'color', { label: 'Цвет', default: '#ffffff' }),
      P('align_h', 'select', { label: 'Выравнивание по X', options: alignH, default: 'CENTER_H' }),
      P('align_v', 'select', { label: 'Выравнивание по Y', options: alignV, default: 'CENTER_V' }),
      P('prefix', 'text', { label: 'Префикс', default: '♥ ' }),
    ],
    dataBindable: true, dataSource: 'HEART',
    defaultSize: { w: 100, h: 36 },
  },

  calories: {
    id: 'calories', name: 'Калории', category: 'Данные',
    widgetId: 'TEXT', apiLevel: '3.0', confidence: 'confirmed',
    description: 'TEXT, привязанный к new Calorie().getCurrent() из @zos/sensor — текущий расход калорий за день, в ккал.',
    properties: [
      ...commonGeometry,
      P('text_size', 'number', { label: 'Размер шрифта', default: 24, min: 8, max: 120 }),
      P('color', 'color', { label: 'Цвет', default: '#ffffff' }),
      P('align_h', 'select', { label: 'Выравнивание по X', options: alignH, default: 'CENTER_H' }),
      P('align_v', 'select', { label: 'Выравнивание по Y', options: alignV, default: 'CENTER_V' }),
      P('suffix', 'text', { label: 'Суффикс', default: ' kcal' }),
    ],
    dataBindable: true, dataSource: 'CALORIE',
    defaultSize: { w: 120, h: 32 },
  },

  distance: {
    id: 'distance', name: 'Расстояние', category: 'Данные',
    widgetId: 'TEXT', apiLevel: '3.0', confidence: 'unverified',
    description: 'TEXT, привязанный к new Distance().getCurrent() из @zos/sensor. ⚠ Единица возвращаемого значения в документации не указана — код исходит из метров и пересчитывает в км/мили.',
    properties: [
      ...commonGeometry,
      P('text_size', 'number', { label: 'Размер шрифта', default: 24, min: 8, max: 120 }),
      P('color', 'color', { label: 'Цвет', default: '#ffffff' }),
      P('align_h', 'select', { label: 'Выравнивание по X', options: alignH, default: 'CENTER_H' }),
      P('align_v', 'select', { label: 'Выравнивание по Y', options: alignV, default: 'CENTER_V' }),
      P('unit', 'select', { label: 'Единица', options: ['km', 'mi'], default: 'km' }),
    ],
    dataBindable: true, dataSource: 'DISTANCE',
    defaultSize: { w: 120, h: 32 },
  },

  altitude: {
    id: 'altitude', name: 'Высота', category: 'Данные',
    widgetId: 'TEXT', apiLevel: '3.0', confidence: 'confirmed',
    description: 'Высота над уровнем моря от барометра часов. Значение в метрах.',
    properties: [
      ...commonGeometry,
      P('text_size', 'number', { label: 'Размер шрифта', default: 26, min: 8, max: 120 }),
      P('color', 'color', { label: 'Цвет', default: '#ffffff' }),
      P('align_h', 'select', { label: 'Выравнивание по X', options: alignH, default: 'CENTER_H' }),
      P('align_v', 'select', { label: 'Выравнивание по Y', options: alignV, default: 'CENTER_V' }),
      P('prefix', 'text', { label: 'Префикс', default: '' }),
      P('suffix', 'text', { label: 'Суффикс', default: ' м' }),
      P('altitude_decimals', 'select', { label: 'Знаков после запятой', options: ['0', '1'], default: '0' }),
    ],
    dataBindable: true, dataSource: 'ALTITUDE',
    defaultSize: { w: 120, h: 36 },
  },

  air_pressure: {
    id: 'air_pressure', name: 'Давление', category: 'Данные',
    widgetId: 'TEXT', apiLevel: '3.0', confidence: 'confirmed',
    description: 'Атмосферное давление от барометра часов. Значение в hPa.',
    properties: [
      ...commonGeometry,
      P('text_size', 'number', { label: 'Размер шрифта', default: 24, min: 8, max: 120 }),
      P('color', 'color', { label: 'Цвет', default: '#ffffff' }),
      P('align_h', 'select', { label: 'Выравнивание по X', options: alignH, default: 'CENTER_H' }),
      P('align_v', 'select', { label: 'Выравнивание по Y', options: alignV, default: 'CENTER_V' }),
      P('prefix', 'text', { label: 'Префикс', default: '' }),
      P('suffix', 'text', { label: 'Суффикс', default: ' hPa' }),
      P('pressure_decimals', 'select', { label: 'Знаков после запятой', options: ['0', '1'], default: '0' }),
    ],
    dataBindable: true, dataSource: 'AIR_PRESSURE',
    defaultSize: { w: 130, h: 36 },
  },

  weather_temp: {
    id: 'weather_temp', name: 'Температура', category: 'Погода',
    widgetId: 'TEXT', apiLevel: '3.0', confidence: 'confirmed',
    description: 'Нативная температура циферблата через hmUI.data_type.WEATHER_CURRENT / WEATHER_HIGH / WEATHER_LOW. Данные предоставляет Zepp OS после синхронизации погоды с телефоном.',
    properties: [
      ...commonGeometry,
      P('text_size', 'number', { label: 'Размер шрифта', default: 32, min: 8, max: 140 }),
      P('color', 'color', { label: 'Цвет', default: '#ffffff' }),
      P('align_h', 'select', { label: 'Выравнивание по X', options: alignH, default: 'CENTER_H' }),
      P('align_v', 'select', { label: 'Выравнивание по Y', options: alignV, default: 'CENTER_V' }),
      P('weather_temp_source', 'select', { label: 'Что показывать', options: [
          { value: 'CURRENT', label: 'Сейчас' },
          { value: 'HIGH', label: 'Сегодня: макс.' },
          { value: 'LOW', label: 'Сегодня: мин.' },
          { value: 'D1_HIGH', label: 'Завтра: макс. ⚠' },
          { value: 'D1_LOW', label: 'Завтра: мин. ⚠' },
          { value: 'D2_HIGH', label: 'Послезавтра: макс. ⚠' },
          { value: 'D2_LOW', label: 'Послезавтра: мин. ⚠' },
        ], default: 'CURRENT', }),
      P('unit', 'select', { label: 'Единица', options: ['°C', '°F'], default: '°C' }),
      P('weather_show_degree', 'checkbox', { label: 'Показывать значок °', default: true }),
    ],
    dataBindable: true, dataSource: 'WEATHER_TEMP',
    defaultSize: { w: 120, h: 40 },
  },

  weather_temp_low: {
    id: 'weather_temp_low', name: 'Температура: мин. сегодня', category: 'Погода',
    widgetId: 'TEXT', apiLevel: '3.0', confidence: 'confirmed',
    description: 'Самая низкая температура сегодня: нативная привязка hmUI.data_type.WEATHER_LOW. Данные предоставляет Zepp OS после синхронизации погоды с телефоном.',
    properties: weatherTempPresetProps('LOW', '#7fb8ff'),
    dataBindable: true, dataSource: 'WEATHER_TEMP',
    defaultSize: { w: 90, h: 40 },
  },

  weather_temp_high: {
    id: 'weather_temp_high', name: 'Температура: макс. сегодня', category: 'Погода',
    widgetId: 'TEXT', apiLevel: '3.0', confidence: 'confirmed',
    description: 'Самая высокая температура сегодня: нативная привязка hmUI.data_type.WEATHER_HIGH. Данные предоставляет Zepp OS после синхронизации погоды с телефоном.',
    properties: weatherTempPresetProps('HIGH', '#ff9f7f'),
    dataBindable: true, dataSource: 'WEATHER_TEMP',
    defaultSize: { w: 90, h: 40 },
  },

  weather_icon: {
    id: 'weather_icon', name: 'Значок погоды', category: 'Погода',
    widgetId: 'IMG', apiLevel: '3.0', confidence: 'confirmed',
    description: 'Нативная иконка погоды через hmUI.data_type.WEATHER_CURRENT. Индекс 0..28 выбирается прошивкой часов; выбранное в Designer условие используется только как стартовое превью.',
    properties: [
      ...commonGeometry,
      P('src', 'weathericon', { label: 'Условие', default: 'sunny' }),
      P('alpha', 'number', { label: 'Прозрачность', default: 100, min: 0, max: 100 }),
    ],
    dataBindable: true, dataSource: 'WEATHER_ICON',
    defaultSize: { w: 64, h: 64 },
  },

  weather_forecast_icon: {
    id: 'weather_forecast_icon', name: 'Значок погоды (прогноз)', category: 'Погода',
    widgetId: 'IMG', apiLevel: '3.0', confidence: 'unverified',
    description: 'Иконка прогноза на сегодня / завтра / послезавтра. Индекс погоды берётся из датчика Weather (@zos/sensor, getForecast) — в документации он помечен устаревшим, поэтому ⚠. Иконки — из набора «Иконки погоды». Почасового прогноза в документированном API нет.',
    properties: [
      ...commonGeometry,
      P('forecast_day', 'select', { label: 'День', options: [
        { value: '0', label: 'Сегодня' }, { value: '1', label: 'Завтра' }, { value: '2', label: 'Послезавтра' },
      ], default: '1' }),
      P('src', 'weathericon', { label: 'Условие (только превью)', default: 'sunny' }),
      P('alpha', 'number', { label: 'Прозрачность', default: 100, min: 0, max: 100 }),
    ],
    dataBindable: false,
    defaultSize: { w: 64, h: 64 },
  },

  system_status: {
    id: 'system_status', name: 'Системный статус', category: 'Изображение',
    widgetId: 'IMG_STATUS', apiLevel: '3.0', confidence: 'confirmed',
    description: 'Системный значок Zepp OS: часы подключены к телефону или включён будильник, режим «Не беспокоить» либо блокировка. Статус обновляет прошивка.',
    properties: [
      ...commonGeometry,
      P('src', 'asset', { label: 'Файл значка' }),
      P('type', 'select', { label: 'Статус', options: [
        { value: 'DISCONNECT', label: 'Нет подключения Bluetooth' },
        { value: 'CLOCK', label: 'Будильник включён' },
        { value: 'DISTURB', label: 'Не беспокоить' },
        { value: 'LOCK', label: 'Экран заблокирован' },
      ], default: 'DISCONNECT' }),
    ],
    dataBindable: false,
    defaultSize: { w: 32, h: 32 },
  },

  image: {
    id: 'image', name: 'Изображение', category: 'Изображение',
    widgetId: 'IMG', apiLevel: '3.0', confidence: 'confirmed',
    description: 'Статичное изображение hmUI.widget.IMG из ваших ресурсов (Asset Manager). Поддерживает прозрачность (alpha).',
    properties: [
      ...commonGeometry,
      P('src', 'asset', { label: 'Файл изображения' }),
      P('alpha', 'number', { label: 'Прозрачность', default: 100, min: 0, max: 100 }),
    ],
    dataBindable: false,
    defaultSize: { w: 100, h: 100 },
  },

  fill_rect: {
    id: 'fill_rect', name: 'Прямоугольник (заливка)', category: 'Фигуры',
    widgetId: 'FILL_RECT', apiLevel: '3.0', confidence: 'confirmed',
    description: 'Залитый прямоугольник hmUI.widget.FILL_RECT с опциональным скруглением углов. Свойство line_width недоступно (удалено из API) — Designer его не выставляет.',
    properties: [
      ...commonGeometry,
      P('radius', 'number', { label: 'Радиус скругления', default: 0, min: 0, max: 240 }),
      P('color', 'color', { label: 'Цвет', default: '#3366ff' }),
      P('alpha', 'number', { label: 'Прозрачность', default: 100, min: 0, max: 100 }),
    ],
    dataBindable: false,
    defaultSize: { w: 150, h: 80 },
  },

  stroke_rect: {
    id: 'stroke_rect', name: 'Прямоугольник (контур)', category: 'Фигуры',
    widgetId: 'STROKE_RECT', apiLevel: '3.0', confidence: 'unverified',
    description: 'Прямоугольник-контур по аналогии с FILL_RECT/CIRCLE-семейством. ⚠ Точный набор полей не подтверждён отдельной документацией — сверьтесь перед публикацией.',
    properties: [
      ...commonGeometry,
      P('radius', 'number', { label: 'Радиус скругления', default: 0, min: 0, max: 240 }),
      P('color', 'color', { label: 'Цвет', default: '#3366ff' }),
      P('line_width', 'number', { label: 'Толщина линии', default: 4, min: 1, max: 40 }),
    ],
    dataBindable: false,
    defaultSize: { w: 150, h: 80 },
  },

  circle: {
    id: 'circle', name: 'Круг (заливка)', category: 'Фигуры',
    widgetId: 'CIRCLE', apiLevel: '3.0', confidence: 'unverified',
    description: 'Залитый круг hmUI.widget.CIRCLE. Задаётся центром и радиусом, а не x/y/w/h.',
    properties: [
      P('center_x', 'number', { label: 'Центр X' }),
      P('center_y', 'number', { label: 'Центр Y' }),
      P('radius', 'number', { label: 'Радиус', default: 40 }),
      P('color', 'color', { label: 'Цвет', default: '#3366ff' }),
      P('alpha', 'number', { label: 'Прозрачность', default: 100, min: 0, max: 100 }),
    ],
    dataBindable: false,
    defaultSize: { w: 80, h: 80 }, // maps to radius on export
  },

  stroke_circle: {
    id: 'stroke_circle', name: 'Круг (контур)', category: 'Фигуры',
    widgetId: 'STROKE_CIRCLE', apiLevel: '3.0', confidence: 'unverified',
    description: 'Контур круга hmUI.widget.STROKE_CIRCLE с настраиваемой толщиной линии.',
    properties: [
      P('center_x', 'number', { label: 'Центр X' }),
      P('center_y', 'number', { label: 'Центр Y' }),
      P('radius', 'number', { label: 'Радиус', default: 40 }),
      P('color', 'color', { label: 'Цвет', default: '#3366ff' }),
      P('line_width', 'number', { label: 'Толщина линии', default: 4, min: 1, max: 40 }),
    ],
    dataBindable: false,
    defaultSize: { w: 80, h: 80 },
  },

  triangle: {
    id: 'triangle', name: 'Треугольник', category: 'Фигуры',
    widgetId: 'TRIANGLE', apiLevel: '3.0', confidence: 'unverified',
    description: 'Треугольник с направлением вверх / вниз / влево / вправо, заливкой и рамкой. Удобен как значок рядом с температурой: вниз — для самой низкой, вверх — для самой высокой. Отдельного виджета-треугольника в Zepp OS нет: на часах он рисуется через hmUI.widget.CANVAS (drawPoly — заливка, strokePoly — рамка; оба метода есть в docs.zepp.com, API_LEVEL 3.0). Система координат внутри холста и соединение углов рамки в документации не описаны — проверьте в симуляторе.',
    properties: [
      ...commonGeometry,
      P('direction', 'select', { group: 'Форма', label: 'Направление', default: 'UP', options: [
        { value: 'UP', label: '▲ Вверх (макс. температура)' },
        { value: 'DOWN', label: '▼ Вниз (мин. температура)' },
        { value: 'LEFT', label: '◀ Влево' },
        { value: 'RIGHT', label: '▶ Вправо' },
      ] }),
      P('fill_enabled', 'checkbox', { group: 'Заливка', label: 'Залить', default: true,
        tip: 'Выключите, чтобы оставить только рамку (пустой треугольник).' }),
      P('color', 'color', { group: 'Заливка', label: 'Цвет заливки', default: '#3366ff', showIf: (pr) => pr.fill_enabled !== false }),
      P('stroke_enabled', 'checkbox', { group: 'Рамка', label: 'Рамка', default: false, confidence: 'unverified',
        tip: '⚠ Рамка рисуется canvas.strokePoly с толщиной из setPaint. Она целиком лежит внутри размера Ш×В: контур сдвигается внутрь на половину толщины. Как strokePoly соединяет углы (острые или скруглённые), документация не указывает — сверьтесь в симуляторе.' }),
      P('stroke_color', 'color', { group: 'Рамка', label: 'Цвет рамки', default: '#ffffff', showIf: (pr) => !!pr.stroke_enabled }),
      P('stroke_width', 'number', { group: 'Рамка', label: 'Толщина рамки', default: 3, min: 1, max: 40, showIf: (pr) => !!pr.stroke_enabled }),
    ],
    dataBindable: false,
    defaultSize: { w: 40, h: 34 },
    note: 'Each triangle is its own CANVAS widget. docs.zepp.com: up to 3 canvas layers may be stacked in one area.',
  },

  arc: {
    id: 'arc', name: 'Дуга', category: 'Фигуры',
    widgetId: 'ARC', apiLevel: '3.0', confidence: 'confirmed',
    description: 'Дуга hmUI.widget.ARC. Без источника данных рисуется целиком от начального до конечного угла. С источником (батарея, шаги, калории, пульс, дистанция, секунды/минуты/часы и др.) заполняется пропорционально значению внутри диапазона углов — кольцо прогресса. Можно включить подложку, скруглённые концы, прозрачность и анимацию появления.',
    properties: [
      ...commonGeometry,
      // --- Источник данных -------------------------------------------------
      P('data_source', 'select', { group: 'Источник данных', label: 'Источник данных', options: [
        { value: 'NONE', label: 'Нет — статическая дуга' },
        { value: 'BATTERY', label: 'Батарея, %' }, { value: 'STEP', label: 'Шаги' },
        { value: 'CALORIE', label: 'Калории' }, { value: 'DISTANCE', label: 'Дистанция, км' },
        { value: 'HEART', label: 'Пульс' },
        { value: 'SECOND', label: 'Секунды (0–60)' }, { value: 'MINUTE', label: 'Минуты (0–60)' },
        { value: 'HOUR', label: 'Часы (12-часовой круг)' }, { value: 'DAY', label: 'День месяца' },
        { value: 'WEEKDAY', label: 'День недели (ПН–ВС)' }, { value: 'MONTH', label: 'Месяц' },
      ], default: 'NONE',
        tip: 'Откуда дуга берёт значение. Дуга заполняется от начального угла к конечному пропорционально значению. Источники времени (секунды, минуты, часы, день, неделя, месяц) считают долю круга сами; для датчиков задайте диапазон ниже.' }),
      P('value_min', 'number', { group: 'Источник данных', label: 'Значение «пусто»', default: 0, min: -100000, max: 100000,
        showIf: (pr) => ['BATTERY','STEP','CALORIE','DISTANCE','HEART'].includes(pr.data_source),
        tip: 'Показание датчика, при котором дуга пуста. Обычно 0.' }),
      P('value_max', 'number', { group: 'Источник данных', label: 'Значение «полно» (0 = авто)', default: 0, min: 0, max: 1000000,
        showIf: (pr) => ['BATTERY','STEP','CALORIE','DISTANCE','HEART'].includes(pr.data_source),
        tip: 'Показание датчика, при котором дуга заполнена полностью. 0 — взять значение по умолчанию: батарея 100, шаги 10000, калории 500, дистанция 5 км, пульс 200. Например, поставьте свою дневную цель по шагам.' }),
      P('preview_percent', 'number', { group: 'Источник данных', label: 'Значение в редакторе, %', default: 70, min: 0, max: 100,
        showIf: (pr) => ['BATTERY','STEP','CALORIE','DISTANCE','HEART'].includes(pr.data_source),
        tip: 'Только для предпросмотра в редакторе: на часах дуга покажет реальное показание. Источники времени в редакторе считаются по текущему времени компьютера.' }),
      // --- Форма -----------------------------------------------------------
      P('start_angle', 'number', { group: 'Форма', label: 'Начальный угол, °', default: 0, min: 0, max: 360 }),
      P('end_angle', 'number', { group: 'Форма', label: 'Конечный угол, °', default: 270, min: 0, max: 360,
        tip: 'Конец диапазона: при значении датчика «полно» дуга доходит именно до этого угла. В редакторе 0° — 12 часов, углы растут по часовой стрелке; при экспорте углы пересчитываются под ARC часов (там 0° — 3 часа).' }),
      P('line_width', 'number', { group: 'Форма', label: 'Толщина линии', default: 8, min: 1, max: 60 }),
      P('rounded_ends', 'checkbox', { group: 'Форма', label: 'Скруглённые концы', default: false, confidence: 'unverified',
        tip: '⚠ (В режиме сегментов не действует — см. группу «Сегменты».) На часах включается свойством corner_flag виджета ARC — оно не подтверждено цитатой из docs.zepp.com, проверьте в симуляторе. В редакторе концы показаны скруглёнными.' }),
      // --- Внешний вид -----------------------------------------------------
      P('color', 'color', { group: 'Внешний вид', label: 'Цвет', default: '#3366ff' }),
      P('gradient_enabled', 'checkbox', { group: 'Сегменты', label: 'Градиентная заливка', default: false, confidence: 'unverified',
        tip: '⚠ У ARC на часах нет градиента, поэтому дуга режется на сегменты (отдельные ARC) с плавным переходом от «Цвета» к «Цвету в конце». Каждый сегмент — отдельный виджет: больше сегментов = плавнее, но тяжелее.' }),
      P('color2', 'color', { group: 'Сегменты', label: 'Цвет в конце дуги', default: '#ff3366', showIf: (pr) => !!pr.gradient_enabled }),
      P('segments_enabled', 'checkbox', { group: 'Сегменты', label: 'Сегментированная дуга', default: false, confidence: 'unverified', showIf: (pr) => !pr.gradient_enabled,
        tip: '⚠ Дуга из отдельных сегментов одного цвета с промежутками (как деления шкалы). Градиент включает сегменты автоматически.' }),
      P('gradient_steps', 'number', { group: 'Сегменты', label: 'Количество сегментов', default: 24, min: 2, max: 48, showIf: (pr) => !!(pr.gradient_enabled || pr.segments_enabled),
        tip: 'Число виджетов ARC. Для плавного градиента 16–32; чем больше, тем плавнее переход и тем больше нагрузка при анимации. Подложка в этом режиме тоже состоит из сегментов.' }),
      P('segment_gap', 'number', { group: 'Сегменты', label: 'Расстояние между сегментами, °', default: 0, min: 0, max: 30, showIf: (pr) => !!(pr.gradient_enabled || pr.segments_enabled),
        tip: 'Угловой промежуток между соседними сегментами. 0 — сплошная дуга (стыки перекрываются на 1°). Промежуток автоматически ограничивается, чтобы каждому сегменту осталось не меньше 0,5°.' }),
      P('segment_rounded', 'checkbox', { group: 'Сегменты', label: 'Скруглённые концы сегментов', default: false, confidence: 'unverified', showIf: (pr) => !!(pr.gradient_enabled || pr.segments_enabled),
        tip: '⚠ corner_flag для каждого сегмента (не подтверждён документацией). Скруглённый колпачок выступает за край сегмента, поэтому видимый промежуток получается меньше заданного — увеличьте расстояние. Пустые сегменты скрываются (prop.VISIBLE), чтобы не рисовать точку.' }),
      P('alpha', 'number', { group: 'Внешний вид', label: 'Прозрачность, % (100 = непрозрачно)', default: 100, min: 0, max: 100, confidence: 'unverified',
        tip: '⚠ Непрозрачность дуги 0–100 %. На часах применяется через setAlpha(); для ARC это не подтверждено цитатой из docs.zepp.com.' }),
      // --- Подложка --------------------------------------------------------
      P('track_enabled', 'checkbox', { group: 'Подложка', label: 'Показывать подложку (весь диапазон)', default: false,
        tip: 'Тусклая дуга на весь диапазон углов под основной — обычная «дорожка» кольца прогресса.' }),
      P('track_color', 'color', { group: 'Подложка', label: 'Цвет подложки', default: '#2a3042', showIf: (pr) => !!pr.track_enabled }),
      P('track_alpha', 'number', { group: 'Подложка', label: 'Прозрачность подложки, %', default: 100, min: 0, max: 100, showIf: (pr) => !!pr.track_enabled }),
      // --- Анимация --------------------------------------------------------
      P('anim_enabled', 'checkbox', { group: 'Анимация появления', label: 'Анимация при появлении циферблата', default: false,
        tip: 'Проигрывается один раз при построении циферблата на часах. Реализована таймером из @zos/timer (около 25 кадров/с, только пока идёт анимация). В режиме AOD не используется.' }),
      P('anim_replay', 'checkbox', { group: 'Анимация появления', label: 'Повторять при пробуждении касанием/кнопкой', default: false, showIf: (pr) => !!pr.anim_enabled,
        tip: 'Анимация запускается заново, когда часы возвращаются на циферблат (касание экрана, кнопка, выход из меню/уведомлений). Использует WIDGET_DELEGATE.resume_call. Если анимация ещё идёт — повторный запуск пропускается.' }),
      P('anim_replay_raise', 'checkbox', { group: 'Анимация появления', label: 'Повторять при поднятии руки', default: false, confidence: 'unverified', showIf: (pr) => !!pr.anim_enabled,
        tip: '⚠ Слушает события экрана (датчик Screen, API_LEVEL 3.0: 1 — включён, 2 — выключен) и дополнительно следит за «паузой» таймера. В консоль пишутся строки «screen status» и «arc replay» — по ним видно, что сработало на Balance 2. Можно включать вместе с предыдущим пунктом: повторный запуск во время анимации пропускается.' }),
      P('anim_type', 'select', { group: 'Анимация появления', label: 'Вид анимации', default: 'FILL', showIf: (pr) => !!pr.anim_enabled, options: [
        { value: 'FILL', label: 'Заполнение до значения' },
        { value: 'FADE', label: 'Плавное проявление' },
        { value: 'FADE_FILL', label: 'Заполнение + проявление' },
        { value: 'OVERSHOOT', label: 'Заполнение с перелётом' },
        { value: 'SWEEP', label: 'Спидометр: до упора и откат к значению' },
        { value: 'GROW', label: 'Рост толщины линии ⚠' },
      ], tip: 'Заполнение — шкала растёт от начала до текущего значения. Проявление — дуга появляется из прозрачности. С перелётом — шкала чуть проскакивает значение и возвращается. «Спидометр» — шкала сначала доходит до полного заполнения, затем откатывается к текущему значению (первая половина длительности — разгон, вторая — откат). Рост толщины меняет line_width на лету (⚠ не подтверждено документацией).' }),
      P('anim_duration', 'number', { group: 'Анимация появления', label: 'Длительность, мс', default: 1200, min: 100, max: 10000, showIf: (pr) => !!pr.anim_enabled }),
      P('anim_delay', 'number', { group: 'Анимация появления', label: 'Задержка старта, мс', default: 0, min: 0, max: 5000, showIf: (pr) => !!pr.anim_enabled }),
      P('anim_easing', 'select', { group: 'Анимация появления', label: 'Плавность', default: 'EASE_OUT', showIf: (pr) => !!pr.anim_enabled && pr.anim_type !== 'OVERSHOOT', options: [
        { value: 'LINEAR', label: 'Равномерно' }, { value: 'EASE_OUT', label: 'Замедление в конце' },
        { value: 'EASE_IN_OUT', label: 'Плавный старт и конец' },
      ] }),
    ],
    dataBindable: false,
    defaultSize: { w: 160, h: 160 },
  },

  canvas: {
    id: 'canvas', name: 'Холст', category: 'Холст',
    widgetId: 'CANVAS', apiLevel: '3.0', confidence: 'confirmed',
    description: 'hmUI.widget.CANVAS — область для рисования примитивов вручную (drawLine/drawRect/drawCircle/drawArc/drawText/drawImage) через методы canvas.* внутри build(). Сам по себе холст на экране не рисует ничего, кроме размеченной области.',
    properties: [
      ...commonGeometry,
    ],
    dataBindable: false,
    defaultSize: { w: 200, h: 200 },
    note: 'Draw primitives (line/rect/circle/arc/text/image) via canvas.* methods inside build().',
  },

  time_pointer_hour: {
    id: 'time_pointer_hour', name: 'Часовая стрелка', category: 'Аналоговые стрелки',
    widgetId: 'TIME_POINTER', apiLevel: '3.0', confidence: 'confirmed',
    description: 'Часовая стрелка аналогового циферблата (hmUI.widget.TIME_POINTER). Все три стрелки (часовая/минутная/секундная) экспортируются одним общим виджетом TIME_POINTER с параметрами hour_*/minute_*/second_*.',
    properties: [
      P('center_x', 'number', { label: 'Центр X', default: 240 }),
      P('center_y', 'number', { label: 'Центр Y', default: 240 }),
      P('pos_x', 'number', { label: 'Точка опоры X (в изображении)', default: 19 }),
      P('pos_y', 'number', { label: 'Точка опоры Y (в изображении)', default: 100 }),
      P('path', 'asset', { label: 'Изображение стрелки' }),
      P('cover_path', 'asset', { label: 'Изображение накладки', optional: true }),
    ],
    dataBindable: true, dataSource: 'TIME_POINTER_HOUR',
    defaultSize: { w: 40, h: 200 },
    single: true, group: 'time_pointer',
  },

  time_pointer_minute: {
    id: 'time_pointer_minute', name: 'Минутная стрелка', category: 'Аналоговые стрелки',
    widgetId: 'TIME_POINTER', apiLevel: '3.0', confidence: 'confirmed',
    description: 'Минутная стрелка аналогового циферблата (hmUI.widget.TIME_POINTER, параметры minute_*).',
    properties: [
      P('center_x', 'number', { label: 'Центр X', default: 240 }),
      P('center_y', 'number', { label: 'Центр Y', default: 240 }),
      P('pos_x', 'number', { label: 'Точка опоры X (в изображении)', default: 19 }),
      P('pos_y', 'number', { label: 'Точка опоры Y (в изображении)', default: 130 }),
      P('path', 'asset', { label: 'Изображение стрелки' }),
      P('cover_path', 'asset', { label: 'Изображение накладки', optional: true }),
    ],
    dataBindable: true, dataSource: 'TIME_POINTER_MINUTE',
    defaultSize: { w: 30, h: 240 },
    single: true, group: 'time_pointer',
  },

  time_pointer_second: {
    id: 'time_pointer_second', name: 'Секундная стрелка', category: 'Аналоговые стрелки',
    widgetId: 'TIME_POINTER', apiLevel: '3.0', confidence: 'confirmed',
    description: 'Секундная стрелка аналогового циферблата (hmUI.widget.TIME_POINTER, параметры second_*). Учитывайте влияние частого обновления на энергопотребление.',
    properties: [
      P('center_x', 'number', { label: 'Центр X', default: 240 }),
      P('center_y', 'number', { label: 'Центр Y', default: 240 }),
      P('pos_x', 'number', { label: 'Точка опоры X (в изображении)', default: 10 }),
      P('pos_y', 'number', { label: 'Точка опоры Y (в изображении)', default: 150 }),
      P('path', 'asset', { label: 'Изображение стрелки' }),
      P('cover_path', 'asset', { label: 'Изображение накладки', optional: true }),
      // --- Ход стрелки -------------------------------------------------
      // TICK   — штатное поведение TIME_POINTER: один скачок в секунду.
      // SMOOTH — плавный «sweep»: TIME_POINTER не умеет этого сам, поэтому
      //          экспортёр рисует секундную стрелку отдельным IMG-виджетом
      //          и крутит его вручную по таймеру из '@zos/timer'. Свойство
      //          поворота IMG (angle/center_x/center_y) не подтверждено
      //          цитатой из офиц. документации → помечено ⚠ (unverified).
      P('motion', 'select', {
        label: 'Ход стрелки',
        options: [
          { value: 'TICK', label: 'Тик — 1 скачок в секунду (штатный TIME_POINTER)' },
          { value: 'SMOOTH', label: '⚠ Плавный ход — ручная анимация по таймеру' },
        ],
        default: 'TICK',
      }),
      P('smooth_fps', 'number', {
        label: 'Частота кадров плавного хода, к/с',
        default: 20, min: 5, max: 60, confidence: 'unverified',
      }),
      P('smooth_step_deg', 'number', {
        label: 'Мин. шаг поворота, ° (0 — без ограничения)',
        default: 0, min: 0, max: 6,
      }),
    ],
    dataBindable: true, dataSource: 'TIME_POINTER_SECOND',
    defaultSize: { w: 20, h: 260 },
    single: true, group: 'time_pointer',
  },
};

// Базовая типографика остаётся у обычного TEXT и других текстовых пресетов.
// Продвинутый дизайнер типографики намеренно подключается только к
// DIGITAL_DISPLAY, потому что именно он экспортирует премиальные символы
// как готовые PNG.
for (const def of Object.values(REGISTRY)) {
  if (def.widgetId !== 'TEXT') continue;
  const keys = new Set(def.properties.map((p) => p.key));
  if (!keys.has('font')) def.properties.push(P('font', 'font', { label: 'Шрифт', optional: true }));
  if (!keys.has('font_weight')) def.properties.push(P('font_weight', 'select', {
    label: 'Жирность', options: [
      { value: '400', label: 'Обычный' }, { value: '500', label: 'Средний' },
      { value: '600', label: 'Полужирный' }, { value: '700', label: 'Жирный' },
      { value: '800', label: 'Очень жирный' }
    ], default: '400'
  }));
  if (!keys.has('font_style')) def.properties.push(P('font_style', 'select', {
    label: 'Наклон', options: [
      { value: 'normal', label: 'Обычный' }, { value: 'italic', label: 'Курсив' },
      { value: 'oblique', label: 'Наклонный' }
    ], default: 'normal'
  }));
  if (!keys.has('letter_spacing')) def.properties.push(P('letter_spacing', 'number', {
    label: 'Межбуквенный интервал, px', default: 0, min: -10, max: 20
  }));
  if (!keys.has('line_height')) def.properties.push(P('line_height', 'number', {
    label: 'Высота строки, ×', default: 1, min: 0.5, max: 3
  }));
}

const digitalPremiumProps = [
  ['text_transform','select',{label:'Регистр',options:[{value:'none',label:'Без изменений'},{value:'uppercase',label:'Верхний'},{value:'lowercase',label:'Нижний'}],default:'none'}],
  ['bevel_profile','select',{label:'Профиль фаски',options:[{value:'soft',label:'Soft'},{value:'hard',label:'Hard'},{value:'deep',label:'Deep'}],default:'soft'}],
  ['glow_enabled','boolean',{label:'Свечение',default:false}],
  ['drop_shadow_enabled','boolean',{label:'Drop Shadow',default:false}],
  ['drop_shadow_blur','number',{label:'Drop Blur, px',default:4,min:0,max:40}],
  ['contact_shadow_enabled','boolean',{label:'Contact Shadow',default:false}],
  ['contact_shadow_opacity','number',{label:'Contact Density, %',default:45,min:0,max:100}],
  ['inner_shadow_enabled','boolean',{label:'Inner Shadow',default:false}],
  ['inner_shadow_opacity','number',{label:'Inner Shadow, %',default:28,min:0,max:100}],
  ['cast_shadow_enabled','boolean',{label:'Cast Shadow',default:false}],
  ['cast_shadow_angle','number',{label:'Угол света, °',default:135,min:0,max:360}],
  ['cast_shadow_elevation','number',{label:'Высота света, °',default:45,min:5,max:85}],
  ['cast_shadow_distance','number',{label:'Длина тени',default:5,min:0,max:100}],
  ['cast_shadow_blur','number',{label:'Мягкость тени',default:3,min:0,max:40}],
  ['cast_shadow_opacity','number',{label:'Плотность тени, %',default:42,min:0,max:100}],
  ['cast_shadow_length','number',{label:'Длина Cast Shadow',default:7,min:0,max:150}],
  ['cast_shadow_falloff','number',{label:'Затухание тени, %',default:65,min:0,max:100}],
];
const digitalDef = REGISTRY.digital_display;
const digitalKeys = new Set(digitalDef.properties.map((p) => p.key));
for (const [key,type,opts] of digitalPremiumProps) {
  if (!digitalKeys.has(key)) digitalDef.properties.push(P(key,type,opts));
}

// ---------------------------------------------------------------------------
// PROPERTY_HINTS — текст всплывающих подсказок для полей Inspector.
// Ключ — имя свойства (см. P(...) в определениях компонентов). Подсказка
// объясняет, что поле означает на устройстве и в каких единицах задаётся;
// у компонента подсказку можно переопределить, передав tip в опциях P().
// ---------------------------------------------------------------------------
const PROPERTY_HINTS = {
  x: 'Левый край виджета в пикселях экрана, считая от левого края циферблата. Те же координаты попадут в createWidget({ x: ... }).',
  y: 'Верхний край виджета в пикселях экрана, считая от верха циферблата.',
  w: 'Ширина области виджета в пикселях. Для текста это рамка, внутри которой работает выравнивание align_h.',
  h: 'Высота области виджета в пикселях. Для текста это рамка, внутри которой работает выравнивание align_v.',

  center_x: 'Ось вращения стрелки на ЭКРАНЕ: X центра циферблата в пикселях (для экрана 480×480 это обычно 240).',
  center_y: 'Ось вращения стрелки на ЭКРАНЕ: Y центра циферблата в пикселях (для экрана 480×480 это обычно 240).',
  pos_x: 'Точка опоры ВНУТРИ картинки стрелки: сколько пикселей от ЛЕВОГО края изображения до оси вращения. Для симметричной стрелки шириной 20 px это 10.',
  pos_y: 'Точка опоры ВНУТРИ картинки стрелки: сколько пикселей от ВЕРХНЕГО края изображения до оси вращения. Обычно это длина стрелки от кончика до центра циферблата.',
  path: 'PNG-изображение стрелки из панели «Ресурсы». Рисуйте стрелку вертикально, кончиком вверх — поворот на 0° соответствует 12 часам.',
  cover_path: 'Необязательная накладка поверх стрелок — например, декоративная гайка в центре циферблата.',
  motion: 'Тик — штатное поведение TIME_POINTER: один скачок в секунду, дёшево по батарее. Плавный ход — непрерывное вращение; стрелка выносится в отдельный виджет IMG и крутится вручную по таймеру (помечено ⚠, проверьте в симуляторе).',
  smooth_fps: 'Сколько раз в секунду пересчитывается угол при плавном ходе. 15–20 к/с выглядят плавно; больше — заметно дороже по батарее. Работает только в режиме «Плавный ход».',
  smooth_step_deg: 'Квантование угла в градусах: 0 — максимально плавно, 0.5–1 — экономнее (стрелка двигается мелкими ступеньками). Работает только в режиме «Плавный ход».',

  color: 'Цвет элемента. При экспорте переводится в формат Zepp OS 0xRRGGBB.',
  text_size: 'Высота шрифта в пикселях устройства — ровно то же число, что увидит createWidget({ text_size }). В редакторе текст показан 1:1.',
  align_h: 'Горизонтальное выравнивание текста внутри рамки W: LEFT / CENTER_H / RIGHT (hmUI.align.*).',
  align_v: 'Вертикальное выравнивание текста внутри рамки H: TOP / CENTER_V / BOTTOM (hmUI.align.*).',
  text_style: 'Поведение длинной строки: NONE — обрезать, WRAP — перенос, SCROLL — бегущая строка (hmUI.text_style.*).',
  font: 'Встроенный в проект файл шрифта. После экспорта он копируется в assets/<target>/fonts/.',
  font_weight: 'Жирность предпросмотра. Для устройства фактическая жирность определяется выбранным файлом шрифта.',
  font_style: 'Наклон предпросмотра. Для устройства используйте файл шрифта с соответствующим начертанием.',
  letter_spacing: 'Межбуквенный интервал предпросмотра в пикселях. Zepp TEXT не гарантирует поддержку этого параметра.',
  line_height: 'Высота строки в предпросмотре. Для однострочного текста обычно оставляйте 1.',
  alpha: 'Непрозрачность 0–100 %. Поддержка на части прошивок подтверждена не для всех виджетов.',

  arc_enabled: 'Раскладывает буквы по дуге окружности. Текст запекается в PNG при экспорте, поэтому дуга работает для статического текста (источник «Нет») и для «Дня недели» (экспортируется 7 картинок, нужная выбирается по текущему дню). Другие динамические источники (время, дата, датчики) дугой не поддерживаются. Ось дуги — центр рамки компонента: верхняя точка окружности лежит в центре рамки, окружность уходит вниз (или вверх при «Дуга снизу»). Межбуквенный интервал берётся из панели типографики.',
  text: 'Статический текст. Если выбран источник данных, это поле игнорируется — значение подставляется автоматически.',
  format: 'Шаблон вывода значения. Форматирование выполняет сгенерированная helper-функция в index.js, а не сам виджет.',
  prefix: 'Строка перед значением, например «♥ ». Подставляется при каждом обновлении данных.',
  suffix: 'Строка после значения, например «%» или « шагов».',
  unit: 'Единица измерения, дописываемая к значению (км/мили, °C/°F).',
  src: 'Файл изображения из панели «Ресурсы». При экспорте попадёт в assets/<устройство>/ под этим же именем.',
  data_source: 'Живые данные, которыми заполняется текст: время, дата, батарея, пульс, шаги и т.д. Для каждого источника ниже появляется свой набор настроек.',

  radius: 'Радиус в пикселях. Для круга — от центра до края, для скруглённого прямоугольника — радиус углов.',
  line_width: 'Толщина линии контура в пикселях.',
  time_format: 'Шаблон времени: HH — 24-часовой формат, hh — 12-часовой (тогда рядом обычно ставят отдельный текст AM/PM). Вариант с :SS обновляется каждую секунду.',
  time_leading_zero: 'Показывать ли ноль перед часами: 09:05 против 9:05. На минуты не влияет.',
  time_separator: 'Разделитель между часами и минутами — обычно «:», но можно поставить точку или пробел.',
  ampm_case: 'Регистр индикатора: AM/PM или am/pm.',
  date_format: 'Порядок и вид частей даты. Собирается helper-функцией в сгенерированном index.js.',
  date_locale: 'Язык названий месяцев (EN/RU) для форматов с MMM и MMMM.',
  weekday_format: 'EEE — сокращение (Пн), EEE3 — 3 буквы (ПОН), EEEE — полное название (Понедельник).',
  weekday_locale: 'Язык названий дней недели (EN/RU).',
  fit_bounds: 'Если включено, размер шрифта автоматически уменьшается (но не увеличивается сверх заданного «Размера шрифта»), чтобы длинный текст — например «ВОСКРЕСЕНЬЕ» вместо «ВС» — уместился по ширине и высоте компонента (его W/H). Для источников с несколькими возможными значениями (день недели, месяц и т.п.) размер подбирается один раз по самому длинному варианту сразу для превью и для экспорта — чтобы в любой день/месяц текст не вылезал за рамку.',
  fit_min_size: 'Нижняя граница авто-подбора: меньше этого размера шрифт уменьшаться не будет, даже если текст всё ещё не помещается по ширине/высоте.',
  battery_low_threshold: 'Порог низкого заряда в процентах — ниже него значение можно подсветить своим кодом в блоке USER ANIMATION CODE.',
  heart_min_valid: 'Минимальное правдоподобное значение пульса. Всё ниже считается «нет данных» и показывается как «--» — датчик отдаёт нули, когда часы сняты с руки.',
  step_thousands_sep: 'Разделять ли тысячи пробелом: 8 452 против 8452.',
  calorie_decimals: 'Сколько знаков после запятой показывать у калорий. 0 — целое число.',
  distance_unit: 'Единица дистанции: км или мили. Конвертация приближённая — исходная единица датчика официально не подтверждена (⚠).',
  distance_decimals: 'Сколько знаков после запятой у дистанции. Обычно 1–2.',
  weather_unit: 'Шкала температуры задаётся настройками часов. Нативная привязка рисует только число и знак °, буква C/F не выводится — если она нужна, добавьте рядом отдельный текст «C».',
  weather_temp_source: 'Что показывать: CURRENT — текущая температура, HIGH — максимум, LOW — минимум. Значение берётся нативным weather data binding Zepp OS.',
  unit: 'Единица измерения значения.',
  weather_show_degree: 'Показывать ли знак ° после числа. Это единственное, что часы дорисовывают к температуре (буквы C/F нет).',

  hour_format: 'HH — 24-часовой формат, hh — 12-часовой (тогда рядом обычно ставят отдельный текст AM/PM).',
  hour_leading_zero: 'Показывать ли ноль перед часами: 09 против 9.',
  minute_leading_zero: 'Показывать ли ноль перед минутами: 05 против 5. Обычно оставляют включённым.',
  second_leading_zero: 'Показывать ли ноль перед секундами: 05 против 5. Обычно оставляют включённым.',
  day_leading_zero: 'Показывать ли ноль перед числом месяца: 03 против 3.',
  month_format: 'MM/M — число месяца (с ведущим нулём или без), MMM/MMMM — короткое или полное название.',
  month_locale: 'Язык названия месяца (EN/RU) — влияет только на форматы MMM/MMMM.',
  year_format: 'YYYY — год из 4 цифр (2026), YY — из 2 (26).',

  start_angle: 'Начальный угол дуги в градусах. 0° — направление «на 3 часа», отсчёт по часовой стрелке.',
  end_angle: 'Конечный угол дуги в градусах; дуга рисуется от начального угла по часовой стрелке.',

  tap_action: 'Что произойдёт при тапе по этому компоненту. «Ничего» — тап не обрабатывается (поля ниже скрыты). «Встроенное приложение из списка» — открыть один из штатных экранов часов (пульс, погода, тренировка и т.д.) — ниже появится список. «Другое приложение» — открыть произвольное приложение вручную по его App ID — ниже появятся поля App ID и путь. «Фонарик» — первый тап включает белый экран, повторный тап по экрану возвращает циферблат.',
  tap_metric: 'Штатный экран часов, который откроется по тапу. Список закрытый — это системные экраны Zepp OS, а не установленные пользователем приложения.',
  tap_app_id: 'Числовой App ID целевого приложения (обычно — вашего собственного второго приложения в том же проекте, id указывается в app.json этого приложения). Без верного App ID переход при экспорте не сработает.',
  tap_app_url: 'Путь до страницы внутри целевого приложения, например «pages/index». Соответствует полю url у createWidget → click_func → launchApp({ appId, url }).',
};

function hintForProperty(p) {
  if (!p) return '';
  if (p.tip) return p.tip;
  return PROPERTY_HINTS[p.key] || '';
}

// ---------------------------------------------------------------------------
// WEATHER_ICON_SET — полный набор из 29 погодных состояний (weather index 0..28).
//
// ⚠ ВАЖНО насчёт достоверности источника: официальной цитируемой таблицы
// hmUI.data_type.WEATHER_ICON / полного списка иконок на docs.zepp.com не
// найдено (см. ZEPP_API_COMPONENTS.md, раздел "Данные"). Этот список —
// не выдумка Designer, а константы из реального открытого кода проекта
// Gadgetbridge (ZeppOsWeatherHandler.java), которые сверены с фактическими
// ответами API Zepp OS в реальном устройстве (Amazfit GTR 4), а не взяты
// из документации:
//   https://codeberg.org/Freeyourgadget/Gadgetbridge/src/branch/master/app/src/main/java/nodomain/freeyourgadget/gadgetbridge/service/devices/huami/zeppos/ZeppOsWeatherHandler.java
// Это более полный и достоверный список, чем прежние 11 "придуманных по
// аналогии" условий (sunny/cloudy/rain/...), но статус — 🟡 подтверждено
// реверс-инжинирингом реального трафика устройства, НЕ официальной
// документацией. Индексы соответствуют порядковому номеру в реальном API
// (0 = Sunny ... 33 = Snow) — при экспорте используются как имена файлов
// assets/.../weather/<id>.png.
const WEATHER_ICON_SET = [
  { id: 'cloudy', label: 'Облачно', glyph: '☁', index: 0 },
  { id: 'showers', label: 'Ливни', glyph: '☔', index: 1 },
  { id: 'snow_showers', label: 'Снегопад', glyph: '❄', index: 2 },
  { id: 'sunny', label: 'Солнечно', glyph: '☀', index: 3 },
  { id: 'overcast', label: 'Пасмурно', glyph: '☁', index: 4 },
  { id: 'light_rain', label: 'Небольшой дождь', glyph: '🌧', index: 5 },
  { id: 'light_snow', label: 'Небольшой снег', glyph: '❄', index: 6 },
  { id: 'moderate_rain', label: 'Умеренный дождь', glyph: '🌧', index: 7 },
  { id: 'moderate_snow', label: 'Умеренный снег', glyph: '❄', index: 8 },
  { id: 'heavy_snow', label: 'Сильный снег', glyph: '❄', index: 9 },
  { id: 'heavy_rain', label: 'Сильный дождь', glyph: '🌧', index: 10 },
  { id: 'sandstorm', label: 'Песчаная буря', glyph: '🌪', index: 11 },
  { id: 'rain_snow', label: 'Дождь со снегом', glyph: '🌨', index: 12 },
  { id: 'fog', label: 'Туман', glyph: '🌫', index: 13 },
  { id: 'hazy', label: 'Мгла', glyph: '🌫', index: 14 },
  { id: 'thunderstorm', label: 'Гроза', glyph: '⛈', index: 15 },
  { id: 'snowstorm', label: 'Метель', glyph: '❄', index: 16 },
  { id: 'floating_dust', label: 'Пыльная взвесь', glyph: '🌫', index: 17 },
  { id: 'very_heavy_rainstorm', label: 'Очень сильный ливень', glyph: '⛈', index: 18 },
  { id: 'rain_hail', label: 'Дождь с градом', glyph: '🌨', index: 19 },
  { id: 'thunderstorm_hail', label: 'Гроза с градом', glyph: '⛈', index: 20 },
  { id: 'heavy_rainstorm', label: 'Сильный ливень', glyph: '⛈', index: 21 },
  { id: 'dust', label: 'Пыль', glyph: '🌫', index: 22 },
  { id: 'heavy_sandstorm', label: 'Сильная песчаная буря', glyph: '🌪', index: 23 },
  { id: 'rainstorm', label: 'Ливень', glyph: '🌧', index: 24 },
  { id: 'unknown', label: 'Неизвестно', glyph: '?', index: 25 },
  { id: 'cloudy_night', label: 'Облачно ночью', glyph: '☾', index: 26 },
  { id: 'showers_night', label: 'Ливни ночью', glyph: '☔', index: 27 },
  { id: 'sunny_night', label: 'Ясно ночью', glyph: '☾', index: 28 },
];


// Обратная совместимость: проекты, сохранённые до этого обновления, могли
// содержать старые "придуманные по аналогии" id погодных условий. Не ломаем
// такие файлы при загрузке — сопоставляем их с ближайшим id из нового
// подтверждённого набора.
const WEATHER_ICON_LEGACY_ALIASES = {
  some_clouds: 'cloudy', partly_cloudy: 'cloudy', rain: 'moderate_rain', wind: 'floating_dust',
  night_clear: 'sunny_night', night_cloudy: 'cloudy_night', hail: 'rain_hail', sleet: 'rain_snow',
  rain_with_sun: 'showers', rainstorm: 'rainstorm', dense_fog: 'fog', snow: 'moderate_snow',
};

const isWeatherIconDef = (def) => !!def && (def.id === 'weather_icon' || def.id === 'weather_forecast_icon');

function normalizeWeatherIconId(id) {
  if (!id) return id;
  if (WEATHER_ICON_SET.some((w) => w.id === id)) return id;
  return WEATHER_ICON_LEGACY_ALIASES[id] || id;
}

// Эффективный источник данных для компонента-инстанса: у "жёстких" пресетов
// (time_hm, battery, heart_rate, ...) он фиксирован в def.dataSource; у
// универсального "text" — выбирается динамически через comp.props.data_source.
function getEffectiveDataSource(comp, def) {
  if (!def) return null;
  if (def.dataBindable && def.dataSource) return def.dataSource;
  if (def.dataSourceSelectable) {
    const v = comp && comp.props && comp.props.data_source;
    if (v && v !== 'NONE') return v;
  }
  return null;
}



// Дополнительные системные данные. Они используют нативный TEXT_FONT + data_type:
// прошивка сама обновляет значение, а Designer отвечает только за геометрию и стиль.
const NATIVE_DATA_COMPONENTS = [
  ['step_target','Цель шагов','STEP_TARGET',100,32], ['cal_target','Цель калорий','CAL_TARGET',110,32],
  ['pai_daily','PAI сегодня','PAI_DAILY',100,32], ['pai_weekly','PAI за неделю','PAI_WEEKLY',120,32],
  ['stand','Стояние','STAND',100,32], ['stand_target','Цель стояния','STAND_TARGET',110,32],
  ['humidity','Влажность','HUMIDITY',100,32], ['uvi','УФ-индекс','UVI',100,32], ['aqi','Качество воздуха','AQI',130,32],
  ['fat_burning','Жиросжигание','FAT_BURNING',130,32], ['fat_burning_target','Цель жиросжигания','FAT_BURNING_TARGET',150,32],
  ['sun_current','До восхода/заката','SUN_CURRENT',150,32], ['sun_rise','Восход','SUN_RISE',100,32], ['sun_set','Закат','SUN_SET',100,32],
  ['wind','Ветер','WIND',100,32], ['stress','Стресс','STRESS',100,32], ['spo2','SpO₂','SPO2',100,32], ['body_temp','Температура тела','BODY_TEMP',140,32],
  ['floor','Этажи','FLOOR',100,32], ['alarm_clock','Будильник','ALARM_CLOCK',120,32], ['count_down','Обратный отсчёт','COUNT_DOWN',140,32],
  ['stop_watch','Секундомер','STOP_WATCH',120,32], ['sleep','Сон','SLEEP',120,32], ['training_load','Нагрузка','TRAINING_LOAD',120,32],
  ['vo2max','VO₂ max','VO2MAX',110,32], ['recovery_time','Восстановление','RECOVERY_TIME',140,32],
  ['month_run_times','Пробежки за месяц','MONTH_RUN_TIMES',150,32], ['month_run_distance','Пробег за месяц','MONTH_RUN_DISTANCE',160,32],
  ['readiness','Готовность','READINESS',120,32],
].forEach(([id,name,source,w,h]) => {
  REGISTRY[id] = {
    id, name, category: 'Данные', widgetId: 'TEXT', apiLevel: '3.0', confidence: 'confirmed',
    description: DATA_SOURCES[source]?.label || name,
    properties: [
      ...commonGeometry,
      P('text_size','number',{label:'Размер шрифта',default:26,min:8,max:120}),
      P('color','color',{label:'Цвет',default:'#ffffff'}),
      P('align_h','select',{label:'Выравнивание по X',options:alignH,default:'CENTER_H'}),
      P('align_v','select',{label:'Выравнивание по Y',options:alignV,default:'CENTER_V'}),
      ...(DATA_SOURCES[source]?.fields || []),
    ],
    dataBindable: true, dataSource: source, defaultSize:{w,h},
  };
});

// Системные экраны часов, которые можно открыть тапом (launchApp + native: true).
// Единый список для инспектора, реестра свойств и экспортёра.
// verified: константы сверены с таблицей «System App ID constants»
// на docs.zepp.com (launchApp); экспортёр импортирует только используемые.
const SYSTEM_SCREENS = [
  { value: 'STATUS', label: 'Активность', verified: true },
  { value: 'HR', label: 'Пульс', verified: true },
  { value: 'SPORT', label: 'Тренировка', verified: true },
  { value: 'WEATHER', label: 'Погода', verified: true },
  { value: 'ALARM', label: 'Будильник', verified: true },
  { value: 'CAMERA', label: 'Пульт камеры', verified: true },
  { value: 'MUSIC', label: 'Музыка', verified: true },
  { value: 'STOPWATCH', label: 'Секундомер', verified: true },
  { value: 'COUNTDOWN', label: 'Таймер', verified: true },
  { value: 'FINE_PHONE', label: 'Поиск телефона', verified: true },
  { value: 'CARD', label: 'Карты', verified: true },
  { value: 'ALIPAY', label: 'Alipay', verified: true },
  { value: 'SETTING', label: 'Настройки', verified: true },
  { value: 'SPORT_HISTORY', label: 'История тренировок', verified: true },
  { value: 'COMPASS', label: 'Компас', verified: true },
  { value: 'PAI', label: 'PAI', verified: true },
  { value: 'WORLD_CLOCK', label: 'Мировое время', verified: true },
  { value: 'PRESSURE', label: 'Стресс', verified: true },
  { value: 'MENSTRUAL', label: 'Цикл', verified: true },
  { value: 'SPORT_STATUS', label: 'Статус тренировки', verified: true },
  { value: 'CALENDAR', label: 'Календарь', verified: true },
  { value: 'SLEEP', label: 'Сон', verified: true },
  { value: 'SPO2', label: 'Кислород крови', verified: true },
  { value: 'PHONE', label: 'Телефон', verified: true },
  { value: 'NETEASE_MUSIC', label: 'NetEase Music', verified: true },
  { value: 'WEPAY', label: 'Weixin Pay', verified: true },
  { value: 'BREATH', label: 'Дыхательные упражнения', verified: true },
  { value: 'POMODORO', label: 'Помодоро', verified: true },
  { value: 'ALEAX', label: 'Alexa', verified: true },
  { value: 'THERMOMETER', label: 'Термометр', verified: true },
  { value: 'TODO_LIST', label: 'Список дел', verified: true },
  { value: 'ALTIMETER', label: 'Барометр и высотомер', verified: true },
  { value: 'VOICE_MEMO', label: 'Диктофон', verified: true },
  { value: 'SUN_AND_MOON', label: 'Солнце и луна', verified: true },
  { value: 'MEASUREMENT', label: 'Измерение', verified: true },
  { value: 'ZEPP_COACH', label: 'Zepp Coach', verified: true },
  { value: 'CLUB_CARD', label: 'Карты (клубные / членские)', verified: true },
  { value: 'BODY_COMPOSITION', label: 'Состав тела', verified: true },
  { value: 'READINESS', label: 'Готовность', verified: true },
];

// Общие настройки действия по тапу для ЛЮБОГО компонента.
// Реальный обработчик создаётся экспортёром отдельной прозрачной BUTTON-зоной:
// это надёжнее, чем полагаться на click_func у TEXT/IMG/CIRCLE и других виджетов.
const TAP_ACTION_PROPERTIES = [
  P('tap_action', 'select', {
    label: 'Открытие по тапу',
    options: [
      { value: 'NONE', label: 'Ничего (тап не обрабатывается)' },
      { value: 'METRIC', label: 'Встроенное приложение из списка' },
      { value: 'APP', label: 'Другое приложение (вручную по App ID)' },
      { value: 'FLASHLIGHT', label: 'Фонарик (вкл./выкл.)' },
    ],
    default: 'NONE',
  }),
  P('tap_metric', 'select', {
    label: 'Какое встроенное приложение открыть',
    options: SYSTEM_SCREENS.map((x) => ({ value: x.value, label: x.label })),
    default: 'STATUS',
  }),
  P('tap_app_id', 'number', { label: 'App ID приложения', default: 0, min: 0, max: 999999999 }),
  P('tap_app_url', 'text', { label: 'Путь / URL приложения', default: 'pages/index' }),
];

// Не меняем существующие проекты: старые компоненты получают значения по умолчанию
// только при открытии/экспорте, а новые компоненты сразу содержат эти свойства.
for (const def of Object.values(REGISTRY)) {
  if (!def.properties.some((x) => x.key === 'tap_action')) {
    def.properties.push(...TAP_ACTION_PROPERTIES.map((x) => ({ ...x, options: x.options ? x.options.map(o => ({...o})) : undefined })));
  }
}

function getComponentDef(componentId) {
  return REGISTRY[componentId];
}

function listByCategory() {
  const map = {};
  for (const cat of CATEGORIES) map[cat] = [];
  for (const key of Object.keys(REGISTRY)) {
    map[REGISTRY[key].category].push(REGISTRY[key]);
  }
  return map;
}
