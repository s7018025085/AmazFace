'use strict';
// bridge/github-publisher.js
//
// Ядро GitHub Publishing на стороне локального моста. Здесь живёт ВСЁ, что
// касается токена: браузер отправляет его один раз при подключении и больше
// никогда не получает назад. Токен:
//   - уходит только в заголовок Authorization запросов к api.github.com;
//   - не попадает в логи (все сообщения проходят через redact());
//   - не попадает в публикуемые файлы (проверка перед загрузкой);
//   - хранится в защищённом виде (Windows DPAPI), а если защитить нечем —
//     только в памяти моста до его перезапуска.
//
// Файл не зависит от server.js и Zeus: сеть и файловая система подменяются
// через опции, поэтому логика проверяется тестами с поддельным GitHub.

const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');
const Gh = require('../src/exporter/github-paths.js');
const { createImporter } = require('./github-import.js');

const GH_ACCEPT = 'application/vnd.github+json';
const TOKEN_RE = /^[A-Za-z0-9_]{20,255}$/;
const SECRET_PATTERN = /github_pat_[A-Za-z0-9_]{20,}|gh[pousr]_[A-Za-z0-9]{20,}/;
const MAX_FILE_BYTES = 95 * 1024 * 1024; // лимит Contents API — 100 МБ, оставляем запас

class GhError extends Error {
  constructor(message, info) {
    super(message);
    this.name = 'GhError';
    Object.assign(this, info || {});
  }
}

const delay = (ms, signal) => new Promise((resolve, reject) => {
  if (signal && signal.aborted) return reject(new GhError('Операция отменена.', { code: 'cancelled' }));
  const t = setTimeout(() => { if (signal) signal.removeEventListener('abort', onAbort); resolve(); }, ms);
  const onAbort = () => { clearTimeout(t); reject(new GhError('Операция отменена.', { code: 'cancelled' })); };
  if (signal) signal.addEventListener('abort', onAbort, { once: true });
});

function gitBlobSha(bytes) {
  return crypto.createHash('sha1').update(`blob ${bytes.length}\0`).update(bytes).digest('hex');
}
const sha256 = (bytes) => crypto.createHash('sha256').update(bytes).digest('hex');

// ───────────────────────── хранение токена и настроек ─────────────────────────

function defaultConfigDir(platform, env) {
  if (env.AMAZFACE_CONFIG_DIR) return env.AMAZFACE_CONFIG_DIR;
  if (platform === 'win32') return path.join(env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming'), 'AmazFace');
  return path.join(os.homedir(), '.config', 'amazface');
}

function runPowerShell(script, input) {
  return new Promise((resolve, reject) => {
    const p = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script], { windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
    let out = '', err = '';
    p.stdout.on('data', d => out += d);
    p.stderr.on('data', d => err += d);
    p.on('error', reject);
    p.on('exit', code => code === 0 ? resolve(out.trim()) : reject(new Error('PowerShell завершился с кодом ' + code)));
    p.stdin.end(input);
  });
}

// DPAPI привязывает шифртекст к пользователю Windows: другой пользователь или
// другой компьютер его не расшифрует. Токен передаётся через stdin, а не через
// аргументы командной строки (аргументы видны в списке процессов).
const windowsDpapi = {
  protect: (text) => runPowerShell('$t=[Console]::In.ReadToEnd().Trim(); ConvertTo-SecureString -String $t -AsPlainText -Force | ConvertFrom-SecureString', text),
  unprotect: (blob) => runPowerShell('$e=[Console]::In.ReadToEnd().Trim(); $s=ConvertTo-SecureString -String $e; $b=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($s); try { [Runtime.InteropServices.Marshal]::PtrToStringBSTR($b) } finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($b) }', blob)
};

function createConfigStore(opts) {
  const platform = opts.platform || process.platform;
  const dir = opts.dir || defaultConfigDir(platform, process.env);
  const file = path.join(dir, 'github.json');
  const dpapi = opts.dpapi || windowsDpapi;

  function read() {
    try { const o = JSON.parse(fs.readFileSync(file, 'utf8')); return o && typeof o === 'object' ? o : { version: 1 }; }
    catch (e) { return { version: 1 }; }
  }
  function write(obj) {
    fs.mkdirSync(dir, { recursive: true });
    const tmp = file + '.' + process.pid + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(obj, null, 2), { mode: 0o600 });
    fs.renameSync(tmp, file);
    try { fs.chmodSync(file, 0o600); } catch (e) { /* Windows: права наследуются от профиля */ }
  }
  function bridgeKey() {
    const cfg = read();
    if (!cfg.bridgeKey) { cfg.bridgeKey = crypto.randomBytes(16).toString('hex'); write(cfg); }
    return cfg.bridgeKey;
  }
  return {
    file, read, write, bridgeKey,
    async saveToken(token) {
      const cfg = read();
      let secret = null, protection = 'memory';
      if (platform === 'win32') {
        try { secret = { protection: 'dpapi', data: await dpapi.protect(token) }; protection = 'dpapi'; }
        catch (e) { secret = null; protection = 'memory'; }
      } else if (platform !== 'win32' && !opts.memoryOnly) {
        // Не-Windows (разработка/тесты): файл с правами 0600 в профиле пользователя.
        secret = { protection: 'file-0600', data: Buffer.from(token, 'utf8').toString('base64') };
        protection = 'file-0600';
      }
      if (secret) cfg.secret = secret; else delete cfg.secret;
      write(cfg);
      return protection;
    },
    async loadToken() {
      const s = read().secret;
      if (!s || !s.data) return null;
      try {
        if (s.protection === 'dpapi') return (await dpapi.unprotect(s.data)) || null;
        if (s.protection === 'file-0600') return Buffer.from(s.data, 'base64').toString('utf8') || null;
      } catch (e) { return null; }
      return null;
    },
    clearToken() { const cfg = read(); delete cfg.secret; delete cfg.login; write(cfg); }
  };
}

// ───────────────────────── публикатор ─────────────────────────

function createPublisher(options) {
  const o = Object.assign({
    apiBase: 'https://api.github.com',
    rawBase: 'https://raw.githubusercontent.com',
    apiTimeoutMs: 30000,
    uploadTimeoutMs: 180000,
    cdnTimeoutMs: 330000,   // кэш raw.githubusercontent живёт 5 минут
    cdnPollMs: 10000,
    retries: 3,
    backoffMs: 1000,
    pauseBetweenUploadsMs: 700,
    maxRateWaitMs: 90000,
    log: () => {},
    sleep: delay,
    fetch: globalThis.fetch,
    now: () => new Date()
  }, options || {});
  const store = options.store;
  if (typeof o.fetch !== 'function') throw new Error('В этой версии Node.js нет fetch. Обновите Node.js до 18 или новее.');

  let token = null;                 // токен в памяти моста
  const jobs = new Map();
  let activeJob = null;

  // ---- защита от утечек токена в тексты ----
  const redact = (text) => {
    let s = String(text == null ? '' : text);
    if (token) s = s.split(token).join('[токен скрыт]');
    return s.replace(/github_pat_[A-Za-z0-9_]{8,}|gh[pousr]_[A-Za-z0-9]{8,}/g, '[токен скрыт]');
  };
  const log = (msg) => { try { o.log(redact(msg)); } catch (e) { /* лог не должен ронять публикацию */ } };

  async function getToken() {
    if (!token) token = await store.loadToken();
    return token;
  }

  // ---- HTTP к GitHub ----
  async function http(method, url, opt) {
    opt = opt || {};
    const ctrl = new AbortController();
    const timeoutMs = opt.timeoutMs || o.apiTimeoutMs;
    let timedOut = false;
    const timer = setTimeout(() => { timedOut = true; ctrl.abort(); }, timeoutMs);
    const onParentAbort = () => ctrl.abort();
    if (opt.signal) { if (opt.signal.aborted) ctrl.abort(); else opt.signal.addEventListener('abort', onParentAbort, { once: true }); }
    const headers = { 'User-Agent': 'AmazFace-Publisher', 'Accept': opt.accept || GH_ACCEPT, 'X-GitHub-Api-Version': '2022-11-28' };
    if (opt.auth !== false) headers.Authorization = 'Bearer ' + opt.token;
    let body;
    if (opt.json !== undefined) { body = JSON.stringify(opt.json); headers['Content-Type'] = 'application/json'; }
    try {
      const res = await o.fetch(url, { method, headers, body, signal: ctrl.signal, redirect: 'follow' });
      return res;
    } catch (e) {
      if (opt.signal && opt.signal.aborted) throw new GhError('Операция отменена.', { code: 'cancelled' });
      if (timedOut) throw new GhError(`Нет ответа от сервера за ${Math.round(timeoutMs / 1000)} с (тайм-аут).`, { code: 'timeout', network: true });
      throw new GhError('Сетевая ошибка: не удалось связаться с сервером (' + redact(e && e.cause && e.cause.code || e && e.message || 'неизвестно') + ').', { code: 'network', network: true });
    } finally {
      clearTimeout(timer);
      if (opt.signal) opt.signal.removeEventListener('abort', onParentAbort);
    }
  }

  async function readJson(res) {
    const text = await res.text();
    try { return text ? JSON.parse(text) : null; } catch (e) { return null; }
  }

  function errorFromResponse(res, json) {
    const status = res.status;
    const apiMsg = redact(json && json.message ? String(json.message) : '').slice(0, 300);
    const remaining = res.headers.get('x-ratelimit-remaining');
    const retryAfter = Number(res.headers.get('retry-after'));
    const reset = Number(res.headers.get('x-ratelimit-reset'));
    const rate = status === 429 || (status === 403 && (remaining === '0' || retryAfter > 0 || /rate limit|abuse|secondary/i.test(apiMsg)));
    if (rate) {
      let waitMs = retryAfter > 0 ? retryAfter * 1000 : (reset > 0 ? Math.max(1000, reset * 1000 - o.now().getTime()) : 60000);
      return new GhError('GitHub ограничил частоту запросов (' + status + '). ' + (apiMsg ? apiMsg + ' ' : '') + 'Подождите несколько минут и повторите.', { status, code: 'rate_limit', waitMs });
    }
    const map = {
      401: ['auth', 'GitHub не принял токен (401): он неверный, отозван или истёк. Создайте новый fine-grained токен.'],
      403: ['forbidden', 'Недостаточно прав (403). Токену нужен доступ к этому репозиторию с разрешением Contents: Read and write.' + (apiMsg ? ' Ответ GitHub: ' + apiMsg : '')],
      404: ['not_found', 'Не найдено (404): репозиторий, ветка или файл отсутствует либо у токена нет к ним доступа.'],
      409: ['conflict', 'Конфликт обновления (409): файл изменился на GitHub во время публикации.'],
      422: ['unprocessable', 'GitHub отклонил запрос (422).' + (apiMsg ? ' ' + apiMsg : '')]
    };
    const m = map[status] || ['http', `GitHub вернул ошибку ${status}.` + (apiMsg ? ' ' + apiMsg : '')];
    return new GhError(m[1], { status, code: m[0], apiMessage: apiMsg });
  }

  // Запрос к API с ожиданием при rate limit (не дольше maxRateWaitMs) и
  // повтором сетевых сбоев. Конфликты 409/422 решает вызывающий код.
  async function api(method, pathAndQuery, opt) {
    opt = opt || {};
    const url = o.apiBase + pathAndQuery;
    let lastErr;
    for (let attempt = 0; attempt <= o.retries; attempt++) {
      try {
        const res = await http(method, url, Object.assign({}, opt, { token: opt.token }));
        const json = await readJson(res);
        if (res.ok) return { status: res.status, json };
        const err = errorFromResponse(res, json);
        if (err.code === 'rate_limit' && err.waitMs <= o.maxRateWaitMs && attempt < o.retries) {
          log(`Rate limit: жду ${Math.ceil(err.waitMs / 1000)} с`);
          await o.sleep(err.waitMs, opt.signal);
          lastErr = err; continue;
        }
        throw err;
      } catch (e) {
        if (e && e.network && attempt < o.retries && opt.retryNetwork !== false) {
          lastErr = e;
          await o.sleep(o.backoffMs * Math.pow(2, attempt), opt.signal);
          continue;
        }
        throw e;
      }
    }
    throw lastErr;
  }

  // ---- проверка доступа к репозиторию ----
  async function checkAccess(cfg, tok, signal) {
    Gh.normalizeFolder(cfg.folder); // путь проверяется до любых запросов
    const user = await api('GET', '/user', { token: tok, signal }).catch(e => {
      if (e.code === 'auth') throw e; throw e;
    });
    const repoPath = `/repos/${cfg.owner}/${cfg.repo}`;
    let repo;
    try { repo = (await api('GET', repoPath, { token: tok, signal })).json; }
    catch (e) {
      if (e.code === 'not_found') throw new GhError(`Репозиторий ${cfg.owner}/${cfg.repo} не найден или токен не имеет к нему доступа. Для fine-grained токена в списке репозиториев должен быть выбран именно он.`, { status: 404, code: 'repo_not_found' });
      throw e;
    }
    if (repo.private) throw new GhError('Репозиторий приватный. Для установки по QR часы скачивают файл без авторизации, поэтому нужен публичный репозиторий.', { code: 'repo_private' });
    if (repo.archived) throw new GhError('Репозиторий в архиве (только чтение). Разархивируйте его в настройках GitHub.', { code: 'repo_archived' });
    if (repo.permissions && repo.permissions.push === false) throw new GhError('У токена нет права записи в этот репозиторий. Нужно разрешение Contents: Read and write.', { code: 'no_write' });
    const warnings = [];
    let branch;
    try { branch = (await api('GET', `${repoPath}/branches/${Gh.encodePath(cfg.branch)}`, { token: tok, signal })).json; }
    catch (e) {
      if (e.code === 'not_found') throw new GhError(`Ветка «${cfg.branch}» не найдена в ${cfg.owner}/${cfg.repo}. Автоматически ветки не создаются — укажите существующую.`, { status: 404, code: 'branch_not_found' });
      throw e;
    }
    if (branch && branch.protected) warnings.push(`Ветка «${cfg.branch}» защищена: если правила запрещают прямые коммиты, GitHub отклонит загрузку.`);
    if (!repo.permissions) warnings.push('GitHub не сообщил права токена; доступ на запись будет проверен при первой загрузке.');
    return { login: user.json && user.json.login, repo: { fullName: repo.full_name, htmlUrl: repo.html_url, defaultBranch: repo.default_branch }, warnings };
  }

  // ---- настройки ----
  function parseSettings(body) {
    const ref = body.repoRef ? Gh.parseRepoRef(body.repoRef) : { owner: Gh.validateOwner(body.owner), repo: Gh.validateRepo(body.repo) };
    const naming = body.naming === 'custom' ? 'custom' : 'auto';
    const s = { owner: ref.owner, repo: ref.repo, branch: Gh.validateBranch(body.branch), folder: Gh.normalizeFolder(body.folder), naming, customSlug: '' };
    if (naming === 'custom') s.customSlug = Gh.normalizeSlug(body.customSlug);
    return s;
  }

  async function status() {
    const cfg = store.read();
    const tok = await getToken();
    return {
      connected: !!(tok && cfg.settings && cfg.login),
      login: cfg.login || '',
      settings: cfg.settings || null,
      protection: cfg.secret ? cfg.secret.protection : (tok ? 'memory' : 'none'),
      tokenInMemoryOnly: !!(tok && !cfg.secret)
    };
  }

  async function connect(body) {
    const settings = parseSettings(body || {});
    let tok = body && body.token ? String(body.token).trim() : null;
    if (tok && !TOKEN_RE.test(tok)) throw new GhError('Токен выглядит неверно: он должен быть одной строкой без пробелов (github_pat_… или ghp_…).', { code: 'bad_token' });
    const fresh = !!tok;
    if (!tok) tok = await getToken();
    if (!tok) throw new GhError('Введите токен GitHub.', { code: 'no_token' });
    const previous = token; token = tok;
    let access;
    try { access = await checkAccess(settings, tok); }
    catch (e) { token = previous; throw e; }
    const cfg = store.read();
    cfg.settings = settings; cfg.login = access.login;
    store.write(cfg);
    let protection = cfg.secret ? cfg.secret.protection : 'memory';
    if (fresh) protection = await store.saveToken(tok);
    log(`GitHub подключён: ${access.login} → ${settings.owner}/${settings.repo}@${settings.branch}/${settings.folder}`);
    return Object.assign(await status(), { access, protection });
  }

  async function disconnect() {
    token = null;
    store.clearToken();
    const cfg = store.read(); delete cfg.settings; store.write(cfg);
    return { connected: false };
  }

  // ───────────────────────── публикация ─────────────────────────

  const STEP_DEFS = [
    ['check', 'Проверка репозитория'],
    ['zeus-build', 'Компиляция Zeus (zeus build)'],
    ['prepare', 'Проверка файлов'],
    ['upload', 'Загрузка на GitHub'],
    ['verify-api', 'Проверка загруженных файлов'],
    ['verify-url', 'Проверка публичной ссылки']
  ];

  function newJob() {
    const id = Date.now().toString(36) + crypto.randomBytes(3).toString('hex');
    const ctrl = new AbortController();
    const job = {
      id, status: 'running', startedAt: o.now().toISOString(), finishedAt: null,
      steps: STEP_DEFS.map(([sid, label]) => ({ id: sid, label, status: 'pending', detail: '' })),
      files: [], result: null, error: null, _ctrl: ctrl
    };
    jobs.set(id, job);
    for (const k of [...jobs.keys()].slice(0, Math.max(0, jobs.size - 8))) jobs.delete(k);
    return job;
  }
  const setStep = (job, id, st, detail) => { const s = job.steps.find(x => x.id === id); if (s) { s.status = st; if (detail !== undefined) s.detail = detail; } };

  function publicJob(job) {
    const { _ctrl, ...rest } = job;
    return rest;
  }

  function containsSecret(bytes) {
    const text = bytes.toString('utf8');
    return SECRET_PATTERN.test(text) || (token && text.includes(token));
  }

  function validateArtifacts(artifacts) {
    const out = {};
    for (const kind of Gh.KINDS) {
      const buf = artifacts && artifacts[kind];
      if (!Buffer.isBuffer(buf) || !buf.length) throw new GhError(`Файл «${kind}» не собран или пустой — публикация остановлена.`, { code: 'bad_artifact' });
      if (buf.length > MAX_FILE_BYTES) throw new GhError(`Файл «${kind}» больше ${Math.round(MAX_FILE_BYTES / 1048576)} МБ — GitHub его не примет.`, { code: 'too_big' });
      if (kind === 'json') {
        try { JSON.parse(buf.toString('utf8')); } catch (e) { throw new GhError('Исходник циферблата (.watchface.json) не является корректным JSON.', { code: 'bad_artifact' }); }
        if (containsSecret(buf)) throw new GhError('В исходнике циферблата найден токен GitHub — публикация остановлена.', { code: 'secret_found' });
      } else if (!(buf[0] === 0x50 && buf[1] === 0x4b && buf[2] === 0x03 && buf[3] === 0x04)) {
        throw new GhError(`Файл «${kind}» не является ZIP-архивом.`, { code: 'bad_artifact' });
      }
      out[kind] = buf;
    }
    checkZpk(out.zpk);
    // Картинки мокапов необязательны для старых клиентов, но если пришли — проверяем PNG.
    for (const kind of ['watch', 'watch200', 'watchQr']) {
      const png = artifacts && artifacts[kind];
      if (png === undefined || png === null) continue;
      const isPng = Buffer.isBuffer(png) && png.length > 8 && png[0] === 0x89 && png[1] === 0x50 && png[2] === 0x4e && png[3] === 0x47;
      if (!isPng) throw new GhError(`Файл «${kind}» не является PNG-картинкой.`, { code: 'bad_artifact' });
      if (png.length > MAX_FILE_BYTES) throw new GhError(`Картинка «${kind}» слишком большая.`, { code: 'too_big' });
      out[kind] = png;
    }
    // Анимированное превью (GIF) тоже необязательно: если пришло — проверяем сигнатуру GIF89a/GIF87a.
    const gif = artifacts && artifacts.watchGif;
    if (gif !== undefined && gif !== null) {
      const sig = Buffer.isBuffer(gif) && gif.length > 14 ? gif.toString('latin1', 0, 6) : '';
      if (sig !== 'GIF89a' && sig !== 'GIF87a') throw new GhError('Файл «watchGif» не является GIF-картинкой.', { code: 'bad_artifact' });
      if (gif.length > MAX_FILE_BYTES) throw new GhError('Анимированное превью (GIF) слишком большое.', { code: 'too_big' });
      out.watchGif = gif;
    }
    return out;
  }

  function checkZpk(zpk) {
    if (zpk.includes(Buffer.from('manifest.json'))) throw new GhError('Внутри .zpk лежит manifest.json: Zepp App не разбирает такой пакет («Parse mini program package failed»). Нужен .zpk из app-side.zip и device.zip.', { code: 'bad_artifact' });
    if (!zpk.includes(Buffer.from('device.zip'))) throw new GhError('Внутри .zpk нет device.zip: это не установочный пакет Zepp.', { code: 'bad_artifact' });
  }

  // Пакет из браузера содержит исходный JS и на часах даёт чёрный экран.
  // Если подключена сборка Zeus, .zpk и device.zip берутся из `zeus build`.
  async function compileWithZeus(job, art, signal) {
    if (!o.zeusBuild) { setStep(job, 'zeus-build', 'done', 'пропущено (Zeus не подключён)'); return art; }
    setStep(job, 'zeus-build', 'running', 'zeus build (до нескольких минут)…');
    let built;
    try {
      built = await o.zeusBuild(art.projectZip, { signal });
    } catch (e) {
      if (e instanceof GhError) throw e;
      throw new GhError('Сборка Zeus не удалась: ' + redact(e.message), { code: e.code === 'zeus_missing' ? 'zeus_missing' : 'zeus_build' });
    }
    for (const [k, buf] of [['zpk', built && built.zpk], ['deviceZip', built && built.deviceZip]]) {
      if (!Buffer.isBuffer(buf) || !buf.length) throw new GhError(`Zeus не вернул «${k}».`, { code: 'zeus_build' });
      if (buf.length > MAX_FILE_BYTES) throw new GhError(`Файл «${k}» от Zeus больше ${Math.round(MAX_FILE_BYTES / 1048576)} МБ — GitHub его не примет.`, { code: 'too_big' });
      if (!(buf[0] === 0x50 && buf[1] === 0x4b && buf[2] === 0x03 && buf[3] === 0x04)) throw new GhError(`Файл «${k}» от Zeus не является ZIP-архивом.`, { code: 'zeus_build' });
    }
    checkZpk(built.zpk);
    setStep(job, 'zeus-build', 'done', `${built.zabName || 'пакет'} → .zpk ${Math.round(built.zpk.length / 1024)} КБ`);
    return Object.assign({}, art, { zpk: built.zpk, deviceZip: built.deviceZip });
  }

  async function listDir(cfg, dir, tok, signal) {
    try {
      const r = await api('GET', `/repos/${cfg.owner}/${cfg.repo}/contents/${Gh.encodePath(dir)}?ref=${encodeURIComponent(cfg.branch)}`, { token: tok, signal });
      if (!Array.isArray(r.json)) throw new GhError(`По пути «${dir}» в репозитории лежит файл, а не папка. Выберите другое имя.`, { code: 'path_is_file' });
      const map = new Map();
      for (const e of r.json) map.set(e.name, { sha: e.sha, type: e.type });
      return map;
    } catch (e) {
      if (e.code === 'not_found') return new Map();
      throw e;
    }
  }

  async function remoteSha(cfg, filePath, tok, signal) {
    try {
      const r = await api('GET', `/repos/${cfg.owner}/${cfg.repo}/contents/${Gh.encodePath(filePath)}?ref=${encodeURIComponent(cfg.branch)}`, { token: tok, signal });
      return r.json && !Array.isArray(r.json) ? r.json.sha : undefined;
    } catch (e) { if (e.code === 'not_found') return undefined; throw e; }
  }

  async function readMarker(cfg, markerPath, tok, signal) {
    const r = await api('GET', `/repos/${cfg.owner}/${cfg.repo}/contents/${Gh.encodePath(markerPath)}?ref=${encodeURIComponent(cfg.branch)}`, { token: tok, signal });
    try { return JSON.parse(Buffer.from(String(r.json.content || ''), 'base64').toString('utf8')); } catch (e) { return null; }
  }

  const cleanMsg = (s) => String(s).replace(/[\r\n\t]+/g, ' ').replace(/[^\x20-\x7e\u0400-\u04ff]/g, '').slice(0, 120);

  async function uploadOne(cfg, entry, knownSha, tok, signal, message) {
    const localSha = gitBlobSha(entry.bytes);
    let current = knownSha;
    let lastErr;
    for (let attempt = 0; attempt <= o.retries; attempt++) {
      if (attempt > 0) {
        await o.sleep(o.backoffMs * Math.pow(2, attempt - 1), signal);
        // После сбоя неизвестно, дошёл ли PUT: читаем актуальный sha заново.
        current = await remoteSha(cfg, entry.path, tok, signal);
      }
      if (current === localSha) return { status: 'unchanged', sha: localSha };
      try {
        const payload = { message: cleanMsg(message), content: entry.bytes.toString('base64'), branch: cfg.branch };
        if (current) payload.sha = current;
        const r = await api('PUT', `/repos/${cfg.owner}/${cfg.repo}/contents/${Gh.encodePath(entry.path)}`, { token: tok, signal, json: payload, timeoutMs: o.uploadTimeoutMs, retryNetwork: false });
        return { status: current ? 'updated' : 'created', sha: r.json && r.json.content && r.json.content.sha, commit: r.json && r.json.commit && r.json.commit.sha };
      } catch (e) {
        const retryable = e.network || e.status === 409 || (e.status === 422 && /sha/i.test(e.apiMessage || ''));
        if (!retryable || attempt === o.retries) {
          if (e.status === 409 || e.status === 422 && /sha/i.test(e.apiMessage || '')) e.message = 'Не удалось обновить файл: он постоянно меняется на GitHub (конфликт SHA). Повторите публикацию позже.';
          throw e;
        }
        lastErr = e;
        log(`Повтор загрузки ${entry.path}: ${e.code || e.status}`);
      }
    }
    throw lastErr;
  }

  async function verifyPublicUrl(url, exp, signal) {
    let res;
    try { res = await http('GET', url, { auth: false, accept: '*/*', signal, timeoutMs: 60000 }); }
    catch (e) { if (e.code === 'cancelled') throw e; return { ok: false, reason: 'network', detail: e.message }; }
    if (res.status !== 200) { try { await res.arrayBuffer(); } catch (e) {} return { ok: false, reason: 'status', detail: `HTTP ${res.status}` }; }
    const ct = res.headers.get('content-type') || '';
    const buf = Buffer.from(await res.arrayBuffer());
    if (/text\/html/i.test(ct)) return { ok: false, reason: 'html', detail: 'сервер вернул HTML-страницу вместо файла' };
    if (buf.length < 4 || !(buf[0] === 0x50 && buf[1] === 0x4b)) return { ok: false, reason: 'not_zip', detail: 'по ссылке отдаётся не ZIP/.zpk' };
    if (buf.length !== exp.size || sha256(buf) !== exp.sha256) return { ok: false, reason: 'stale', detail: 'по ссылке пока отдаётся предыдущая версия (кэш CDN)' };
    return { ok: true, contentType: ct, size: buf.length };
  }

  async function runPublish(job, cfg, tok, req) {
    const signal = job._ctrl.signal;
    const names = Gh.fileNames(req.slug);
    const paths = Gh.targetPaths({ folder: cfg.folder, slug: req.slug });
    const zpkUrl = Gh.rawUrl({ owner: cfg.owner, repo: cfg.repo, branch: cfg.branch, path: paths.files.zpk });

    // 1. репозиторий
    setStep(job, 'check', 'running');
    const access = await checkAccess(cfg, tok, signal);
    setStep(job, 'check', 'done', `${access.login} → ${cfg.owner}/${cfg.repo}@${cfg.branch}` + (access.warnings.length ? ' · ' + access.warnings.join(' ') : ''));

    // 2. файлы
    const input = validateArtifacts(req.artifacts);
    const art = await compileWithZeus(job, input, signal);
    setStep(job, 'prepare', 'running');
    const publishedAt = o.now().toISOString();
    const hashes = {};
    for (const k of Gh.KINDS) hashes[names[k]] = { sha256: sha256(art[k]), size: art[k].length };
    for (const kind of ['watch', 'watch200', 'watchGif']) if (art[kind]) hashes[names[kind]] = { sha256: sha256(art[kind]), size: art[kind].length };
    const deepLink = 'zpkd1://' + zpkUrl.replace(/^https?:\/\//i, '');
    const warnings = access.warnings.slice();
    // Картинка с QR публикуется, только если QR в ней закодирован ровно на ту ссылку, которую
    // мост сам построил из своих настроек. Иначе в репозитории оказался бы «чужой» QR.
    let watchQr = null;
    if (art.watchQr) {
      if (req.watchQrLink === deepLink) { watchQr = art.watchQr; hashes[names.watchQr] = { sha256: sha256(watchQr), size: watchQr.length }; }
      else warnings.push('watch-qr.png не загружен: ссылка в QR не совпала с настройками публикации. Сохраните настройки и опубликуйте заново.');
    }
    const readme = Buffer.from(Gh.buildReadme({
      name: req.name, version: req.version, publishedAt, zpkName: names.zpk, zpkUrl,
      deepLink, jsonName: names.json, watchName: art.watch ? names.watch : null,
      watch200Name: art.watch200 ? names.watch200 : null, watchQrName: watchQr ? names.watchQr : null,
      watchGifName: art.watchGif ? names.watchGif : null
    }), 'utf8');
    if (containsSecret(readme)) throw new GhError('README содержит токен — публикация остановлена.', { code: 'secret_found' });
    const marker = Buffer.from(JSON.stringify({ generator: 'AmazFace', schema: 1, appId: String(req.appId), name: req.name, slug: req.slug, version: req.version, publishedAt, files: hashes }, null, 2), 'utf8');
    // Порядок важен: служебный маркер — первым (защита папки), установочный
    // .zpk — последним (постоянная ссылка переключается на новую версию только
    // когда всё остальное уже загружено).
    const order = [
      { kind: 'marker', path: paths.files.marker, bytes: marker },
      { kind: 'projectZip', path: paths.files.projectZip, bytes: art.projectZip },
      { kind: 'deviceZip', path: paths.files.deviceZip, bytes: art.deviceZip },
      { kind: 'json', path: paths.files.json, bytes: art.json },
      ...(art.watch ? [{ kind: 'watch', path: paths.files.watch, bytes: art.watch }] : []),
      ...(art.watch200 ? [{ kind: 'watch200', path: paths.files.watch200, bytes: art.watch200 }] : []),
      ...(art.watchGif ? [{ kind: 'watchGif', path: paths.files.watchGif, bytes: art.watchGif }] : []),
      ...(watchQr ? [{ kind: 'watchQr', path: paths.files.watchQr, bytes: watchQr }] : []),
      { kind: 'readme', path: paths.files.readme, bytes: readme },
      { kind: 'zpk', path: paths.files.zpk, bytes: art.zpk }
    ];
    job.files = order.map(e => ({ kind: e.kind, path: e.path, size: e.bytes.length, status: 'pending' }));
    setStep(job, 'prepare', 'done', `${order.length} файлов, .zpk ${Math.round(art.zpk.length / 1024)} КБ`);

    // 3. загрузка
    setStep(job, 'upload', 'running', 'Читаю текущее состояние папки…');
    const existing = await listDir(cfg, paths.dir, tok, signal);
    if (existing.size) {
      if (!existing.has(Gh.MARKER_NAME)) throw new GhError(`Папка «${paths.dir}» уже существует и содержит файлы, созданные не AmazFace. Чтобы не перезаписать чужое, публикация остановлена — выберите другую папку или имя.`, { code: 'foreign_folder' });
      const m = await readMarker(cfg, paths.files.marker, tok, signal);
      if (!m || m.generator !== 'AmazFace') throw new GhError(`Служебный файл в «${paths.dir}» повреждён или создан не AmazFace — публикация остановлена.`, { code: 'foreign_folder' });
      if (String(m.appId) !== String(req.appId)) throw new GhError(`Папка «${paths.dir}» принадлежит другому циферблату («${m.name || 'без имени'}»). Чтобы не перезаписать его файлы, публикация остановлена — задайте другое имя в настройках публикации.`, { code: 'foreign_project' });
    }
    let done = 0;
    for (let i = 0; i < order.length; i++) {
      const e = order[i], rec = job.files[i];
      rec.status = 'uploading';
      setStep(job, 'upload', 'running', `Загружаю ${path.posix.basename(e.path)} (${done + 1}/${order.length})`);
      const known = existing.get(path.posix.basename(e.path));
      try {
        const r = await uploadOne(cfg, e, known && known.sha, tok, signal, `AmazFace: ${req.name} v${req.version} — ${path.posix.basename(e.path)}`);
        rec.status = r.status; rec.sha = r.sha; rec.commit = r.commit;
      } catch (err) { rec.status = 'failed'; throw err; }
      done++;
      if (i < order.length - 1 && o.pauseBetweenUploadsMs) await o.sleep(o.pauseBetweenUploadsMs, signal);
    }
    setStep(job, 'upload', 'done', `Загружено: ${job.files.filter(f => f.status === 'created' || f.status === 'updated').length}, без изменений: ${job.files.filter(f => f.status === 'unchanged').length}`);

    // 4. файлы действительно в репозитории
    setStep(job, 'verify-api', 'running');
    const after = await listDir(cfg, paths.dir, tok, signal);
    const missing = order.filter(e => {
      const a = after.get(path.posix.basename(e.path));
      return !a || a.sha !== gitBlobSha(e.bytes);
    });
    if (missing.length) throw new GhError('После загрузки в репозитории не совпали файлы: ' + missing.map(m => path.posix.basename(m.path)).join(', ') + '. Повторите публикацию.', { code: 'verify_api' });
    setStep(job, 'verify-api', 'done', 'Все файлы на месте, SHA совпадают');

    // 5. публичная ссылка (без авторизации) возвращает именно .zpk
    setStep(job, 'verify-url', 'running', 'Запрашиваю ссылку без авторизации…');
    const exp = { size: art.zpk.length, sha256: sha256(art.zpk) };
    let waited = 0;
    let attempts = 0, last = null, wrongContent = 0;
    for (;;) {
      attempts++;
      last = await verifyPublicUrl(zpkUrl.replace(/^https:\/\/raw\.githubusercontent\.com/, o.rawBase), exp, signal);
      if (last.ok) break;
      wrongContent = (last.reason === 'html' || last.reason === 'not_zip') ? wrongContent + 1 : 0;
      if (wrongContent >= 3 || waited + o.cdnPollMs > o.cdnTimeoutMs) break;
      setStep(job, 'verify-url', 'running', `Попытка ${attempts}: ${last.detail}. Жду обновления CDN GitHub (до ${Math.round(o.cdnTimeoutMs / 60000 * 10) / 10} мин)…`);
      await o.sleep(o.cdnPollMs, signal);
      waited += o.cdnPollMs;
    }
    if (!last.ok) {
      const why = last.reason === 'stale' ? 'Ссылка всё ещё отдаёт предыдущую версию файла (кэш CDN GitHub).'
        : last.reason === 'html' || last.reason === 'not_zip' ? 'Ссылка отдаёт не установочный пакет: ' + last.detail + '.'
        : 'Ссылка не открылась без авторизации: ' + last.detail + '.';
      throw new GhError(why + ' Файлы в репозитории загружены; QR не создан, чтобы он не указывал на неверный файл. Нажмите «Повторить» через несколько минут.', { code: last.reason === 'stale' ? 'cdn_stale' : 'url_unavailable', uploaded: true });
    }
    setStep(job, 'verify-url', 'done', `Ссылка отдаёт .zpk (${Math.round(last.size / 1024)} КБ), содержимое совпадает`);

    const lastCommit = [...job.files].reverse().find(f => f.commit);
    return {
      zpkUrl, zpkName: names.zpk,
      deepLink,
      repoUrl: Gh.repoUrl(cfg), folderUrl: Gh.treeUrl({ owner: cfg.owner, repo: cfg.repo, branch: cfg.branch, path: paths.dir }),
      commitUrl: lastCommit ? `${Gh.repoUrl(cfg)}/commit/${lastCommit.commit}` : null,
      sha256: exp.sha256, size: exp.size, verifiedAt: o.now().toISOString(), attempts,
      warnings
    };
  }

  async function startPublish(body) {
    if (activeJob && activeJob.status === 'running') throw new GhError('Публикация уже выполняется.', { code: 'busy', status: 409 });
    const cfg = store.read().settings;
    const tok = await getToken();
    if (!cfg || !tok) throw new GhError('GitHub не подключён: откройте настройки публикации и подключите репозиторий.', { code: 'not_connected', status: 409 });
    const slug = Gh.normalizeSlug(cfg.naming === 'custom' ? cfg.customSlug : body.slug);
    if (!body.appId && body.appId !== 0) throw new GhError('У проекта нет appId — публикация невозможна.', { code: 'bad_request', status: 400 });
    const req = {
      slug, appId: body.appId, name: String(body.name || slug).slice(0, 120),
      version: String(body.version || '1.0.0').slice(0, 40), artifacts: body.artifacts,
      watchQrLink: typeof body.watchQrLink === 'string' ? body.watchQrLink : ''
    };
    const job = newJob(); activeJob = job;
    (async () => {
      try {
        job.result = await runPublish(job, cfg, tok, req);
        job.status = 'done';
      } catch (e) {
        job.status = job.status === 'cancelled' ? 'cancelled' : 'failed';
        const running = job.steps.find(s => s.status === 'running');
        if (running) { running.status = 'failed'; running.detail = redact(e.message); }
        job.error = { code: e.code || 'error', message: redact(e && e.message || String(e)), step: running ? running.id : null, uploaded: !!e.uploaded };
        log('Публикация не удалась: ' + job.error.message);
      } finally {
        job.finishedAt = o.now().toISOString();
        job.artifactsReleased = true;
      }
    })();
    return publicJob(job);
  }

  function getJob(id) { const j = jobs.get(String(id)); return j ? publicJob(j) : null; }
  function cancel(id) {
    const j = jobs.get(String(id));
    if (!j || j.status !== 'running') return false;
    j.status = 'cancelled'; j._ctrl.abort();
    return true;
  }

  // Импорт проектов (только чтение): тот же клиент `api`, тот же токен и настройки.
  const importer = createImporter({ api, getToken, store, GhError, log, now: () => o.now().getTime() });

  return {
    status, connect, disconnect, startPublish, getJob, cancel, checkAccess,
    listImportProjects: importer.listProjects, getImportManifest: importer.getManifest, getImportFile: importer.getFile,
    _internals: { verifyPublicUrl, gitBlobSha, redact }
  };
}

module.exports = { createPublisher, createConfigStore, GhError, gitBlobSha, sha256, SECRET_PATTERN, TOKEN_RE };
