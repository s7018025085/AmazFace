'use strict';
// bridge/github-routes.js
//
// HTTP-слой GitHub Publishing для локального моста. Подключается из server.js
// одной строкой и не затрагивает маршруты Zeus (/health, /bridge/*, /preview…).
//
// Защита (остальные маршруты моста открыты с CORS «*», здесь строже, потому что
// рядом лежит токен GitHub):
//   1. Host должен быть loopback — защита от DNS rebinding.
//   2. Origin — только null (file://) и localhost/127.0.0.1. Чужие сайты в
//      браузере пользователя получают 403, в том числе на preflight.
//   3. Заголовок X-AmazFace-Key с кодом доступа, который мост печатает в своём
//      окне и хранит в профиле. Закрывает остальных локальных веб-клиентов и
//      sandbox-iframe с Origin «null».
//   4. Ни одного маршрута, который выполняет команды или читает произвольные
//      файлы: путь и ветка публикации берутся из сохранённых настроек.

const crypto = require('crypto');
const { createPublisher, createConfigStore, GhError } = require('./github-publisher');

const ORIGIN_RE = /^(null|https?:\/\/(localhost|127\.0\.0\.1|\[::1\])(:\d{1,5})?)$/i;
const HOST_RE = /^(127\.0\.0\.1|localhost|\[::1\])(:\d{1,5})?$/i;
const MAX_BODY = 260 * 1024 * 1024;

function createGithubRoutes(opts) {
  opts = opts || {};
  const store = opts.store || createConfigStore({});
  const publisher = opts.publisher || createPublisher(Object.assign({ store, log: opts.log || (() => {}) }, opts.publisherOptions || {}));
  const key = () => store.bridgeKey();

  function setCors(req, res) {
    const origin = req.headers.origin;
    res.removeHeader('Access-Control-Allow-Origin');
    if (origin) { res.setHeader('Access-Control-Allow-Origin', origin); res.setHeader('Vary', 'Origin'); }
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type,X-AmazFace-Key');
    res.setHeader('Access-Control-Allow-Private-Network', 'true');
  }
  function send(req, res, code, obj) {
    setCors(req, res);
    res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(JSON.stringify(obj));
  }
  function readBody(req) {
    return new Promise((resolve, reject) => {
      const chunks = []; let size = 0;
      req.on('data', c => { size += c.length; if (size > MAX_BODY) { reject(new GhError('Запрос слишком большой.', { status: 413, code: 'too_big' })); req.destroy(); } else chunks.push(c); });
      req.on('end', () => resolve(Buffer.concat(chunks)));
      req.on('error', reject);
    });
  }
  async function readJson(req) {
    const buf = await readBody(req);
    if (!buf.length) return {};
    try { return JSON.parse(buf.toString('utf8')); } catch (e) { throw new GhError('Некорректный JSON в запросе.', { status: 400, code: 'bad_request' }); }
  }
  function keyOk(req) {
    const given = String(req.headers['x-amazface-key'] || '');
    const a = Buffer.from(given), b = Buffer.from(key());
    return a.length === b.length && crypto.timingSafeEqual(a, b);
  }

  function sendBytes(req, res, buf) {
    setCors(req, res);
    res.writeHead(200, { 'Content-Type': 'application/octet-stream', 'Content-Length': buf.length, 'Cache-Control': 'no-store' });
    res.end(buf);
  }

  const matches = (req) => String(req.url || '').split('?')[0].startsWith('/github/');

  async function handle(req, res) {
    const url = new URL(req.url, 'http://127.0.0.1');
    const route = url.pathname;
    try {
      if (!HOST_RE.test(String(req.headers.host || ''))) return send(req, res, 403, { error: 'Недопустимый Host.' });
      const origin = req.headers.origin;
      if (origin && !ORIGIN_RE.test(origin)) { res.removeHeader('Access-Control-Allow-Origin'); return send({ headers: {} }, res, 403, { error: 'Источник запроса не разрешён.' }); }
      if (req.method === 'OPTIONS') { setCors(req, res); res.writeHead(204); return res.end(); }

      if (req.method === 'GET' && route === '/github/ping') {
        return send(req, res, 200, { ok: true, keyRequired: true, keyValid: keyOk(req), node: process.version });
      }
      if (!keyOk(req)) return send(req, res, 401, { error: 'Нужен код доступа к мосту. Он показан в окне моста (start-zeus-bridge.bat).', code: 'key' });

      if (req.method === 'GET' && route === '/github/status') return send(req, res, 200, await publisher.status());
      if (req.method === 'POST' && route === '/github/connect') return send(req, res, 200, await publisher.connect(await readJson(req)));
      if (req.method === 'POST' && route === '/github/disconnect') return send(req, res, 200, await publisher.disconnect());
      if (req.method === 'POST' && route === '/github/publish') {
        const body = await readJson(req);
        const artifacts = {};
        for (const [k, v] of Object.entries(body.artifacts || {})) {
          if (typeof v !== 'string') throw new GhError('Некорректное содержимое файла «' + k + '».', { status: 400, code: 'bad_request' });
          artifacts[k] = Buffer.from(v, 'base64');
        }
        return send(req, res, 202, await publisher.startPublish(Object.assign({}, body, { artifacts })));
      }
      if (req.method === 'GET' && route === '/github/job') {
        const job = publisher.getJob(url.searchParams.get('id'));
        return job ? send(req, res, 200, job) : send(req, res, 404, { error: 'Задание не найдено.' });
      }
      if (req.method === 'POST' && route === '/github/cancel') {
        const b = await readJson(req);
        return send(req, res, 200, { ok: publisher.cancel(b.id) });
      }
      // Импорт проектов: только чтение, те же настройки и токен, что у публикации.
      if (req.method === 'GET' && route === '/github/import/projects') return send(req, res, 200, await publisher.listImportProjects());
      if (req.method === 'GET' && route === '/github/import/manifest') return send(req, res, 200, await publisher.getImportManifest(url.searchParams.get('dir')));
      if (req.method === 'GET' && route === '/github/import/file') {
        return sendBytes(req, res, await publisher.getImportFile(url.searchParams.get('dir'), url.searchParams.get('path')));
      }
      return send(req, res, 404, { error: 'Not found' });
    } catch (e) {
      // Ошибки GitHub не пробрасываем как HTTP-статус моста (404 от GitHub не должен
      // выглядеть как «нет такого маршрута»): наружу — 400, детали в code/error.
      const code = e && e.code;
      const status = code === 'busy' || code === 'not_connected' ? 409 : code === 'too_big' ? 413 : 400;
      // Сообщение уже очищено от токена внутри публикатора; stack наружу не отдаём.
      return send(req, res, status, { error: String(e && e.message || e), code: code || 'error' });
    }
  }

  return { matches, handle, publisher, store, bridgeKey: key };
}

module.exports = { createGithubRoutes, ORIGIN_RE, HOST_RE };
