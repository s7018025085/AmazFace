// Тесты кодировщика GIF: круговая проверка встроенным декодером (BgAnim.decodeGif).
// Запуск: node scripts/test-gif-encoder.js
const G = require('../src/exporter/gif-encoder.js');
const B = require('../src/anim/bg-anim.js');

let failed = 0;
function ok(name, cond, extra) { if (cond) console.log('ok: ' + name); else { failed++; console.log('FAIL: ' + name + (extra ? ' — ' + extra : '')); } }

const W = 64, H = 48, N = 6;
function makeFrame(n, transparentCorners) {
  const f = new Uint8ClampedArray(W * H * 4);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const i = (y * W + x) * 4;
    f[i] = Math.round(255 * x / (W - 1));
    f[i + 1] = Math.round(255 * y / (H - 1));
    f[i + 2] = (n * 40) % 256;
    f[i + 3] = 255;
    if (transparentCorners && x + y < 10) f[i + 3] = 0;
  }
  return f;
}
const maxErr = (a, b, skipTransparent) => {
  let m = 0;
  for (let i = 0; i < a.length; i += 4) {
    if (skipTransparent && (b[i + 3] === 0 || a[i + 3] === 0)) continue;
    for (let c = 0; c < 3; c++) m = Math.max(m, Math.abs(a[i + c] - b[i + c]));
  }
  return m;
};

// 1. непрозрачные кадры
let frames = Array.from({ length: N }, (_, n) => makeFrame(n, false));
let gif = G.encode(frames, { width: W, height: H, delayCs: 8 });
ok('сигнатура GIF89a', String.fromCharCode(...gif.slice(0, 6)) === 'GIF89a');
ok('завершающий байт 0x3B', gif[gif.length - 1] === 0x3B);
let dec = B.decodeGif(gif);
ok('размер и число кадров', dec.width === W && dec.height === H && dec.frames.length === N, dec.width + 'x' + dec.height + ' ' + dec.frames.length);
ok('задержка кадра 80 мс', dec.frames.every((f) => f.delay === 80), dec.frames.map((f) => f.delay).join());
let worst = 0;
dec.frames.forEach((f, n) => { worst = Math.max(worst, maxErr(frames[n], f.rgba, false)); });
ok('цвета близки к исходным (макс. ошибка ≤ 40)', worst <= 40, 'ошибка ' + worst);
ok('все пиксели непрозрачны', dec.frames.every((f) => { for (let i = 3; i < f.rgba.length; i += 4) if (f.rgba[i] !== 255) return false; return true; }));

// 2. прозрачные углы
frames = Array.from({ length: N }, (_, n) => makeFrame(n, true));
gif = G.encode(frames, { width: W, height: H, delayCs: [5, 5, 5, 5, 5, 20] });
dec = B.decodeGif(gif);
ok('прозрачность: угол (0,0) прозрачен во всех кадрах', dec.frames.every((f) => f.rgba[3] === 0));
ok('прозрачность: центр непрозрачен', dec.frames.every((f) => f.rgba[((H >> 1) * W + (W >> 1)) * 4 + 3] === 255));
ok('прозрачность: диспоз. 2 не копит пиксели между кадрами', dec.frames.every((f, n) => { let m = 0; for (let i = 0; i < f.rgba.length; i += 4) if (frames[n][i + 3] === 0 && f.rgba[i + 3] !== 0) m++; return m === 0; }));
ok('задержки по кадрам 50…200 мс', dec.frames[0].delay === 50 && dec.frames[5].delay === 200, dec.frames.map((f) => f.delay).join());
let w2 = 0;
dec.frames.forEach((f, n) => { w2 = Math.max(w2, maxErr(frames[n], f.rgba, true)); });
ok('прозрачность: цвета близки (≤ 40)', w2 <= 40, 'ошибка ' + w2);

// 3. NETSCAPE: бесконечный цикл
const s = Buffer.from(gif).toString('latin1');
const at = s.indexOf('NETSCAPE2.0');
ok('NETSCAPE2.0: цикл 0 = бесконечно', at > 0 && gif[at + 11] === 3 && gif[at + 12] === 1 && gif[at + 13] === 0 && gif[at + 14] === 0);

// 4. сложная картинка: переполнение словаря LZW (сброс кода очистки)
const BW = 200, BH = 200;
const noisy = new Uint8ClampedArray(BW * BH * 4);
let seed = 12345;
for (let i = 0; i < noisy.length; i += 4) { seed = (seed * 1103515245 + 12345) & 0x7fffffff; noisy[i] = seed >> 8; noisy[i + 1] = seed >> 12; noisy[i + 2] = seed >> 4; noisy[i + 3] = 255; }
const bigGif = G.encode([noisy, noisy], { width: BW, height: BH });
const bigDec = B.decodeGif(bigGif);
ok('шум: декодируется, 2 кадра, пиксели заполнены', bigDec.frames.length === 2 && bigDec.frames[0].rgba.every((v, i) => i % 4 !== 3 || v === 255));
ok('шум: два одинаковых кадра декодируются одинаково', Buffer.compare(Buffer.from(bigDec.frames[0].rgba), Buffer.from(bigDec.frames[1].rgba)) === 0);

// 4b. большой «фото-подобный» кадр: словарь LZW переполняется несколько раз, цвета должны сохраниться
const PW = 320, PH = 320, photo = new Uint8ClampedArray(PW * PH * 4);
for (let y = 0; y < PH; y++) for (let x = 0; x < PW; x++) {
  const i = (y * PW + x) * 4;
  photo[i] = 128 + 120 * Math.sin(x / 23) * Math.cos(y / 31);
  photo[i + 1] = 128 + 120 * Math.sin((x + y) / 41);
  photo[i + 2] = 128 + 120 * Math.cos(x / 17 - y / 29);
  photo[i + 3] = 255;
}
const pDec = B.decodeGif(G.encode([photo], { width: PW, height: PH }));
let sum = 0; for (let i = 0; i < photo.length; i += 4) for (let c = 0; c < 3; c++) sum += Math.abs(photo[i + c] - pDec.frames[0].rgba[i + c]);
const mean = sum / (PW * PH * 3);
ok('большой кадр: средняя ошибка цвета мала (< 12, это потери 256 цветов)', mean < 12, 'средняя ошибка ' + mean.toFixed(2));

// 4c. LZW напрямую: индексы после кодирования и независимого декодирования совпадают точно
function lzwDecodeRef(bytes, minCode, n) {
  const clear = 1 << minCode, eoi = clear + 1;
  let size = minCode + 1, dict = [], out = [], bits = 0, nb = 0, pos = 0, prev = null;
  const reset = () => { dict = []; for (let i = 0; i < clear + 2; i++) dict[i] = [i]; size = minCode + 1; prev = null; };
  reset();
  while (out.length < n) {
    while (nb < size) { if (pos >= bytes.length) return out; bits |= bytes[pos++] << nb; nb += 8; }
    const code = bits & ((1 << size) - 1); bits >>>= size; nb -= size;
    if (code === clear) { reset(); continue; }
    if (code === eoi) break;
    let entry;
    if (code < dict.length) entry = dict[code]; else entry = prev.concat(prev[0]);
    for (const v of entry) out.push(v);
    if (prev) dict.push(prev.concat(entry[0]));
    prev = entry;
    if (dict.length >= (1 << size) - 0 && size < 12) size++;
    if (dict.length >= 4096) { /* ждём clear от кодировщика */ }
  }
  return out;
}
for (const [bitsPer, len] of [[2, 20000], [4, 100000], [8, 200000]]) {
  const idx = new Uint8Array(len); let sd = 777 + bitsPer;
  for (let i = 0; i < len; i++) { sd = (sd * 1103515245 + 12345) & 0x7fffffff; idx[i] = ((sd >> 10) ^ (i >> 3)) & ((1 << bitsPer) - 1); }
  const enc = G.lzwEncode(idx, Math.max(2, bitsPer));
  const back = lzwDecodeRef(enc, Math.max(2, bitsPer), len);
  let same = back.length === len; for (let i = 0; same && i < len; i++) if (back[i] !== idx[i]) same = false;
  ok(`LZW: ${bitsPer} бит, ${len} пикселей — декодирование побайтно совпадает`, same, 'получено ' + back.length);
}

// 5. ошибки
let threw = false; try { G.encode([], { width: 2, height: 2 }); } catch (e) { threw = true; }
ok('пустой список кадров → ошибка', threw);
threw = false; try { G.encode([new Uint8ClampedArray(8)], { width: 3, height: 3 }); } catch (e) { threw = true; }
ok('неверный размер кадра → ошибка', threw);

console.log(failed ? `\ngif-encoder: упало ${failed}` : '\ngif-encoder: all checks passed');
process.exit(failed ? 1 : 0);
