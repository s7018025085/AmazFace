// Поддельный GitHub (API + raw CDN) для тестов публикации и сквозной проверки UI.
const http = require('node:http');
const path = require('node:path');
const crypto = require('node:crypto');
const { gitBlobSha } = require('../bridge/github-publisher.js');

const TOKEN = 'github_pat_TESTTOKEN0123456789abcdefABCDEF_xyz';
const OWNER = 'tester', REPO = 'faces';

// ───────── поддельный GitHub ─────────
function createFakeGithub() {
  const m = {
    tokens: { [TOKEN]: 'tester' },
    repo: { private: false, archived: false, permissions: { push: true } , exists: true },
    branches: new Set(['main']),
    files: new Map(),           // path → {bytes, sha}
    hooks: { put: null, get: null },       // (path, n) → {status,body,headers} | {drop:true} | {dropAfterApply:true}
    putCount: 0, putLog: [], requestLog: [], authSeen: [],
    rawLag: 0, rawHtml: false, rawOld: new Map(), rawHits: new Map(), rawMissing: false
  };
  const sha1 = (b) => gitBlobSha(b);
  const json = (res, code, obj, headers) => { res.writeHead(code, Object.assign({ 'Content-Type': 'application/json' }, headers || {})); res.end(JSON.stringify(obj)); };
  m.server = http.createServer((req, res) => {
    const chunks = [];
    req.on('data', c => chunks.push(c));
    req.on('end', () => {
      const body = Buffer.concat(chunks);
      const url = new URL(req.url, 'http://x');
      const p = decodeURIComponent(url.pathname);
      m.requestLog.push(req.method + ' ' + p);
      if (p.startsWith('/raw/')) {
        // /raw/<owner>/<repo>/<branch>/<path…>
        const rest = p.slice(5).split('/').slice(3).join('/');
        if (m.authSeen.length === 0) m.authSeen = [];
        m.authSeen.push('raw:' + (req.headers.authorization || ''));
        const f = m.files.get(rest);
        if (m.rawMissing || !f) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('404: Not Found'); }
        if (m.rawHtml) { res.writeHead(200, { 'Content-Type': 'text/html' }); return res.end('<html>GitHub</html>'); }
        const hits = (m.rawHits.get(rest) || 0) + 1; m.rawHits.set(rest, hits);
        const old = m.rawOld.get(rest);
        const bytes = (old && hits <= m.rawLag) ? old : f.bytes;
        res.writeHead(200, { 'Content-Type': 'application/octet-stream' });
        return res.end(bytes);
      }
      m.authSeen.push('api:' + (req.headers.authorization || ''));
      const auth = (req.headers.authorization || '').replace(/^Bearer /, '');
      const user = m.tokens[auth];
      if (!user) return json(res, 401, { message: 'Bad credentials' });
      if (p === '/user') return json(res, 200, { login: user });
      const rm = p.match(/^\/repos\/([^/]+)\/([^/]+)(\/.*)?$/);
      if (!rm || rm[1] !== OWNER || rm[2] !== REPO || !m.repo.exists) return json(res, 404, { message: 'Not Found' });
      const sub = rm[3] || '';
      if (sub === '') return json(res, 200, { full_name: `${OWNER}/${REPO}`, html_url: `https://github.com/${OWNER}/${REPO}`, default_branch: 'main', private: m.repo.private, archived: m.repo.archived, permissions: m.repo.permissions });
      // Чтение для импорта: список дерева и содержимое blob по sha (+ хук для сбоев GET).
      const gh = req.method === 'GET' && m.hooks.get && m.hooks.get(sub);
      if (gh && gh.drop) return req.socket.destroy();
      if (gh && gh.status) return json(res, gh.status, gh.body || { message: 'hooked' }, gh.headers);
      if (sub.startsWith('/git/trees/')) {
        if (!m.branches.has(sub.slice(11))) return json(res, 404, { message: 'Not Found' });
        if (!m.files.size) return json(res, 409, { message: 'Git Repository is empty.' });
        return json(res, 200, { tree: [...m.files].map(([fp, f]) => ({ path: fp, type: 'blob', sha: f.sha, size: f.bytes.length })), truncated: !!m.treeTruncated });
      }
      if (sub.startsWith('/git/blobs/')) {
        const sha = sub.slice(11);
        for (const f of m.files.values()) if (f.sha === sha) return json(res, 200, { sha, size: f.bytes.length, encoding: 'base64', content: f.bytes.toString('base64').replace(/(.{60})/g, '$1\n') });
        return json(res, 404, { message: 'Not Found' });
      }
      if (sub.startsWith('/branches/')) { const b = sub.slice(10); return m.branches.has(b) ? json(res, 200, { name: b, protected: false }) : json(res, 404, { message: 'Branch not found' }); }
      if (sub.startsWith('/contents/')) {
        const fp = sub.slice(10);
        if (req.method === 'GET') {
          if (m.files.has(fp)) { const f = m.files.get(fp); return json(res, 200, { name: path.posix.basename(fp), path: fp, sha: f.sha, type: 'file', content: f.bytes.toString('base64'), encoding: 'base64' }); }
          const kids = new Map();
          for (const [k, f] of m.files) if (k.startsWith(fp + '/')) { const name = k.slice(fp.length + 1).split('/')[0]; kids.set(name, { name, path: fp + '/' + name, sha: f.sha, type: 'file' }); }
          return kids.size ? json(res, 200, [...kids.values()]) : json(res, 404, { message: 'Not Found' });
        }
        if (req.method === 'PUT') {
          m.putCount++;
          const n = m.putCount;
          const hook = m.hooks.put && m.hooks.put(fp, n);
          if (hook && hook.drop) return req.socket.destroy();
          if (hook && hook.status) return json(res, hook.status, hook.body || { message: 'hooked' }, hook.headers);
          const b = JSON.parse(body.toString('utf8'));
          if (!m.branches.has(b.branch)) return json(res, 404, { message: 'Branch not found' });
          const existing = m.files.get(fp);
          if (existing && !b.sha) return json(res, 422, { message: 'Invalid request.\n\n"sha" wasn\'t supplied.' });
          if (existing && b.sha !== existing.sha) return json(res, 409, { message: `${fp} does not match ${b.sha}` });
          const bytes = Buffer.from(b.content, 'base64');
          if (existing) m.rawOld.set(fp, existing.bytes);
          m.rawHits.set(fp, 0);
          const f = { bytes, sha: sha1(bytes) };
          m.files.set(fp, f);
          m.putLog.push({ path: fp, update: !!existing, message: b.message });
          if (hook && hook.dropAfterApply) return req.socket.destroy();
          return json(res, existing ? 200 : 201, { content: { sha: f.sha }, commit: { sha: crypto.randomBytes(20).toString('hex') } });
        }
      }
      json(res, 404, { message: 'Not Found' });
    });
  });
  return m;
}


module.exports = { createFakeGithub, TOKEN, OWNER, REPO };
