# Проверка экспорта «Экспорт превью» и «Экспорт превью часов» в Chromium. Запуск: python3 scripts/e2e-mockup.py (PNG сохраняются в /tmp).
import base64, json, sys, threading, http.server, socketserver, functools
from playwright.sync_api import sync_playwright
import os; root=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
Handler=functools.partial(http.server.SimpleHTTPRequestHandler, directory=root)
class Q(Handler.func):
    def log_message(self,*a): pass
Handler=functools.partial(Q, directory=root)
socketserver.TCPServer.allow_reuse_address=True
srv=socketserver.TCPServer(('127.0.0.1',5231),Handler); threading.Thread(target=srv.serve_forever,daemon=True).start()
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1400,'height':900}, accept_downloads=True)
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e))); pg.on('console',lambda m: errs.append(m.text) if m.type=='error' else None)
    pg.goto('http://127.0.0.1:5231/index.html'); pg.wait_for_timeout(800)
    # закрыть приветствие если есть
    pg.evaluate("document.getElementById('welcome-screen')?.remove(); document.querySelectorAll('dialog[open]').forEach(d=>d.close())")
    pg.once('dialog', lambda d: d.accept())
    pg.click('#act-demo'); pg.wait_for_timeout(500)
    pg.click('#export-menu-btn'); pg.wait_for_timeout(200)
    ids=pg.evaluate("[...document.querySelectorAll('#export-menu-list button')].map(b=>b.id+': '+b.textContent.trim())")
    print('MENU',ids)
    for tag,key in (('preview','#act-export-preview'),('mockup','#act-export-mockup')):
        (pg.click('#export-menu-btn') if not pg.is_visible('#export-menu-list') else None); pg.wait_for_timeout(150)
        with pg.expect_download(timeout=90000) as dl:
            pg.click(key)
        d=dl.value; print(tag, d.suggested_filename); d.save_as(f'/tmp/{d.suggested_filename}')
    (pg.click('#export-menu-btn') if not pg.is_visible('#export-menu-list') else None); pg.wait_for_timeout(150)
    with pg.expect_download(timeout=90000) as dl:
        pass
        pg.click('#act-export-mockup', modifiers=['Shift'])
    d=dl.value; d.save_as('/tmp/transparent-mockup.png'); print('transparent saved')
    print('ERRORS',errs)
    b.close()
