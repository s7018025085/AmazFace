// Тесты импорта архивов ZPK / проект Саши (src/project/archive-import.js).
// Запуск: node scripts/test-archive-import.js
const A = require('../src/project/archive-import.js');

let failed = 0;
function ok(name, cond, extra) { if (cond) console.log('ok: ' + name); else { failed++; console.log('FAIL: ' + name + (extra ? ' — ' + extra : '')); } }

// ── комментарии не должны давать виджетов; «//» внутри строки — не комментарий
const src = `
  // hmUI.createWidget(hmUI.widget.IMG, { x: 1, y: 1, src: 'dead.png' });
  /* hmUI.createWidget(hmUI.widget.IMG, { src: 'dead2.png' }); */
  a = hmUI.createWidget(hmUI.widget.IMG, { x: 0, y: 0, w: 480, h: 480, src: 'bg.png', show_level: hmUI.show_level.ONLY_NORMAL });
  b = hmUI.createWidget(hmUI.widget.IMG, { x: 5, y: 6, src: 'http://x//y.png', show_level: hmUI.show_level.ONLY_AOD });
  c = hmUI.createWidget(hmUI.widget.TIME_POINTER, { second_path: 's.png', second_centerX: 240, second_centerY: 240, second_posX: 20, second_posY: 241 });
  d = hmUI.createWidget(hmUI.widget.BUTTON, { x: 1, color: 0xFFFF8C00, click_func: (w) => { hmApp.startApp({url: 'A', native: true }); }, show_level: hmUI.show_level.ONLY_NORMAL });
  e = hmUI.createWidget(hmUI.widget.FILL_RECT);
  f = hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 387, y: 261, font_array: ["0.png","1.png"], angle: -90, type: hmUI.data_type.STEP });
`;
const w = A.parseWatchface(src);
ok('закомментированные виджеты пропущены, найдено 6', w.length === 6, String(w.length));
ok('IMG: числа и строки', w[0].props.w === 480 && w[0].props.src === 'bg.png');
ok('сцена Normal / AOD / обе', w[0].scene === 'normal' && w[1].scene === 'aod' && w[2].scene === 'both');
ok('«//» внутри строки сохраняется', w[1].props.src === 'http://x//y.png');
ok('шестнадцатеричное число', w[3].props.color === 0xFFFF8C00);
ok('функция click_func не ломает разбор и не выполняется', w[3].props.click_func && '$expr' in w[3].props.click_func);
ok('виджет без параметров', w[4].widget === 'FILL_RECT' && Object.keys(w[4].props).length === 0);
ok('массив строк и ссылка на enum', w[5].props.font_array.length === 2 && w[5].props.type.$ref === 'data_type.STEP');

// ── формат SOMH: заголовок + палитра + строки, выровненные до 16
function makeSomh(realW, h, pixels /* индексы */, palette) {
  const storedW = Math.ceil(realW / 16) * 16;
  const b = new Uint8Array(18 + 46 + 1024 + storedW * h);
  b[0] = 46; b[1] = 1; b[2] = 1; b[5] = 0; b[6] = 1; b[7] = 32;
  b[12] = storedW & 255; b[13] = storedW >> 8; b[14] = h & 255; b[15] = h >> 8; b[16] = 8; b[17] = 32;
  b.set([0x53, 0x4f, 0x4d, 0x48, realW & 255, realW >> 8], 18);
  palette.forEach((c, i) => b.set(c, 18 + 46 + i * 4));
  for (let y = 0; y < h; y++) for (let x = 0; x < realW; x++) b[18 + 46 + 1024 + y * storedW + x] = pixels[y * realW + x];
  return b;
}
const pal = [[0, 0, 0, 0], [255, 0, 0, 255], [127, 0, 0, 127]];
const img = A.decodeSomh(makeSomh(3, 2, [0, 1, 2, 1, 1, 0], pal));
ok('SOMH: размер берётся из реальной ширины, а не из выровненной', img && img.width === 3 && img.height === 2);
ok('SOMH: непрозрачный и прозрачный пиксели', img.rgba[4] === 255 && img.rgba[7] === 255 && img.rgba[3] === 0);
ok('SOMH: цвет возвращается из премультиплицированного вида', img.rgba[8] >= 254 && img.rgba[11] === 127, String(img.rgba[8]));
ok('не-SOMH данные дают null', A.decodeSomh(new Uint8Array(2000)) === null);
ok('PNG распознаётся', A.isPng(new Uint8Array([0x89, 0x50, 0x4e, 0x47, 13, 10, 26, 10, 0])));

// ── распаковка вложенных архивов (подставной unzip)
(async () => {
  const tree = {
    'pack.zab': new Map([['manifest.json', new Uint8Array(1)], ['face.zpk', 'ZPK']]),
    ZPK: new Map([['app-side.zip', 'SIDE'], ['device.zip', 'DEV']]),
    SIDE: new Map([['app.json', new Uint8Array([1])], ['app-side/index.js', new Uint8Array(1)]]),
    DEV: new Map([['Face/app.json', new Uint8Array([2])], ['Face/watchface/index.js', new Uint8Array([3])], ['Face/assets/a.png', new Uint8Array([4])]]),
  };
  const fake = async (b) => (typeof b === 'string' ? tree[b] : tree['pack.zab']);
  // подставной zip отдаёт вложенные «архивы» строками
  tree['pack.zab'].set('face.zpk', 'ZPK'); tree.ZPK.set('device.zip', 'DEV'); tree.ZPK.set('app-side.zip', 'SIDE');
  const r = await A.unpackArchive(new Uint8Array(1), fake);
  ok('.zab → .zpk → device.zip: берётся device, не app-side', r.files.has('app.json') && r.files.has('watchface/index.js') && r.files.get('app.json')[0] === 2, [...r.files.keys()].join());
  ok('префикс подпапки отрезается', r.files.has('assets/a.png'));
  let msg = '';
  try { await A.unpackArchive(new Uint8Array(1), async () => new Map([['readme.txt', new Uint8Array(1)]])); } catch (e) { msg = e.message; }
  ok('архив без циферблата — понятная ошибка', /не найден циферблат/.test(msg), msg);

  // ── сборка слоёв
  const sizes = { 'bg.png': [480, 480], 's.png': [40, 40], '0.png': [15, 21], '1.png': [15, 21] };
  const ctx = {
    assetId: (f) => (sizes[f] ? 'id:' + f : null), assetSize: (f) => (sizes[f] ? { width: sizes[f][0], height: sizes[f][1] } : null),
    defaults: () => ({}), defaultSize: () => ({ w: 50, h: 50 }), nameOf: (d) => d,
  };
  const { scenes, report } = A.buildScenes(w, ctx);
  ok('полноэкранная картинка становится фоном Normal', scenes.normal.background.imageAssetId === 'id:bg.png');
  ok('картинка с неизвестным файлом уходит в отчёт', !scenes.aod.components.some((c) => c.defId === 'image') && report.skipped.some((s) => /не найдена/.test(s.reason)));
  const hand = scenes.normal.components.find((c) => c.defId === 'time_pointer_second');
  ok('стрелка перенесена в обе сцены с опорной точкой', hand && hand.props.pos_y === 241 && scenes.aod.components.some((c) => c.defId === 'time_pointer_second'));
  const txt = scenes.normal.components.find((c) => c.defId === 'text');
  ok('цифры-картинки → текст с источником данных', txt && txt.props.data_source === 'STEP' && txt.name.startsWith('⚠'));
  ok('кнопка и пустой FILL_RECT не пропадают молча', report.skipped.some((s) => s.widget === 'BUTTON') && report.skipped.some((s) => s.widget === 'FILL_RECT'));

  if (failed) { console.log(`\n${failed} тест(ов) не прошло`); process.exit(1); }
  console.log('\nВсе тесты импорта архивов прошли.');
})();
