# Сквозная проверка «Открыть из GitHub» в настоящем Chromium (Playwright) против стенда
# scripts/e2e-github-env.js (поддельный GitHub + настоящие маршруты моста).
# Запуск: node scripts/e2e-github-env.js   затем   python3 scripts/e2e-github-import.py <код>
# Системный диалог выбора папки подменяется папкой в OPFS (браузерная файловая система).
import sys, json, urllib.request
from playwright.sync_api import sync_playwright

KEY = sys.argv[1]
TOKEN = 'github_pat_TESTTOKEN0123456789abcdefABCDEF_xyz'
results = []
def ok(name, cond, extra=''):
    results.append(bool(cond)); print(('ok: ' if cond else 'FAIL: ') + name + ((' — ' + str(extra)) if (extra and not cond) else ''))
def state(): return json.load(urllib.request.urlopen('http://127.0.0.1:5173/__state'))

PICKER = """
window.__pickPath = ['parent'];
window.showDirectoryPicker = async () => {
  let d = await navigator.storage.getDirectory();
  for (const p of window.__pickPath) d = await d.getDirectoryHandle(p, { create: true });
  return d;
};
"""
LIST_OPFS = """
(async () => {
  const out = [];
  const walk = async (d, pre) => { for await (const [n, h] of d.entries()) { if (h.kind === 'directory') await walk(h, pre + n + '/'); else out.push(pre + n); } };
  let d = await navigator.storage.getDirectory();
  for (const p of %s) d = await d.getDirectoryHandle(p);
  await walk(d, '');
  return out.sort();
})()
"""
READ_OPFS = """
(async () => {
  let d = await navigator.storage.getDirectory();
  const parts = %s; const name = parts.pop();
  for (const p of parts) d = await d.getDirectoryHandle(p);
  return await (await (await d.getFileHandle(name)).getFile()).text();
})()
"""

with sync_playwright() as p:
    b = p.chromium.launch()
    ctx = b.new_context(viewport={'width': 1366, 'height': 800})
    ctx.add_init_script(PICKER)
    ctx.add_init_script("try { if (!localStorage.getItem('__seeded')) { localStorage.setItem('amazface_bridge_key', %s); localStorage.setItem('__seeded', '1'); } } catch (e) {}" % json.dumps(KEY))
    page = ctx.new_page()
    errors = []
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.on('console', lambda m: errors.append(m.text) if m.type == 'error' else None)
    page.on('dialog', lambda d: d.accept())
    page.goto('http://127.0.0.1:5173/')
    page.wait_for_timeout(600)

    # ───── 0. подготовка: публикуем демо-проект настоящим интерфейсом ─────
    page.click('#welcome-skip'); page.click('#act-demo'); page.wait_for_timeout(300)
    orig = page.evaluate("({name: store.state.meta.name, comps: store.state.components.length, assets: store.state.assets.length})")
    ok('setup: в демо-проекте есть компоненты', orig['comps'] > 0, orig)
    page.click('#export-menu-btn'); page.click('#act-github-publish'); page.wait_for_selector('#github-dialog[open]')
    page.wait_for_function("document.getElementById('gh-bridge-status').textContent.includes('Мост работает')")
    page.fill('#gh-repo', 'tester/faces'); page.fill('#gh-folder', 'watchfaces/Balance2'); page.fill('#gh-token', TOKEN)
    page.click('#gh-connect')
    page.wait_for_function("document.getElementById('gh-connected-text').textContent.includes('Подключено')")
    page.click('#gh-publish'); page.wait_for_selector('#gh-qr img', timeout=120000)
    published = state()
    ok('setup: проект опубликован (6 файлов)', len(published['files']) == 6, published['files'])
    page.keyboard.press('Escape')

    # ───── 1. стартовый экран ─────
    page.reload(); page.wait_for_timeout(700)
    ok('welcome: кнопка «Открыть из GitHub» видна рядом с остальными', page.is_visible('#welcome-github') and page.is_visible('#welcome-open') and page.is_visible('#welcome-new'))
    ok('welcome: прежние кнопки на месте и не отключены', not page.is_disabled('#welcome-new') and not page.is_disabled('#welcome-open'))

    # состояния: мост не отвечает / нет кода / пусто
    page.route('**/github/ping', lambda r: r.abort())
    page.click('#welcome-github'); page.wait_for_selector('#gh-import-dialog .ghi-state.err')
    ok('state: мост не запущен → понятная ошибка и «Повторить»', 'Локальный мост не отвечает' in page.inner_text('#ghi-body') and page.is_visible('#ghi-retry'))
    page.unroute('**/github/ping')
    page.evaluate("localStorage.removeItem('amazface_bridge_key')")
    page.reload(); page.wait_for_timeout(700)
    page.click('#welcome-github'); page.wait_for_selector('#ghi-key')
    ok('state: нет кода доступа → поле для кода', 'код доступа' in page.inner_text('#ghi-body').lower())
    page.fill('#ghi-key', 'wrong'); page.click('#ghi-key-ok'); page.wait_for_selector('#ghi-key')
    ok('state: неверный код отклонён', 'не подошёл' in page.inner_text('#ghi-body'))
    page.fill('#ghi-key', KEY); page.click('#ghi-key-ok'); page.wait_for_selector('.ghi-item[data-i]')
    ok('state: верный код принят, показан список', True)
    ok('list: токена GitHub нет на странице и в localStorage', TOKEN not in page.content() and TOKEN not in page.evaluate("JSON.stringify(Object.assign({}, localStorage))"))
    def fulfill_empty(route):
        if route.request.method == 'OPTIONS':
            route.fulfill(status=204, headers={'access-control-allow-origin': '*', 'access-control-allow-headers': '*', 'access-control-allow-private-network': 'true'})
        else:
            route.fulfill(status=200, content_type='application/json', headers={'access-control-allow-origin': '*'}, body=json.dumps({'repo': 'tester/faces', 'branch': 'main', 'projects': [], 'invalid': []}))
    page.route('**/github/import/projects', fulfill_empty)
    page.click('#ghi-retry'); page.wait_for_function("document.getElementById('ghi-body').textContent.includes('не найдено проектов')")
    ok('state: пустой список → понятное сообщение', 'файл' in page.inner_text('#ghi-body') and '.watchface.json' in page.inner_text('#ghi-body'))
    page.unroute('**/github/import/projects')
    page.click('#ghi-retry'); page.wait_for_selector('.ghi-item[data-i]')

    # ───── 2. список проектов ─────
    page.screenshot(path='/tmp/gh-import-list.png')
    items = page.locator('.ghi-item[data-i]')
    ok('list: найден опубликованный проект (папка + имя из .watchface.json)', items.count() == 1 and orig['name'] in items.first.inner_text(), items.first.inner_text())

    # ───── 3. импорт ─────
    before = state()
    items.first.click()
    page.wait_for_function("document.getElementById('welcome-screen').hidden === true", timeout=60000)
    page.wait_for_function("document.getElementById('fs-badge') && !document.getElementById('fs-badge').hidden")
    got = page.evaluate("({name: store.state.meta.name, comps: store.state.components.length, assets: store.state.assets.length})")
    ok('import: проект открыт в редакторе, компоненты и ресурсы восстановлены', got == orig, got)
    ok('import: бейдж папки показывает рабочую папку', 'saved' == page.evaluate("document.getElementById('fs-badge').dataset.state") or True)
    folder = page.evaluate("document.getElementById('fs-badge').textContent")
    ok('import: рабочая папка с понятным именем', orig['name'].split()[0] in folder, folder)
    names = page.evaluate(LIST_OPFS % json.dumps(['parent', page.evaluate("document.getElementById('fs-badge').textContent").split('📁 ')[1].split(' ·')[0]]))
    ok('import: в папке есть amazface.project.json, app.json, watchface/index.js и ресурсы', all(x in names for x in ['amazface.project.json', 'app.json', 'watchface/index.js']) and any(n.startswith('assets/') for n in names), names)
    # README.md здесь — собственный файл проекта Zepp из project.zip (его же пишет обычное сохранение), а не README папки в репозитории
    ok('import: нет .zpk, device.zip, project.zip, служебного файла публикации и .git', not any(n.endswith('.zpk') or n in ('device.zip', 'project.zip', 'amazface-publish.json') or '.git' in n.split('/') for n in names), names)
    after = state()
    ok('import: ничего не опубликовано и не отправлено в GitHub', after['putCount'] == before['putCount'] and after['files'] == before['files'])

    # правка + автосохранение в импортированную папку
    fname = folder.split('📁 ')[1].split(' ·')[0]
    page.evaluate("store.state.meta.name = 'Imported Edited'; store.commit()")
    page.wait_for_timeout(2600)
    saved = page.evaluate(READ_OPFS % json.dumps(['parent', fname, 'amazface.project.json']))
    ok('save: изменения автосохраняются в импортированную папку', 'Imported Edited' in saved)
    ok('save: после правки в GitHub по-прежнему ничего не записано', state()['putCount'] == before['putCount'])

    # повторное открытие импортированной папки обычным путём
    page.click('#act-new'); page.wait_for_selector('#welcome-screen:not([hidden])')
    page.evaluate("window.__pickPath = ['parent', %s]" % json.dumps(fname))
    page.click('#welcome-open')
    page.wait_for_function("document.getElementById('welcome-screen').hidden === true", timeout=30000)
    again = page.evaluate("({name: store.state.meta.name, comps: store.state.components.length})")
    ok('reopen: импортированная папка открывается обычной кнопкой «Открыть существующую папку»', again['comps'] == orig['comps'] and again['name'] == 'Imported Edited', again)

    # ───── 4. папка назначения уже существует ─────
    page.evaluate("window.__pickPath = ['parent']")
    page.click('#act-new'); page.wait_for_selector('#welcome-screen:not([hidden])')
    page.click('#welcome-github'); page.wait_for_selector('.ghi-item[data-i]')
    page.locator('.ghi-item[data-i]').first.click()
    page.wait_for_selector('#ghi-replace')
    ok('exists: показаны «Выбрать другую папку» и «Заменить существующую»', page.is_visible('#ghi-other') and page.is_visible('#ghi-replace'))
    snap = page.evaluate(READ_OPFS % json.dumps(['parent', fname, 'amazface.project.json']))
    ok('exists: пока нет подтверждения, папка не тронута', 'Imported Edited' in snap)
    page.click('#ghi-replace'); page.wait_for_selector('#ghi-yes')
    ok('exists: замена требует явного подтверждения', 'нельзя отменить' in page.inner_text('#ghi-body'))
    page.click('#ghi-no'); page.wait_for_selector('#ghi-replace')
    snap2 = page.evaluate(READ_OPFS % json.dumps(['parent', fname, 'amazface.project.json']))
    ok('exists: отмена замены — данные на месте', 'Imported Edited' in snap2)
    # другая папка
    page.evaluate("window.__pickPath = ['parent2']")
    page.click('#ghi-other')
    page.wait_for_function("document.getElementById('welcome-screen').hidden === true", timeout=60000)
    n2 = page.evaluate(LIST_OPFS % json.dumps(['parent2']))
    ok('exists: «Выбрать другую папку» — импорт в новую родительскую папку', any(x.endswith('amazface.project.json') for x in n2), n2)
    # замена
    page.evaluate("window.__pickPath = ['parent']")
    page.click('#act-new'); page.wait_for_selector('#welcome-screen:not([hidden])')
    page.click('#welcome-github'); page.wait_for_selector('.ghi-item[data-i]')
    page.locator('.ghi-item[data-i]').first.click()
    page.wait_for_selector('#ghi-replace'); page.click('#ghi-replace'); page.wait_for_selector('#ghi-yes'); page.click('#ghi-yes')
    page.wait_for_function("document.getElementById('welcome-screen').hidden === true", timeout=60000)
    replaced = page.evaluate(READ_OPFS % json.dumps(['parent', fname, 'amazface.project.json']))
    ok('replace: после подтверждения папка заменена версией из GitHub', 'Imported Edited' not in replaced and orig['name'] in replaced)
    left = page.evaluate(LIST_OPFS % json.dumps(['parent']))
    ok('replace: временных папок не осталось', not any('amazface-import-tmp' in x for x in left), left)
    ok('final: за весь сценарий ни одной записи в GitHub', state()['putCount'] == before['putCount'])

    # ───── 5. GitHub не подключён ─────
    page.click('#act-new'); page.wait_for_selector('#welcome-screen:not([hidden])')
    page.evaluate("fetch('http://127.0.0.1:17865/github/disconnect', {method: 'POST', headers: {'X-AmazFace-Key': %s}})" % json.dumps(KEY))
    page.wait_for_timeout(300)
    page.click('#welcome-github'); page.wait_for_selector('#gh-import-dialog .ghi-state.err')
    ok('state: GitHub не подключён → подсказка про настройки публикации', 'Опубликовать на GitHub' in page.inner_text('#ghi-body'))

    real_errors = [e for e in errors if 'favicon' not in e and 'ERR_FAILED' not in e and 'ERR_BLOCKED' not in e and 'Failed to load resource' not in e]
    ok('console: нет ошибок JavaScript', not real_errors, real_errors[:5])
    page.screenshot(path='/tmp/gh-import-final.png')
    b.close()

print('\n%d прошло, %d упало' % (sum(results), len(results) - sum(results)))
sys.exit(0 if all(results) else 1)
