// Проверка покадровой анимации фона: экспорт IMG_ANIM (только Normal), имена кадров, жизненный цикл, предпросмотр.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.resolve(__dirname, '..');
const ctx = { console, Math, Date, JSON, window: {} };
vm.createContext(ctx);
for (const rel of ['src/util/slug.js', 'src/components/registry.js', 'src/exporter/index-js-exporter.js']) {
  const src = fs.readFileSync(path.join(root, rel), 'utf8');
  vm.runInContext(src + '\n;globalThis.__ex = Object.assign(globalThis.__ex || {}, {' +
    ['REGISTRY', 'exportIndexJs', 'exportIndexJsDual', 'computeAssetFilenames', 'getBgAnimFrameIds'].filter((n) => src.includes(`const ${n}`) || src.includes(`function ${n}`)).join(',') + '});', ctx, { filename: rel });
}
const { exportIndexJsDual, computeAssetFilenames } = ctx.__ex;
vm.runInContext(fs.readFileSync(path.join(root, 'src/exporter/project-exporter.js'), 'utf8') + '\n;globalThis.__pre = runDesignerPreflight;', ctx, { filename: 'project-exporter.js' });
const preflight = ctx.__pre;
const BgAnim = require(path.join(root, 'src/anim/bg-anim.js'));

let failed = 0;
function check(name, cond, extra) { if (!cond) { failed++; console.error('FAIL:', name, extra || ''); } else console.log('ok:', name); }
function syntaxOk(code) { try { new vm.Script(code.replace(/^import .*$/gm, '')); return true; } catch (e) { return e.message; } }

const asset = (id, name, extra) => Object.assign({ id, name, dataUrl: 'data:image/png;base64,AAAA', width: 480, height: 480, format: 'PNG' }, extra || {});
function mkProject(anim, assets) {
  const bg = { color: '#000000', imageAssetId: 'bg0', alpha: 100, anim };
  const normal = { components: [], background: bg, nextIndex: {} };
  const aod = { components: [], background: JSON.parse(JSON.stringify(bg)), nextIndex: {} };
  return {
    device: { w: 480, h: 480 }, mode: 'normal', components: [], fonts: [], background: bg,
    assets: assets || [asset('bg0', 'bg'), asset('f0', 'bgf_000', { bgFrame: true }), asset('f1', 'bgf_001', { bgFrame: true }), asset('f2', 'bgf_002', { bgFrame: true })],
    scenes: { normal, aod },
  };
}
function run(project) {
  const map = computeAssetFilenames(project);
  return { map, r: exportIndexJsDual(project, map, {}, {}) };
}

// 1. Включённая анимация: 3 кадра
let { map, r } = run(mkProject({ enabled: true, frames: ['f0', 'f1', 'f2'], fps: 15, loop: true }));
check('syntax ok', syntaxOk(r.code) === true, syntaxOk(r.code));
check('frames renamed bganim/f_<i>.png', map.f0 === 'bganim/f_0.png' && map.f1 === 'bganim/f_1.png' && map.f2 === 'bganim/f_2.png', JSON.stringify(map));
check('regular bg keeps its own name', map.bg0 === 'bg.png', map.bg0);
check('exactly one IMG_ANIM', (r.code.match(/widget\.IMG_ANIM/g) || []).length === 1);
check('IMG_ANIM is ONLY_NORMAL', /createWidget\(widget\.IMG_ANIM, \{\s*show_level: show_level\.ONLY_NORMAL/.test(r.code));
check('anim params', /anim_path: ["']bganim["']/.test(r.code) && /anim_prefix: ["']f["']/.test(r.code) && /anim_ext: ["']png["']/.test(r.code) && /anim_fps: 15/.test(r.code) && /anim_size: 3/.test(r.code));
check('loop → repeat_count 0 (infinite)', /repeat_count: 0\b/.test(r.code));
check('anim_status imported', /import \{[^}]*anim_status[^}]*\} from '@zos\/ui'/.test(r.code));
check('resume starts animation', /resume_call: function \(\) \{[\s\S]*ANIM_STATUS, anim_status\.START/.test(r.code));
check('pause stops animation', /pause_call: function \(\) \{[^}]*ANIM_STATUS, anim_status\.STOP/.test(r.code));
check('static bg image still emitted (AOD / before start)', /src: ["']bg\.png["']/.test(r.code));
check('unverified warning', r.validation.warnings.some((w) => w.includes('IMG_ANIM')));
check('no errors', r.validation.errors.length === 0, r.validation.errors.join(' | '));
check('AOD scene has no IMG_ANIM', !/ONAL_AOD[^;]*IMG_ANIM|ONLY_AOD[^;]*IMG_ANIM/.test(r.code));

// 2. Не зациклено: repeat
({ r } = run(mkProject({ enabled: true, frames: ['f0', 'f1'], fps: 10, loop: false, repeat: 3 })));
check('repeat_count 3', /repeat_count: 3\b/.test(r.code) && /anim_size: 2/.test(r.code));

// 3. Выключена / один кадр / нет anim
({ r } = run(mkProject({ enabled: false, frames: ['f0', 'f1'] })));
check('disabled: no IMG_ANIM, no anim_status', !r.code.includes('IMG_ANIM') && !r.code.includes('anim_status'));
({ r } = run(mkProject(undefined)));
check('no anim field: no IMG_ANIM', !r.code.includes('IMG_ANIM'));
({ r } = run(mkProject({ enabled: true, frames: ['f0'] })));
check('one frame: not exported + warning', !r.code.includes('IMG_ANIM') && r.validation.warnings.some((w) => w.includes('меньше двух')));

// 4. Удалённый кадр — ошибка экспорта (а не битый путь на часах)
const broken = mkProject({ enabled: true, frames: ['f0', 'gone', 'f2'] });
({ r } = run(broken));
check('missing frame is dropped from assets map → error or <2 guard', r.validation.errors.length > 0 || !r.code.includes('IMG_ANIM'));

// 5. Нормализация и натуральная сортировка
const n = BgAnim.normalize({ fps: 999, frames: ['a', null, 'b'], repeat: 0 });
check('normalize clamps', n.fps === 30 && n.frames.length === 2 && n.repeat === 1 && n.loop === true && n.enabled === false);
check('natural sort', BgAnim.sortFilesNatural([{ name: 'f10.png' }, { name: 'f2.png' }, { name: 'f1.png' }]).map((f) => f.name).join() === 'f1.png,f2.png,f10.png');

// 6. Предпросмотр: цикл кадров, остановка, AOD
{
  const shown = []; let state = { mode: 'normal', background: { anim: { enabled: true, frames: ['a', 'b', 'c'], fps: 10, loop: false, repeat: 2 } } };
  const timers = []; const host = { setBgFrameOverride: (id) => shown.push(id) };
  const pv = BgAnim.createPreview({ getState: () => state, host, setInterval: (fn) => { timers.push(fn); return timers.length; }, clearInterval: () => {} });
  check('play returns true', pv.play() === true && pv.isPlaying());
  for (let i = 0; i < 20 && pv.isPlaying(); i++) timers[0]();
  check('plays a,b,c twice (repeat 2) then resets to static', shown.join(',') === 'a,b,c,a,b,c,' .replace(/,$/, '') + ',', shown.join(','));
  check('finished and cleared override', !pv.isPlaying() && shown[shown.length - 1] === null, shown.join(','));
  state = { mode: 'aod', background: state.background };
  check('no preview in AOD', pv.play() === false);
}

// 7. GIF: декодер (3 кадра 6×4: красный 100 мс, зелёный 200 мс, синий 100 мс)
{
  const GIF_B64 = 'R0lGODlhBgAEAIEAAP8AAAAAAAAAAAAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQACgAAACwAAAAABgAEAAAICwABCBxIsKDBgQEBACH5BAAUAAAALAAAAAAGAAQAgQD/AAAAAAAAAAAAAAgLAAEIHEiwoMGBAQEAIfkEAAoAAAAsAAAAAAYABACBAAD/AAAAAAAAAAAACAsAAQgcSLCgwYEBAQA7';
  const g = BgAnim.decodeGif(Buffer.from(GIF_B64, 'base64'));
  const px = (f) => Array.from(f.rgba.slice(0, 4)).join(',');
  check('gif: size and frame count', g.width === 6 && g.height === 4 && g.frames.length === 3);
  check('gif: frame colors red/green/blue', px(g.frames[0]) === '255,0,0,255' && px(g.frames[1]) === '0,255,0,255' && px(g.frames[2]) === '0,0,255,255', g.frames.map(px).join(' | '));
  check('gif: delays 100/200/100 ms', g.frames.map((f) => f.delay).join() === '100,200,100', g.frames.map((f) => f.delay).join());
  check('gif: all pixels filled', g.frames.every((f) => f.rgba.length === 6 * 4 * 4 && f.rgba[f.rgba.length - 1] === 255));
  let threw = false; try { BgAnim.decodeGif(Buffer.from('not a gif at all')); } catch (e) { threw = true; }
  check('gif: garbage rejected', threw);
  check('gif: file detection', BgAnim.isGif({ name: 'a.GIF', type: '' }) && BgAnim.isVideo({ name: 'c.mp4', type: '' }) && BgAnim.isVideo({ name: 'x', type: 'video/webm' }) && !BgAnim.isGif({ name: 'a.png', type: 'image/png' }));
}

// 8. Отсчёты по времени
{
  const si = BgAnim.sampleIndices;
  // t = 0, 250, 500→100 (loop of 400 ms), 750→350 ms → кадры 0,1,1,2
  check('sample: 1 s at 4 fps over 100/200/100 ms → [0,1,1,2]', si([100, 200, 100], 4, 0, 1, 60).join() === '0,1,1,2', si([100, 200, 100], 4, 0, 1, 60).join());
  check('sample: len 0 = whole clip (0.4 s at 10 fps → 4)', si([100, 200, 100], 10, 0, 0, 60).length === 4);
  check('sample: loops past end (1 s at 10 fps of 0.4 s clip → 10)', si([100, 200, 100], 10, 0, 1, 60).length === 10 && si([100, 200, 100], 10, 0, 1, 60)[4] === 0);
  check('sample: capped to max', si([100], 30, 0, 100, 60).length === 60);
  check('sample: at least 2', si([100, 100], 1, 0, 0.1, 60).length === 2);
}


// 6. Нет картинки фона (пропал ресурс или не выбран), но есть анимация → статичным фоном первый кадр
{
  const miss = (anim, bgId) => { const pr = mkProject(anim); for (const b of [pr.background, pr.scenes.normal.background, pr.scenes.aod.background]) b.imageAssetId = bgId; pr.assets = pr.assets.filter((a) => a.id !== 'bg0'); return pr; };
  const on = { enabled: true, frames: ['f0', 'f1', 'f2'], fps: 10, loop: true };
  let pr = miss(on, 'asset_951');
  let rr = run(pr);
  check('пропавший фон + анимация: экспорт без ошибок', rr.r.validation.errors.length === 0, rr.r.validation.errors.join(' | '));
  check('пропавший фон + анимация: статичный IMG берёт bganim/f_0.png', /createWidget\(widget\.IMG, \{[^}]*src: ["']bganim\/f_0\.png["']/.test(rr.r.code));
  check('пропавший фон + анимация: IMG_ANIM по-прежнему один', (rr.r.code.match(/widget\.IMG_ANIM/g) || []).length === 1);
  check('пропавший фон + анимация: есть предупреждение про asset_951', rr.r.validation.warnings.some((w) => w.includes('asset_951')));
  let pf = preflight(pr);
  check('проверка проекта: MISSING_BACKGROUND не ошибка при анимации', !pf.diagnostics.some((d) => d.code === 'MISSING_BACKGROUND') && pf.diagnostics.some((d) => d.code === 'MISSING_BACKGROUND_FALLBACK'));

  pr = miss(on, null);
  rr = run(pr);
  check('фон не выбран + анимация: статичный IMG = первый кадр', rr.r.validation.errors.length === 0 && /widget\.IMG, \{[^}]*src: ["']bganim\/f_0\.png["']/.test(rr.r.code));

  pr = miss({ enabled: false, frames: ['f0', 'f1'], fps: 10, loop: true }, 'asset_951');
  rr = run(pr);
  check('пропавший фон без включённой анимации: ошибка остаётся', rr.r.validation.errors.length > 0 || preflight(pr).diagnostics.some((d) => d.code === 'MISSING_BACKGROUND'));
  check('пропавший фон без анимации: проверка проекта по-прежнему ошибка', preflight(pr).diagnostics.some((d) => d.code === 'MISSING_BACKGROUND' && d.severity === 'error'));

  pr = mkProject(on);
  rr = run(pr);
  check('нормальный фон + анимация: статичный фон остаётся своим bg.png', /widget\.IMG, \{[^}]*src: ["']bg\.png["']/.test(rr.r.code));
}

if (failed) { console.error(`\n${failed} check(s) failed`); process.exit(1); }
console.log('\nbg-anim: all checks passed');
