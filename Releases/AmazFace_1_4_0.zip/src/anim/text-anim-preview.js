// src/anim/text-anim-preview.js
//
// Живой предпросмотр анимации выбранного компонента «Текст» на холсте редактора.
// Один контроллер на всё приложение: один rAF-цикл, который работает ТОЛЬКО пока
// идёт воспроизведение. Ничего не пишет в проект. Браузерный предпросмотр — это
// не доказательство работы эффекта на часах.
//
// Зависимости внедряются (для тестов без браузера):
//   deps.getState()        → project state;  deps.host.setTextAnimOverrides(map|null)
//   deps.textFor(comp)     → строка, которая сейчас видна на холсте
//   deps.raf / deps.caf    → requestAnimationFrame / cancelAnimationFrame
(function (root) {
  'use strict';
  const TA = root.TextAnim || (typeof require === 'function' ? require('./text-anim.js') : null);

  function createController(deps) {
    const raf = deps.raf || ((fn) => setTimeout(() => fn(Date.now()), 16));
    const caf = deps.caf || clearTimeout;
    const minFrameMs = 1000 / (deps.fps || 30);
    let attachedId = null, session = null, signature = '', textSig = '';
    let t = 0, playing = false, rafId = null, lastTs = null, lastDraw = -1e9, aod = false;
    const listeners = new Set();

    function findComp() {
      const st = deps.getState();
      return st && (st.components || []).find((c) => c.id === attachedId) || null;
    }
    function sigOf(comp) {
      if (!comp) return '';
      // x/y не входят: перемещение компонента не должно перезапускать анимацию.
      // Текст сюда не входит: при «живом времени» он меняется каждую секунду и не должен
      // перезапускать анимацию (см. textOf / sync).
      return JSON.stringify({ p: comp.props, w: comp.w, h: comp.h, aod });
    }
    function textOf(comp) { return comp && deps.textFor ? deps.textFor(comp) : ''; }
    function push(frame) {
      if (!attachedId || !frame) deps.host.setTextAnimOverrides(null);
      else { const m = {}; m[attachedId] = frame; deps.host.setTextAnimOverrides(m); }
    }
    function state() {
      return {
        attached: !!attachedId, compId: attachedId, playing, t, aod,
        duration: session ? session.duration : 0, perpetual: !!(session && session.perpetual),
        enabled: !!(session && session.cfg && session.cfg.enabled), supported: !!(session && session.info && session.info.supported),
        demo: session && session.demo ? session.demo.label : null, effect: session ? session.effect : null,
      };
    }
    function notify() { const s = state(); listeners.forEach((fn) => { try { fn(s); } catch (e) { /* UI может быть уже заменён */ } }); }
    function cancelLoop() { if (rafId !== null) { caf(rafId); rafId = null; } lastTs = null; }
    function disposeSession() { if (session && session.dispose) session.dispose(); session = null; }
    function build() {
      disposeSession();
      const comp = findComp();
      signature = sigOf(comp); textSig = textOf(comp);
      if (!comp || comp.defId !== 'text') return;
      const text = deps.textFor ? deps.textFor(comp) : String((comp.props && comp.props.text) || '');
      session = TA.createSession(comp, { text, aod });
    }
    function tick(ts) {
      rafId = null;
      if (!playing || !session) return;
      if (lastTs === null) lastTs = ts;
      t += Math.max(0, ts - lastTs); lastTs = ts;
      if (t >= session.duration) {
        if (session.perpetual) t = t % session.duration;
        else { t = session.duration; playing = false; }
      }
      if (ts - lastDraw >= minFrameMs || !playing) { lastDraw = ts; push(session.sample(t)); }
      notify();
      if (playing) rafId = raf(tick);
    }
    const ctl = {
      attach(id) {
        if (attachedId === id) return;
        ctl.detach();
        attachedId = id; t = 0; playing = false;
        build(); notify();
      },
      detach() {
        const had = attachedId !== null;
        cancelLoop(); playing = false; t = 0;
        disposeSession();
        attachedId = null; signature = '';
        if (had) { push(null); notify(); }
      },
      play() {
        if (!attachedId) return;
        if (!session) build();
        if (!session || !session.cfg.enabled || !session.info.supported) return;
        if (t >= session.duration && !session.perpetual) t = 0;
        playing = true; lastTs = null; lastDraw = -1e9;
        cancelLoop(); rafId = raf(tick); notify();
      },
      restart() { t = 0; ctl.play(); },
      pause() { playing = false; cancelLoop(); notify(); },
      // «Сбросить»: остановка и возврат к исходному (неанимированному) виду.
      reset() { playing = false; cancelLoop(); t = 0; push(null); notify(); },
      seek(ms) {
        if (!session) return;
        playing = false; cancelLoop();
        t = Math.max(0, Math.min(session.duration, Number(ms) || 0));
        push(session.sample(t)); notify();
      },
      setAod(on) {
        aod = !!on; build();
        if (aod) { playing = false; cancelLoop(); t = 0; if (session) push(session.finalState ? session.finalState() : null); }
        else push(null);
        notify();
      },
      // Вызывается при каждом изменении проекта/выделения.
      sync(st, selection) {
        const ids = selection ? [...selection] : [];
        const comp = ids.length === 1 && st ? (st.components || []).find((c) => c.id === ids[0]) : null;
        if (st && st.mode === 'aod') { ctl.detach(); return; }
        if (!attachedId) return;
        if (!comp || comp.id !== attachedId || comp.defId !== 'text') { ctl.detach(); return; }
        const sg = sigOf(comp);
        if (sg === signature) {
          // Изменился только текст (идут живые часы): пересобираем сессию, но сохраняем
          // позицию и состояние воспроизведения — эффект продолжается на новом тексте.
          const tx = textOf(comp);
          if (tx !== textSig && !aod) {
            build();
            if (session && t > 0 && session.cfg.enabled && session.info.supported) push(session.sample(Math.min(t, session.duration)));
            notify();
          }
          return;
        }
        if (sg !== signature) {
          // Настройки изменились — предпросмотр обновляется сразу и проигрывается заново.
          const wasAod = aod;
          build();
          if (wasAod) { push(session && session.finalState ? session.finalState() : null); notify(); return; }
          t = 0; playing = false; cancelLoop(); push(null);
          if (session && session.cfg.enabled && session.info.supported) ctl.play(); else notify();
        }
      },
      subscribe(fn) { listeners.add(fn); return () => listeners.delete(fn); },
      getState: state,
      dispose() { ctl.detach(); listeners.clear(); },
    };
    return ctl;
  }

  const api = { createController };
  root.TextAnimPreview = api;
  if (root !== globalThis) globalThis.TextAnimPreview = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
