// src/anim/bg-anim.js
//
// Покадровая анимация фона циферблата (экспорт: widget.IMG_ANIM, только Normal).
// Модель: project.background.anim = { enabled, frames: [assetId...], fps, loop, repeat }.
//   frames  — id ресурсов-кадров по порядку (PNG, размер устройства);
//   fps     — 1..30 (по умолчанию 12);
//   loop    — бесконечный повтор (по умолчанию true), иначе repeat проходов.
// Кадры — обычные ресурсы проекта; при экспорте они получают имена bganim/f_<i>.png.
// Здесь: нормализация настроек, импорт кадров из файлов и предпросмотр на холсте
// (один setInterval, только пока идёт воспроизведение; в проект ничего не пишет).
(function (root) {
  'use strict';

  const MAX_FRAMES = 60;       // потолок: каждый кадр — отдельный ресурс в памяти часов
  const DEFAULTS = { enabled: false, frames: [], fps: 12, loop: true, repeat: 1 };

  function normalize(a) {
    const o = Object.assign({}, DEFAULTS, a || {});
    o.frames = Array.isArray(o.frames) ? o.frames.filter(Boolean) : [];
    o.fps = Math.max(1, Math.min(30, Math.round(Number(o.fps) || 12)));
    o.repeat = Math.max(1, Math.round(Number(o.repeat) || 1));
    o.loop = o.loop !== false;
    o.enabled = !!o.enabled;
    return o;
  }

  // Натуральная сортировка имён: f2.png < f10.png.
  function sortFilesNatural(files) {
    return Array.from(files).sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' }));
  }

  // Файл → PNG dataURL нужного размера (cover по центру). Кадры всегда PNG:
  // IMG_ANIM принимает одно расширение на все кадры.
  function fileToPngFrame(file, w, h) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onerror = () => reject(new Error('Не удалось прочитать ' + file.name));
      reader.onload = () => {
        const img = new Image();
        img.onerror = () => reject(new Error('Не удалось декодировать ' + file.name));
        img.onload = () => {
          const c = document.createElement('canvas');
          c.width = w; c.height = h;
          const ctx = c.getContext('2d');
          const k = Math.max(w / img.width, h / img.height);
          const dw = img.width * k, dh = img.height * k;
          ctx.drawImage(img, (w - dw) / 2, (h - dh) / 2, dw, dh);
          resolve({ dataUrl: c.toDataURL('image/png'), width: w, height: h });
        };
        img.src = reader.result;
      };
      reader.readAsDataURL(file);
    });
  }

  // ---- GIF: собственный декодер (LZW, interlace, прозрачность, disposal 0–3) ----
  // Возвращает { width, height, frames: [{ rgba: Uint8ClampedArray (полный кадр), delay: мс }] }.
  function lzwDecode(minCode, data, npix) {
    const clear = 1 << minCode, eoi = clear + 1;
    let size = minCode + 1, next = eoi + 1;
    const prefix = new Uint16Array(4096), suffix = new Uint8Array(4096), stack = new Uint8Array(4097);
    const out = new Uint8Array(npix);
    for (let i = 0; i < clear; i++) suffix[i] = i;
    let bits = 0, nbits = 0, pos = 0, op = 0, old = -1, first = 0;
    while (op < npix) {
      while (nbits < size) { if (pos >= data.length) return out; bits |= data[pos++] << nbits; nbits += 8; }
      let code = bits & ((1 << size) - 1); bits >>= size; nbits -= size;
      if (code === clear) { size = minCode + 1; next = eoi + 1; old = -1; continue; }
      if (code === eoi) break;
      if (old === -1) { out[op++] = suffix[code]; old = code; first = code; continue; }
      const inCode = code; let sp = 0;
      if (code >= next) { stack[sp++] = first; code = old; }
      while (code >= clear) { stack[sp++] = suffix[code]; code = prefix[code]; }
      first = suffix[code];
      stack[sp++] = first;
      if (next < 4096) { prefix[next] = old; suffix[next] = first; next++; if (next >= (1 << size) && size < 12) size++; }
      old = inCode;
      while (sp > 0 && op < npix) out[op++] = stack[--sp];
    }
    return out;
  }

  function decodeGif(buf) {
    const d = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
    const sig = String.fromCharCode(d[0], d[1], d[2], d[3], d[4], d[5]);
    if (sig !== 'GIF87a' && sig !== 'GIF89a') throw new Error('Это не GIF-файл.');
    const u16 = (i) => d[i] | (d[i + 1] << 8);
    const W = u16(6), H = u16(8);
    let p = 13, gct = null;
    if (d[10] & 0x80) { const n = 3 * (1 << ((d[10] & 7) + 1)); gct = d.subarray(p, p + n); p += n; }
    const canvas = new Uint8ClampedArray(W * H * 4);
    const frames = [];
    let gce = null, prevDisp = 0, prevRect = null, snapshot = null;
    while (p < d.length) {
      const b = d[p++];
      if (b === 0x3B) break;
      if (b === 0x21) {
        const label = d[p++];
        if (label === 0xF9) { gce = { disp: (d[p + 1] >> 2) & 7, trans: (d[p + 1] & 1) ? d[p + 4] : -1, delay: u16(p + 2) * 10 }; }
        while (d[p] !== 0 && p < d.length) p += d[p] + 1;
        p++;
        continue;
      }
      if (b !== 0x2C) break;
      const fx = u16(p), fy = u16(p + 2), fw = u16(p + 4), fh = u16(p + 6), packed = d[p + 8]; p += 9;
      let pal = gct;
      if (packed & 0x80) { const n = 3 * (1 << ((packed & 7) + 1)); pal = d.subarray(p, p + n); p += n; }
      const interlace = !!(packed & 0x40);
      const minCode = d[p++];
      const chunks = []; let total = 0;
      while (d[p] !== 0 && p < d.length) { chunks.push(d.subarray(p + 1, p + 1 + d[p])); total += d[p]; p += d[p] + 1; }
      p++;
      const data = new Uint8Array(total); let o = 0; for (const c of chunks) { data.set(c, o); o += c.length; }
      const idx = lzwDecode(minCode, data, fw * fh);
      // disposal предыдущего кадра
      if (prevDisp === 2 && prevRect) {
        for (let y = 0; y < prevRect.h; y++) for (let x = 0; x < prevRect.w; x++) {
          const cx = prevRect.x + x, cy = prevRect.y + y; if (cx < W && cy < H) canvas.fill(0, (cy * W + cx) * 4, (cy * W + cx) * 4 + 4);
        }
      } else if (prevDisp === 3 && snapshot) canvas.set(snapshot);
      snapshot = (gce && gce.disp === 3) ? new Uint8ClampedArray(canvas) : null;
      // порядок строк при interlace
      let rows;
      if (interlace) { rows = []; for (const [st, step] of [[0, 8], [4, 8], [2, 4], [1, 2]]) for (let y = st; y < fh; y += step) rows.push(y); }
      const trans = gce ? gce.trans : -1;
      for (let r = 0; r < fh; r++) {
        const y = interlace ? rows[r] : r, cy = fy + y;
        if (cy >= H) continue;
        for (let x = 0; x < fw; x++) {
          const ci = idx[r * fw + x], cx = fx + x;
          if (ci === trans || cx >= W || !pal) continue;
          const di = (cy * W + cx) * 4;
          canvas[di] = pal[ci * 3]; canvas[di + 1] = pal[ci * 3 + 1]; canvas[di + 2] = pal[ci * 3 + 2]; canvas[di + 3] = 255;
        }
      }
      let delay = gce ? gce.delay : 100; if (delay < 20) delay = 100;   // как в браузерах: 0/10 мс → 100 мс
      frames.push({ rgba: new Uint8ClampedArray(canvas), delay });
      prevDisp = gce ? gce.disp : 0; prevRect = { x: fx, y: fy, w: fw, h: fh }; gce = null;
    }
    if (!frames.length) throw new Error('В GIF нет кадров.');
    return { width: W, height: H, frames };
  }

  // Какие кадры взять из набора с длительностями: n отсчётов с шагом 1/fps, начиная со start (с).
  // Если интервал длиннее ролика — ролик зацикливается.
  function sampleIndices(delaysMs, fps, startSec, lenSec, maxFrames) {
    const total = delaysMs.reduce((a, b) => a + b, 0) || 1;
    const len = lenSec > 0 ? lenSec : total / 1000 - startSec;
    const n = Math.max(2, Math.min(maxFrames || MAX_FRAMES, Math.round(len * fps)));
    const out = [];
    for (let k = 0; k < n; k++) {
      let t = ((startSec * 1000 + (k * 1000) / fps) % total + total) % total, i = 0;
      while (i < delaysMs.length - 1 && t >= delaysMs[i]) { t -= delaysMs[i]; i++; }
      out.push(i);
    }
    return out;
  }

  function drawCover(ctx, src, sw, sh, w, h) {
    const k = Math.max(w / sw, h / sh), dw = sw * k, dh = sh * k;
    ctx.drawImage(src, (w - dw) / 2, (h - dh) / 2, dw, dh);
  }

  // GIF-файл → кадры PNG (dataURL) нужного размера. opts: { fps, start, len, w, h, onProgress }.
  async function gifFileToFrames(file, opts) {
    const g = decodeGif(await file.arrayBuffer());
    const picks = sampleIndices(g.frames.map((f) => f.delay), opts.fps, opts.start || 0, opts.len || 0, MAX_FRAMES);
    const src = document.createElement('canvas'); src.width = g.width; src.height = g.height;
    const sctx = src.getContext('2d');
    const c = document.createElement('canvas'); c.width = opts.w; c.height = opts.h;
    const ctx = c.getContext('2d');
    const out = [];
    for (let k = 0; k < picks.length; k++) {
      sctx.putImageData(new ImageData(g.frames[picks[k]].rgba, g.width, g.height), 0, 0);
      ctx.clearRect(0, 0, opts.w, opts.h);
      drawCover(ctx, src, g.width, g.height, opts.w, opts.h);
      out.push({ dataUrl: c.toDataURL('image/png'), width: opts.w, height: opts.h });
      if (opts.onProgress) opts.onProgress(k + 1, picks.length);
    }
    return out;
  }

  // Видео-файл → кадры PNG: перемотка <video> на каждый момент и снимок в canvas.
  async function videoFileToFrames(file, opts) {
    const url = URL.createObjectURL(file);
    try {
      const v = document.createElement('video');
      v.muted = true; v.playsInline = true; v.preload = 'auto'; v.src = url;
      await new Promise((res, rej) => { v.onloadedmetadata = res; v.onerror = () => rej(new Error('Браузер не смог открыть видео (формат/кодек не поддерживается). Подойдут MP4 (H.264), WebM.')); });
      const dur = v.duration;
      if (!isFinite(dur) || dur <= 0) throw new Error('Не удалось определить длительность видео.');
      const start = Math.max(0, Math.min(opts.start || 0, dur - 0.05));
      const len = Math.min(opts.len > 0 ? opts.len : dur - start, dur - start);
      const n = Math.max(2, Math.min(MAX_FRAMES, Math.round(len * opts.fps)));
      const c = document.createElement('canvas'); c.width = opts.w; c.height = opts.h;
      const ctx = c.getContext('2d');
      const out = [];
      for (let k = 0; k < n; k++) {
        const t = Math.min(start + k / opts.fps, dur - 0.001);
        await new Promise((res, rej) => {
          const to = setTimeout(() => rej(new Error('Видео не перематывается (таймаут). Попробуйте MP4 H.264 или WebM.')), 15000);
          v.onseeked = () => { clearTimeout(to); res(); };
          v.currentTime = t;
        });
        ctx.clearRect(0, 0, opts.w, opts.h);
        drawCover(ctx, v, v.videoWidth, v.videoHeight, opts.w, opts.h);
        out.push({ dataUrl: c.toDataURL('image/png'), width: opts.w, height: opts.h });
        if (opts.onProgress) opts.onProgress(k + 1, n);
      }
      return out;
    } finally { URL.revokeObjectURL(url); }
  }

  const isGif = (f) => f.type === 'image/gif' || /\.gif$/i.test(f.name || '');
  const isVideo = (f) => /^video\//.test(f.type) || /\.(mp4|webm|mov|m4v|ogv)$/i.test(f.name || '');

  // Предпросмотр. deps: getState(), host.setBgFrameOverride(id|null), setInterval/clearInterval.
  function createPreview(deps) {
    const si = deps.setInterval || ((fn, ms) => setInterval(fn, ms));
    const ci = deps.clearInterval || ((id) => clearInterval(id));
    let timer = null, idx = 0, plays = 0, onChange = null;

    function cfg() {
      const st = deps.getState();
      return normalize(st && st.background && st.background.anim);
    }
    function stop(resetFrame) {
      if (timer !== null) { ci(timer); timer = null; }
      if (resetFrame !== false) deps.host.setBgFrameOverride(null);
      if (onChange) onChange(false, idx);
    }
    function play() {
      const a = cfg();
      const st = deps.getState();
      if (st && st.mode === 'aod') return false;        // в AOD анимаций нет
      if (a.frames.length < 2) return false;
      stop(false);
      if (idx >= a.frames.length - 1) idx = 0;
      plays = 0;
      deps.host.setBgFrameOverride(a.frames[idx]);
      timer = si(() => {
        const cur = cfg();
        if (cur.frames.length < 2) { stop(); return; }
        idx++;
        if (idx >= cur.frames.length) {
          idx = 0; plays++;
          if (!cur.loop && plays >= cur.repeat) { stop(); return; }   // как на часах: после последнего прохода — статичный фон
        }
        deps.host.setBgFrameOverride(cur.frames[idx]);
        if (onChange) onChange(true, idx);
      }, Math.round(1000 / a.fps));
      if (onChange) onChange(true, idx);
      return true;
    }
    function seek(frameIndex) {
      const a = cfg();
      if (!a.frames.length) return false;
      stop(false);
      idx = Math.max(0, Math.min(a.frames.length - 1, Math.round(Number(frameIndex) || 0)));
      deps.host.setBgFrameOverride(a.frames[idx]);
      if (onChange) onChange(false, idx);
      return true;
    }
    return {
      play, stop, seek,
      currentIndex: () => idx,
      isPlaying: () => timer !== null,
      setOnChange: (fn) => { onChange = fn; },
      dispose: () => stop(),
    };
  }

  const api = { MAX_FRAMES, DEFAULTS, normalize, sortFilesNatural, fileToPngFrame, createPreview, decodeGif, sampleIndices, gifFileToFrames, videoFileToFrames, isGif, isVideo };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.BgAnim = api;
})(typeof window !== 'undefined' ? window : globalThis);
