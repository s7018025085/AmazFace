// Timeline for scrubbing and previewing the background animation frames.
(function (root) {
  'use strict';

  class BgAnimTimeline {
    constructor(el, deps) {
      this.el = el;
      this.getState = deps.getState;
      this.preview = deps.preview;
      this.index = 0;
      this.zoom = Math.max(44, Math.min(112, Number(localStorage.getItem('amazface.bgTimeline.zoom')) || 64));
      this.height = Math.max(90, Math.min(320, Number(localStorage.getItem('amazface.bgTimeline.height')) || 142));
      this.collapsed = localStorage.getItem('amazface.bgTimeline.collapsed') === '1';
      this.dragStart = null;
      this.el.addEventListener('input', (e) => this._input(e));
      this.el.addEventListener('click', (e) => this._click(e));
      this.el.addEventListener('pointerdown', (e) => this._pointerDown(e));
      this._onMove = (e) => this._pointerMove(e);
      this._onUp = () => this._pointerUp();
      window.addEventListener('pointermove', this._onMove);
      window.addEventListener('pointerup', this._onUp);
      window.addEventListener('pointercancel', this._onUp);
      this.preview.setOnChange((playing, index) => {
        if (Number.isInteger(index)) this.index = index;
        this._syncPlayButton(playing);
        this._syncPosition(true);
      });
      this.render();
    }

    _anim() {
      return BgAnim.normalize(this.getState()?.background?.anim);
    }

    _escAttr(value) {
      return String(value).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    }

    render() {
      const state = this.getState();
      const anim = this._anim();
      const frames = anim.frames;
      const assets = state?.assets || [];
      if (state?.mode === 'aod' || frames.length < 2) {
        this.el.hidden = true;
        return;
      }
      this.el.hidden = false;
      this.index = Math.max(0, Math.min(this.index, frames.length - 1));
      this.el.classList.toggle('is-collapsed', this.collapsed);
      this.el.style.setProperty('--bg-timeline-height', this.height + 'px');
      this.el.style.setProperty('--bg-timeline-frame-width', this.zoom + 'px');
      this.el.innerHTML = `
        <div class="bg-timeline-grip" data-ba-timeline-grip title="Потяните, чтобы изменить высоту таймлайна"><span></span></div>
        <div class="bg-timeline-head">
          <div class="bg-timeline-title"><b>Таймлайн фона</b><span data-ba-time>Кадр ${this.index + 1} / ${frames.length}</span></div>
          <div class="bg-timeline-actions">
            <button type="button" data-ba-timeline-act="play" title="Воспроизвести">▶</button>
            <button type="button" data-ba-timeline-act="zoom-out" title="Уменьшить кадры">−</button>
            <button type="button" data-ba-timeline-act="zoom-in" title="Увеличить кадры">+</button>
            <button type="button" data-ba-timeline-act="collapse" title="Свернуть таймлайн">${this.collapsed ? '▴' : '▾'}</button>
          </div>
        </div>
        <div class="bg-timeline-body">
          <div class="bg-timeline-rail" data-ba-rail>
            ${frames.map((id, i) => {
              const asset = assets.find((a) => a.id === id);
              return `<button type="button" class="bg-timeline-frame${i === this.index ? ' active' : ''}" data-ba-frame="${i}" title="Кадр ${i + 1}"><img alt="" src="${this._escAttr(asset?.dataUrl || '')}"><span>${i + 1}</span></button>`;
            }).join('')}
          </div>
          <div class="bg-timeline-scrubber">
            <input type="range" data-ba-scrub min="0" max="${frames.length - 1}" value="${this.index}" aria-label="Положение на таймлайне">
            <span data-ba-position>${this.index + 1} / ${frames.length}</span>
          </div>
        </div>`;
      this._syncPlayButton(this.preview.isPlaying());
      this._syncPosition(false);
    }

    _input(e) {
      if (e.target.matches('[data-ba-scrub]')) this._seek(Number(e.target.value));
    }

    _click(e) {
      const frame = e.target.closest('[data-ba-frame]');
      if (frame) { this._seek(Number(frame.dataset.baFrame)); return; }
      const action = e.target.closest('[data-ba-timeline-act]')?.dataset.baTimelineAct;
      if (!action) return;
      if (action === 'play') {
        if (this.preview.isPlaying()) this.preview.stop(false);
        else this.preview.play();
      } else if (action === 'zoom-in' || action === 'zoom-out') {
        this.zoom = Math.max(44, Math.min(112, this.zoom + (action === 'zoom-in' ? 12 : -12)));
        localStorage.setItem('amazface.bgTimeline.zoom', String(this.zoom));
        this.render();
      } else if (action === 'collapse') {
        this.collapsed = !this.collapsed;
        localStorage.setItem('amazface.bgTimeline.collapsed', this.collapsed ? '1' : '0');
        this.render();
      }
    }

    _seek(index) {
      const frames = this._anim().frames;
      if (!frames.length) return;
      this.preview.seek(Math.max(0, Math.min(frames.length - 1, Math.round(index))));
    }

    _syncPosition(scrollIntoView) {
      if (this.el.hidden) return;
      const frames = this._anim().frames;
      const range = this.el.querySelector('[data-ba-scrub]');
      if (!range) return;
      this.index = Math.max(0, Math.min(this.index, frames.length - 1));
      range.value = String(this.index);
      const position = this.el.querySelector('[data-ba-position]');
      const time = this.el.querySelector('[data-ba-time]');
      if (position) position.textContent = `${this.index + 1} / ${frames.length}`;
      if (time) time.textContent = `Кадр ${this.index + 1} / ${frames.length}`;
      this.el.querySelectorAll('[data-ba-frame]').forEach((el, i) => el.classList.toggle('active', i === this.index));
      if (scrollIntoView) this.el.querySelector(`[data-ba-frame="${this.index}"]`)?.scrollIntoView({ block: 'nearest', inline: 'nearest' });
    }

    _syncPlayButton(playing) {
      const button = this.el.querySelector('[data-ba-timeline-act="play"]');
      if (button) {
        button.textContent = playing ? '⏸' : '▶';
        button.title = playing ? 'Остановить' : 'Воспроизвести';
      }
    }

    _pointerDown(e) {
      if (!e.target.closest('[data-ba-timeline-grip]') || this.collapsed || e.button !== 0) return;
      e.preventDefault();
      this.dragStart = { y: e.clientY, height: this.height };
      this.el.classList.add('is-resizing');
    }

    _pointerMove(e) {
      if (!this.dragStart) return;
      this.height = Math.max(90, Math.min(320, this.dragStart.height + this.dragStart.y - e.clientY));
      this.el.style.setProperty('--bg-timeline-height', this.height + 'px');
    }

    _pointerUp() {
      if (!this.dragStart) return;
      this.dragStart = null;
      this.el.classList.remove('is-resizing');
      localStorage.setItem('amazface.bgTimeline.height', String(this.height));
    }
  }

  root.BgAnimTimeline = BgAnimTimeline;
})(typeof window !== 'undefined' ? window : globalThis);
