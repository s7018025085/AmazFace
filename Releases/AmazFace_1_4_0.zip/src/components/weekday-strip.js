// Shared layout for the seven-day strip used by preview and export.
(function (root) {
  'use strict';

  const DAYS = {
    EN: {
      short: ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'],
      full: ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'],
    },
    RU: {
      short: ['ВС', 'ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ'],
      full: ['ВОСКРЕСЕНЬЕ', 'ПОНЕДЕЛЬНИК', 'ВТОРНИК', 'СРЕДА', 'ЧЕТВЕРГ', 'ПЯТНИЦА', 'СУББОТА'],
    },
  };
  const DAYS_RU_3 = ['ВОС', 'ПОН', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ'];

  function orderIndices(weekStart) {
    return weekStart === 'SUNDAY' ? [0, 1, 2, 3, 4, 5, 6] : [1, 2, 3, 4, 5, 6, 0];
  }

  function labels(props = {}) {
    const locale = props.weekday_locale === 'RU' ? 'RU' : 'EN';
    const format = props.weekday_format || 'EEE';
    const source = format === 'EEEE' ? DAYS[locale].full : locale === 'RU' && format === 'EEE3' ? DAYS_RU_3 : DAYS[locale].short;
    return orderIndices(props.week_start).map((day) => source[day]);
  }

  function activeIndex(props = {}, date = new Date()) {
    const selected = props.preview_weekday;
    const jsDay = selected !== undefined && selected !== null && selected !== '' && selected !== 'AUTO'
      ? Math.max(0, Math.min(6, Number(selected) || 0))
      : date.getDay();
    return props.week_start === 'SUNDAY' ? jsDay : (jsDay + 6) % 7;
  }

  function layout(comp, props = {}) {
    const x = Number(comp.x) || 0, y = Number(comp.y) || 0;
    const w = Math.max(7, Number(comp.w) || 280), h = Math.max(1, Number(comp.h) || 48);
    const size = Math.max(8, Number(props.text_size) || 22);
    const layout = props.layout || 'LINE';
    const horizontalArc = ['ARC', 'ARC_TOP', 'ARC_BOTTOM'].includes(layout);
    const verticalArc = ['ARC_LEFT', 'ARC_RIGHT'].includes(layout);
    const slotW = horizontalArc || !verticalArc ? w / 7 : w;
    const slotH = verticalArc ? h / 7 : h;
    const rawDepth = Number(props.arc_depth), rawPadX = Number(props.marker_pad_x), rawPadY = Number(props.marker_pad_y);
    const depthLimit = verticalArc ? w - size : h - size;
    const depth = horizontalArc || verticalArc ? Math.max(0, Math.min(depthLimit, Number.isFinite(rawDepth) ? rawDepth : 24)) : 0;
    const padX = Math.max(0, Number.isFinite(rawPadX) ? rawPadX : 4);
    const padY = Math.max(0, Number.isFinite(rawPadY) ? rawPadY : 3);
    const markerW = Number(props.marker_width) > 0 ? Math.min(slotW, Number(props.marker_width)) : Math.max(1, slotW - padX * 2);
    const markerH = Number(props.marker_height) > 0 ? Math.min(slotH, Number(props.marker_height)) : Math.min(slotH, size * 1.25 + padY * 2);
    const dotSize = Math.max(2, Number(props.marker_dot_size) || 7);
    const names = labels(props);
    return names.map((label, i) => {
      const t = (i + 0.5) / 7;
      const arcWave = Math.sin(Math.PI * t) - 0.5;
      const slotX = verticalArc
        ? x + w / 2 + (layout === 'ARC_LEFT' ? -1 : 1) * depth * arcWave
        : x + slotW * (i + 0.5);
      const slotY = verticalArc
        ? y + slotH * (i + 0.5)
        : y + h / 2 + (horizontalArc ? depth * (layout === 'ARC_BOTTOM' ? arcWave : -arcWave) : 0);
      return {
        index: i,
        label,
        x: slotX,
        y: slotY,
        w: slotW,
        h: slotH,
        textSize: size,
        marker: {
          x: slotX,
          y: slotY + (props.marker_style === 'UNDERLINE' ? size * 0.62 + padY : props.marker_style === 'DOT' ? size * 0.78 + padY : 0),
          w: props.marker_style === 'DOT' ? dotSize : markerW,
          h: props.marker_style === 'DOT' ? dotSize : props.marker_style === 'UNDERLINE' ? Math.max(1, Number(props.marker_line_width) || 2) : markerH,
        },
      };
    });
  }

  root.WeekdayStripModel = { labels, activeIndex, layout };
})(typeof window !== 'undefined' ? window : globalThis);
