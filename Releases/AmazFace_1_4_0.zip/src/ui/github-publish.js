// src/ui/github-publish.js
//
// Диалог «Опубликовать на GitHub». Сборка файлов использует существующие
// экспортёры без изменений (exportFullProject, exportZpkPackage), QR —
// существующие toZpkd1Url / qrEncodeToMatrix. Всё, что связано с токеном и
// GitHub API, делает локальный мост: редактор отправляет токен один раз при
// подключении и дальше ни хранит, ни получает его.
//
// Файл подключается ПОСЛЕ app.js: использует его глобальные store,
// ZEUS_BRIDGE, runFullPreflight, withBusyOverlay.

(() => {
  const dlg = document.getElementById('github-dialog');
  if (!dlg || typeof AmazGh === 'undefined') return;

  const $ = (id) => document.getElementById(id);
  const esc = (t) => String(t == null ? '' : t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const KEY_STORAGE = 'amazface_bridge_key'; // код доступа к МОСТУ, не токен GitHub
  const BRIDGE = () => (typeof ZEUS_BRIDGE === 'string' ? ZEUS_BRIDGE : 'http://127.0.0.1:17865');

  const S = {
    key: '', bridgeUp: null, keyValid: false, status: null, nodeVersion: '',
    running: false, job: null, lastBuild: null, steps: [], qr: null, signature: ''
  };
  try { S.key = localStorage.getItem(KEY_STORAGE) || ''; } catch (e) { /* localStorage может быть недоступен */ }

  // ───────── связь с мостом ─────────
  async function bridge(pathname, opts) {
    opts = opts || {};
    let res;
    try {
      res = await fetch(BRIDGE() + pathname, {
        method: opts.method || 'GET',
        headers: Object.assign({ 'X-AmazFace-Key': S.key || '' }, opts.body !== undefined ? { 'Content-Type': 'application/json' } : {}),
        body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined
      });
    } catch (e) {
      const err = new Error('Локальный мост не отвечает. Запустите bridge/start-zeus-bridge.bat и оставьте окно открытым.');
      err.code = 'bridge_down'; throw err;
    }
    let json = null;
    try { json = await res.json(); } catch (e) { /* пустой ответ */ }
    if (!res.ok) {
      const err = new Error((json && json.error) || `Ошибка моста (${res.status}).`);
      err.code = json && json.code; err.status = res.status; throw err;
    }
    return json;
  }

  // ───────── вспомогательное ─────────
  const slugAuto = () => latinSlug(store.state.meta && store.state.meta.name, 'watchface');
  function currentSlug() {
    const s = S.status && S.status.settings;
    return s && s.naming === 'custom' && s.customSlug ? s.customSlug : AmazGh.normalizeSlug(slugAuto(), 'watchface');
  }
  function projectSignature() {
    try { return JSON.stringify([store.state.components, store.state.background, store.state.scenes, store.state.meta && store.state.meta.name]); }
    catch (e) { return ''; }
  }
  function toBase64(bytes) {
    return new Promise((resolve, reject) => {
      const fr = new FileReader();
      fr.onload = () => resolve(String(fr.result).split(',')[1] || '');
      fr.onerror = () => reject(new Error('Не удалось подготовить файл к отправке.'));
      fr.readAsDataURL(new Blob([bytes]));
    });
  }
  const kb = (n) => `${Math.max(1, Math.round(n / 1024))} КБ`;
  const say = (el, html) => { el.innerHTML = html; };

  // ───────── отображение ─────────
  function renderStatus() {
    const el = $('gh-bridge-status');
    $('gh-key-row').hidden = !(S.bridgeUp && !S.keyValid);
    const connected = !!(S.status && S.status.connected);
    $('gh-connected').hidden = !connected;
    if (S.bridgeUp === null) say(el, 'Проверяю локальный мост…');
    else if (!S.bridgeUp) say(el, '<span class="err">Локальный мост не запущен.</span> Запустите <code>bridge/start-zeus-bridge.bat</code>, оставьте окно открытым и нажмите «Опубликовать на GitHub» снова.');
    else if (!S.keyValid) say(el, '<span class="warn">Мост найден, нужен код доступа.</span> Он напечатан в окне моста — введите его один раз.');
    else say(el, '<span class="ok">Мост работает.</span>');

    if (connected) {
      const st = S.status, c = st.settings;
      const prot = st.protection === 'dpapi' ? 'токен защищён Windows DPAPI'
        : st.protection === 'file-0600' ? 'токен в файле с доступом только для вас (не Windows)'
        : 'токен только в памяти моста — после перезапуска моста введите его снова';
      say($('gh-connected-text'), `<span class="ok">Подключено:</span> ${esc(st.login)} → ${esc(c.owner)}/${esc(c.repo)} · ветка ${esc(c.branch)} · папка ${esc(c.folder || '/')}<br><span class="zpk-note">${esc(prot)}</span>`);
      $('gh-settings').open = false;
    } else if (S.keyValid) {
      $('gh-settings').open = true;
    }
    renderFiles();
    renderButtons();
  }

  function fillForm() {
    const c = S.status && S.status.settings;
    if (!c) return;
    $('gh-repo').value = `${c.owner}/${c.repo}`;
    $('gh-branch').value = c.branch;
    $('gh-folder').value = c.folder;
    document.querySelector(`input[name="gh-naming"][value="${c.naming}"]`).checked = true;
    $('gh-slug').value = c.customSlug || '';
  }

  function renderFiles() {
    const ul = $('gh-files');
    $('gh-auto-slug').textContent = AmazGh.normalizeSlug(slugAuto(), 'watchface');
    const c = S.status && S.status.settings;
    if (!c) { ul.innerHTML = '<li>Сначала подключите репозиторий.</li>'; return; }
    try {
      const t = AmazGh.targetPaths({ folder: c.folder, slug: currentSlug() });
      const animated = !!(window.ShareImages && ShareImages.hasAnimation && ShareImages.hasAnimation(store.state));
      ul.innerHTML = ['zpk', 'deviceZip', 'projectZip', 'json', 'watch', 'watch200', 'watchQr'].concat(animated ? ['watchGif'] : [], ['readme', 'marker']).map(k => `<li><code>${esc(t.files[k])}</code></li>`).join('');
    } catch (e) { ul.innerHTML = `<li class="err">${esc(e.message)}</li>`; }
  }

  function renderSteps() {
    $('gh-steps').innerHTML = S.steps.map(s => {
      const ico = s.status === 'done' ? '✓' : s.status === 'running' ? '…' : s.status === 'failed' ? '✕' : '○';
      return `<li class="${s.status}"><span class="gh-ico">${ico}</span><span>${esc(s.label)}${s.detail ? `<span class="gh-detail">${esc(s.detail)}</span>` : ''}</span></li>`;
    }).join('');
  }

  function renderButtons() {
    const ready = !!(S.status && S.status.connected && S.keyValid && S.bridgeUp);
    $('gh-publish').disabled = S.running || !ready;
    $('gh-retry').hidden = !(S.lastBuild && !S.running && S.job && S.job.status !== 'done');
    $('gh-retry').disabled = S.running || !ready;
    $('gh-cancel').hidden = !S.running;
    $('gh-connect').disabled = S.running || !S.keyValid;
    $('gh-disconnect').disabled = S.running || !(S.status && S.status.connected);
    $('gh-publish').textContent = S.job && S.job.status === 'done' ? 'Опубликовать заново' : 'Опубликовать';
  }

  function clearQr() {
    S.qr = null;
    $('gh-result').hidden = true; $('gh-share').hidden = true; $('gh-placeholder').hidden = false;
    $('gh-qr').innerHTML = ''; $('gh-qr-text').textContent = ''; $('gh-links').innerHTML = ''; $('gh-qr-warn').innerHTML = '';
    for (const id of ['gh-open-repo', 'gh-copy-url']) $(id).disabled = true;
    clearShare();
  }

  // ───────── картинки для публикации: QR / часы / часы+QR ─────────
  let shareSeq = 0; // защита от устаревших результатов при быстрой смене настроек
  function clearShare() {
    shareSeq++;
    if (S.share) for (const f of S.share) URL.revokeObjectURL(f.url);
    S.share = null; S.shareGif = null;
    $('gh-share-grid').innerHTML = ''; $('gh-share-msg').innerHTML = ''; $('gh-share-all').disabled = true;
  }

  function renderShareGrid() {
    $('gh-share-grid').innerHTML = S.share.map((f, i) =>
      `<figure class="gh-share-card"><div class="gh-share-thumb"><img src="${f.url}" alt="${esc(f.label)}"></div>` +
      `<figcaption>${esc(f.label)}<small>${esc(f.name)} · ${f.width}×${f.height}${f.note ? ' · ' + esc(f.note) : ''}</small></figcaption>` +
      `<button class="btn-secondary" type="button" data-share="${i}">Сохранить…</button></figure>`).join('');
    $('gh-share-all').textContent = S.share.length > 1 ? `Сохранить все (${S.share.length}) в папку…` : 'Сохранить в папку…';
  }

  async function buildShare() {
    if (!S.qr) return;
    const my = ++shareSeq;
    $('gh-share-all').disabled = true;
    say($('gh-share-msg'), 'Готовлю картинки…');
    try {
      const files = await ShareImages.buildAll(store.state, S.qr.matrix, { transparentWatch: $('gh-share-transparent').checked });
      if (my !== shareSeq) return;
      const slug = S.qr.slug;
      if (S.share) for (const f of S.share) URL.revokeObjectURL(f.url);
      S.share = files.map(f => ({ ...f, name: `${slug}-${f.suffix}.png`, url: URL.createObjectURL(f.blob) }));
      renderShareGrid();
      $('gh-share-all').disabled = false;
      say($('gh-share-msg'), '');
    } catch (e) {
      if (my === shareSeq) say($('gh-share-msg'), `<span class="err">Не удалось подготовить картинки: ${esc(e.message)}</span>`);
      return;
    }
    await addShareGif(my);
  }

  // Анимированное превью (GIF) — если у фона есть покадровая анимация. Собирается после PNG,
  // чтобы картинки появились сразу; от «прозрачного фона» не зависит, поэтому кешируется до смены проекта.
  async function addShareGif(my) {
    if (!(ShareImages.buildAnimatedGif && ShareImages.hasAnimation && ShareImages.hasAnimation(store.state))) return;
    try {
      if (!S.shareGif) {
        $('gh-share-all').disabled = true;
        const g = await ShareImages.buildAnimatedGif(store.state, {
          onProgress: (i, n) => { if (my === shareSeq) say($('gh-share-msg'), `GIF-превью: кадр ${i} из ${n}…`); }
        });
        if (my !== shareSeq) return;
        if (!g || !g.bytes || !g.bytes.length) { $('gh-share-all').disabled = false; say($('gh-share-msg'), ''); return; }
        S.shareGif = g;
      }
      if (my !== shareSeq || !S.share) return;
      const g = S.shareGif;
      const blob = new Blob([g.bytes], { type: 'image/gif' });
      S.share.push({
        id: 'gif', label: 'Анимированное превью (GIF)', suffix: 'watch', note: `${g.frames} кадров, ${kb(g.bytes.length)}`,
        blob, width: g.width, height: g.height, name: `${S.qr.slug}-watch.gif`, url: URL.createObjectURL(blob)
      });
      renderShareGrid();
      $('gh-share-all').disabled = false;
      say($('gh-share-msg'), '');
    } catch (e) {
      console.warn('GIF preview failed:', e);
      if (my === shareSeq) { $('gh-share-all').disabled = false; say($('gh-share-msg'), `<span class="warn">GIF-превью не создан: ${esc(e.message)}</span>`); }
    }
  }

  function reportSaved(how, what) {
    if (how === 'cancelled') say($('gh-share-msg'), '');
    else if (how === 'download') say($('gh-share-msg'), `<span class="ok">${esc(what)}: отправлено в загрузки браузера.</span> <span class="zpk-note">Выбор папки при сохранении доступен в Chrome/Edge.</span>`);
    else say($('gh-share-msg'), `<span class="ok">${esc(what)}: сохранено.</span>`);
  }

  $('gh-share-grid').addEventListener('click', async (e) => {
    const b = e.target.closest('button[data-share]');
    if (!b || !S.share) return;
    const f = S.share[Number(b.dataset.share)];
    try { reportSaved(await ShareImages.saveBlob(f.blob, f.name), f.name); }
    catch (err) { say($('gh-share-msg'), `<span class="err">Не удалось сохранить: ${esc(err.message)}</span>`); }
  });
  $('gh-share-all').addEventListener('click', async () => {
    if (!S.share) return;
    try { reportSaved(await ShareImages.saveAll(S.share.map(f => ({ name: f.name, blob: f.blob }))), S.share.length === 1 ? 'Картинка' : `Картинки (${S.share.length})`); }
    catch (err) { say($('gh-share-msg'), `<span class="err">Не удалось сохранить: ${esc(err.message)}</span>`); }
  });
  $('gh-share-transparent').addEventListener('change', buildShare);

  function showResult(result) {
    // QR строится только из ссылки, которую мост подтвердил (200, тот же файл,
    // без авторизации), и только существующими функциями проекта.
    const deepLink = toZpkd1Url(result.zpkUrl);
    if (deepLink !== result.deepLink) throw new Error('Ссылка для QR не совпала с подтверждённой — QR не создан.');
    const matrix = qrEncodeToMatrix(deepLink, 'M');
    S.qr = { matrix, url: result.zpkUrl, deepLink, folderUrl: result.folderUrl, repoUrl: result.repoUrl, slug: currentSlug() };
    S.signature = projectSignature();
    $('gh-result').hidden = false; $('gh-share').hidden = false; $('gh-placeholder').hidden = true;
    const img = document.createElement('img');
    img.src = qrMatrixToPngDataUrl(matrix, 8); img.alt = 'QR-код для установки циферблата';
    // Отображаем вдвое меньше прежнего (≈130 px вместо ≈260 px) и строго по целым
    // пикселям на модуль — без размытия; белая «тихая зона» (4 модуля) остаётся в картинке.
    const totalModules = matrix.size + 8;
    const px = Math.max(2, Math.round(130 / totalModules)) * totalModules;
    img.width = px; img.height = px;
    img.style.width = px + 'px'; img.style.height = px + 'px';
    $('gh-qr').innerHTML = ''; $('gh-qr').appendChild(img);
    $('gh-qr-text').textContent = deepLink;
    const notes = checkZpkUrl(result.zpkUrl);
    const links = [
      `Репозиторий: <a href="${esc(result.repoUrl)}" target="_blank" rel="noopener">${esc(result.repoUrl)}</a>`,
      `Прямая ссылка на пакет: <a href="${esc(result.zpkUrl)}" target="_blank" rel="noopener">${esc(result.zpkUrl)}</a>`,
      result.commitUrl ? `Последний коммит: <a href="${esc(result.commitUrl)}" target="_blank" rel="noopener">${esc(result.commitUrl)}</a>` : '',
      `<span class="ok">Ссылка проверена без авторизации: отдаётся ${kb(result.size)}, содержимое совпадает с загруженным (${esc(result.sha256.slice(0, 12))}…).</span>`
    ].filter(Boolean).join('<br>');
    say($('gh-links'), links + notes.map(n => `<br><span class="warn">${esc(n)}</span>`).join('') + (result.warnings || []).map(n => `<br><span class="warn">${esc(n)}</span>`).join(''));
    for (const id of ['gh-open-repo', 'gh-copy-url']) $(id).disabled = false;
    checkStaleQr();
    buildShare(); // картинки для 4PDA — не блокирует результат публикации
  }

  // Если проект изменили после публикации, QR остаётся верным для ОПУБЛИКОВАННОЙ
  // версии, но пользователь должен это видеть.
  function checkStaleQr() {
    const w = $('gh-qr-warn');
    if (S.qr && S.signature && projectSignature() !== S.signature) say(w, '<span class="warn">Проект изменён после публикации: этот QR ставит ранее опубликованную версию. Нажмите «Опубликовать заново», чтобы обновить её.</span>');
    else w.innerHTML = '';
  }

  // ───────── сборка файлов существующими экспортёрами ─────────
  async function buildArtifacts(setStep) {
    const pre = await runFullPreflight(false);
    if (!pre.ok) throw new Error(`Проверка проекта не пройдена (ошибок: ${pre.errors.length}). Откройте «🔎 Проверка» и исправьте их:\n` + pre.errors.slice(0, 5).join('\n'));

    setStep('Собираю project.zip…');
    const full = await exportFullProject(store.state);
    if (full.validation && full.validation.errors && full.validation.errors.length) throw new Error('Проект не собран — критические ошибки генератора:\n' + full.validation.errors.slice(0, 5).join('\n'));
    const projectZip = new Uint8Array(await full.blob.arrayBuffer());

    setStep('Собираю .zpk и device.zip…');
    // Раздаётся по ссылке zpkd1:// «средний уровень» — .zpk из app-side.zip и device.zip
    // БЕЗ внешнего manifest.json. Проверено на телефоне: с manifest.json Zepp App пишет
    // «Parse mini program package failed», без него пакет устанавливается.
    const zpkPkg = await exportZpkPackage(store.state, { compress: true });
    if (zpkPkg.validation && zpkPkg.validation.errors && zpkPkg.validation.errors.length) throw new Error('Пакет не собран — критические ошибки:\n' + zpkPkg.validation.errors.slice(0, 5).join('\n'));
    const inner = zpkPkg.bytes;
    const innerEntries = await readZipEntries(inner);
    if (!innerEntries.has('device.zip')) throw new Error('В пакете нет device.zip — публикация остановлена.');
    const deviceZip = innerEntries.get('device.zip'); // тот же, что внутри .zpk

    setStep('Готовлю исходник циферблата…');
    try {
      store.state.preview = store.state.preview || {};
      store.state.preview.dataUrl = await buildPreviewDataUrl(store.state, 324);
      store.state.preview.width = 324; store.state.preview.height = 324; store.state.preview.handsTime = '10:10';
    } catch (e) { console.warn('Preview generation failed:', e); }
    store._saveActiveScene();
    const json = new TextEncoder().encode(store.toJSON());

    const parts = { zpk: inner, deviceZip, projectZip, json };
    for (const [k, v] of Object.entries(parts)) if (!v || !v.length) throw new Error(`Файл «${k}» получился пустым — публикация остановлена.`);
    // Мокапы собираются в трёх вариантах. QR строится из ссылки, которую мост
    // вычислит сам из тех же настроек; мост сверит её перед загрузкой.
    let watchQrLink = '';
    const c = S.status && S.status.settings;
    if (!c || typeof ShareImages === 'undefined' || !ShareImages.buildAll) throw new Error('Не удалось подготовить мокапы для GitHub.');
    setStep('Готовлю три варианта мокапа…');
    const paths = AmazGh.targetPaths({ folder: c.folder, slug: currentSlug() });
    const predicted = AmazGh.rawUrl({ owner: c.owner, repo: c.repo, branch: c.branch, path: paths.files.zpk });
    watchQrLink = toZpkd1Url(predicted);
    const mockups = await ShareImages.buildAll(store.state, qrEncodeToMatrix(watchQrLink, 'M'));
    for (const f of mockups) {
      if (f.id === 'qr') continue; // QR-only is for the manual share gallery; GitHub receives the three watch mockups.
      const key = f.id === 'watch200' ? 'watch200' : f.id === 'combined' ? 'watchQr' : f.id;
      parts[key] = new Uint8Array(await f.blob.arrayBuffer());
    }
    // Анимированное превью (GIF) — только если у фона есть покадровая анимация (≥ 2 кадров).
    // Ошибка GIF не должна срывать публикацию: превью вторично, поэтому просто идём дальше с предупреждением.
    let gifInfo = null, gifWarn = '';
    if (ShareImages.buildAnimatedGif && ShareImages.hasAnimation && ShareImages.hasAnimation(store.state)) {
      try {
        setStep('Готовлю GIF-превью анимации…');
        const g = await ShareImages.buildAnimatedGif(store.state, { onProgress: (i, n) => setStep(`GIF-превью: кадр ${i} из ${n}…`) });
        if (g && g.bytes && g.bytes.length) { parts.watchGif = g.bytes; gifInfo = g; }
      } catch (e) { console.warn('GIF preview failed:', e); gifWarn = e.message; }
    }
    return {
      artifacts: parts,
      gifInfo, gifWarn,
      watchQrLink,
      meta: { appId: store.state.app && store.state.app.appId, name: store.state.meta && store.state.meta.name || 'AmazFace Watch Face', version: (store.state.app && store.state.app.versionName) || '1.0.0', slug: slugAuto() },
      sizes: Object.fromEntries(Object.entries(parts).map(([k, v]) => [k, v.length]))
    };
  }

  // ───────── публикация ─────────
  async function publish(reuse) {
    if (S.running) return;                                  // повторный запуск блокируется
    S.running = true; S.job = null; clearQr(); say($('gh-msg'), '');
    S.steps = [
      { id: 'build', label: 'Сборка проекта, device.zip и .zpk', status: 'running', detail: '' },
      { id: 'send', label: 'Передача файлов на локальный мост', status: 'pending', detail: '' },
      { id: 'check', label: 'Проверка репозитория', status: 'pending', detail: '' },
      { id: 'zeus-build', label: 'Компиляция Zeus (zeus build)', status: 'pending', detail: '' },
      { id: 'prepare', label: 'Проверка файлов', status: 'pending', detail: '' },
      { id: 'upload', label: 'Загрузка на GitHub', status: 'pending', detail: '' },
      { id: 'verify-api', label: 'Проверка загруженных файлов', status: 'pending', detail: '' },
      { id: 'verify-url', label: 'Проверка публичной ссылки', status: 'pending', detail: '' },
      { id: 'qr', label: 'Генерация QR-кода', status: 'pending', detail: '' }
    ];
    renderSteps(); renderButtons();
    const step = (id, status, detail) => { const s = S.steps.find(x => x.id === id); if (s) { s.status = status; if (detail !== undefined) s.detail = detail; } renderSteps(); };
    try {
      if (!reuse || !S.lastBuild) {
        S.lastBuild = null;
        S.lastBuild = await withBusyOverlay('Собираю файлы для GitHub…', 'project.zip, device.zip и .zpk', () => buildArtifacts((d) => step('build', 'running', d)));
      }
      const b = S.lastBuild;
      step('build', 'done', `.zpk ${kb(b.sizes.zpk)}, device.zip ${kb(b.sizes.deviceZip)}, project.zip ${kb(b.sizes.projectZip)}, мокапы: полный ${kb(b.sizes.watch)}, 200 px ${kb(b.sizes.watch200)}, с QR ${kb(b.sizes.watchQr)}` + (b.sizes.watchGif ? `, GIF ${kb(b.sizes.watchGif)} (${b.gifInfo.frames} кадров, ${b.gifInfo.width}×${b.gifInfo.height})` : b.gifWarn ? `; GIF не создан: ${b.gifWarn}` : ''));

      step('send', 'running');
      const payload = { slug: b.meta.slug, appId: b.meta.appId, name: b.meta.name, version: b.meta.version, watchQrLink: b.watchQrLink || '', artifacts: {} };
      for (const [k, v] of Object.entries(b.artifacts)) payload.artifacts[k] = await toBase64(v);
      let job = await bridge('/github/publish', { method: 'POST', body: payload });
      step('send', 'done');
      S.job = job;

      // Опрос задания: шаги приходят с моста
      for (;;) {
        for (const ms of job.steps) step(ms.id, ms.status, ms.detail);
        showFilesProgress(job);
        if (job.status !== 'running') break;
        await new Promise(r => setTimeout(r, 600));
        job = await bridge('/github/job?id=' + encodeURIComponent(job.id));
        S.job = job;
      }
      if (job.status === 'cancelled') { say($('gh-msg'), '<span class="warn">Публикация прервана. Уже загруженные файлы остались в репозитории; «Повторить» продолжит с того же места.</span>'); return; }
      if (job.status === 'failed') { reportFailure(job); return; }

      step('qr', 'running');
      showResult(job.result);
      step('qr', 'done', 'QR соответствует проверенной ссылке');
      say($('gh-msg'), '<span class="ok">Опубликовано.</span> Проверьте установку на часах: сканируйте QR в Zepp App (режим разработчика).');
    } catch (e) {
      const cur = S.steps.find(s => s.status === 'running');
      if (cur) { cur.status = 'failed'; cur.detail = e.message.split('\n')[0]; renderSteps(); }
      say($('gh-msg'), `<span class="err">${esc(e.message).replace(/\n/g, '<br>')}</span>`);
    } finally {
      S.running = false; renderButtons();
    }
  }

  function showFilesProgress(job) {
    const ul = $('gh-files');
    if (!job.files || !job.files.length) return;
    const label = { pending: '○ ожидает', uploading: '… загружается', created: '✓ создан', updated: '✓ обновлён', unchanged: '✓ без изменений', failed: '✕ не загружен' };
    ul.innerHTML = job.files.map(f => `<li><code>${esc(f.path)}</code> — ${label[f.status] || esc(f.status)}</li>`).join('');
  }

  function reportFailure(job) {
    const e = job.error || {};
    const done = (job.files || []).filter(f => f.status === 'created' || f.status === 'updated' || f.status === 'unchanged');
    const todo = (job.files || []).filter(f => f.status !== 'created' && f.status !== 'updated' && f.status !== 'unchanged');
    let html = `<span class="err">${esc(e.message || 'Публикация не удалась.')}</span>`;
    if (job.files && job.files.length) {
      html += `<br>Загружено файлов: ${done.length} из ${job.files.length}.`;
      if (todo.length) html += ` Не загружены: ${todo.map(f => esc(f.path.split('/').pop())).join(', ')}.`;
      html += '<br>Нажмите «Повторить» — загруженные файлы не будут продублированы.';
    }
    if (e.uploaded) html += '<br><span class="warn">QR не показан: ссылка ещё не подтверждена.</span>';
    say($('gh-msg'), html);
  }

  // ───────── подключение ─────────
  async function refresh() {
    S.bridgeUp = null; renderStatus();
    try {
      const ping = await bridge('/github/ping');
      S.bridgeUp = true; S.keyValid = !!ping.keyValid; S.nodeVersion = ping.node;
    } catch (e) { S.bridgeUp = false; S.keyValid = false; S.status = null; renderStatus(); return; }
    if (S.keyValid) {
      try { S.status = await bridge('/github/status'); fillForm(); } catch (e) { S.status = null; }
    } else S.status = null;
    renderStatus();
  }

  async function connect() {
    const out = $('gh-connect-status');
    const tokenEl = $('gh-token');
    const token = tokenEl.value.trim();
    if (S.connecting) return;
    S.connecting = true; $('gh-connect').disabled = true;
    say(out, 'Проверяю доступ к репозиторию…');
    try {
      const body = {
        repoRef: $('gh-repo').value, branch: $('gh-branch').value, folder: $('gh-folder').value,
        naming: document.querySelector('input[name="gh-naming"]:checked').value, customSlug: $('gh-slug').value
      };
      if (token) body.token = token;
      const r = await bridge('/github/connect', { method: 'POST', body });
      say(out, `<span class="ok">Доступ подтверждён: ${esc(r.login)}, запись в ${esc(r.access.repo.fullName)} возможна.</span>` +
        (r.access.warnings || []).map(w => `<br><span class="warn">${esc(w)}</span>`).join('') +
        '<br><span class="zpk-note">Право записи GitHub до реальной загрузки не проверяет, поэтому нехватка прав может проявиться при первой публикации.</span>');
      clearQr(); S.job = null; S.lastBuild = null;
      S.status = await bridge('/github/status');
      renderStatus();
    } catch (e) {
      say(out, `<span class="err">${esc(e.message)}</span>`);
    } finally {
      tokenEl.value = ''; // токен не остаётся в поле
      S.connecting = false; renderButtons();
    }
  }

  async function disconnect() {
    if (!confirm('Отключить GitHub? Токен будет удалён с моста; файлы в репозитории останутся.')) return;
    try { await bridge('/github/disconnect', { method: 'POST', body: {} }); S.status = null; clearQr(); S.job = null; S.lastBuild = null; $('gh-repo').value = ''; say($('gh-connect-status'), 'GitHub отключён.'); }
    catch (e) { say($('gh-connect-status'), `<span class="err">${esc(e.message)}</span>`); }
    await refresh();
  }

  // ───────── события ─────────
  $('act-github-publish')?.addEventListener('click', async () => {
    if (typeof dlg.showModal === 'function') dlg.showModal(); else dlg.setAttribute('open', '');
    renderFiles(); checkStaleQr();
    await refresh();
  });
  $('gh-close').addEventListener('click', () => dlg.close());
  $('gh-key-save').addEventListener('click', async () => {
    S.key = $('gh-key').value.trim();
    try { localStorage.setItem(KEY_STORAGE, S.key); } catch (e) { /* не критично */ }
    $('gh-key').value = '';
    await refresh();
    if (!S.keyValid) say($('gh-bridge-status'), '<span class="err">Код не подошёл. Скопируйте его из окна моста целиком.</span>');
  });
  $('gh-connect').addEventListener('click', connect);
  $('gh-disconnect').addEventListener('click', disconnect);
  $('gh-publish').addEventListener('click', () => publish(false));
  $('gh-retry').addEventListener('click', () => publish(true));
  $('gh-cancel').addEventListener('click', async () => { try { if (S.job) await bridge('/github/cancel', { method: 'POST', body: { id: S.job.id } }); } catch (e) { /* уже завершено */ } });

  const download = (href, name) => { const a = document.createElement('a'); a.href = href; a.download = name; a.click(); };
  $('gh-open-repo').addEventListener('click', () => { if (S.qr) window.open(S.qr.folderUrl || S.qr.repoUrl, '_blank', 'noopener'); });
  $('gh-copy-url').addEventListener('click', async () => {
    if (!S.qr) return;
    try { await navigator.clipboard.writeText(S.qr.url); say($('gh-qr-warn'), '<span class="ok">Ссылка скопирована.</span>'); } catch (e) { say($('gh-qr-warn'), '<span class="warn">Не удалось скопировать — выделите ссылку вручную.</span>'); }
  });
  for (const id of ['gh-repo', 'gh-branch', 'gh-folder', 'gh-slug']) $(id).addEventListener('input', () => { if (S.qr) { clearQr(); say($('gh-msg'), '<span class="warn">Настройки изменены — QR сброшен. Сохраните настройки и опубликуйте снова.</span>'); } });
  document.querySelectorAll('input[name="gh-naming"]').forEach(r => r.addEventListener('change', renderFiles));
})();
