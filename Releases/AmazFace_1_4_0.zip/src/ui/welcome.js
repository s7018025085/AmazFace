// src/ui/welcome.js
//
// Стартовый экран + прямая работа с папкой проекта.
// Подключается ПОСЛЕ app.js и только подменяет обработчики кнопок
// «Новый / Сохранить / Открыть»; canvas, layers, inspector и экспортёры не тронуты.
// Если File System Access API недоступен (Firefox/Safari) — редактор работает
// по-старому (сохранение в .watchface.json), стартовый экран даёт войти «без папки».

(function () {
  const $ = (id) => document.getElementById(id);
  const screen = $('welcome-screen');
  const btnNew = $('welcome-new');
  const btnOpen = $('welcome-open');
  const btnBack = $('welcome-back');
  const btnSkip = $('welcome-skip');
  const note = $('welcome-note');
  const supported = FsProject.supported();

  /** @type {FsProject|null} */
  let fs = null;
  let lastSaved = '';
  let autosaveTimer = null;
  let autosaveInFlight = null;
  let fullSaveInFlight = null;

  // Манифест: какие файлы создали МЫ. Удаляем из папки только их — чужие файлы
  // пользователя (README, заметки, свои картинки) никогда не трогаются.
  //   files  — всё, что записала последняя полная сборка;
  //   assets — файлы ресурсов проекта (синхронизируются при каждом автосохранении).
  const MANIFEST = '.amazface-files.json';
  let manifest = { files: [], assets: [] };
  let assetSig = '';

  // Последняя папка запоминается (IndexedDB), чтобы открыть её одной кнопкой.
  const idb = (mode, fn) => new Promise((resolve) => {
    try {
      const req = indexedDB.open('amazface', 1);
      req.onupgradeneeded = () => req.result.createObjectStore('kv');
      req.onerror = () => resolve(null);
      req.onsuccess = () => {
        const tx = req.result.transaction('kv', mode);
        const r = fn(tx.objectStore('kv'));
        tx.oncomplete = () => resolve(r && r.result !== undefined ? r.result : null);
        tx.onerror = () => resolve(null);
      };
    } catch (e) { resolve(null); }
  });
  const rememberFolder = (handle) => idb('readwrite', (st) => st.put(handle, 'last'));
  const lastFolder = () => idb('readonly', (st) => st.get('last'));

  // ---- индикатор папки в верхней панели ----
  const badge = document.createElement('div');
  badge.id = 'fs-badge';
  badge.hidden = true;
  document.querySelector('.topbar .brand').after(badge);
  const setBadge = (state) => {
    if (!fs) { badge.hidden = true; return; }
    const label = { saved: '✓ сохранено', saving: '… сохранение', error: '⚠ ошибка записи' }[state] || '';
    badge.hidden = false;
    badge.dataset.state = state;
    badge.textContent = `📁 ${fs.name} · ${label}`;
    badge.title = 'Проект сохраняется прямо в эту папку. Ctrl+S — полное сохранение (с пересборкой файлов Zepp).';
  };

  // ---- уведомления ----
  function toast(text, kind = 'ok') {
    const el = document.createElement('div');
    el.className = `fs-toast ${kind}`;
    el.textContent = text;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), kind === 'ok' ? 3500 : 9000);
  }

  // ---- показ / скрытие стартового экрана ----
  async function showWelcome() {
    if (!(await flushProjectWrites())) throw new Error('Не удалось сохранить текущий проект. Исправьте ошибку записи перед переключением проекта.');
    screen.hidden = false;
    btnBack.hidden = !fs;
    btnSkip.hidden = !!fs;
    note.hidden = supported;
    if (!supported) {
      note.textContent = 'Этот браузер не поддерживает File System Access API (нужен Chrome, Edge или Opera). ' +
        'Можно продолжить без папки: проект будет сохраняться в файл .watchface.json, как раньше.';
    }
    btnNew.disabled = btnOpen.disabled = !supported;
    refreshLastButton();
  }
  const hideWelcome = () => { screen.hidden = true; };

  function enterEditor() {
    hideWelcome();
    lastSaved = store.toJSON();
    try { manifest = Object.assign({ files: [], assets: [] }, JSON.parse(fs.readText(MANIFEST) || '{}')); }
    catch (e) { manifest = { files: [], assets: [] }; }
    if (!fs.has(MANIFEST)) {
      // Папка сохранена прежней версией: файлы ресурсов проекта опознаём по именам экспортёра.
      try { manifest.assets = [...wantedAssetFiles().keys()].filter((path) => fs.has(path)); } catch (e) { /* без манифеста */ }
      manifest.files = [...manifest.assets];
    }
    assetSig = currentAssetSig();
    setBadge('saved');
    document.title = `${store.state.meta.name} — AmazFace`;
    rememberFolder(fs.root);
    setTimeout(repairIfNeeded, 0);
  }

  // Файлы, которые редактор создавал раньше, но в папке их уже нет (удалили вручную,
  // не доехали при синхронизации диска и т.п.): без них на часах пустое место.
  // Полное сохранение пересоздаёт всё из проекта.
  async function repairIfNeeded() {
    if (!fs) return;
    const missing = manifest.files.filter((path) => !fs.has(path));
    if (!missing.length) return;
    toast(`В папке не хватало файлов: ${missing.length}. Восстанавливаю из проекта…`, 'warn');
    await saveToFolder();
  }

  // ---- синхронизация ресурсов с папкой ----
  // Длина dataUrl не позволяет заметить замену изображения на другое того же
  // размера. Используем два независимых 32-битных хеша содержимого, чтобы
  // обнаруживать такие изменения без сохранения огромных строк в сигнатуре.
  function contentSignature(value) {
    const text = String(value || '');
    let h1 = 0x811c9dc5; // FNV-1a
    let h2 = 0x9e3779b9; // независимый rolling hash
    for (let i = 0; i < text.length; i++) {
      const c = text.charCodeAt(i);
      h1 ^= c;
      h1 = Math.imul(h1, 0x01000193) >>> 0;
      h2 = Math.imul(h2 ^ (c + i), 0x85ebca6b) >>> 0;
      h2 ^= h2 >>> 13;
    }
    return `${text.length}:${h1.toString(16)}:${h2.toString(16)}`;
  }
  const currentAssetSig = () => (store.state.assets || [])
    .map((a) => `${a.id}|${a.name}|${a.format}|${contentSignature(a.dataUrl)}`)
    .join(';');

  /** Путь в папке → ресурс, по правилам именования экспортёра. */
  function wantedAssetFiles() {
    const map = computeAssetFilenames(store.state);
    const dir = `assets/${store.state.device.targetKey}/`;
    return new Map((store.state.assets || []).map((a) => [dir + map[a.id], a]));
  }

  async function writeManifest() {
    await fs.write(MANIFEST, JSON.stringify(manifest, null, 2));
  }

  /**
   * Приводит файлы ресурсов в папке в соответствие с проектом: записывает
   * новые/изменённые, удаляет те, которые убрали или переименовали в редакторе.
   */
  async function syncAssets() {
    const sig = currentAssetSig();
    if (sig === assetSig) return;
    const want = wantedAssetFiles();
    for (const [path, a] of want) await fs.write(path, dataUrlToBytes(a.dataUrl));
    const gone = manifest.assets.filter((path) => !want.has(path));
    for (const path of gone) await fs.remove(path);
    manifest.assets = [...want.keys()];
    manifest.files = [...new Set([...manifest.files.filter((path) => !gone.includes(path)), ...manifest.assets])];
    await writeManifest();
    assetSig = sig;
  }

  // ---- запись ----
  async function writeState() {
    const json = store.toJSON();
    await fs.write(FS_STATE_FILE, json);
    lastSaved = json;
  }

  async function refreshPreview() {
    try {
      const st = store.state;
      st.preview = st.preview || {};
      st.preview.dataUrl = await buildPreviewDataUrl(st, 324);
      st.preview.width = 324;
      st.preview.height = 324;
      st.preview.handsTime = '10:10';
    } catch (e) { console.warn('Preview generation failed:', e); }
  }

  /** Полное сохранение: состояние редактора + пересборка файлов Zepp прямо в папку. */
  async function saveToFolder() {
    if (fullSaveInFlight) return fullSaveInFlight;
    fullSaveInFlight = saveToFolderNow();
    try { return await fullSaveInFlight; }
    finally { fullSaveInFlight = null; }
  }

  async function saveToFolderNow() {
    if (!(await flushAutosave())) {
      setBadge('error');
      toast('Не удалось сохранить текущие изменения перед пересборкой файлов.', 'err');
      return;
    }
    setBadge('saving');
    let saveState = 'saved';
    try {
      await withBusyOverlay('Сохраняю в папку…', 'Превью, состояние проекта и файлы циферблата', async () => {
        await refreshPreview();
        await writeState();
        if (!fs.has('app.json')) await fs.write('app.json', buildAppJson(store.state));
        try {
          const { blob, validation } = await exportFullProject(store.state);
          if (validation.errors.length) {
            runFullPreflight(true);
            toast(`Состояние сохранено, но файлы Zepp не обновлены: ${validation.errors.length} критических ошибок.`, 'warn');
            saveState = 'error';
            return;
          }
          // exportFullProject отдаёт ZIP в памяти — распаковываем его сразу в папку,
          // на диск архив не попадает.
          const entries = await readZipEntries(new Uint8Array(await blob.arrayBuffer()));
          for (const [path, bytes] of entries) await fs.write(path, bytes);
          // Проверяем по факту, что всё легло на диск: пропавший PNG = пустое место на часах.
          const lost = [];
          for (const path of entries.keys()) if (!(await fs.exists(path))) lost.push(path);
          if (lost.length) {
            toast(`Не удалось записать файлов: ${lost.length} (например, ${lost[0]}). Нажмите Ctrl+S ещё раз.`, 'err');
            saveState = 'error';
            return;
          }
          // Удаляем из assets/ то, что прошлая сборка создала, а эта — уже нет
          // (удалённые картинки и шрифты, переименованные ресурсы).
          let removed = 0;
          for (const path of manifest.files) {
            if (path.startsWith('assets/') && !entries.has(path) && await fs.remove(path)) removed++;
          }
          manifest = { files: [...entries.keys()], assets: [...wantedAssetFiles().keys()] };
          await writeManifest();
          assetSig = currentAssetSig();
          toast(`Сохранено в папку «${fs.name}»` + (removed ? ` · удалено устаревших файлов: ${removed}` : ''));
        } catch (err) {
          toast(`Состояние сохранено, но сборка файлов Zepp не удалась: ${err.message}`, 'warn');
          saveState = 'error';
        }
      });
      setBadge(saveState);
    } catch (err) {
      setBadge('error');
      toast(`Не удалось записать в папку: ${err.message}`, 'err');
    }
  }

  // ---- автосохранение: только amazface.project.json (без дорогой пересборки) ----
  function scheduleAutosave() {
    if (!fs) return;
    clearTimeout(autosaveTimer);
    autosaveTimer = setTimeout(runAutosave, 1500);
  }
  async function runAutosave() {
    autosaveTimer = null;
    if (autosaveInFlight) return autosaveInFlight;
    const target = fs;
    if (!target) return true;
    autosaveInFlight = (async () => {
      try {
        const dirty = store.toJSON() !== lastSaved;
        const assetsChanged = currentAssetSig() !== assetSig;
        if (!dirty && !assetsChanged) return true;
        setBadge('saving');
        if (assetsChanged) await syncAssets();
        if (dirty) await writeState();
        if (fs === target) setBadge('saved');
        return fs === target;
      } catch (err) {
        if (fs === target) setBadge('error');
        console.warn('Autosave failed:', err);
        return false;
      } finally {
        autosaveInFlight = null;
      }
    })();
    return autosaveInFlight;
  }
  async function flushAutosave() {
    if (autosaveTimer) { clearTimeout(autosaveTimer); autosaveTimer = null; }
    if (autosaveInFlight) await autosaveInFlight;
    return fs ? runAutosave() : true;
  }
  async function flushProjectWrites() {
    if (fullSaveInFlight) await fullSaveInFlight;
    const ok = await flushAutosave();
    if (fullSaveInFlight) await fullSaveInFlight;
    return ok;
  }
  store.subscribe(() => scheduleAutosave());
  document.addEventListener('visibilitychange', () => { if (document.hidden) void flushAutosave(); });

  // ---- открыть существующую папку ----
  async function openFolder(knownHandle) {
    const handle = knownHandle || await FsProject.pick();
    if (!(await flushProjectWrites())) throw new Error('Не удалось сохранить текущий проект. Новый проект не открыт.');
    const project = new FsProject(handle);
    await withBusyOverlay('Читаю папку…', handle.name, () => project.scan());

    if (!project.has('app.json')) {
      throw new Error('В выбранной папке нет app.json — это не проект Zepp OS. Выберите корень проекта или создайте новый.');
    }
    JSON.parse(project.readText('app.json')); // понятная ошибка, если конфиг повреждён

    await loadProject(project);
  }

  // Отсоединяем прежнюю папку до загрузки данных: импорт обычного Zepp-проекта
  // асинхронный, и его промежуточное состояние нельзя отправлять в старую папку.
  async function loadProject(project) {
    const previousFs = fs;
    const previousState = store.toJSON();
    fs = null;
    setBadge();
    try {
      if (project.has(FS_STATE_FILE)) {
        store.loadFromJSON(project.readText(FS_STATE_FILE));
      } else {
        await importPlainZeppProject(project);
      }
      fs = project;
      enterEditor();
    } catch (err) {
      // Не оставляем редактор в частично импортированном состоянии, если
      // чтение ресурсов новой папки прервалось.
      if (previousFs) {
        store.loadFromJSON(previousState);
        fs = previousFs;
        enterEditor();
      } else {
        fs = null;
        setBadge();
      }
      throw err;
    }
  }

  // Папка без состояния редактора (проект создан не в AmazFace): из app.json берём
  // имя/версию, из assets/ — картинки. Компоненты из index.js восстановить нельзя.
  async function importPlainZeppProject(project) {
    const app = JSON.parse(project.readText('app.json')).app || {};
    store.newProject();
    const st = store.state;
    if (app.appName) st.meta.name = app.appName;
    if (Number(app.appId)) st.app.appId = Number(app.appId);
    if (app.vender) st.app.vendor = app.vender;
    if (app.version?.name) st.app.versionName = app.version.name;
    if (Number(app.version?.code)) st.app.versionCode = Number(app.version.code);

    const skip = /(^|\/)(preview|icon)(_en)?\.png$|\/(weather|fonts)\//i;
    let count = 0;
    for (const [path, f] of project.files) {
      if (!/^assets\/.+\.(png|jpe?g)$/i.test(path) || skip.test(path) || !f.bytes) continue;
      const isPng = /\.png$/i.test(path);
      const blob = new Blob([f.bytes], { type: isPng ? 'image/png' : 'image/jpeg' });
      const bmp = await createImageBitmap(blob);
      const dataUrl = await new Promise((res, rej) => {
        const r = new FileReader();
        r.onload = () => res(r.result);
        r.onerror = () => rej(r.error);
        r.readAsDataURL(blob);
      });
      st.assets.push({
        id: makeAssetId(),
        name: path.split('/').pop().replace(/\.(png|jpe?g)$/i, ''),
        dataUrl, width: bmp.width, height: bmp.height,
        format: isPng ? 'PNG' : 'JPEG', size: f.size,
      });
      count++;
    }
    store.loadFromJSON(store.toJSON()); // сброс истории и перерисовка
    toast(`Файла ${FS_STATE_FILE} в папке нет: импортированы app.json и ресурсы (${count}). ` +
      'Компоненты из watchface/index.js восстановить нельзя — макет собирается заново.', 'warn');
  }

  // ---- создать новый проект ----
  async function createProject() {
    const handle = await FsProject.pick();
    if (!(await flushProjectWrites())) throw new Error('Не удалось сохранить текущий проект. Новый проект не создан.');
    const project = new FsProject(handle);
    await project.scan();

    if (project.has('app.json')) {
      if (!confirm('В этой папке уже есть app.json. Открыть её как существующий проект?\n\n«Отмена» — ничего не делать.')) return;
      // повторное чтение не нужно — папка уже просканирована
      await loadProject(project);
      return;
    }
    if (project.files.size && !confirm('Папка не пуста. Добавить в неё файлы нового проекта?\nФайлы с теми же именами будут перезаписаны.')) return;

    store.newProject();
    store.state.meta.name = handle.name;
    store.loadFromJSON(store.toJSON()); // чистая история с уже заданным именем
    fs = project;
    enterEditor();
    await saveToFolder(); // шаблон: app.json, app.js, package.json, watchface/, assets/…
  }

  // ---- обёртка: ошибки и отмена диалога ----
  async function guarded(fn) {
    try { await fn(); }
    catch (err) {
      if (err && err.name === 'AbortError') return; // пользователь закрыл диалог
      console.error(err);
      alert(err.message || String(err));
    }
  }

  // ---- «Продолжить последний проект» ----
  const btnLast = $('welcome-last');
  let lastHandle = null;
  async function refreshLastButton() {
    lastHandle = supported ? await lastFolder() : null;
    btnLast.hidden = !lastHandle;
    if (lastHandle) btnLast.querySelector('b').textContent = `Продолжить: ${lastHandle.name}`;
  }
  async function openLast() {
    // requestPermission допустим только внутри клика — мы как раз в нём.
    if (await lastHandle.requestPermission({ mode: 'readwrite' }) !== 'granted') {
      throw new Error('Доступ к папке не предоставлен. Нажмите «Открыть существующую папку» и выберите её заново.');
    }
    await openFolder(lastHandle);
  }

  // ---- кнопки стартового экрана ----
  btnNew.onclick = () => guarded(createProject);
  btnOpen.onclick = () => guarded(() => openFolder());
  btnLast.onclick = () => guarded(openLast);
  // Для src/ui/github-import.js: открыть уже записанную папку тем же механизмом, что «Открыть существующую».
  // Для src/project/archive-import.js: проект из архива уже загружен в store.
  // После выбора архива папка назначения выбирается и передаётся сюда.
  async function adoptImported(destinationHandle) {
    if (!supported) { fs = null; setBadge(); return; }
    try {
      const handle = destinationHandle || await FsProject.pick();
      const project = new FsProject(handle);
      await project.scan();
      if (project.files.size && !confirm(`В выбранной папке «${handle.name}» уже есть файлы. Записать сюда проект AmazFace?\nФайлы с теми же именами будут перезаписаны.`)) { fs = null; setBadge(); return; }
      hideWelcome();
      document.title = `${store.state.meta.name} — AmazFace`;
      fs = project;
      enterEditor();
      await saveToFolder();
      toast(`Проект сохранён в выбранную папку «${handle.name}».`, 'ok');
    } catch (err) {
      fs = null; setBadge();
      if (!err || err.name !== 'AbortError') toast(`Папку выбрать не удалось: ${err.message || err}`, 'warn');
    }
  }
  async function prepareForArchiveImport() {
    if (!(await flushProjectWrites())) throw new Error('Не удалось сохранить текущий проект. Импорт архива остановлен.');
    fs = null;
    setBadge();
  }
  window.AmazWelcome = { openFolder, toast, adoptImported, prepareForArchiveImport };

  // Сбой записи (например, закрыли доступ к папке): клик по бейджу — повторить.
  badge.onclick = () => guarded(async () => {
    if (badge.dataset.state !== 'error' || !fs) return;
    if (await fs.root.requestPermission({ mode: 'readwrite' }) !== 'granted') throw new Error('Доступ к папке не предоставлен.');
    await saveToFolder();
  });
  badge.style.cursor = 'pointer';

  // Не даём закрыть вкладку, пока изменения ещё не легли на диск.
  window.addEventListener('beforeunload', (e) => {
    if (fs && (autosaveTimer || badge.dataset.state === 'saving' || badge.dataset.state === 'error')) {
      e.preventDefault(); e.returnValue = '';
    }
  });
  btnBack.onclick = hideWelcome;
  btnSkip.onclick = () => { fs = null; setBadge(); hideWelcome(); };

  // ---- подмена кнопок верхней панели (только если API доступен) ----
  if (supported) {
    $('act-new').onclick = () => guarded(showWelcome);
    $('act-open').closest('label').addEventListener('click', (e) => {
      e.preventDefault(); // не открывать файловый диалог для .json
      guarded(openFolder);
    });
  }
  if (supported) {
    $('act-new').dataset.tip = 'Начать другой проект: откроется стартовый экран. Текущий проект уже сохранён в его папке.';
    $('act-save').dataset.tip = 'Сохранить (Ctrl+S): записывает проект прямо в выбранную папку — состояние редактора, app.json, watchface/index.js и ресурсы. Устаревшие файлы ресурсов удаляются. Изменения также сохраняются автоматически.';
    $('act-open').closest('label').dataset.tip = 'Открыть папку проекта: выберите папку с app.json.';
  }
  const legacySave = $('act-save').onclick; // скачивание .watchface.json — запасной путь
  $('act-save').onclick = (e) => (fs ? saveToFolder() : legacySave.call($('act-save'), e));
  window.addEventListener('keydown', (e) => {
    if (!((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's')) return;
    e.preventDefault(); // иначе браузер предложит сохранить страницу
    if (screen.hidden) $('act-save').click();
  });

  showWelcome();
})();
