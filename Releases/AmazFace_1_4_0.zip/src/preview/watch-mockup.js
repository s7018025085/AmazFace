// src/preview/watch-mockup.js
//
// Компоновщик «превью часов»: актуальный циферблат проекта вставляется в корпус
// пользователя (assets/mockup/watch-case.png — корпус и ремешок с прозрачным окном
// под экран). Корпус не перерисовывается: берётся именно это изображение.
//
// По умолчанию изображение ограничено 200 пикселями по длинной стороне.
// Для GitHub можно запросить полный размер исходного шаблона (769×1000).
// Ресурс шаблона грузится локально (data URL), без сети.

(function () {
  'use strict';

  const TEMPLATE_SRC = 'assets/mockup/watch-case-data.js';
  const MAX_EXPORT_SIZE = 200;
  let templatePromise = null;

  function loadScript(src) {
    return new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = src; s.onload = resolve;
      s.onerror = () => reject(new Error('Не найден шаблон корпуса: ' + src));
      document.head.appendChild(s);
    });
  }

  // Шаблон: { width, height, screen:{cx,cy,r}, image } — грузится один раз.
  function loadTemplate() {
    if (!templatePromise) {
      templatePromise = (async () => {
        if (!window.WATCH_CASE_TEMPLATE) await loadScript(TEMPLATE_SRC);
        const t = window.WATCH_CASE_TEMPLATE;
        if (!t || !t.dataUrl) throw new Error('Шаблон корпуса повреждён');
        const image = new Image();
        image.src = t.dataUrl;
        await image.decode();
        return { width: t.width, height: t.height, screen: t.screen, image };
      })().catch(e => { templatePromise = null; throw e; });
    }
    return templatePromise;
  }

  function makeCanvas(w, h) {
    const c = document.createElement('canvas');
    c.width = w; c.height = h;
    return c;
  }

  /**
   * Собирает мокап часов на прозрачном фоне.
   * Если передан проект, его циферблат помещается в круглое окно корпуса.
   * @returns {Promise<HTMLCanvasElement>} canvas в заданном размере, не больше исходника
   */
  async function buildWatchMockupCanvas(project, opts = {}) {
    const tpl = await loadTemplate();
    const { width: W, height: H, screen, image } = tpl;
    const requestedMaxSize = Number(opts.maxSize);
    const maxSize = Number.isFinite(requestedMaxSize) && requestedMaxSize > 0 ? requestedMaxSize : MAX_EXPORT_SIZE;
    const scale = Math.min(1, maxSize / Math.max(W, H));
    const outW = Math.max(1, Math.round(W * scale));
    const outH = Math.max(1, Math.round(H * scale));
    const out = makeCanvas(outW, outH);
    const ctx = out.getContext('2d');
    ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';

    if (project && window.WatchfacePreviewRenderer) {
      const face = makeCanvas(1, 1);
      const faceSize = Math.max(1, Math.ceil(screen.r * 2 * scale));
      await WatchfacePreviewRenderer.draw(project, face, {
        size: faceSize,
        previewMode: true,
        highQuality: true,
        transparentBackground: !!opts.transparent,
        bgFrameId: opts.bgFrameId || null   // кадр покадровой анимации фона (для GIF-превью)
      });

      const cx = screen.cx * scale, cy = screen.cy * scale, radius = screen.r * scale;
      ctx.save();
      ctx.beginPath();
      ctx.arc(cx, cy, radius, 0, Math.PI * 2);
      ctx.clip();
      ctx.drawImage(face, cx - radius, cy - radius, radius * 2, radius * 2);
      ctx.restore();
    }

    // PNG корпуса кладётся поверх циферблата: его окантовка и блики сохраняются.
    ctx.drawImage(image, 0, 0, outW, outH);
    return out;
  }

  function canvasToBlob(canvas) {
    return new Promise((resolve, reject) => canvas.toBlob(b => b ? resolve(b) : reject(new Error('Не удалось получить PNG')), 'image/png'));
  }

  window.WatchMockup = { buildWatchMockupCanvas, canvasToBlob, loadTemplate };
})();
