// src/exporter/gif-encoder.js
//
// Маленький кодировщик анимированного GIF89a без зависимостей: общая палитра
// (median cut по 15-битной гистограмме), прозрачность по порогу альфы, LZW,
// бесконечный цикл (NETSCAPE2.0). Нужен для превью-анимации циферблата на GitHub.
// Подключается и в браузере (глобальный GifEncoder), и в Node (require) — для тестов.
//
//   GifEncoder.encode(frames, { width, height, delayCs, loop })
//     frames   — массив Uint8ClampedArray/Uint8Array RGBA размера width*height*4
//     delayCs  — задержка кадра в сотых секунды (по умолчанию 8), можно массивом на кадр
//     loop     — 0 = бесконечно (по умолчанию), N = N повторов
//   Возвращает Uint8Array с готовым файлом.

(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module && module.exports) module.exports = api;
  else root.GifEncoder = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const ALPHA_CUTOFF = 128;

  // ---- палитра: median cut по гистограмме 5 бит на канал ----
  function buildPalette(frames, maxColors) {
    const hist = new Uint32Array(32768);
    let any = false;
    for (const f of frames) {
      // Достаточно каждого 2-го пикселя: палитра от этого почти не меняется, а работает вдвое быстрее.
      for (let i = 0; i < f.length; i += 8) {
        if (f[i + 3] < ALPHA_CUTOFF) continue;
        hist[((f[i] >> 3) << 10) | ((f[i + 1] >> 3) << 5) | (f[i + 2] >> 3)]++;
        any = true;
      }
    }
    if (!any) return [[0, 0, 0]];
    const bins = [];
    for (let i = 0; i < 32768; i++) if (hist[i]) bins.push(i);
    const chan = (bin, c) => (c === 0 ? bin >> 10 : c === 1 ? (bin >> 5) & 31 : bin & 31);

    function stats(box) {
      let min = [31, 31, 31], max = [0, 0, 0], total = 0;
      for (const b of box) {
        total += hist[b];
        for (let c = 0; c < 3; c++) { const v = chan(b, c); if (v < min[c]) min[c] = v; if (v > max[c]) max[c] = v; }
      }
      const range = [max[0] - min[0], max[1] - min[1], max[2] - min[2]];
      return { total, range, widest: range[0] >= range[1] && range[0] >= range[2] ? 0 : range[1] >= range[2] ? 1 : 2 };
    }

    let boxes = [bins];
    while (boxes.length < maxColors) {
      // делим самый «тяжёлый» бокс, в котором ещё есть что делить
      let bi = -1, best = -1;
      for (let i = 0; i < boxes.length; i++) {
        if (boxes[i].length < 2) continue;
        const s = stats(boxes[i]);
        const score = s.total * (1 + s.range[s.widest]);
        if (score > best) { best = score; bi = i; }
      }
      if (bi < 0) break;
      const box = boxes[bi], c = stats(box).widest;
      box.sort((a, b) => chan(a, c) - chan(b, c));
      const half = stats(box).total / 2;
      let acc = 0, cut = 1;
      for (let i = 0; i < box.length - 1; i++) { acc += hist[box[i]]; cut = i + 1; if (acc >= half) break; }
      boxes.splice(bi, 1, box.slice(0, cut), box.slice(cut));
    }
    return boxes.map((box) => {
      let r = 0, g = 0, b = 0, n = 0;
      for (const bin of box) { const w = hist[bin]; r += chan(bin, 0) * w; g += chan(bin, 1) * w; b += chan(bin, 2) * w; n += w; }
      const to8 = (v) => Math.min(255, Math.round((v / n) * 8 + 4));
      return [to8(r), to8(g), to8(b)];
    });
  }

  // ---- LZW (вариант GIF) ----
  function lzwEncode(pixels, minCode) {
    const clear = 1 << minCode, eoi = clear + 1;
    const out = [];
    let cur = 0, nbits = 0;
    const emit = (code, size) => {
      cur |= code << nbits; nbits += size;
      while (nbits >= 8) { out.push(cur & 255); cur >>>= 8; nbits -= 8; }
    };
    let size = minCode + 1, next = eoi + 1;
    let dict = new Map();
    emit(clear, size);
    let prefix = pixels[0];
    for (let i = 1; i < pixels.length; i++) {
      const k = pixels[i], key = prefix * 256 + k;
      const v = dict.get(key);
      if (v !== undefined) { prefix = v; continue; }
      emit(prefix, size);
      if (next < 4096) {
        dict.set(key, next);
        if (next >= (1 << size) && size < 12) size++;
        next++;
      } else {
        emit(clear, size);
        dict = new Map(); size = minCode + 1; next = eoi + 1;
      }
      prefix = k;
    }
    emit(prefix, size);
    emit(eoi, size);
    if (nbits > 0) out.push(cur & 255);
    return out;
  }

  function encode(frames, o) {
    o = o || {};
    const W = o.width | 0, H = o.height | 0;
    if (!frames || !frames.length) throw new Error('GIF: нет кадров.');
    if (W < 1 || H < 1 || W > 65535 || H > 65535) throw new Error('GIF: неверный размер кадра.');
    for (const f of frames) if (!f || f.length !== W * H * 4) throw new Error('GIF: размер кадра не совпадает с width×height.');

    // Прозрачный пиксель есть хотя бы в одном кадре? Тогда индекс 0 палитры — прозрачный.
    let hasAlpha = false;
    scan: for (const f of frames) for (let i = 3; i < f.length; i += 4) if (f[i] < ALPHA_CUTOFF) { hasAlpha = true; break scan; }
    const reserve = hasAlpha ? 1 : 0;
    const colors = buildPalette(frames, 256 - reserve);
    const palette = hasAlpha ? [[0, 0, 0]].concat(colors) : colors;

    let bitsPerPixel = 1;
    while ((1 << bitsPerPixel) < palette.length) bitsPerPixel++;
    const tableSize = 1 << bitsPerPixel;
    const minCode = Math.max(2, bitsPerPixel);

    // ближайший цвет, кэш по 15-битному ключу
    const cache = new Int16Array(32768).fill(-1);
    function nearest(r, g, b) {
      const key = ((r >> 3) << 10) | ((g >> 3) << 5) | (b >> 3);
      const hit = cache[key];
      if (hit >= 0) return hit;
      const rr = (r & 0xF8) | 4, gg = (g & 0xF8) | 4, bb = (b & 0xF8) | 4;
      let best = reserve, bd = Infinity;
      for (let i = reserve; i < palette.length; i++) {
        const dr = palette[i][0] - rr, dg = palette[i][1] - gg, db = palette[i][2] - bb;
        const d = dr * dr * 3 + dg * dg * 4 + db * db * 2;
        if (d < bd) { bd = d; best = i; }
      }
      cache[key] = best;
      return best;
    }

    const bytes = [];
    const u16 = (v) => { bytes.push(v & 255, (v >> 8) & 255); };
    const str = (s) => { for (let i = 0; i < s.length; i++) bytes.push(s.charCodeAt(i)); };

    str('GIF89a');
    u16(W); u16(H);
    bytes.push(0x80 | 0x70 | (bitsPerPixel - 1), 0, 0);   // глобальная палитра, фон = индекс 0
    for (let i = 0; i < tableSize; i++) { const c = palette[i] || [0, 0, 0]; bytes.push(c[0], c[1], c[2]); }
    const loop = o.loop == null ? 0 : Math.max(0, Math.min(65535, o.loop | 0));
    bytes.push(0x21, 0xFF, 11); str('NETSCAPE2.0'); bytes.push(3, 1); u16(loop); bytes.push(0);

    frames.forEach((f, n) => {
      const delay = Math.max(2, Math.round(Array.isArray(o.delayCs) ? o.delayCs[n] : (o.delayCs == null ? 8 : o.delayCs)));
      // disposal 2 («восстановить фон»): прозрачные области не копятся от кадра к кадру
      bytes.push(0x21, 0xF9, 4, (hasAlpha ? 2 << 2 : 0) | (hasAlpha ? 1 : 0)); u16(delay); bytes.push(0, 0);
      bytes.push(0x2C); u16(0); u16(0); u16(W); u16(H); bytes.push(0);
      const idx = new Uint8Array(W * H);
      for (let p = 0, i = 0; p < idx.length; p++, i += 4) {
        idx[p] = (hasAlpha && f[i + 3] < ALPHA_CUTOFF) ? 0 : nearest(f[i], f[i + 1], f[i + 2]);
      }
      bytes.push(minCode);
      const data = lzwEncode(idx, minCode);
      for (let i = 0; i < data.length; i += 255) {
        const n2 = Math.min(255, data.length - i);
        bytes.push(n2);
        for (let j = 0; j < n2; j++) bytes.push(data[i + j]);
      }
      bytes.push(0);
    });
    bytes.push(0x3B);
    return Uint8Array.from(bytes);
  }

  return { encode, buildPalette, lzwEncode };
});
