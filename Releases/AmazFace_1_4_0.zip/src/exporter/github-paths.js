// src/exporter/github-paths.js
//
// Общая чистая логика GitHub Publishing: проверка owner/repo/ветки/папки,
// построение путей файлов в репозитории, публичных URL и README.md.
// Файл подключается и в браузере (глобальный объект AmazGh), и в локальном
// мосте (require). Здесь НЕТ сети, токенов и работы с DOM — только строки.
//
// Все пути в репозитории строит именно этот модуль, из проверенных частей.
// Мост берёт repo/branch/folder из своих сохранённых настроек, а не из
// запроса браузера, поэтому запрос не может перенаправить запись «в другое место».

(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module && module.exports) module.exports = api;
  else root.AmazGh = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const OWNER_RE = /^[A-Za-z0-9](?:[A-Za-z0-9-]{0,38})$/;
  const REPO_RE = /^[A-Za-z0-9._-]{1,100}$/;
  const SEGMENT_RE = /^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/;
  const SLUG_RE = /^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$/;

  const MARKER_NAME = 'amazface-publish.json';
  const KINDS = ['zpk', 'deviceZip', 'projectZip', 'json'];

  function fail(msg) { throw new Error(msg); }

  function validateOwner(owner) {
    const v = String(owner || '').trim();
    if (!OWNER_RE.test(v)) fail('Имя владельца репозитория указано неверно (латиница, цифры и дефис, например: ivanov).');
    return v;
  }

  function validateRepo(repo) {
    const v = String(repo || '').trim();
    if (!REPO_RE.test(v) || v === '.' || v === '..' || /\.git$/i.test(v)) fail('Название репозитория указано неверно (латиница, цифры, точка, дефис, подчёркивание; без «.git»).');
    return v;
  }

  // Принимает "owner/repo", а также ссылку https://github.com/owner/repo(.git)
  function parseRepoRef(text) {
    let t = String(text || '').trim();
    t = t.replace(/^https?:\/\/github\.com\//i, '').replace(/\.git$/i, '').replace(/\/+$/, '');
    const parts = t.split('/');
    if (parts.length !== 2) fail('Укажите репозиторий в виде «владелец/репозиторий».');
    return { owner: validateOwner(parts[0]), repo: validateRepo(parts[1]) };
  }

  function validateBranch(branch) {
    const v = String(branch || '').trim() || 'main';
    if (v.length > 200 || !/^[A-Za-z0-9._\/-]+$/.test(v) || v.includes('..') || v.includes('//') ||
        v.startsWith('/') || v.endsWith('/') || v.startsWith('-') || v.endsWith('.lock') || v.endsWith('.')) {
      fail('Имя ветки указано неверно.');
    }
    return v;
  }

  // '' допустимо (корень репозитория). Разделитель — только "/".
  function normalizeFolder(folder) {
    const raw = String(folder == null ? '' : folder).trim();
    if (raw.includes('\\')) fail('В пути папки используйте «/», а не «\\».');
    const segs = raw.split('/').filter(s => s.length);
    if (segs.length > 8) fail('Слишком длинный путь папки публикации.');
    for (const s of segs) {
      if (s === '.' || s === '..' || s.toLowerCase() === '.git' || !SEGMENT_RE.test(s)) {
        fail(`Недопустимая часть пути «${s}». Разрешены латиница, цифры, «.», «-», «_»; путь не должен начинаться с точки.`);
      }
    }
    return segs.join('/');
  }

  // Имя папки и файлов циферблата. Не транслитерирует (это делает latinSlug
  // в браузере) — только гарантирует безопасный ASCII-вид.
  function normalizeSlug(input, fallback) {
    let s = String(input == null ? '' : input).replace(/[^A-Za-z0-9_-]+/g, '_').replace(/_+/g, '_').replace(/^[_-]+|[_-]+$/g, '').slice(0, 64);
    if (!s) s = fallback || '';
    if (!SLUG_RE.test(s)) fail('Не удалось получить безопасное имя циферблата для файлов.');
    return s;
  }

  function fileNames(slug) {
    const s = normalizeSlug(slug);
    return {
      zpk: `${s}.zpk`,
      deviceZip: 'device.zip',
      projectZip: 'project.zip',
      json: `${s}.watchface.json`,
      watch: `${s}-watch.png`,
      watch200: `${s}-watch-200.png`,
      watchQr: `${s}-watch-qr.png`,
      watchGif: `${s}-watch.gif`,
      readme: 'README.md',
      marker: MARKER_NAME
    };
  }

  /**
   * @param {{folder:string, slug:string}} p
   * @returns {{dir:string, files:Object<string,string>}} пути внутри репозитория
   */
  function targetPaths(p) {
    const folder = normalizeFolder(p.folder);
    const slug = normalizeSlug(p.slug);
    const dir = (folder ? folder + '/' : '') + slug;
    const names = fileNames(slug);
    const files = {};
    for (const k of Object.keys(names)) files[k] = dir + '/' + names[k];
    return { dir, files };
  }

  const encodePath = (p) => String(p).split('/').map(encodeURIComponent).join('/');

  function rawUrl(o) {
    return `https://raw.githubusercontent.com/${validateOwner(o.owner)}/${validateRepo(o.repo)}/${encodePath(validateBranch(o.branch))}/${encodePath(o.path)}`;
  }
  function repoUrl(o) {
    return `https://github.com/${validateOwner(o.owner)}/${validateRepo(o.repo)}`;
  }
  function treeUrl(o) {
    return `${repoUrl(o)}/tree/${encodePath(validateBranch(o.branch))}/${encodePath(o.path)}`;
  }

  function buildReadme(o) {
    const lines = [];
    lines.push(`# ${o.name}`);
    lines.push('');
    lines.push('Циферблат для Amazfit Balance 2 (Zepp OS), создан в редакторе AmazFace.');
    lines.push('');
    // Относительный путь: GitHub показывает картинку в README, лежащем в той же папке.
    if (o.watchGifName) { lines.push(`![Анимация циферблата](${o.watchGifName})`); lines.push(''); }
    if (o.watchQrName) { lines.push(`![Часы с циферблатом и QR-кодом для установки](${o.watchQrName})`); lines.push(''); }
    lines.push(`- **Версия:** ${o.version}`);
    lines.push(`- **Опубликовано:** ${o.publishedAt}`);
    lines.push(`- **Установочный пакет:** [${o.zpkName}](${o.zpkUrl})`);
    lines.push(`- **Ссылка для QR (zpkd1://):** \`${o.deepLink}\``);
    lines.push('');
    lines.push('## Установка');
    lines.push('');
    lines.push('1. Включите режим разработчика в Zepp App: Профиль → Настройки → О программе → семь раз нажмите на значок Zepp.');
    lines.push('2. Профиль → ваши часы → «Режим разработчика» → «Сканировать» (часы должны быть подключены).');
    lines.push('3. Отсканируйте QR-код циферблата. Ссылка на пакет постоянная: при обновлении циферблата тот же QR ставит актуальную версию (GitHub CDN может отдавать прежнюю версию до 5 минут).');
    lines.push('');
    lines.push('## Файлы');
    lines.push('');
    lines.push(`- \`${o.zpkName}\` — установочный пакет`);
    lines.push('- `device.zip` — содержимое для устройства (то же, что внутри пакета)');
    lines.push('- `project.zip` — полный проект Zepp OS');
    if (o.watchName) lines.push(`- \`${o.watchName}\` — мокап часов в полном качестве`);
    if (o.watch200Name) lines.push(`- \`${o.watch200Name}\` — мокап часов высотой 200 px`);
    if (o.watchQrName) lines.push(`- \`${o.watchQrName}\` — мокап часов с циферблатом и QR-кодом`);
    if (o.watchGifName) lines.push(`- \`${o.watchGifName}\` — анимированное превью циферблата (GIF)`);
    lines.push(`- \`${o.jsonName}\` — исходник циферблата для редактора AmazFace («Открыть»)`);
    lines.push(`- \`${MARKER_NAME}\` — служебный файл AmazFace: защищает папку от случайной перезаписи другим проектом`);
    lines.push('');
    return lines.join('\n');
  }

  return {
    MARKER_NAME, KINDS,
    validateOwner, validateRepo, parseRepoRef, validateBranch, normalizeFolder,
    normalizeSlug, fileNames, targetPaths, rawUrl, repoUrl, treeUrl, buildReadme, encodePath
  };
});
