// src/project/github-import.js
//
// Логика импорта проекта из GitHub, не зависящая от DOM и сети: проверки путей и
// состояния, сборка набора файлов в памяти и безопасная запись в папку через
// File System Access API (в тестах подменяется поддельной файловой системой).
// Подключается и в браузере (глобальный объект AmazImport), и в тестах (require).
//
// Принципы:
//   - Сначала ВСЁ скачивается и проверяется в памяти — на диск до этого ничего не пишется.
//   - Новая папка: пишем сразу; при сбое созданная папка удаляется целиком.
//   - Замена существующей: сначала полная копия во временную папку рядом, и только
//     потом старая папка заменяется. Без явного replace:true существующее не трогаем.
//   - Ничего не публикуем и не собираем: только записываем скачанные файлы.

(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module && module.exports) module.exports = api;
  else root.AmazImport = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const STATE_NAME = 'amazface.project.json'; // то же имя, что FS_STATE_FILE в fs-project.js
  const TMP_MARK = '.amazface-import-tmp-';

  class ImportError extends Error {
    constructor(message, code, extra) { super(message); this.name = 'ImportError'; this.code = code || 'import'; Object.assign(this, extra || {}); }
  }

  // ---- пути ----
  /** Относительный путь внутри проекта: «/», без «..», «.», обратных слэшей, диска и «.git». */
  function validateRelPath(path) {
    if (typeof path !== 'string' || !path.trim()) throw new ImportError('Пустой путь файла.', 'bad_path');
    if (path.includes('\\') || path.startsWith('/') || /^[a-zA-Z]:/.test(path) || /[\u0000-\u001f]/.test(path)) {
      throw new ImportError(`Недопустимый путь файла: ${path}`, 'bad_path');
    }
    const parts = path.split('/');
    if (parts.some((p) => !p || p === '.' || p === '..' || p.toLowerCase() === '.git')) {
      throw new ImportError(`Недопустимый путь файла: ${path}`, 'bad_path');
    }
    return parts;
  }

  const RESERVED = /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(\..*)?$/i;
  /** Безопасное имя локальной папки (Windows/macOS/Linux). */
  function safeFolderName(name, fallback) {
    let s = String(name == null ? '' : name).replace(/[<>:"/\\|?*\u0000-\u001f]+/g, '_').replace(/\s+/g, ' ').trim();
    s = s.replace(/[. ]+$/g, '').replace(/^\.+/, '').slice(0, 80).trim();
    if (!s || RESERVED.test(s)) s = s ? '_' + s : '';
    return s || fallback || 'amazface-project';
  }

  // ---- состояние редактора ----
  function sceneComponents(obj) {
    const n = obj.scenes && obj.scenes.normal;
    return n && Array.isArray(n.components) ? n.components : (Array.isArray(obj.components) ? obj.components : []);
  }
  /** Разбирает .watchface.json. Не меняет формат: проверяет только то, что нужно загрузчику. */
  function inspectState(text) {
    let obj;
    try { obj = JSON.parse(text); } catch (e) { return { ok: false, error: 'Файл состояния повреждён: это не корректный JSON.' }; }
    if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return { ok: false, error: 'Файл состояния повреждён: ожидался объект проекта.' };
    const hasScenes = obj.scenes && typeof obj.scenes === 'object' && obj.scenes.normal && Array.isArray(obj.scenes.normal.components);
    if (!Array.isArray(obj.components) && !hasScenes) return { ok: false, error: 'Файл не похож на состояние редактора AmazFace (нет списка компонентов).' };
    return {
      ok: true,
      name: obj.meta && typeof obj.meta.name === 'string' ? obj.meta.name.trim() : '',
      componentCount: sceneComponents(obj).length,
      assetCount: Array.isArray(obj.assets) ? obj.assets.length : 0
    };
  }

  const aborted = (signal) => { if (signal && signal.aborted) { const e = new Error('Операция отменена.'); e.name = 'AbortError'; throw e; } };

  /**
   * Скачивает и проверяет проект целиком в памяти.
   * @param {object} o
   * @param {() => Promise<{files:{path,size,role}[]}>} o.fetchManifest
   * @param {(path:string) => Promise<Uint8Array>} o.fetchFile
   * @param {(bytes:Uint8Array) => Promise<Map<string,Uint8Array>>} o.unzip  readZipEntries
   * @param {(stateText:string) => string} [o.makeAppJson]  если в проекте нет app.json
   * @param {(done:number,total:number,path:string) => void} [o.onProgress]
   * @param {AbortSignal} [o.signal]
   */
  async function stageImport(o) {
    const manifest = await o.fetchManifest();
    const list = (manifest && Array.isArray(manifest.files)) ? manifest.files : [];
    const stateEntry = list.find((f) => f.role === 'state');
    if (!stateEntry) throw new ImportError('В папке нет файла .watchface.json — это не проект AmazFace.', 'no_state');
    for (const f of list) validateRelPath(f.path);

    const total = list.length;
    let done = 0;
    const progress = (p) => { done++; if (o.onProgress) o.onProgress(done, total, p); };
    const enc = new TextEncoder();

    // 1) состояние — главный источник; проверяем до скачивания остального
    aborted(o.signal);
    const stateBytes = await o.fetchFile(stateEntry.path);
    const stateText = new TextDecoder().decode(stateBytes);
    const info = inspectState(stateText);
    if (!info.ok) throw new ImportError(info.error, 'bad_state');
    progress(stateEntry.path);

    // 2) остальное
    const fromRepo = new Map(), fromZip = new Map();
    for (const f of list) {
      if (f === stateEntry) continue;
      aborted(o.signal);
      const bytes = await o.fetchFile(f.path);
      if (f.role === 'project-zip') {
        let entries;
        try { entries = await o.unzip(bytes); }
        catch (e) { throw new ImportError(`project.zip повреждён: ${e && e.message || e}`, 'bad_zip'); }
        for (const [p, data] of entries) {
          if (p.endsWith('/')) continue;
          const parts = p.split('/');
          if (parts.some((s) => s.toLowerCase() === '.git')) continue; // .git никогда не попадает в папку
          validateRelPath(p);                                          // защита от «../» в архиве
          fromZip.set(p, data);
        }
      } else {
        fromRepo.set(f.path, bytes);
      }
      progress(f.path);
    }

    // 3) итоговый набор: файлы Zepp из архива < отдельные файлы папки < состояние редактора
    const files = new Map([...fromZip, ...fromRepo]);
    files.set(STATE_NAME, stateBytes);
    if (!files.has('app.json')) {
      if (typeof o.makeAppJson !== 'function') throw new ImportError('В проекте нет app.json (и project.zip с ним) — это не проект Zepp OS.', 'no_app_json');
      files.set('app.json', enc.encode(o.makeAppJson(stateText)));
    }
    try { JSON.parse(new TextDecoder().decode(files.get('app.json'))); }
    catch (e) { throw new ImportError('app.json в проекте повреждён.', 'bad_app_json'); }

    let bytes = 0;
    for (const v of files.values()) bytes += v.length;
    return {
      files, stateText,
      info: { name: info.name, componentCount: info.componentCount, assetCount: info.assetCount },
      stats: { files: files.size, bytes, zipEntries: fromZip.size }
    };
  }

  // ---- запись в папку (File System Access API) ----
  const isNotFound = (e) => e && (e.name === 'NotFoundError');

  async function getDirIfExists(parent, name) {
    try { return await parent.getDirectoryHandle(name); }
    catch (e) {
      if (isNotFound(e)) return null;
      if (e && e.name === 'TypeMismatchError') throw new ImportError(`«${name}» — это файл, а не папка.`, 'exists_as_file');
      throw e;
    }
  }
  /** true, если в parent уже есть папка (или файл) с таким именем. Ничего не создаёт. */
  async function destinationExists(parent, name) {
    try { await parent.getDirectoryHandle(name); return true; }
    catch (e) {
      if (isNotFound(e)) return false;
      if (e && e.name === 'TypeMismatchError') return true;
      throw e;
    }
  }

  async function writeTree(dir, files) {
    for (const [path, data] of files) {
      const parts = validateRelPath(path).slice();
      const name = parts.pop();
      let d = dir;
      for (const p of parts) d = await d.getDirectoryHandle(p, { create: true });
      const fh = await d.getFileHandle(name, { create: true });
      const w = await fh.createWritable();
      try { await w.write(data); } finally { await w.close(); }
    }
  }
  async function verifyTree(dir, files) {
    for (const [path, data] of files) {
      const parts = path.split('/'); const name = parts.pop();
      let d = dir;
      for (const p of parts) d = await d.getDirectoryHandle(p);
      const file = await (await d.getFileHandle(name)).getFile();
      if (file.size !== data.length) throw new ImportError(`Файл «${path}» записан не полностью.`, 'verify');
    }
  }
  const quietRemove = async (parent, name) => { try { await parent.removeEntry(name, { recursive: true }); } catch (e) { /* уже нет */ } };

  /**
   * Записывает проект в parent/name.
   * Без replace:true существующая папка не затрагивается (ошибка 'exists').
   * @returns {Promise<FileSystemDirectoryHandle>} папка проекта
   */
  async function commitImport({ parent, name, files, replace }) {
    const existing = await getDirIfExists(parent, name);
    if (existing && replace !== true) throw new ImportError(`Папка «${name}» уже существует.`, 'exists');

    if (!existing) {
      const dir = await parent.getDirectoryHandle(name, { create: true });
      try { await writeTree(dir, files); await verifyTree(dir, files); }
      catch (e) { await quietRemove(parent, name); throw e; } // не оставляем частичную папку
      return dir;
    }

    // Замена: сначала полная проверяемая копия рядом; старое не тронуто, пока она не готова.
    const tmpName = name + TMP_MARK + Date.now().toString(36);
    const tmp = await parent.getDirectoryHandle(tmpName, { create: true });
    try { await writeTree(tmp, files); await verifyTree(tmp, files); }
    catch (e) { await quietRemove(parent, tmpName); throw e; }

    await parent.removeEntry(name, { recursive: true });
    const dir = await parent.getDirectoryHandle(name, { create: true });
    try { await writeTree(dir, files); await verifyTree(dir, files); }
    catch (e) {
      // Старая папка уже удалена, но полная новая копия сохранена рядом — ничего не потеряно.
      throw new ImportError(`Не удалось завершить замену: ${e && e.message || e}. Готовая копия проекта осталась в папке «${tmpName}».`, 'swap_failed', { tmpName });
    }
    await quietRemove(parent, tmpName);
    return dir;
  }

  return { STATE_NAME, TMP_MARK, ImportError, validateRelPath, safeFolderName, inspectState, stageImport, destinationExists, commitImport };
});
