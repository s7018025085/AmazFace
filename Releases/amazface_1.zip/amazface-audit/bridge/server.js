'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const {spawn, execFileSync} = require('child_process');
const {createPromptHandler} = require('./prompt-handler');
const {createGithubRoutes} = require('./github-routes');
const {createZeusBuilder} = require('./zeus-build');
const INSTALL_TIMEOUT_MS = 5*60*1000;
let promptHandler = null; let installTimer = null; let requestedDevice = '';

const PORT = 17865;
const DEBUG_LOG = path.join(__dirname, 'bridge-debug.log');
function debug(message, data){const line=`[${new Date().toISOString()}] ${message}${data===undefined?'':' '+(typeof data==='string'?data:JSON.stringify(data))}`;console.log(line);try{fs.appendFileSync(DEBUG_LOG,line+'\r\n','utf8');}catch(e){console.error('Cannot write debug log:',e.message);}}
let child = null;
// GitHub Publishing: отдельные маршруты /github/* со своей защитой (см. github-routes.js).
// Пакет для GitHub собирается через `zeus build` (байткод), как и при установке через Bridge.
const githubRoutes = createGithubRoutes({log:m=>debug('GITHUB '+m),publisherOptions:{zeusBuild:createZeusBuilder({log:m=>debug('ZEUS BUILD '+m)}).build}});
let state = {running:false, mode:null, log:'', startedAt:null, projectDir:null, connected:false, connectRequested:false, installRequested:false, installFinished:false, installSucceeded:false, installPhase:'idle', autoAnswers:[]};
function cors(res){res.setHeader('Access-Control-Allow-Origin','*');res.setHeader('Access-Control-Allow-Methods','GET,POST,OPTIONS');res.setHeader('Access-Control-Allow-Headers','Content-Type,X-Project-Name,X-Device-Name');res.setHeader('Access-Control-Allow-Private-Network','true');}
function json(res,code,obj){cors(res);res.writeHead(code,{'Content-Type':'application/json; charset=utf-8'});res.end(JSON.stringify(obj));}
function addLog(s){
  const raw=String(s); debug('ZEUS OUTPUT',raw); const chunk=raw.replace(/\x1b\[[0-9;?]*[ -\/]*[@-~]/g,'').replace(/\r(?!\n)/g,''); state.log+=chunk; if(state.log.length>50000)state.log=state.log.slice(-50000);
  if(state.mode!=='bridge')return;
  if(/No connectable online App or Simulator/i.test(chunk)){state.connectRequested=false;state.connected=false;state.log+='\n[AmazFace] Zeus не нашёл подключённое приложение. На телефоне: Zepp App → Профиль → Режим разработчика → «+» → Bridge, затем снова нажмите Connect.\n';}
  // Zeus CLI messages vary a little between versions. Only mark connected when
  // the output describes an established connection, not merely a command prompt.
  if(/(connected successfully|successfully connected|connection established|connection successful|connected to (device|runtime|app|watch|environment)|status\s*[:=]\s*connected|已连接|连接成功)/i.test(chunk)) state.connected=true;
  if(state.installRequested && !state.installFinished){
    if(/building\.\.\./i.test(chunk))state.installPhase='building';
    else if(/Which device would you like/i.test(chunk))state.installPhase='device-prompt';
    else if(/(installing|uploading|pushing|transferring|sending)/i.test(chunk))state.installPhase='installing';
  }
  if(state.installRequested && /(install(?:ation)? (?:completed|succeeded|successful)|installed successfully|install success|安装成功|安装完成)/i.test(chunk)) {state.installFinished=true;state.installSucceeded=true;state.installPhase='done';clearTimeout(installTimer);}
  if(state.installRequested && /(install failed|installation failed|build failed|error:|安装失败|构建失败)/i.test(chunk)) {state.installFinished=true;state.installSucceeded=false;state.installPhase='failed';clearTimeout(installTimer);}
}
function findZeus(){try{const out=execFileSync('cmd.exe',['/d','/c','where zeus'],{encoding:'utf8',windowsHide:true}).trim();const all=out.split(/\r?\n/).map(s=>s.trim()).filter(Boolean);return all.find(x=>/\.(cmd|exe|bat)$/i.test(x))||all[0]||null;}catch{return null;}}
function kill(){if(!child){state.running=false;return;}try{spawn('taskkill',['/pid',String(child.pid),'/t','/f'],{windowsHide:true});}catch(e){}child=null;state.running=false;}
function launchZeus(dir,mode){
  debug('launchZeus requested',{dir,mode,previousState:state});
  kill(); const zeus=findZeus();
  debug('Zeus CLI lookup',{zeus,PATH:process.env.PATH});
  if(!zeus)throw new Error('Команда zeus не найдена в PATH. Установите Zeus CLI и перезапустите Bridge.');
  state={running:true,mode,log:'',startedAt:new Date().toISOString(),projectDir:dir,connected:false,connectRequested:false,installRequested:false,installFinished:false,installSucceeded:false,installPhase:'idle',autoAnswers:[]};
  clearTimeout(installTimer); installTimer=null;
  const subcommand=mode==='bridge'?'bridge':'preview';
  addLog(`$ "${zeus}" ${subcommand}\n$ cwd: ${dir}\n\n`);
  const command=`""${zeus}" ${subcommand}"`;
  debug('Spawning Zeus CLI',{command,cwd:dir,platform:process.platform,node:process.version});
  child=spawn('cmd.exe',['/d','/s','/c',command],{cwd:dir,windowsHide:false,windowsVerbatimArguments:true,stdio:['pipe','pipe','pipe']});
  debug('Zeus child process spawned',{pid:child.pid});
  const handler=createPromptHandler({
    write:k=>{if(!child||!child.stdin||child.stdin.destroyed)throw new Error('stdin Zeus закрыт');child.stdin.write(k);},
    log:m=>{debug('AUTO-ANSWER',m.trim());state.log+=m;},
    onAnswer:a=>{state.autoAnswers.push({at:new Date().toISOString(),...a});if(state.installRequested&&!state.installFinished)state.installPhase='installing';}
  });
  handler.setDevice(requestedDevice);
  promptHandler=handler;
  child.stdout.on('data',d=>{const chunk=d.toString();addLog(chunk);handler.feed(chunk);});
  child.stderr.on('data',d=>{const c=d.toString();addLog(c);handler.feed(c);});
  child.on('error',e=>{debug('CHILD PROCESS ERROR',{message:e.message,stack:e.stack});addLog(`\n[process error] ${e.message}\n`);state.running=false;child=null;handler.reset();});
  child.on('exit',(code,signal)=>{debug('CHILD PROCESS EXIT',{code,signal,pid:child?.pid});addLog(`\n[zeus exited] code=${code} signal=${signal||''}\n`);state.running=false;child=null;handler.reset();clearTimeout(installTimer);if(state.installRequested&&!state.installFinished){state.installFinished=true;state.installSucceeded=false;state.installPhase='failed';}});
  return {zeus,projectDir:dir};
}
function body(req){return new Promise((resolve,reject)=>{const a=[];req.on('data',c=>a.push(c));req.on('end',()=>resolve(Buffer.concat(a)));req.on('error',reject);});}
async function unpackProject(req){
  debug('unpackProject: request body started');
  const zip=await body(req);debug('unpackProject: request body received',{bytes:zip.length,contentType:req.headers['content-type'],projectName:req.headers['x-project-name']});if(!zip.length)throw new Error('Пустой ZIP проекта');
  const root=path.join(os.tmpdir(),'AmazFace-ZeusBridge');fs.mkdirSync(root,{recursive:true});
  const id=Date.now()+'-'+crypto.randomBytes(4).toString('hex');const dir=path.join(root,id);const zipPath=path.join(root,id+'.zip');fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(zipPath,zip);
  debug('unpackProject: extracting ZIP',{zipPath,dir});
  try{execFileSync('tar.exe',['-xf',zipPath,'-C',dir],{stdio:'pipe',windowsHide:true});}
  catch(tarErr){debug('tar failed, fallback to Expand-Archive',{message:tarErr.message});
    try{execFileSync('powershell.exe',['-NoProfile','-ExecutionPolicy','Bypass','-Command',`Expand-Archive -LiteralPath '${zipPath.replace(/'/g,"''")}' -DestinationPath '${dir.replace(/'/g,"''")}' -Force`],{stdio:'pipe'});}catch(e){throw new Error('Не удалось распаковать проект: '+(e.stderr?.toString()||e.message));}}
  debug('unpackProject: extraction finished',{dir,entries:fs.readdirSync(dir)});
  if(!fs.existsSync(path.join(dir,'app.json'))||!fs.existsSync(path.join(dir,'package.json'))||!fs.existsSync(path.join(dir,'watchface','index.js')))throw new Error('ZIP не похож на проект AmazFace: в корне должны быть app.json, package.json и watchface/index.js.');
  return dir;
}
async function startBridge(req,res){debug('HTTP POST /bridge/start');try{requestedDevice=String(req.headers['x-device-name']||'').replace(/[^\x20-\x7e]/g,'').trim();const dir=await unpackProject(req);debug('Project unpacked; launching bridge',{dir});const info=launchZeus(dir,'bridge');debug('Bridge launch accepted',info);return json(res,200,{ok:true,message:'Zeus Developer Bridge запущен. Теперь нажмите Connect.',projectDir:info.projectDir,zeus:info.zeus});}catch(e){debug('START BRIDGE FAILED',{message:e.message,stack:e.stack});return json(res,500,{error:e.message,stack:e.stack});}}
function sendBridgeCommand(command,res){
  if(!child||!state.running||state.mode!=='bridge')return json(res,409,{error:'Developer Bridge не запущен. Сначала нажмите «Запустить Bridge».',state});
  if(command==='install'&&!state.connected)return json(res,409,{error:'Установка заблокирована: сначала дождитесь подтверждённого соединения Connect.',state});
  if(command==='connect'&&state.connectRequested&&!state.connected)return json(res,409,{error:'Команда Connect уже отправлена. Дождитесь ответа Zeus CLI.',state});
  try{child.stdin.write(command+'\n');if(command==='connect')state.connectRequested=true;if(command==='install'){state.installRequested=true;state.installFinished=false;state.installSucceeded=false;state.installPhase='building';if(promptHandler)promptHandler.reset();clearTimeout(installTimer);installTimer=setTimeout(()=>{if(state.installRequested&&!state.installFinished){const ph=state.installPhase;state.installFinished=true;state.installSucceeded=false;state.installPhase='failed';addLog(`\n[AmazFace] Установка не завершилась за ${INSTALL_TIMEOUT_MS/60000} мин (фаза: ${ph}). Проверьте журнал Zeus выше.\n`);}},INSTALL_TIMEOUT_MS);}addLog(`\n> ${command}\n`);return json(res,200,{ok:true,message:command==='connect'?'Команда Connect отправлена. Следите за журналом Zeus.':'Команда Install отправлена. Следите за журналом Zeus.',state});}catch(e){return json(res,500,{error:'Не удалось отправить команду в Zeus: '+e.message});}
}
async function preview(req,res){try{requestedDevice=String(req.headers['x-device-name']||'').replace(/[^\x20-\x7e]/g,'').trim();const dir=await unpackProject(req);const info=launchZeus(dir,'preview');json(res,200,{ok:true,message:'Проект распакован. Запускаю Zeus Preview.',projectDir:info.projectDir,zeus:info.zeus});}catch(e){json(res,500,{error:e.message});}}

// ---- Проверка окружения: установлен ли Zeus CLI и выполнен ли вход (zeus status) ----
function stripAnsi(t){return String(t).replace(/\x1b\[[0-9;?]*[ -\/]*[@-~]/g,'').replace(/\r/g,'');}
function runZeusQuick(zeus,args,timeoutMs){
  return new Promise(resolve=>{
    let out='',done=false,p;
    const finish=(code)=>{if(done)return;done=true;clearTimeout(t);resolve({code,out:stripAnsi(out).trim(),timedOut:code==='timeout'});};
    try{p=spawn('cmd.exe',['/d','/s','/c',`""${zeus}" ${args}"`],{windowsHide:true,windowsVerbatimArguments:true,stdio:['ignore','pipe','pipe']});}catch(e){return resolve({code:'error',out:e.message});}
    p.stdout.on('data',d=>out+=d);p.stderr.on('data',d=>out+=d);
    p.on('error',e=>{out+=e.message;finish('error');});
    p.on('exit',c=>finish(c));
    const t=setTimeout(()=>{try{spawn('taskkill',['/pid',String(p.pid),'/t','/f'],{windowsHide:true});}catch{}finish('timeout');},timeoutMs);
  });
}
function parseLogin(text){
  const t=String(text||'');
  if(!t)return {loggedIn:null,user:''};
  if(/not\s*(yet\s*)?log(?:ged)?\s*in|未登录|unauthori[sz]ed|login\s*status\s*[:：=]\s*(false|no|not|unlogin|logged\s*out|✗|×|✘)|please\s+(?:run\s+)?(?:`?zeus\s+)?login/i.test(t))return {loggedIn:false,user:''};
  const nick=t.match(/(?:nick\s*name|user\s*name|account)\s*[:：=]\s*([^\n]+)/i);
  if(/login\s*status\s*[:：=]\s*(true|yes|ok|logged|success|✔|✓)|logged\s*in|已登录|nick\s*name|user\s*id/i.test(t))return {loggedIn:true,user:nick?nick[1].trim():''};
  return {loggedIn:null,user:''};
}
async function checkEnv(){
  const zeus=findZeus();
  const env={ok:true,bridgeServer:true,node:process.version,zeus:zeus||'',zeusVersion:'',loggedIn:null,user:'',statusRaw:'',statusError:''};
  if(!zeus)return env;
  const [v,st]=await Promise.all([runZeusQuick(zeus,'--version',10000),runZeusQuick(zeus,'status',20000)]);
  const ver=(v.out.match(/\d+\.\d+\.\d+[\w.\-]*/)||[''])[0];env.zeusVersion=ver;
  env.statusRaw=st.out.slice(0,1500);
  if(st.timedOut){env.statusError='Zeus не ответил на «zeus status» за 20 секунд.';}
  else{const r=parseLogin(st.out);env.loggedIn=r.loggedIn;env.user=r.user;
    if(r.loggedIn===null)env.statusError=st.out?'Не удалось распознать ответ «zeus status».':'«zeus status» ничего не вернул.';}
  debug('checkEnv',env);
  return env;
}
function openZeusLogin(){
  const zeus=findZeus();if(!zeus)throw new Error('Команда zeus не найдена в PATH.');
  // Отдельное видимое окно консоли: zeus login открывает браузер и ждёт завершения входа.
  spawn('cmd.exe',['/d','/c','start','"Zeus login"','cmd','/k',`"${zeus}" login`],{windowsHide:false,detached:true,stdio:'ignore'}).unref();
  return zeus;
}
const server=http.createServer(async(req,res)=>{cors(res);if(githubRoutes.matches(req))return githubRoutes.handle(req,res);if(req.method==='OPTIONS'){debug('HTTP OPTIONS '+req.url,{origin:req.headers.origin});res.writeHead(204);return res.end();}try{
  if(req.method==='GET'&&req.url==='/health'){const zeus=findZeus();debug('HTTP GET /health',{zeus,running:state.running,mode:state.mode});return json(res,200,{ok:true,zeus:zeus||'',running:state.running,mode:state.mode,connected:state.connected});}
  if(req.method==='GET'&&req.url==='/env')return json(res,200,await checkEnv());
  if(req.method==='POST'&&req.url==='/zeus/login'){try{const z=openZeusLogin();return json(res,200,{ok:true,message:'Окно входа Zeus открыто. Завершите вход в браузере и вернитесь в редактор.',zeus:z});}catch(e){return json(res,500,{error:e.message});}}
  if(req.method==='GET'&&req.url==='/status')return json(res,200,state);
  if(req.method==='POST'&&req.url==='/preview')return preview(req,res);
  if(req.method==='POST'&&req.url==='/bridge/start')return startBridge(req,res);
  if(req.method==='POST'&&req.url==='/bridge/connect')return sendBridgeCommand('connect',res);
  if(req.method==='POST'&&req.url==='/bridge/install')return sendBridgeCommand('install',res);
  if(req.method==='POST'&&req.url==='/stop'){kill();return json(res,200,{ok:true});}
  return json(res,404,{error:'Not found'});
}catch(e){return json(res,500,{error:e.message});}});
server.on('error',e=>debug('HTTP SERVER ERROR',{message:e.message,code:e.code,stack:e.stack}));
server.listen(PORT,'127.0.0.1',()=>{console.log('\n[AmazFace] Код доступа для GitHub-публикации (введите его один раз в редакторе): '+githubRoutes.bridgeKey()+'\n');debug(`AmazFace Zeus Bridge listening on http://127.0.0.1:${PORT}`,{pid:process.pid,node:process.version,platform:process.platform,debugLog:DEBUG_LOG});});
