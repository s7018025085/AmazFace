'use strict';
// bridge/zeus-build.js
//
// Сборка установочного пакета через Zeus CLI для GitHub Publishing.
//
// Зачем: браузерный экспортёр кладёт в device.zip исходный текст
// (watchface/index.js с ESM-импортами @zos/*). Часы такой пакет не запускают
// (чёрный экран). `zeus build` компилирует код в байткод (index.bin, app.bin),
// приводит app.json и ресурсы к боевому виду — именно этот пакет ставит и
// режим бриджа. Здесь мы прогоняем тот же project.zip через `zeus build` и
// достаём из dist/*.zab внутренний .zpk (app-side.zip + device.zip).
//
// Модуль без зависимостей: ZIP читается через zlib, процесс zeus запускается
// так же, как в server.js (cmd.exe на Windows).

const fs = require('fs');
const os = require('os');
const path = require('path');
const zlib = require('zlib');
const crypto = require('crypto');
const { spawn, execFileSync } = require('child_process');

const BUILD_TIMEOUT_MS = 5 * 60 * 1000;
const OUT_LIMIT = 50000;

// ───────── минимальный ZIP-ридер (STORE и DEFLATE, без zip64) ─────────
function readZip(buf) {
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65557); i--) {
    if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd < 0) throw new Error('Не ZIP-архив (нет конца центрального каталога).');
  const count = buf.readUInt16LE(eocd + 10);
  let off = buf.readUInt32LE(eocd + 16);
  const out = new Map();
  for (let n = 0; n < count; n++) {
    if (buf.readUInt32LE(off) !== 0x02014b50) throw new Error('Повреждённый центральный каталог ZIP.');
    const method = buf.readUInt16LE(off + 10);
    const csize = buf.readUInt32LE(off + 20);
    const usize = buf.readUInt32LE(off + 24);
    const nlen = buf.readUInt16LE(off + 28), xlen = buf.readUInt16LE(off + 30), clen = buf.readUInt16LE(off + 32);
    const lho = buf.readUInt32LE(off + 42);
    const name = buf.toString('utf8', off + 46, off + 46 + nlen);
    off += 46 + nlen + xlen + clen;
    if (csize === 0xffffffff || usize === 0xffffffff) throw new Error('ZIP64 не поддерживается.');
    if (name.endsWith('/')) continue;
    if (buf.readUInt32LE(lho) !== 0x04034b50) throw new Error('Повреждённый заголовок файла в ZIP: ' + name);
    const start = lho + 30 + buf.readUInt16LE(lho + 26) + buf.readUInt16LE(lho + 28);
    const raw = buf.subarray(start, start + csize);
    let data;
    if (method === 0) data = Buffer.from(raw);
    else if (method === 8) data = zlib.inflateRawSync(raw);
    else throw new Error('Неподдерживаемый метод сжатия ' + method + ': ' + name);
    out.set(name, data);
  }
  return out;
}

function extractTo(entries, dir, skip) {
  const root = path.resolve(dir);
  for (const [name, data] of entries) {
    if (skip && skip(name)) continue;
    const target = path.resolve(root, name);
    if (target !== root && !target.startsWith(root + path.sep)) throw new Error('Небезопасный путь в архиве: ' + name);
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.writeFileSync(target, data);
  }
}

// ───────── поиск и запуск Zeus ─────────
function findZeus() {
  try {
    if (process.platform === 'win32') {
      const out = execFileSync('cmd.exe', ['/d', '/c', 'where zeus'], { encoding: 'utf8', windowsHide: true }).trim();
      const all = out.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
      return all.find(x => /\.(cmd|exe|bat)$/i.test(x)) || all[0] || null;
    }
    return execFileSync('which', ['zeus'], { encoding: 'utf8' }).trim() || null;
  } catch (e) { return null; }
}

function stripAnsi(s) { return String(s).replace(/\x1b\[[0-9;?]*[ -\/]*[@-~]/g, '').replace(/\r(?!\n)/g, ''); }

function runZeus(zeus, args, cwd, opts) {
  return new Promise((resolve, reject) => {
    let child;
    try {
      if (process.platform === 'win32') {
        child = spawn('cmd.exe', ['/d', '/s', '/c', `""${zeus}" ${args}"`], { cwd, windowsHide: true, windowsVerbatimArguments: true, stdio: ['ignore', 'pipe', 'pipe'] });
      } else {
        child = spawn(zeus, args.split(' '), { cwd, stdio: ['ignore', 'pipe', 'pipe'] });
      }
    } catch (e) { return reject(e); }
    let out = '', settled = false;
    const add = (c) => { out += stripAnsi(c); if (out.length > OUT_LIMIT) out = out.slice(-OUT_LIMIT); };
    child.stdout.on('data', add); child.stderr.on('data', add);
    const killTree = () => {
      try {
        if (process.platform === 'win32') spawn('taskkill', ['/pid', String(child.pid), '/t', '/f'], { windowsHide: true });
        else child.kill('SIGKILL');
      } catch (e) { /* ignore */ }
    };
    const finish = (r) => { if (settled) return; settled = true; clearTimeout(timer); if (opts.signal) opts.signal.removeEventListener('abort', onAbort); resolve(Object.assign({ out }, r)); };
    const onAbort = () => { killTree(); finish({ code: 'aborted' }); };
    const timer = setTimeout(() => { killTree(); finish({ code: 'timeout' }); }, opts.timeoutMs || BUILD_TIMEOUT_MS);
    if (opts.signal) { if (opts.signal.aborted) return onAbort(); opts.signal.addEventListener('abort', onAbort); }
    child.on('error', (e) => { if (!settled) { settled = true; clearTimeout(timer); reject(e); } });
    child.on('exit', (code) => finish({ code }));
  });
}

function tail(s, n) { const t = String(s).trim(); return t.length > n ? '…' + t.slice(-n) : t; }

/**
 * @param {{log?:Function, findZeus?:Function, run?:Function, tmpRoot?:string, timeoutMs?:number}} [options]
 * `run(zeus, args, cwd, {signal, timeoutMs})` → {code, out} подменяется в тестах.
 */
function createZeusBuilder(options) {
  const o = Object.assign({ log: () => {}, findZeus, run: runZeus, tmpRoot: path.join(os.tmpdir(), 'AmazFace-GithubBuild'), timeoutMs: BUILD_TIMEOUT_MS }, options || {});

  /**
   * @param {Buffer} projectZip полный проект Zepp OS (тот же, что уходит в /preview)
   * @returns {Promise<{zpk:Buffer, deviceZip:Buffer, zabName:string, deviceFiles:string[]}>}
   */
  async function build(projectZip, ctx) {
    ctx = ctx || {};
    const zeus = o.findZeus();
    if (!zeus) throw buildError('Команда zeus не найдена в PATH. Установите Zeus CLI (npm i -g @zeppos/zeus-cli), выполните «zeus login» и перезапустите мост.', 'zeus_missing');

    fs.mkdirSync(o.tmpRoot, { recursive: true });
    const dir = path.join(o.tmpRoot, Date.now() + '-' + crypto.randomBytes(4).toString('hex'));
    fs.mkdirSync(dir, { recursive: true });
    try {
      const entries = readZip(projectZip);
      for (const need of ['app.json', 'package.json', 'watchface/index.js']) {
        if (!entries.has(need)) throw buildError(`В project.zip нет ${need} — это не проект AmazFace.`, 'zeus_build');
      }
      // dist/ из архива не берём: нужен только свежий результат этой сборки.
      extractTo(entries, dir, (n) => /^dist\//.test(n));
      o.log('zeus build: ' + zeus + ' в ' + dir);

      const r = await o.run(zeus, 'build', dir, { signal: ctx.signal, timeoutMs: o.timeoutMs });
      o.log('zeus build завершён: code=' + r.code + '\n' + tail(r.out, 4000));
      if (r.code === 'aborted') throw buildError('Сборка Zeus прервана.', 'zeus_build');
      if (r.code === 'timeout') throw buildError('Zeus не завершил сборку за ' + Math.round(o.timeoutMs / 60000) + ' мин.\n' + tail(r.out, 800), 'zeus_build');

      const distDir = path.join(dir, 'dist');
      const zabs = fs.existsSync(distDir) ? fs.readdirSync(distDir).filter(f => /\.zab$/i.test(f)) : [];
      if (r.code !== 0 || !zabs.length) {
        throw buildError(`«zeus build» не дал пакета (код ${r.code}).\n` + tail(r.out, 800), 'zeus_build');
      }
      zabs.sort((a, b) => fs.statSync(path.join(distDir, b)).mtimeMs - fs.statSync(path.join(distDir, a)).mtimeMs);
      const zabName = zabs[0];
      const zab = readZip(fs.readFileSync(path.join(distDir, zabName)));

      let zpkName = null;
      try {
        const m = JSON.parse(zab.get('manifest.json').toString('utf8'));
        zpkName = m.zpks && m.zpks[0] && m.zpks[0].name;
      } catch (e) { /* ниже запасной вариант */ }
      if (!zpkName || !zab.has(zpkName)) zpkName = [...zab.keys()].find(k => /\.zpk$/i.test(k));
      if (!zpkName) throw buildError('В .zab от Zeus нет .zpk.', 'zeus_build');

      const zpk = zab.get(zpkName);
      const inner = readZip(zpk);
      const deviceZip = inner.get('device.zip');
      if (!deviceZip) throw buildError('В .zpk от Zeus нет device.zip.', 'zeus_build');
      const deviceFiles = [...readZip(deviceZip).keys()];
      return { zpk, deviceZip, zabName, deviceFiles };
    } finally {
      try { fs.rmSync(dir, { recursive: true, force: true }); } catch (e) { /* временная папка */ }
    }
  }

  return { build };
}

function buildError(message, code) { const e = new Error(message); e.code = code; return e; }

module.exports = { createZeusBuilder, readZip, findZeus };
