'use strict';
// Перехват интерактивных Inquirer-вопросов Zeus CLI.
// Zeus запускается без TTY, поэтому «Which device would you like to preview?»
// ждёт нажатия клавиши вечно. Модуль копит вывод, ждёт «тишины» и отправляет
// нужные клавиши в stdin. Чистая логика (без child_process) — легко тестируется.

const ANSI = /\x1b\[[0-9;?]*[ -\/]*[@-~]/g;
const ARROW_DOWN = '\x1b[B';
const ENTER = '\r\n';

function clean(s) { return String(s).replace(ANSI, '').replace(/\r(?!\n)/g, '\n'); }

// Разбирает последний отрисованный список выбора Inquirer.
function parseListPrompt(text) {
  const lines = clean(text).split(/\n/).map(l => l.replace(/\s+$/, ''));
  let q = -1;
  for (let i = lines.length - 1; i >= 0; i--) {
    if (/^\s*\?\s+.*\(Use arrow keys\)/i.test(lines[i]) || /^\s*\?\s+.*(Use arrow keys)/i.test(lines[i])) { q = i; break; }
  }
  if (q < 0) return null;
  const question = lines[q].replace(/^\s*\?\s+/, '').replace(/\s*\(Use arrow keys\).*$/i, '').trim();
  const choices = []; let current = 0;
  for (let i = q + 1; i < lines.length; i++) {
    const raw = lines[i];
    if (!raw.trim()) continue;
    if (/^\s*\?\s+/.test(raw)) break;               // следующий вопрос
    if (/^\s*\[.\]/.test(raw) || /^\s*bridge\$/i.test(raw)) break;
    const m = raw.match(/^\s*([>❯])\s+(.*)$/);
    const label = (m ? m[2] : raw.replace(/^\s+/, '')).trim();
    if (!label || /^\(Move up and down/i.test(label)) continue;
    if (m) current = choices.length;
    choices.push(label);
  }
  return {question, choices, current};
}

function createPromptHandler({write, log, preferred = process.env.AMAZFACE_ZEUS_DEVICE || 'Balance 2', settleMs = 200, keyDelayMs = 60, onAnswer, setTimer = setTimeout, clearTimer = clearTimeout}) {
  let buf = ''; let timer = null; let busy = false; let device = preferred;
  const norm = s => String(s).toLowerCase().replace(/[^a-z0-9]+/g, '');

  function pickIndex(p) {
    const want = norm(device);
    const idx = want ? p.choices.findIndex(c => norm(c).includes(want)) : -1;
    return idx >= 0 ? idx : p.current;
  }

  function answer() {
    timer = null;
    const text = buf;
    // Подтверждение Y/n
    const tail = clean(text).split(/\n/).filter(l => l.trim()).slice(-1)[0] || '';
    const list = parseListPrompt(text);
    if (list) {
      const target = pickIndex(list);
      const downs = target - list.current;
      const keys = [];
      if (downs > 0) for (let i = 0; i < downs; i++) keys.push(ARROW_DOWN);
      else if (downs < 0) for (let i = 0; i < -downs; i++) keys.push('\x1b[A');
      keys.push(ENTER);
      log(`[AmazFace] Автоответ на вопрос Zeus «${list.question}»: выбираю «${list.choices[target] || '(по умолчанию)'}» (вариантов: ${list.choices.length}).\n`);
      busy = true; buf = '';
      let i = 0;
      const next = () => { if (i >= keys.length) { busy = false; onAnswer && onAnswer({type: 'list', question: list.question, choice: list.choices[target] || null}); return; }
        try { write(keys[i++]); } catch (e) { log(`[AmazFace] Не удалось отправить клавишу в Zeus: ${e.message}\n`); busy = false; return; }
        setTimer(next, keyDelayMs); };
      next();
      return;
    }
    if (/^\s*\?\s+.*(\(Y\/n\)|\(y\/N\)|\[Y\/n\]|\[y\/N\])\s*$/.test(tail)) {
      log(`[AmazFace] Автоответ «y» на вопрос Zeus: ${tail.trim()}\n`);
      buf = '';
      try { write('y' + ENTER); } catch (e) { log(`[AmazFace] stdin Zeus недоступен: ${e.message}\n`); }
      onAnswer && onAnswer({type: 'confirm', question: tail.trim()});
    }
  }

  function looksLikePrompt(text) {
    const t = clean(text);
    return /\?\s+.*\(Use arrow keys\)/i.test(t) || /\?\s+.*(\(Y\/n\)|\(y\/N\)|\[Y\/n\]|\[y\/N\])\s*$/m.test(t);
  }

  return {
    setDevice(name) { if (name && String(name).trim()) device = String(name).trim(); },
    feed(chunk) {
      if (busy) return;
      buf += String(chunk);
      if (buf.length > 20000) buf = buf.slice(-20000);
      if (!looksLikePrompt(buf)) { if (!/\?\s/.test(clean(buf))) buf = buf.slice(-2000); return; }
      if (timer) clearTimer(timer);
      timer = setTimer(answer, settleMs);   // ждём, пока Inquirer дорисует список
    },
    reset() { if (timer) clearTimer(timer); timer = null; buf = ''; busy = false; },
    _parse: parseListPrompt,
  };
}

module.exports = {createPromptHandler, parseListPrompt, clean};
