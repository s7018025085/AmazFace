# AmazFace — Zeus Developer Bridge

Локальный Windows Bridge связывает редактор AmazFace с настоящим интерактивным `zeus bridge`. Сборка текущего циферблата передаётся из редактора в локальный сервер; команды `connect` и `install` отправляются в процесс Zeus CLI, а его stdout/stderr отображаются в журнале редактора.

## Требования

- Windows
- Node.js (команда `node` доступна в PATH)
- Zeus CLI, команда `zeus` доступна в PATH
- В Zepp App на телефоне включён Developer Mode → `+` → Bridge
- Для Developer Bridge выполнен `zeus login` под тем же Zepp-аккаунтом, что используется в runtime-среде

## Быстрый запуск

1. Запустите `start-zeus-bridge.bat` и оставьте консоль открытой.
2. Откройте `index.html` редактора AmazFace и нажмите `⌚ Zeus Bridge / Preview`.
3. Панель сама проверяет цепочку: **локальный мост → Zeus CLI установлен → выполнен вход (`zeus status`)**. Если что-то не так, она покажет, что делать (команда установки, кнопка «Войти в Zeus»).
4. Дальше работает одна главная кнопка: **Запустить Bridge → Подключиться к телефону → Установить на часы**. Перед подключением на телефоне откройте Zepp App → Профиль → Режим разработчика → «+» → Bridge.

QR Preview (старый способ) спрятан в раздел «Дополнительно».

## Что делает локальный сервер

- Слушает только `127.0.0.1:17865`.
- `GET /health` — проверяет доступность Zeus CLI.
- `GET /env` — проверка окружения: путь и версия Zeus CLI, статус входа (разбор вывода `zeus status`).
- `POST /zeus/login` — открывает окно `zeus login`.
- `GET /status` — возвращает состояние и журнал.
- `POST /bridge/start` — принимает ZIP проекта, проверяет ключевые файлы и запускает `zeus bridge`.
- `POST /bridge/connect` — отправляет `connect` в интерактивный процесс CLI.
- `POST /bridge/install` — отправляет `install` в интерактивный процесс CLI.
- `POST /preview` — сохраняет прежний сценарий `zeus preview`.
- `POST /stop` — останавливает запущенный процесс Zeus.

Если версия Zeus CLI не поддерживает устройство или формат проекта, журнал покажет ответ CLI. Интерфейс не подменяет сообщение об успехе и не считает сам факт запуска CLI успешной установкой.

## Автоответ на интерактивные вопросы Zeus CLI

Zeus CLI на `install`/`preview` может задать Inquirer-вопрос (например, `? Which device would you like to preview? (Use arrow keys)`). Мост запускает Zeus без TTY, поэтому такой вопрос сам не закрывается. `bridge/prompt-handler.js` копит вывод Zeus, ждёт ~200 мс «тишины» (пока Inquirer дорисует список), разбирает список устройств и отправляет в `stdin` стрелки вниз (если указатель не на нужном пункте) и Enter (`\r\n`). Нужное устройство берётся из заголовка `X-Device-Name` (редактор шлёт имя текущего устройства), иначе из переменной окружения `AMAZFACE_ZEUS_DEVICE`, иначе `Balance 2`; если такого пункта в списке нет — подтверждается пункт по умолчанию. Вопросы `(Y/n)` подтверждаются `y`.

Каждый автоответ пишется в журнал (`[AmazFace] Автоответ на вопрос Zeus …`), в `bridge-debug.log` и в `GET /status` (`autoAnswers`, `installPhase`: `building` → `device-prompt` → `installing` → `done`/`failed`). Если Install не завершился за 5 минут, статус переводится в `failed` с пояснением в журнале.

Проверка логики перехвата без Zeus: `node scripts/test-prompt-handler.js`.


## GitHub Publishing (маршруты `/github/*`)

Тот же мост обслуживает публикацию циферблата на GitHub — подробности в `../docs/GITHUB_PUBLISHING.md`.
Zeus CLI для этого не нужен, нужен только Node.js 18+. При запуске мост печатает **код доступа**
(его вводят в редакторе один раз). Маршруты: `GET /github/ping`, `GET /github/status`,
`POST /github/connect`, `POST /github/disconnect`, `POST /github/publish`, `GET /github/job`,
`POST /github/cancel`. Все (кроме `ping`) требуют заголовок `X-AmazFace-Key`; запросы с чужим
`Origin` или `Host` отклоняются. Токен GitHub хранится только мостом (DPAPI) и в редактор не возвращается.
