# Premium Typography export — v31

Premium Typography TEXT objects are kept editable in the Designer project.
When the user opens the Premium Typography editor, `premium_enabled=true` is stored on that TEXT object.
During watchface export only, static premium TEXT is rendered by the existing Canvas renderer at 4x and downsampled to the final PNG with transparency.

Export pipeline:

TEXT source -> 4x renderer -> high-quality downsample -> RGBA PNG -> IMG widget on watch

The original TEXT object is never replaced in the saved project.
Dynamic TEXT data sources (time/date/sensors) are not rasterized because a static PNG cannot update on the watch; those remain native TEXT widgets and produce an export warning.
