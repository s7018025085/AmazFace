// src/ui/panel-sections.js
//
// 1) Сворачиваемые секции боковых панелей («Компоненты», «Устройство и сборка»,
//    «Свойства»). «Ресурсы» и «Слои» уже сворачиваются своим кодом (app.js /
//    asset-manager.js) — здесь они не трогаются.
//    Состояние каждой секции запоминается в localStorage.
// 2) Выпадающее меню «Экспорт» в верхней панели.
(function () {
  const PREFIX = 'amazface.section.';
  // Секции, которые нужны редко, по умолчанию свёрнуты.
  const COLLAPSED_BY_DEFAULT = new Set(['Устройство и сборка']);

  function initSections() {
    document.querySelectorAll('.left-panel, .right-panel').forEach((panel) => {
      const titles = [...panel.children].filter(
        (el) => el.classList.contains('panel-title') && !el.classList.contains('collapsible')
      );
      titles.forEach((title) => {
        const label = title.textContent.trim();
        // Всё, что идёт после заголовка до следующего заголовка, — тело секции.
        const body = document.createElement('div');
        body.className = 'panel-section-body';
        let n = title.nextElementSibling;
        while (n && !n.classList.contains('panel-title')) {
          const next = n.nextElementSibling;
          body.appendChild(n);
          n = next;
        }
        title.after(body);

        title.classList.add('collapsible', 'section-title');
        title.setAttribute('role', 'button');
        title.tabIndex = 0;
        title.innerHTML = '<span class="toggle-btn" aria-hidden="true">▼</span> ';
        title.appendChild(document.createTextNode(label));

        const key = PREFIX + label;
        const saved = localStorage.getItem(key);
        const apply = (collapsed) => {
          body.classList.toggle('collapsed', collapsed);
          title.querySelector('.toggle-btn').textContent = collapsed ? '▶' : '▼';
          title.setAttribute('aria-expanded', String(!collapsed));
        };
        apply(saved === null ? COLLAPSED_BY_DEFAULT.has(label) : saved === '1');

        const toggle = () => {
          const collapsed = !body.classList.contains('collapsed');
          apply(collapsed);
          localStorage.setItem(key, collapsed ? '1' : '0');
        };
        title.addEventListener('click', toggle);
        title.addEventListener('keydown', (e) => {
          if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(); }
        });
      });
    });
  }

  function initExportMenu() {
    const wrap = document.getElementById('export-menu');
    const btn = document.getElementById('export-menu-btn');
    const list = document.getElementById('export-menu-list');
    if (!wrap || !btn || !list) return;
    const close = () => { list.hidden = true; btn.setAttribute('aria-expanded', 'false'); };
    const open = () => { list.hidden = false; btn.setAttribute('aria-expanded', 'true'); };
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      list.hidden ? open() : close();
    });
    // Клик по пункту выполняет его обработчик из app.js и закрывает меню.
    list.addEventListener('click', () => setTimeout(close, 0));
    document.addEventListener('click', (e) => { if (!wrap.contains(e.target)) close(); });
    window.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); });
  }

  initSections();
  initExportMenu();
})();
