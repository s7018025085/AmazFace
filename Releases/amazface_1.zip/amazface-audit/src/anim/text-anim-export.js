// src/anim/text-anim-export.js
//
// Генерация кода Zepp OS для анимации текста. Не знает про DOM и про остальные
// компоненты. Вызывается из index-js-exporter.js ТОЛЬКО для компонента «Текст».
//
//   plan(comp, ctx)   — решает, можно ли и нужно ли экспортировать анимацию;
//   emitWidgets(...)  — строки createWidget(...) + запись аниматора + прокси-объект,
//                       через который обычные строки обновления
//                       `<var>.setProperty(prop.MORE, { text: ... })` попадают в аниматор
//                       (код обновления времени/датчиков не меняется);
//   runtimeBlock(ids) — исходник рантайма (общий с предпросмотром).
(function (root) {
  'use strict';
  const TA = root.TextAnim || (typeof require === 'function' ? require('./text-anim.js') : null);

  const DELEGATE_NOTE = 'Текст: пауза анимации через WIDGET_DELEGATE.pause_call и повтор через resume_call (остановка таймеров при уходе с циферблата) — проверьте на часах';

  function compLabel(comp) { return '«' + (comp.name || comp.id || 'Текст') + '»'; }

  // ctx: { showLevel, effSize }
  function plan(comp, ctx) {
    ctx = ctx || {};
    const out = { active: false, silent: true, warnings: [], unverified: [], effect: null };
    if (!TA || !comp || comp.defId !== 'text') return out;
    const info = TA.analyze(comp, { mode: 'normal' });
    if (!info.enabled) return out;
    // В AOD-сцене анимации нет: экран почти не обновляется. Показывается итоговое состояние.
    if (/AOD/.test(String(ctx.showLevel || ''))) { out.aod = true; return out; }
    out.silent = false;
    if (!info.supported) {
      out.warnings = info.reasons.map((r) => 'Анимация текста ' + compLabel(comp) + ' не экспортирована: ' + r);
      return out;
    }
    const cfg = info.cfg;
    const base = TA.baseState(cfg, comp, ctx.effSize);
    out.active = true;
    out.cfg = cfg;
    out.info = info;
    out.effect = cfg.effect;
    out.rc = TA.runtimeConfig(cfg, comp);
    out.base = base;
    out.finalColor = base.fin;
    out.colon = !!info.colonLayout;
    out.needsDelegate = info.needsDelegate;
    out.warnings = info.warnings.map((w) => 'Анимация текста ' + compLabel(comp) + ': ' + w);
    out.unverified = info.unverified.slice();
    out.unverified.push(DELEGATE_NOTE);
    if (cfg.effect === 'reveal' && !cfg.reveal_to_linked) {
      out.warnings.push('Анимация текста ' + compLabel(comp) + ': после «Проявления» текст остаётся конечного цвета (' + cfg.reveal_to + '), а не цвета компонента.');
    }
    return out;
  }

  // helpers: { objLit, jsStr, alignConst }
  function emitWidgets(args) {
    const { varName, plan: pl, baseProps, comp, helpers } = args;
    const { objLit, jsStr } = helpers;
    const lines = [];
    const rcLit = TA.jsLiteral(pl.rc);
    const baseLit = TA.jsLiteral({ x: pl.base.x, y: pl.base.y, color: pl.base.color, fin: pl.base.fin, size: pl.base.size });
    // ЦВЕТ виджета с самого начала — итоговый (после анимации).
    const withKeys = (pairs, over) => pairs.filter(Boolean).map(([k, v]) => (over[k] !== undefined ? [k, over[k]] : [k, v]));
    const finColor = '0x' + ('000000' + (pl.base.fin >>> 0).toString(16)).slice(-6);

    if (pl.colon) {
      const x = Math.round(Number(comp.x || 0)), y = Math.round(Number(comp.y || 0));
      const w = Math.round(Number(comp.w || 0)), h = Math.round(Number(comp.h || 0));
      const cg = Math.max(8, Math.round(pl.base.size * 0.38));
      const half = Math.round(cg / 2);
      const cx = x + Math.round(w / 2);
      const hhW = Math.max(1, cx - half - x);
      const mmX = cx + half;
      const mmW = Math.max(1, x + w - mmX);
      lines.push(`const ${varName}_w = createWidget(widget.TEXT, ${objLit(withKeys(baseProps, { x: x, y: y, w: hhW, h: h, align_h: 'align.RIGHT', color: finColor }).concat([['text', jsStr('')]]))});`);
      lines.push(`const ${varName}_m = createWidget(widget.TEXT, ${objLit(withKeys(baseProps, { x: mmX, y: y, w: mmW, h: h, align_h: 'align.LEFT', color: finColor }).concat([['text', jsStr('')]]))});`);
      lines.push(`const ${varName}_c = createWidget(widget.TEXT, ${objLit(withKeys(baseProps, { x: cx - half, y: y, w: cg, h: h, align_h: 'align.CENTER_H', color: finColor }).concat([['text', jsStr(':')]]))});`);
      lines.push(`const ${varName}_a = __taCreate(${varName}_w, ${rcLit}, ${baseLit}, ${varName}_m, ${varName}_c);`);
    } else {
      lines.push(`const ${varName}_w = createWidget(widget.TEXT, ${objLit(withKeys(baseProps, { color: finColor }).concat([['text', jsStr('')]]))});`);
      lines.push(`const ${varName}_a = __taCreate(${varName}_w, ${rcLit}, ${baseLit});`);
    }
    // Прокси: существующий код обновления вызывает setProperty(prop.MORE, { text }) — текст
    // уходит в аниматор, остальные свойства — напрямую в виджет.
    lines.push(`const ${varName} = { setProperty: function (k, o) { if (o && typeof o.text === 'string') { __taSetText(${varName}_a, o.text); } else { ${varName}_w.setProperty(k, o); } } };`);
    return lines;
  }

  function runtimeBlock(effectIds) {
    return TA.runtimeSource(effectIds);
  }

  const api = { plan, emitWidgets, runtimeBlock };
  root.TextAnimExport = api;
  if (root !== globalThis) globalThis.TextAnimExport = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
