// Тень стрелок.
//
// В проекте (asset.dataUrl) лежит ЧИСТАЯ картинка стрелки с прозрачными полями под тень,
// а тень — это параметры asset.shadow. Поэтому тень можно менять в любой момент.
// PNG с тенью строится при сохранении проекта в Zepp-файлы (все виды экспорта идут
// через AssetShadow.bakeProject). Размеры и ось вращения при этом не меняются:
// поля под тень редактор оставляет в самом PNG.
//
// Для предпросмотра в редакторе используется runtime-кэш asset.shadowedUrl
// (неперечисляемое свойство: в JSON проекта и в снапшоты не попадает).
// Классический <script>, как и остальные файлы проекта.

const AssetShadow = (() => {
  const DEFAULTS = { enabled: false, angle: 135, distance: 6, blur: 5, spread: 0, opacity: 45, color: '#000000', rotate: true };
  const cache = new Map(); // ключ: параметры + dataUrl → Promise<dataUrl с тенью>
  const MAX_CACHE = 40;

  const norm = (s) => (s && s.enabled ? Object.assign({}, DEFAULTS, s) : null);

  const loadImage = (url) => new Promise((resolve, reject) => {
    const im = new Image();
    im.onload = () => resolve(im);
    im.onerror = () => reject(new Error('Не удалось загрузить изображение ресурса'));
    im.src = url;
  });

  const rgba = (hex, a) => {
    const h = String(hex || '#000000').replace('#', '');
    const n = parseInt(h.length === 3 ? h.split('').map((c) => c + c).join('') : h, 16);
    return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${Math.max(0, Math.min(1, a))})`;
  };

  // Та же отрисовка, что и в редакторе (drawWithShadow): сначала тень, поверх — картинка.
  function paint(ctx, image, w, h, sv) {
    if (sv.distance <= 0 && sv.blur <= 0 && sv.spread <= 0) { ctx.drawImage(image, 0, 0, w, h); return; }
    const a = sv.angle * Math.PI / 180;
    const spread = Math.max(0, sv.spread);
    const steps = spread > 0 ? Math.min(16, Math.max(4, Math.ceil(spread / 2))) : 1;
    ctx.save();
    ctx.shadowColor = rgba(sv.color, sv.opacity / 100);
    ctx.shadowBlur = sv.blur;
    ctx.shadowOffsetX = Math.cos(a) * sv.distance;
    ctx.shadowOffsetY = Math.sin(a) * sv.distance;
    for (let i = 0; i < steps; i++) {
      const t = steps === 1 ? 0 : (i / steps) * Math.PI * 2;
      ctx.drawImage(image, spread ? Math.cos(t) * spread : 0, spread ? Math.sin(t) * spread : 0, w, h);
    }
    ctx.restore();
    ctx.drawImage(image, 0, 0, w, h);
  }

  /** PNG (dataURL) ресурса с запечённой тенью; без тени — исходный dataUrl. */
  function render(asset) {
    const sv = norm(asset && asset.shadow);
    if (!sv || !asset.dataUrl) return Promise.resolve(asset ? asset.dataUrl : null);
    const key = JSON.stringify(sv) + '|' + asset.dataUrl;
    if (cache.has(key)) return cache.get(key);
    const p = loadImage(asset.dataUrl).then((im) => {
      const c = document.createElement('canvas');
      c.width = im.naturalWidth; c.height = im.naturalHeight;
      paint(c.getContext('2d'), im, c.width, c.height, sv);
      return c.toDataURL('image/png');
    });
    cache.set(key, p);
    if (cache.size > MAX_CACHE) cache.delete(cache.keys().next().value);
    p.catch(() => cache.delete(key));
    return p;
  }

  const setRuntime = (asset, url) => {
    Object.defineProperty(asset, 'shadowedUrl', { value: url || undefined, writable: true, configurable: true, enumerable: false });
  };

  /** Что показывать в предпросмотре: с тенью (если есть), иначе исходная картинка. */
  const url = (asset) => (asset ? (asset.shadowedUrl || asset.dataUrl) : '');

  /** Обновляет runtime-кэш предпросмотра. Возвращает true, если что-то изменилось. */
  async function refreshAll(assets) {
    let changed = false;
    for (const a of assets || []) {
      if (!a) continue;
      const want = norm(a.shadow) ? await render(a).catch(() => null) : null;
      if ((a.shadowedUrl || null) !== (want || null)) { setRuntime(a, want); changed = true; }
    }
    return changed;
  }

  /** Копия проекта для экспорта: у стрелок с тенью dataUrl заменён на PNG с тенью. */
  async function bakeProject(project) {
    if (!project || !(project.assets || []).some((a) => norm(a && a.shadow))) return project;
    const assets = [];
    for (const a of project.assets) {
      assets.push(norm(a && a.shadow) ? Object.assign({}, a, { dataUrl: await render(a) }) : a);
    }
    return Object.assign({}, project, { assets });
  }

  return { DEFAULTS, url, render, refreshAll, bakeProject };
})();

if (typeof window !== 'undefined') window.AssetShadow = AssetShadow;
