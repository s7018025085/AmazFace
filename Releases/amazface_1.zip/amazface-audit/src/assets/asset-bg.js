// Фон циферблата: хранение настроек отдельно + запекание при сохранении проекта.
//
// Так же, как с тенью стрелок (asset-shadow.js): в проекте (asset.dataUrl) лежит ИСХОДНАЯ
// картинка фона как есть, а всё, что делал редактор фона (масштаб, сдвиг, поворот, коррекция,
// эффекты, градиент), — это параметры asset.bg = { v:1, params:{…} }. Поэтому фон можно
// переоткрыть и подправить в любой момент без потерь (ничего не «вшито» в пиксели исходника).
// Готовый PNG 480×480 строится при сохранении проекта в Zepp-файлы (все виды экспорта идут
// через AssetBg.bakeProject) и в runtime-кэш предпросмотра asset.bgBakedUrl
// (неперечисляемое свойство: в JSON проекта и в снапшоты не попадает).
// ВАЖНО: функция paint() — единственная реализация отрисовки: ею же рисует и сам редактор
// фона, поэтому в PNG попадает ровно то, что видно в окне редактора.
// Классический <script>, как и остальные файлы проекта.

const AssetBg = (() => {
  const VERSION = 1;
  const DEFAULTS = {
    zoom: 100, x: 0, y: 0, rot: 0,
    brightness: 100, contrast: 100, saturation: 100, hue: 0, gray: 0, sepia: 0, blur: 0, alpha: 100,
    edgeFade: 0, vignette: 0, glass: 0, volume: 0, glow: 0, bloom: 0, reflection: 0, grain: 0,
    scanlines: 0, chroma: 0, pixelate: 0, tint: 0, gradient: 0, bezel: 0,
    tintColor: '#ff8c28', bezelColor: '#c9a24a',
    gradType: 'linear', gradAngle: 180, gradBlend: 'normal', gradC1: '#ff5e62', gradC2: '#ffb347', gradC3: '#5b3cff'
  };
  const cache = new Map(); // ключ: параметры + dataUrl → Promise<dataUrl 480×480>
  const MAX_CACHE = 12;

  const isBg = (a) => !!(a && a.bg && a.bg.params);
  const params = (a) => Object.assign({}, DEFAULTS, isBg(a) ? a.bg.params : null);

  // ---- общая отрисовка (перенесена из редактора фона без изменений логики) ----
  let work = null;
  const getWork = () => {
    if (work) return work;
    // Рабочие холсты 480×480: «слой» (изображение с фильтрами) и «сборка»
    // (слой + эффекты). Эффекты собираются изолированно и только потом
    // кладутся на целевой холст, поэтому режимы наложения не задевают
    // подложку предпросмотра.
    const mk = () => { const c = document.createElement('canvas'); c.width = c.height = 480; return c; };
    const layerCv = mk(), layerCtx = layerCv.getContext('2d', { willReadFrequently: true });
    const compCv = mk(), compCtx = compCv.getContext('2d');
    const tmpCv = mk(), tmpCtx = tmpCv.getContext('2d');
    const rng = (seed) => () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
    const hexA = (hex, a) => { const n = parseInt(String(hex || '#000000').replace('#', '').padStart(6, '0'), 16); return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${Math.max(0, Math.min(1, a))})`; };

    work = { layerCv, layerCtx, compCv, compCtx, tmpCv, tmpCtx, rng, hexA };
    return work;
  };

  /** Рисует содержимое циферблата 480×480 (картинка + эффекты) в targetCtx со смещением padX/padY. */
  function paint(targetCtx, img, state, padX = 0, padY = 0) {
    const { layerCv, layerCtx, compCv, compCtx, tmpCv, tmpCtx, rng } = getWork();
    const getRenderedSize = () => { const base = state.zoom / 100; return { base, w: img.naturalWidth * base, h: img.naturalHeight * base }; };
    const cx = 240, cy = 240, dialR = 240, S = 480;
    const L = layerCtx, c = compCtx;

    // 1. Слой: изображение с цветовыми фильтрами.
    L.setTransform(1, 0, 0, 1, 0, 0); L.globalAlpha = 1; L.globalCompositeOperation = 'source-over'; L.filter = 'none';
    L.clearRect(0, 0, S, S);
    L.save();
    L.translate(240 + state.x, 240 + state.y);
    L.rotate(state.rot * Math.PI / 180);
    const { w, h } = getRenderedSize();
    L.filter = `brightness(${state.brightness}%) contrast(${state.contrast}%) saturate(${state.saturation}%) hue-rotate(${state.hue}deg) grayscale(${state.gray}%) sepia(${state.sepia}%)` + (state.blur > 0 ? ` blur(${state.blur}px)` : '');
    L.drawImage(img, -w / 2, -h / 2, w, h);
    L.restore();
    L.filter = 'none';

    // 2. Пикселизация (мозаика).
    if (state.pixelate > 0) {
      const block = Math.max(2, Math.round(state.pixelate / 100 * 28));
      const sw = Math.ceil(S / block);
      tmpCtx.setTransform(1, 0, 0, 1, 0, 0); tmpCtx.clearRect(0, 0, S, S);
      tmpCtx.imageSmoothingEnabled = true; tmpCtx.drawImage(layerCv, 0, 0, sw, sw);
      L.clearRect(0, 0, S, S); L.imageSmoothingEnabled = false;
      L.drawImage(tmpCv, 0, 0, sw, sw, 0, 0, sw * block, sw * block);
      L.imageSmoothingEnabled = true;
    }

    // 3. Хроматическая аберрация: красный и синий каналы смещаются
    // радиально в разные стороны (как у линзы), зелёный остаётся на месте.
    if (state.chroma > 0) {
      const k = state.chroma / 100 * 0.03;
      const src = L.getImageData(0, 0, S, S), dst = L.createImageData(S, S), a = src.data, d = dst.data;
      const cl = (v) => v < 0 ? 0 : v > S - 1 ? S - 1 : v;
      for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
        const i = (y * S + x) * 4;
        const ir = (cl(Math.round(cy + (y - cy) * (1 - k))) * S + cl(Math.round(cx + (x - cx) * (1 - k)))) * 4;
        const ib = (cl(Math.round(cy + (y - cy) * (1 + k))) * S + cl(Math.round(cx + (x - cx) * (1 + k)))) * 4;
        d[i] = a[ir]; d[i + 1] = a[i + 1]; d[i + 2] = a[ib + 2];
        d[i + 3] = Math.max(a[i + 3], a[ir + 3], a[ib + 3]);
      }
      L.putImageData(dst, 0, 0);
    }

    // 4. Сборка: всё внутри КРУГА (фон циферблата — круг, а не квадрат),
    // поэтому ни один эффект не заходит в квадратные углы.
    c.setTransform(1, 0, 0, 1, 0, 0); c.globalAlpha = 1; c.globalCompositeOperation = 'source-over'; c.filter = 'none';
    c.clearRect(0, 0, S, S);
    c.save();
    c.beginPath(); c.arc(cx, cy, dialR, 0, Math.PI * 2); c.clip();
    c.globalAlpha = state.alpha / 100; c.drawImage(layerCv, 0, 0); c.globalAlpha = 1;

    // Тонировка и градиент — только поверх непрозрачных пикселей изображения.
    if (state.tint > 0) {
      c.save(); c.globalCompositeOperation = 'source-atop'; c.globalAlpha = state.tint / 100 * 0.75;
      c.fillStyle = state.tintColor; c.fillRect(0, 0, S, S); c.restore();
    }
    if (state.gradient > 0) {
      // Многоцветный градиент рисуется на отдельном холсте, обрезается по
      // альфе изображения и накладывается выбранным режимом.
      const t = tmpCtx;
      t.setTransform(1, 0, 0, 1, 0, 0); t.globalAlpha = 1; t.globalCompositeOperation = 'source-over'; t.clearRect(0, 0, S, S);
      const th = (Number(state.gradAngle) || 0) * Math.PI / 180;
      const dx = Math.sin(th), dy = -Math.cos(th), half = (Math.abs(dx) + Math.abs(dy)) * S / 2;
      const C1 = state.gradC1, C2 = state.gradC2, C3 = state.gradC3;
      let g;
      if (state.gradType === 'radial') {
        g = t.createRadialGradient(cx, cy, 0, cx, cy, dialR);
        g.addColorStop(0, C1); g.addColorStop(.5, C2); g.addColorStop(1, C3);
      } else if (state.gradType === 'conic' && t.createConicGradient) {
        g = t.createConicGradient(th - Math.PI / 2, cx, cy);
        g.addColorStop(0, C1); g.addColorStop(.33, C2); g.addColorStop(.66, C3); g.addColorStop(1, C1);
      } else {
        g = t.createLinearGradient(cx - dx * half, cy - dy * half, cx + dx * half, cy + dy * half);
        if (state.gradType === 'mirror') { g.addColorStop(0, C1); g.addColorStop(.25, C2); g.addColorStop(.5, C3); g.addColorStop(.75, C2); g.addColorStop(1, C1); }
        else { g.addColorStop(0, C1); g.addColorStop(.5, C2); g.addColorStop(1, C3); }
      }
      t.fillStyle = g; t.fillRect(0, 0, S, S);
      t.globalCompositeOperation = 'destination-in'; t.drawImage(layerCv, 0, 0); t.globalCompositeOperation = 'source-over';
      const BM = { normal: 'source-over', color: 'color', soft: 'soft-light', overlay: 'overlay', screen: 'screen', multiply: 'multiply' };
      c.save(); c.globalCompositeOperation = BM[state.gradBlend] || 'source-over'; c.globalAlpha = state.gradient / 100;
      c.drawImage(tmpCv, 0, 0); c.restore();
    }
    // Сияние (bloom): размытая копия слоя, добавленная «экраном».
    if (state.bloom > 0) {
      const a = state.bloom / 100;
      c.save(); c.globalCompositeOperation = 'screen'; c.globalAlpha = .75 * a;
      c.filter = `blur(${6 + 14 * a}px) brightness(${1.1 + .5 * a}) saturate(1.2)`;
      c.drawImage(layerCv, 0, 0); c.restore(); c.filter = 'none';
    }
    if (state.glow > 0) {
      const g = c.createRadialGradient(cx, cy, 40, cx, cy, 300);
      const a = (state.glow / 100) * 0.34;
      g.addColorStop(0, `rgba(255,255,255,${a})`); g.addColorStop(.45, `rgba(180,210,255,${a * .35})`); g.addColorStop(1, 'rgba(0,0,0,0)');
      c.fillStyle = g; c.fillRect(0, 0, S, S);
    }
    if (state.glass > 0) {
      const a = state.glass / 100;
      const g = c.createLinearGradient(70, 20, 420, 460);
      g.addColorStop(0, `rgba(255,255,255,${0.34 * a})`); g.addColorStop(.22, `rgba(255,255,255,${0.08 * a})`); g.addColorStop(.48, 'rgba(255,255,255,0)'); g.addColorStop(.7, `rgba(100,180,255,${0.05 * a})`); g.addColorStop(1, `rgba(255,255,255,${0.12 * a})`);
      c.fillStyle = g; c.fillRect(0, 0, S, S);
      c.save(); c.globalAlpha = 0.10 * a; c.filter = `blur(${1 + 4 * a}px)`; c.strokeStyle = '#fff'; c.lineWidth = 10 + 18 * a; c.beginPath(); c.arc(240, 240, 210, Math.PI * 1.05, Math.PI * 1.65); c.stroke(); c.restore();
    }
    if (state.volume > 0) {
      const a = state.volume / 100;
      c.save();
      c.globalCompositeOperation = 'multiply';
      let g = c.createRadialGradient(240, 240, 150, 240, 240, 340);
      g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(.72, `rgba(0,0,0,${0.10 * a})`); g.addColorStop(1, `rgba(0,0,0,${0.62 * a})`);
      c.fillStyle = g; c.fillRect(0, 0, S, S);
      c.globalCompositeOperation = 'screen';
      g = c.createLinearGradient(80, 70, 400, 390); g.addColorStop(0, `rgba(255,255,255,${0.16 * a})`); g.addColorStop(.35, 'rgba(255,255,255,0)'); g.addColorStop(1, `rgba(0,0,0,${0.08 * a})`);
      c.fillStyle = g; c.fillRect(0, 0, S, S); c.restore();
    }
    if (state.vignette > 0) {
      const a = state.vignette / 100;
      const g = c.createRadialGradient(cx, cy, Math.max(80, 220 - 130 * a), cx, cy, dialR);
      g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(.65, 'rgba(0,0,0,0)'); g.addColorStop(1, `rgba(0,0,0,${.88 * a})`);
      c.fillStyle = g; c.fillRect(0, 0, S, S);
    }
    if (state.reflection > 0) {
      const a = state.reflection / 100; c.save(); c.globalAlpha = .28 * a; c.globalCompositeOperation = 'screen'; c.translate(240, 240); c.rotate(-0.55); c.scale(1, 0.34); const rg = c.createRadialGradient(0, -90, 20, 0, -90, 230); rg.addColorStop(0, 'rgba(255,255,255,.85)'); rg.addColorStop(1, 'rgba(255,255,255,0)'); c.fillStyle = rg; c.beginPath(); c.arc(0, -90, 230, 0, Math.PI * 2); c.fill(); c.restore();
    }
    if (state.scanlines > 0) {
      const a = state.scanlines / 100;
      c.save(); c.fillStyle = `rgba(0,0,0,${.45 * a})`;
      for (let y = 0; y < S; y += 4) c.fillRect(0, y, S, 2);
      c.restore();
    }
    if (state.grain > 0) {
      // Зерно с фиксированным seed: картинка не «мерцает» при каждой перерисовке.
      const rnd = rng(1337), n = Math.round(9000 * state.grain / 100);
      c.save(); c.globalAlpha = .10 * (state.grain / 100); c.fillStyle = '#fff';
      for (let i = 0; i < n; i++) { const x = rnd() * S, y = rnd() * S, sz = rnd() < .7 ? 1 : 2; c.fillRect(x, y, sz, sz); }
      c.restore();
    }
    if (state.bezel > 0) {
      const bw = 2 + state.bezel / 100 * 28;
      c.save(); c.lineWidth = bw; c.strokeStyle = state.bezelColor;
      c.beginPath(); c.arc(cx, cy, dialR - bw / 2, 0, Math.PI * 2); c.stroke();
      c.lineWidth = 1; c.strokeStyle = 'rgba(0,0,0,.45)';
      c.beginPath(); c.arc(cx, cy, dialR - bw - .5, 0, Math.PI * 2); c.stroke();
      c.lineWidth = 1; c.strokeStyle = 'rgba(255,255,255,.35)';
      c.beginPath(); c.arc(cx, cy, dialR - .5, 0, Math.PI * 2); c.stroke();
      c.restore();
    }
    c.restore(); // конец круглой обрезки

    // 5. Затухание краёв — маска по альфа-каналу, поэтому делаем после всего.
    if (state.edgeFade > 0) {
      const fade = state.edgeFade / 100;
      const fadeStart = Math.max(0, dialR - Math.max(1, dialR * fade)) / dialR;
      const mg = tmpCtx.createRadialGradient(cx, cy, 0, cx, cy, dialR);
      mg.addColorStop(0, 'rgba(255,255,255,1)'); mg.addColorStop(Math.min(0.999, fadeStart), 'rgba(255,255,255,1)'); mg.addColorStop(1, 'rgba(255,255,255,0)');
      tmpCtx.setTransform(1, 0, 0, 1, 0, 0); tmpCtx.globalCompositeOperation = 'source-over'; tmpCtx.clearRect(0, 0, S, S);
      tmpCtx.fillStyle = mg; tmpCtx.fillRect(0, 0, S, S);
      c.save(); c.globalCompositeOperation = 'destination-in'; c.drawImage(tmpCv, 0, 0); c.restore();
    }
    targetCtx.drawImage(compCv, padX, padY);
    targetCtx.drawImage(compCv, padX, padY);
  }

  const loadImage = (url) => new Promise((resolve, reject) => {
    const im = new Image();
    im.onload = () => resolve(im);
    im.onerror = () => reject(new Error('Не удалось загрузить изображение фона'));
    im.src = url;
  });

  const approxBytes = (dataUrl) => Math.max(0, Math.round((String(dataUrl).length - String(dataUrl).indexOf(',') - 1) * 3 / 4));

  /** PNG 480×480 (dataURL) фона с применёнными настройками; не-«bg» ресурс возвращается как есть. */
  function render(asset) {
    if (!isBg(asset) || !asset.dataUrl) return Promise.resolve(asset ? asset.dataUrl : null);
    const p = params(asset);
    const key = JSON.stringify(p) + '|' + asset.dataUrl;
    if (cache.has(key)) return cache.get(key);
    const job = loadImage(asset.dataUrl).then((im) => {
      const c = document.createElement('canvas');
      c.width = c.height = 480;
      const cx = c.getContext('2d');
      cx.imageSmoothingEnabled = true; cx.imageSmoothingQuality = 'high';
      paint(cx, im, p, 0, 0);
      return c.toDataURL('image/png');
    });
    cache.set(key, job);
    if (cache.size > MAX_CACHE) cache.delete(cache.keys().next().value);
    job.catch(() => cache.delete(key));
    return job;
  }

  const setRuntime = (asset, url) => {
    Object.defineProperty(asset, 'bgBakedUrl', { value: url || undefined, writable: true, configurable: true, enumerable: false });
  };

  /** Что показывать в предпросмотре: запечённый фон (если есть настройки), иначе как у обычного ресурса. */
  const url = (asset) => (asset && asset.bgBakedUrl) || (typeof AssetShadow !== 'undefined' ? AssetShadow.url(asset) : (asset ? asset.dataUrl : ''));

  /** Обновляет runtime-кэш предпросмотра. Возвращает true, если что-то изменилось. */
  async function refreshAll(assets) {
    let changed = false;
    for (const a of assets || []) {
      if (!a) continue;
      const want = isBg(a) ? await render(a).catch(() => null) : null;
      if ((a.bgBakedUrl || null) !== (want || null)) { setRuntime(a, want); changed = true; }
    }
    return changed;
  }

  /** Копия проекта для экспорта: у фонов с настройками dataUrl заменён на готовый PNG 480×480. */
  async function bakeProject(project) {
    if (!project || !(project.assets || []).some(isBg)) return project;
    const assets = [];
    for (const a of project.assets) {
      if (!isBg(a)) { assets.push(a); continue; }
      const baked = await render(a);
      const copy = Object.assign({}, a, { dataUrl: baked, width: 480, height: 480, format: 'PNG', size: approxBytes(baked) });
      delete copy.bg;
      assets.push(copy);
    }
    return Object.assign({}, project, { assets });
  }

  return { VERSION, DEFAULTS, isBg, params, paint, render, url, refreshAll, bakeProject };
})();

if (typeof window !== 'undefined') window.AssetBg = AssetBg;
