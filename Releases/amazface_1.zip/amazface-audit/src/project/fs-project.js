// src/project/fs-project.js
//
// Проект в обычной папке на диске (File System Access API, window.showDirectoryPicker).
// Классический <script>, без сборки: работает с file:// в Chromium-браузерах
// (Chrome / Edge / Opera). Модуль ничего не знает о редакторе — только о файлах.
//
// Состав папки после сохранения:
//   amazface.project.json     — полное состояние редактора (слои, ресурсы, AOD…)
//   app.json, app.js, …       — реальный проект Zepp OS (результат exportFullProject)
//   watchface/index.js        — сгенерированный код
//   assets/<target>/…         — PNG, шрифты, превью

const FS_STATE_FILE = 'amazface.project.json';
const FS_SKIP_DIRS = new Set(['node_modules', '.git']);
const FS_MAX_DEPTH = 8;
const FS_MAX_READ_BYTES = 25 * 1024 * 1024; // файлы крупнее в память не грузим

class FsProject {
  static supported() {
    return typeof window.showDirectoryPicker === 'function';
  }

  /** Диалог выбора папки с правом записи. Отмена → DOMException AbortError. */
  static pick() {
    return window.showDirectoryPicker({ id: 'amazface-project', mode: 'readwrite' });
  }

  constructor(rootHandle) {
    this.root = rootHandle;
    /** @type {Map<string, {handle: FileSystemFileHandle, size: number, bytes: Uint8Array|null}>} */
    this.files = new Map();
    this._queue = Promise.resolve();
  }

  get name() { return this.root.name; }
  has(path) { return this.files.has(path); }

  /** Рекурсивно читает папку в память (путь с «/» → содержимое). */
  async scan() {
    this.files.clear();
    await this._walk(this.root, '', 0);
    return this.files;
  }

  async _walk(dir, prefix, depth) {
    if (depth > FS_MAX_DEPTH) return;
    for await (const [name, handle] of dir.entries()) {
      const path = prefix + name;
      if (handle.kind === 'directory') {
        if (!FS_SKIP_DIRS.has(name)) await this._walk(handle, path + '/', depth + 1);
      } else {
        const file = await handle.getFile();
        const bytes = file.size <= FS_MAX_READ_BYTES ? new Uint8Array(await file.arrayBuffer()) : null;
        this.files.set(path, { handle, size: file.size, bytes });
      }
    }
  }

  readBytes(path) {
    const entry = this.files.get(path);
    if (!entry) return null;
    if (entry.bytes === null) {
      throw new Error(`Файл «${path}» слишком большой для чтения в редактор (лимит ${Math.round(FS_MAX_READ_BYTES / 1024 / 1024)} MiB). Файл на диске не изменён.`);
    }
    return entry.bytes;
  }

  readText(path) {
    const b = this.readBytes(path);
    return b === null ? null : new TextDecoder().decode(b);
  }

  /** Проверяет относительный путь без молчаливой нормализации. */
  static validatePath(path) {
    if (typeof path !== 'string' || !path.trim()) {
      throw new Error('Путь к файлу не может быть пустым.');
    }
    if (path.includes('\\') || path.startsWith('/') || /^[a-zA-Z]:/.test(path)) {
      throw new Error(`Ожидается относительный путь с разделителями «/»: ${path}`);
    }
    const parts = path.split('/');
    if (parts.some((p) => !p || p === '.' || p === '..')) {
      throw new Error(`Недопустимый путь: ${path}`);
    }
    return parts;
  }

  /**
   * Записывает файл (создаёт вложенные папки). Неизменившиеся файлы не
   * перезаписываются. Операции записи выстраиваются в очередь — автосохранение
   * и ручное «Сохранить» не гоняются друг с другом.
   * @returns {Promise<boolean>} true, если файл реально записан
   */
  write(path, data) {
    const run = () => this._write(path, data);
    this._queue = this._queue.then(run, run);
    return this._queue;
  }

  async _write(path, data) {
    const parts = FsProject.validatePath(path);
    const bytes = typeof data === 'string' ? new TextEncoder().encode(data) : data;
    const old = this.files.get(parts.join('/'));
    if (old && old.bytes && FsProject._same(old.bytes, bytes)) return false;

    const name = parts.pop();
    let dir = this.root;
    for (const p of parts) dir = await dir.getDirectoryHandle(p, { create: true });
    const handle = await dir.getFileHandle(name, { create: true });
    const w = await handle.createWritable();
    try { await w.write(bytes); } finally { await w.close(); }
    this.files.set([...parts, name].join('/'), { handle, size: bytes.length, bytes });
    return true;
  }

  /**
   * Удаляет файл и опустевшие папки над ним (кроме верхнего уровня).
   * Отсутствующий файл — не ошибка.
   * @returns {Promise<boolean>} true, если файл был и удалён
   */
  remove(path) {
    const run = () => this._remove(path);
    this._queue = this._queue.then(run, run);
    return this._queue;
  }

  async _remove(path) {
    const parts = FsProject.validatePath(path);
    const key = parts.join('/');
    const name = parts.pop();
    const chain = [this.root];
    try {
      for (const p of parts) chain.push(await chain[chain.length - 1].getDirectoryHandle(p));
      await chain[chain.length - 1].removeEntry(name);
    } catch (e) {
      this.files.delete(key);
      if (e && (e.name === 'NotFoundError' || e.name === 'TypeMismatchError')) return false;
      throw e;
    }
    this.files.delete(key);
    for (let i = parts.length; i > 1; i--) { // верхнюю папку (assets/) не трогаем
      let empty = true;
      for await (const _ of chain[i].entries()) { empty = false; break; }
      if (!empty) break;
      await chain[i - 1].removeEntry(parts[i - 1]);
    }
    return true;
  }

  /** Проверяет по-настоящему на диске (а не в кэше), что файл существует. */
  async exists(path) {
    const parts = String(path).split('/').filter(Boolean);
    const name = parts.pop();
    try {
      let dir = this.root;
      for (const p of parts) dir = await dir.getDirectoryHandle(p);
      await dir.getFileHandle(name);
      return true;
    } catch (e) { return false; }
  }

  static _same(a, b) {
    if (a.length !== b.length) return false;
    for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
    return true;
  }
}
