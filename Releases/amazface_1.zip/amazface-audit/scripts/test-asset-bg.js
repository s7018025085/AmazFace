// Проверка AssetBg без браузера: фейковый canvas, все эффекты включены (ловит ReferenceError в paint),
// плюс логика isBg/params/bakeProject.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const mkCtx = () => new Proxy({}, {
  get(t, k) {
    if (k in t) return t[k];
    if (k === 'getImageData' || k === 'createImageData') return (x, y, w, h) => { const W = h === undefined ? x : w, H = h === undefined ? y : h; return { data: new Uint8ClampedArray(W * H * 4), width: W, height: H }; };
    if (k === 'createLinearGradient' || k === 'createRadialGradient' || k === 'createConicGradient') return () => ({ addColorStop() {} });
    return () => {};
  },
  set(t, k, v) { t[k] = v; return true; },
});
const mkCanvas = () => ({ width: 0, height: 0, getContext: mkCtx, toDataURL: () => 'data:image/png;base64,AAAA' });
class FakeImage { set src(v) { this.naturalWidth = 1000; this.naturalHeight = 800; setTimeout(() => this.onload && this.onload()); } }
const sandbox = { window: {}, document: { createElement: mkCanvas }, Image: FakeImage, console, setTimeout, JSON, Math, Object, Promise, Uint8ClampedArray, Number, String, Map, Array };
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'src/assets/asset-bg.js'), 'utf8') + '\nthis.AssetBg = AssetBg;', sandbox);
const { AssetBg } = sandbox;

const assert = (c, m) => { if (!c) { console.error('FAIL:', m); process.exit(1); } };
const full = Object.assign({}, AssetBg.DEFAULTS, {
  pixelate: 40, chroma: 50, tint: 30, gradient: 60, gradType: 'conic', bloom: 40, glow: 30, glass: 30, volume: 30,
  vignette: 30, reflection: 30, scanlines: 30, grain: 30, bezel: 30, edgeFade: 20, blur: 3, alpha: 80, rot: 15,
});
for (const gradType of ['linear', 'mirror', 'radial', 'conic']) AssetBg.paint(mkCtx(), new FakeImage(), Object.assign({}, full, { gradType, zoom: 50 }), 0, 0);

const plain = { id: 'a1', name: 'x', dataUrl: 'data:image/png;base64,QQ==', width: 10, height: 10 };
const bg = { id: 'a2', name: 'bg', dataUrl: 'data:image/png;base64,QQ==', width: 1000, height: 800, format: 'PNG', size: 1, bg: { v: 1, params: { zoom: 55, bloom: 20 } } };
assert(!AssetBg.isBg(plain) && AssetBg.isBg(bg), 'isBg');
assert(AssetBg.params(bg).zoom === 55 && AssetBg.params(bg).hue === 0, 'params merge with defaults');
assert(AssetBg.url(plain) === plain.dataUrl, 'url without bake = dataUrl');

(async () => {
  const project = { assets: [plain, bg] };
  assert((await AssetBg.bakeProject({ assets: [plain] })).assets[0] === plain, 'no-bg project passes through untouched');
  assert(await AssetBg.refreshAll(project.assets) === true, 'refreshAll reports change');
  assert(AssetBg.url(bg).startsWith('data:image/png'), 'url uses baked cache');
  assert(JSON.stringify(project).indexOf('bgBakedUrl') < 0, 'runtime cache is not serialised');
  const out = await AssetBg.bakeProject(project);
  const b = out.assets[1];
  assert(b.width === 480 && b.height === 480 && b.format === 'PNG' && !b.bg && b.dataUrl.endsWith('AAAA'), 'bake replaces dataUrl/size, drops bg');
  assert(out.assets[0] === plain, 'plain asset untouched');
  assert(bg.bg.params.zoom === 55 && bg.dataUrl.endsWith('QQ=='), 'project asset itself is not mutated');
  console.log('AssetBg tests passed.');
})();
