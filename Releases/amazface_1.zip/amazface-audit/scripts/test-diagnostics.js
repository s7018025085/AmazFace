// Регрессионный тест валидатора сгенерированного index.js (UNDECLARED_WIDGET и др.).
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert');

const root = path.resolve(__dirname, '..');
const src = fs.readFileSync(path.join(root, 'src/exporter/project-exporter.js'), 'utf8');
const ctx = { console, Math, Date, JSON, window: {}, document: {} };
vm.createContext(ctx);
// В браузере оба файла — обычные <script> в одном глобальном скоупе (index-js-exporter.js раньше project-exporter.js).
for (const rel of ['src/util/slug.js', 'src/components/registry.js', 'src/exporter/index-js-exporter.js']) {
  vm.runInContext(fs.readFileSync(path.join(root, rel), 'utf8'), ctx, { filename: rel });
}
vm.runInContext(src + '\n;globalThis.__diag = diagnoseGeneratedWatchfaceCode;', ctx, { filename: 'project-exporter.js' });
const diag = ctx.__diag;
const undeclared = (code) => diag(code).filter((d) => d.code === 'UNDECLARED_WIDGET');

// 1. Поля объекта (a.w2.setProperty, a.w.setProperty) — не переменные.
assert.strictEqual(undeclared(
  'const a = { w: null, w2: null };\nfunction f(a) {\n  a.w2.setProperty(prop.MORE, {});\n  if (a.w) { a.w.setProperty(prop.MORE, {}); }\n}\n'
).length, 0, 'a.w2.setProperty не должно давать UNDECLARED_WIDGET');

// 2. Параметр функции объявлен.
assert.strictEqual(undeclared('function g(w) { w.setProperty(prop.MORE, {}); }\nconst h = (x) => x.setProperty(1, 2);').length, 0, 'параметры функций объявлены');

// 3. Упоминание в строке/комментарии игнорируется.
assert.strictEqual(undeclared("const s = 'ghost.setProperty(1)'; // ghost.setText(2)").length, 0, 'строки и комментарии не проверяются');

// 4. Настоящая ошибка по-прежнему находится (в т.ч. вторая на той же строке).
assert.strictEqual(undeclared('ghost.setProperty(prop.MORE, {});').length, 1, 'настоящая необъявленная переменная должна ловиться');
assert.strictEqual(undeclared('const ok = 1; ghost.setText(1); phantom.setAlpha(2);').length, 2, 'ловятся все вызовы в строке');

// 5. Объявленная const-переменная — не ошибка.
assert.strictEqual(undeclared('const w1 = createWidget(widget.TEXT, {});\nw1.setProperty(prop.MORE, {});').length, 0);

console.log('Diagnostics tests passed.');
