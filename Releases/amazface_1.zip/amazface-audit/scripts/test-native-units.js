// Нативные данные: единица PAI и вид температуры на часах должны совпадать с редактором.
const path = require('node:path');
const assert = require('node:assert');
const fx = require('./export-fixtures.js');
const root = path.resolve(__dirname, '..');
const ex = fx.loadExporter(root, ['src/anim/text-anim.js', 'src/anim/text-anim-export.js']);

const unitType = (props) => {
  const code = ex.exportIndexJs(fx.project([fx.mk('n1', 'text', Object.assign({ text_size: 30, color: '#fff' }, props))]), {}, {}, {}).code;
  const m = code.match(/unit_type:\s*(\d)/);
  assert.ok(m, 'в коде нет unit_type: ' + JSON.stringify(props));
  return m[1];
};

// PAI: без явной настройки — только число, как в редакторе.
assert.strictEqual(unitType({ data_source: 'PAI_DAILY' }), '0');
assert.strictEqual(unitType({ data_source: 'PAI_WEEKLY' }), '0');
// Явно включили — единица от прошивки включается.
assert.strictEqual(unitType({ data_source: 'PAI_DAILY', native_show_unit: true }), '1');
assert.strictEqual(unitType({ data_source: 'PAI_DAILY', native_show_unit: false }), '0');
// Остальные нативные источники не изменились: по умолчанию единица включена.
assert.strictEqual(unitType({ data_source: 'HUMIDITY' }), '1');
assert.strictEqual(unitType({ data_source: 'HUMIDITY', native_show_unit: false }), '0');
// Погода: знак ° включается/выключается через weather_show_degree.
assert.strictEqual(unitType({ data_source: 'WEATHER_TEMP' }), '1');
assert.strictEqual(unitType({ data_source: 'WEATHER_TEMP', weather_show_degree: false }), '0');
console.log('Native units tests passed.');
