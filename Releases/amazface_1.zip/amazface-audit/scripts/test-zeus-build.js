// Тест сборки через Zeus для GitHub Publishing (без реального zeus: запуск подменён).
// Запуск: node scripts/test-zeus-build.js
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const zlib = require('node:zlib');
const { createZeusBuilder, readZip } = require('../bridge/zeus-build.js');

let passed = 0, failed = 0;
const ok = (n, c, x) => { if (c) { passed++; console.log('ok: ' + n); } else { failed++; console.log('FAIL: ' + n + (x ? ' — ' + x : '')); } };

function crc32(buf) {
  let c, crc = 0xffffffff;
  for (let i = 0; i < buf.length; i++) { c = (crc ^ buf[i]) & 0xff; for (let k = 0; k < 8; k++) c = c & 1 ? (c >>> 1) ^ 0xedb88320 : c >>> 1; crc = (crc >>> 8) ^ c; }
  return (crc ^ 0xffffffff) >>> 0;
}
// Минимальный ZIP-писатель (deflate для .txt/.js/.json, store для остального)
function makeZip(files) {
  const locals = [], central = []; let off = 0;
  for (const [name, data] of Object.entries(files)) {
    const nb = Buffer.from(name), raw = Buffer.from(data);
    const method = /\.(js|json|txt)$/.test(name) ? 8 : 0;
    const body = method === 8 ? zlib.deflateRawSync(raw) : raw;
    const lh = Buffer.alloc(30); lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(method, 8);
    lh.writeUInt32LE(crc32(raw), 14); lh.writeUInt32LE(body.length, 18); lh.writeUInt32LE(raw.length, 22); lh.writeUInt16LE(nb.length, 26);
    const ch = Buffer.alloc(46); ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(20, 4); ch.writeUInt16LE(20, 6); ch.writeUInt16LE(method, 10);
    ch.writeUInt32LE(crc32(raw), 16); ch.writeUInt32LE(body.length, 20); ch.writeUInt32LE(raw.length, 24); ch.writeUInt16LE(nb.length, 28); ch.writeUInt32LE(off, 42);
    locals.push(lh, nb, body); central.push(ch, nb); off += 30 + nb.length + body.length;
  }
  const cd = Buffer.concat(central);
  const e = Buffer.alloc(22); e.writeUInt32LE(0x06054b50, 0); e.writeUInt16LE(Object.keys(files).length, 8); e.writeUInt16LE(Object.keys(files).length, 10);
  e.writeUInt32LE(cd.length, 12); e.writeUInt32LE(off, 16);
  return Buffer.concat([...locals, cd, e]);
}

(async () => {
  const projectZip = makeZip({ 'app.json': '{}', 'package.json': '{}', 'watchface/index.js': 'import x from "@zos/ui"', 'dist/old.zab': 'stale' });
  const deviceZip = makeZip({ 'app.json': '{}', 'app.bin': 'BC', 'watchface/index.bin': 'BC' });
  const zpk = makeZip({ 'device.zip': deviceZip, 'app-side.zip': makeZip({ 'app.json': '{}' }) });
  const zab = makeZip({ 'manifest.json': JSON.stringify({ zpks: [{ name: 'abc.zpk' }] }), 'abc.zpk': zpk });
  const tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'amazface-zb-'));
  const seen = {};

  const run = async (zeus, args, cwd) => {
    seen.args = args; seen.zeus = zeus; seen.hadOldDist = fs.existsSync(path.join(cwd, 'dist', 'old.zab'));
    seen.hasIndex = fs.existsSync(path.join(cwd, 'watchface', 'index.js')); seen.cwd = cwd;
    fs.mkdirSync(path.join(cwd, 'dist'), { recursive: true });
    fs.writeFileSync(path.join(cwd, 'dist', 'new.zab'), zab);
    return { code: 0, out: 'ok' };
  };
  const b = createZeusBuilder({ findZeus: () => 'zeus', run, tmpRoot });
  const r = await b.build(projectZip, {});
  ok('build: вызван «zeus build»', seen.args === 'build');
  ok('build: проект распакован, старый dist/ не взят', seen.hasIndex && !seen.hadOldDist);
  ok('build: .zpk и device.zip извлечены из .zab', r.zpk.equals(zpk) && r.deviceZip.equals(deviceZip) && r.zabName === 'new.zab');
  ok('build: в device.zip байткод', r.deviceFiles.includes('watchface/index.bin') && !r.deviceFiles.includes('watchface/index.js'));
  ok('build: временная папка удалена', !fs.existsSync(seen.cwd));
  ok('readZip: deflate и store читаются', readZip(projectZip).get('watchface/index.js').toString() === 'import x from "@zos/ui"');

  let e = await createZeusBuilder({ findZeus: () => null, tmpRoot }).build(projectZip, {}).catch(x => x);
  ok('нет zeus: понятная ошибка', e && e.code === 'zeus_missing' && /zeus/i.test(e.message));

  e = await createZeusBuilder({ findZeus: () => 'zeus', tmpRoot, run: async () => ({ code: 1, out: 'build failed: boom' }) }).build(projectZip, {}).catch(x => x);
  ok('сбой zeus: код и вывод в сообщении', e && e.code === 'zeus_build' && /boom/.test(e.message));

  e = await createZeusBuilder({ findZeus: () => 'zeus', tmpRoot, run: async () => ({ code: 0, out: '' }) }).build(projectZip, {}).catch(x => x);
  ok('zeus без .zab: ошибка', e && e.code === 'zeus_build');

  e = await createZeusBuilder({ findZeus: () => 'zeus', tmpRoot, run: async () => ({ code: 'timeout', out: 'hang' }) }).build(projectZip, {}).catch(x => x);
  ok('таймаут: ошибка', e && /не завершил/.test(e.message));

  e = await createZeusBuilder({ findZeus: () => 'zeus', tmpRoot }).build(makeZip({ 'app.json': '{}' }), {}).catch(x => x);
  ok('чужой zip отклонён до запуска', e && /не проект/.test(e.message));

  const evil = makeZip({ 'app.json': '{}', 'package.json': '{}', 'watchface/index.js': '1', '../escape.txt': 'x' });
  e = await createZeusBuilder({ findZeus: () => 'zeus', tmpRoot, run }).build(evil, {}).catch(x => x);
  ok('path traversal в архиве отклонён', e && /Небезопасный/.test(e.message) && !fs.existsSync(path.join(tmpRoot, 'escape.txt')));

  console.log(`\n${passed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})();
