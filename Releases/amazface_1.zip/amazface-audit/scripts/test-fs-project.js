const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const assert = require('node:assert/strict');

const source = fs.readFileSync(path.join(__dirname, '../src/project/fs-project.js'), 'utf8');
const context = { window: {}, TextEncoder, TextDecoder, Map, Set, Error, String, Uint8Array };
vm.createContext(context);
vm.runInContext(`${source}\nglobalThis.__FsProject = FsProject;`, context);
const FsProject = context.__FsProject;

for (const valid of ['amazface.project.json', 'assets/dial.png', 'watchface/index.js']) {
  assert.deepEqual(Array.from(FsProject.validatePath(valid)), valid.split('/'));
}
for (const invalid of ['', '/', '/tmp/file', 'C:/temp/file', 'assets\\dial.png', 'assets//dial.png', 'assets/../secret', './file', 'assets/./file']) {
  assert.throws(() => FsProject.validatePath(invalid), undefined, `should reject ${JSON.stringify(invalid)}`);
}
console.log('FsProject path validation tests passed.');
