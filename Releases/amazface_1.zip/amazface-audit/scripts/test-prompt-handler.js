'use strict';
const assert = require('assert');
const {createPromptHandler} = require('../bridge/prompt-handler');
function run(chunks, opts = {}) {
  const sent = [], logs = [];
  const h = createPromptHandler({write: k => sent.push(k), log: s => logs.push(s), settleMs: 5, keyDelayMs: 1, ...opts});
  return new Promise(res => { let i = 0; const tick = () => { if (i < chunks.length) { h.feed(chunks[i++]); setTimeout(tick, 1); } else setTimeout(() => res({sent, logs, h}), 80); }; tick(); });
}
(async () => {
  // 1. Лог из задачи: единственное устройство -> Enter
  let r = await run(['[ℹ] building...\r\n', '? Which device would you like to preview? (Use arrow keys)\r\n', '\x1b[36m> Amazfit Balance 2 \x1b[39m\r\n']);
  assert.deepStrictEqual(r.sent, ['\r\n']); assert(/Balance 2/.test(r.logs.join('')));
  // 2. Несколько устройств, указатель на другом -> стрелки вниз + Enter
  r = await run(['? Which device would you like to preview? (Use arrow keys)\n> Amazfit GTR 4\n  Amazfit Balance\n  Amazfit Balance 2\n']);
  assert.deepStrictEqual(r.sent, ['\x1b[B', '\x1b[B', '\r\n']);
  // 3. Перерисовка списка Inquirer (дважды) — отвечаем один раз
  r = await run(['? Which device would you like to preview? (Use arrow keys)\n> A\n  Amazfit Balance 2\n', '\x1b[2K\x1b[1A? Which device would you like to preview? (Use arrow keys)\n> A\n  Amazfit Balance 2\n']);
  assert.strictEqual(r.sent.filter(x => x === '\r\n').length, 1);
  // 4. Ответ уже дан: строка без «(Use arrow keys)» не триггерит повторно
  r = await run(['? Which device would you like to preview? Amazfit Balance 2\n']);
  assert.deepStrictEqual(r.sent, []);
  // 5. Y/n
  r = await run(['? Overwrite existing build? (Y/n) ']);
  assert.deepStrictEqual(r.sent, ['y\r\n']);
  // 6. Побитно разбитый чанк
  r = await run(['? Which device would you l', 'ike to preview? (Use arrow keys)\n> Amazfit ', 'Balance 2 \n']);
  assert.deepStrictEqual(r.sent, ['\r\n']);
  console.log('prompt-handler: OK');
})().catch(e => { console.error(e); process.exit(1); });
