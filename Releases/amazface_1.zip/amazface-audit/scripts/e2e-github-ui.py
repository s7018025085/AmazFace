# Сквозная проверка интерфейса публикации в настоящем Chromium (Playwright) против стенда
# scripts/e2e-github-env.js. Запуск: python3 scripts/e2e-github-ui.py <key>
import sys, json, re, time, urllib.request
from playwright.sync_api import sync_playwright

KEY = sys.argv[1]
TOKEN = 'github_pat_TESTTOKEN0123456789abcdefABCDEF_xyz'
results = []
def ok(name, cond, extra=''):
    results.append(bool(cond)); print(('ok: ' if cond else 'FAIL: ') + name + ((' — ' + str(extra)) if (extra and not cond) else ''))
def ctl(q): urllib.request.urlopen('http://127.0.0.1:5173/__ctl?' + q).read()
def state(): return json.load(urllib.request.urlopen('http://127.0.0.1:5173/__state'))

with sync_playwright() as p:
    b = p.chromium.launch()
    ctx = b.new_context(accept_downloads=True, viewport={'width': 1400, 'height': 1000})
    page = ctx.new_page()
    errors = []
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.on('console', lambda m: errors.append(m.text) if m.type == 'error' else None)
    page.on('dialog', lambda d: d.accept())
    reqs = []
    page.on('request', lambda r: reqs.append((r.url, r.post_data or '')))
    page.goto('http://127.0.0.1:5173/')
    page.wait_for_timeout(600)
    if page.locator('#welcome-skip').is_visible(): page.click('#welcome-skip')
    page.click('#act-demo')
    page.wait_for_timeout(300)

    def open_dialog():
        page.click('#export-menu-btn'); page.click('#act-github-publish')
        page.wait_for_selector('#github-dialog[open]')
    open_dialog()
    page.wait_for_function("document.getElementById('gh-bridge-status').textContent.includes('код')")
    ok('ui: кнопка есть в меню экспорта, остальные кнопки на месте', all(page.locator(s).count() == 1 for s in ['#act-export-project', '#act-export-direct', '#act-export-zpk', '#act-zeus-preview', '#act-github-publish']))
    ok('ui: без кода доступа публикация недоступна', page.is_disabled('#gh-publish') and page.is_visible('#gh-key-row'))
    page.fill('#gh-key', 'wrong'); page.click('#gh-key-save'); page.wait_for_timeout(500)
    ok('ui: неверный код доступа отклонён', 'не подошёл' in page.inner_text('#gh-bridge-status'))
    page.fill('#gh-key', KEY); page.click('#gh-key-save')
    page.wait_for_function("document.getElementById('gh-bridge-status').textContent.includes('Мост работает')")
    ok('ui: верный код принят', not page.is_visible('#gh-key-row'))

    # неверный токен
    page.fill('#gh-repo', 'tester/faces'); page.fill('#gh-folder', 'watchfaces/Balance2')
    page.fill('#gh-token', 'github_pat_WRONGTOKEN0123456789abcdefABC'); page.click('#gh-connect')
    page.wait_for_function("(t=>t.length>20&&!t.startsWith('Проверяю'))(document.getElementById('gh-connect-status').textContent)")
    ok('ui: неверный токен → понятная ошибка, поле очищено', 'токен' in page.inner_text('#gh-connect-status').lower() and page.input_value('#gh-token') == '')
    # приватный репозиторий
    ctl('private=1')
    page.fill('#gh-token', TOKEN); page.click('#gh-connect')
    page.wait_for_function("document.getElementById('gh-connect-status').textContent.includes('приватный')")
    ok('ui: приватный репозиторий отклонён с объяснением', True)
    ctl('private=0')
    page.fill('#gh-token', TOKEN); page.click('#gh-connect')
    page.wait_for_function("document.getElementById('gh-connect-status').textContent.includes('Доступ подтверждён')")
    ok('ui: подключение успешно, токен очищен из поля', page.input_value('#gh-token') == '' and 'Подключено' in page.inner_text('#gh-connected-text'))
    page.wait_for_timeout(200)
    ok('ui: список файлов публикации показан', 'watchfaces/Balance2/' in page.inner_text('#gh-files') and '.zpk' in page.inner_text('#gh-files'))

    # публикация
    page.click('#gh-publish')
    ok('ui: во время публикации кнопка заблокирована', page.is_disabled('#gh-publish'))
    page.wait_for_selector('#gh-qr img', timeout=120000)
    st = state()
    steps = page.locator('#gh-steps li.done').count()
    ok('ui: все 8 этапов выполнены', steps == 8, steps)
    ok('ui: 6 файлов в репозитории', len(st['files']) == 6, st['files'])
    ok('ui: .zpk — установочный .zpk (app-side.zip + device.zip)', st['zpkSize'] > 1000)
    url1 = page.inner_text('#gh-qr-text')
    ok('ui: QR-строка в формате zpkd1://', url1.startswith('zpkd1://raw.githubusercontent.com/tester/faces/main/watchfaces/Balance2/'), url1)
    ok('ui: в репозиторий не попал токен', not st['anyTokenInRepo'])
    with page.expect_download() as d: page.click('#gh-qr-png')
    png = d.value.path()
    try:
        import cv2
        img = cv2.imread(str(png)); val, _, _ = cv2.QRCodeDetector().detectAndDecode(cv2.resize(img, None, fx=1, fy=1, interpolation=cv2.INTER_NEAREST))
        ok('qr: PNG декодируется сторонним декодером (OpenCV) в ту же строку', val == url1, val)
    except ImportError:
        print('skip: OpenCV не установлен')
    with page.expect_download() as d2: page.click('#gh-qr-svg')
    ok('ui: SVG скачивается', open(d2.value.path(), encoding='utf8').read().lstrip().startswith('<'))
    page.screenshot(path='/tmp/gh-ui-success.png', full_page=False)

    # редактирование проекта после публикации → предупреждение
    page.click('#gh-close'); 
    page.evaluate("store.state.components[0].x += 7; store.commit()")
    open_dialog(); page.wait_for_timeout(500)
    ok('ui: после правки проекта QR помечен как относящийся к прежней версии', 'изменён после публикации' in page.inner_text('#gh-qr-warn'))

    # повторная публикация, CDN отстаёт
    ctl('rawLag=3')
    page.click('#gh-publish'); page.wait_for_function("document.querySelectorAll('#gh-steps li.done').length===8 || document.querySelectorAll('#gh-steps li.failed').length>0", timeout=120000)
    ok('ui: повтор с отстающим CDN доводится до конца', page.locator('#gh-steps li.done').count() == 8, page.inner_text('#gh-msg'))
    ok('ui: постоянная ссылка не изменилась', page.inner_text('#gh-qr-text') == url1)
    st2 = state()
    ok('ui: содержимое .zpk обновилось (другой sha256)', st2['zpkSha256'] != st['zpkSha256'] and len(st2['files']) == 6)
    ctl('rawLag=0')

    # частичный сбой и «Повторить»
    page.evaluate("store.state.components[0].x += 5; store.commit()")
    ctl('failPut=device.zip&times=1')
    page.click('#gh-publish'); page.wait_for_selector('#gh-retry:not([hidden])', timeout=120000)
    msg = page.inner_text('#gh-msg')
    ok('ui: частичный сбой → сказано что загружено, а что нет', 'Загружено файлов' in msg and 'device.zip' in msg and 'Повторить' in msg, msg)
    ok('ui: QR при сбое не показан', not page.is_visible('#gh-result'))
    ctl('clearHooks=1')
    page.click('#gh-retry'); page.wait_for_selector('#gh-qr img', timeout=120000)
    ok('ui: «Повторить» завершает публикацию', page.locator('#gh-steps li.done').count() == 8)

    # перезагрузка: настройки сохраняются, повторный ввод не нужен
    page.reload(); page.wait_for_timeout(600)
    if page.locator('#welcome-skip').is_visible(): page.click('#welcome-skip')
    open_dialog()
    page.wait_for_function("document.getElementById('gh-connected-text').textContent.includes('Подключено')")
    ok('ui: после перезагрузки подключение и настройки сохранены', page.input_value('#gh-repo') == 'tester/faces' and not page.is_disabled('#gh-publish'))

    # токен нигде в браузере
    dump = page.evaluate("JSON.stringify([Object.entries(localStorage), Object.entries(sessionStorage), document.documentElement.innerHTML.includes('%s')])" % TOKEN)
    ok('secrets: токена нет в localStorage/sessionStorage/DOM', TOKEN not in dump and not json.loads(dump)[2])
    leaked = [u for (u, body) in reqs if TOKEN in u]
    ok('secrets: токен не передавался в URL', not leaked)
    bodies = [u for (u, body) in reqs if TOKEN in body]
    ok('secrets: токен уходил только в одном запросе — /github/connect на мост', all(u.endswith('/github/connect') for u in bodies) and len(bodies) <= 2, bodies)
    # Два ожидаемых HTTP 400 — наши негативные проверки (неверный токен, приватный репозиторий).
    unexpected = [e for e in errors if 'status of 400' not in e]
    ok('console: ошибок JavaScript нет (кроме двух ожидаемых 400 от негативных проверок)', not unexpected and len(errors) - len(unexpected) == 2, errors[:4])
    page.click('#gh-close')

    # регрессия соседних экспортёров в том же браузере
    with page.expect_download() as dp:
        page.click('#export-menu-btn'); page.click('#act-export-project')
    ok('regression: «Проект .zip» по-прежнему экспортируется', dp.value.suggested_filename.endswith('.zip'))
    with page.expect_download() as dd:
        page.click('#export-menu-btn'); page.click('#act-export-direct')
    ok('regression: «Direct ZIP» по-прежнему экспортируется', dd.value.suggested_filename.endswith('.device.zip'))
    page.click('#export-menu-btn'); page.click('#act-export-zpk'); page.wait_for_selector('#zpk-dialog[open]')
    with page.expect_download() as dz: page.click('#zpk-build')
    ok('regression: «ZPK + QR» по-прежнему собирает .zpk', dz.value.suggested_filename.endswith('.zpk'))
    page.fill('#zpk-url', 'https://example.com/a.zpk'); page.click('#zpk-make-qr')
    ok('regression: «ZPK + QR» по-прежнему генерирует QR', page.locator('#zpk-qr-out img').count() == 1)
    b.close()

print('\nUI-проверка: %d прошло, %d упало.' % (sum(results), len(results) - sum(results)))
sys.exit(0 if all(results) else 1)
