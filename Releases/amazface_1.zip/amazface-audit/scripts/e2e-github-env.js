// Стенд для ручной/автоматической проверки интерфейса публикации без интернета:
// поддельный GitHub + настоящие маршруты моста на 127.0.0.1:17865 + статика редактора на :5173.
// Запуск: node scripts/e2e-github-env.js   (останавливается Ctrl+C)
const http = require('node:http');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { createFakeGithub, TOKEN } = require('./fake-github.js');
const { createGithubRoutes } = require('../bridge/github-routes.js');
const { createPublisher, createConfigStore } = require('../bridge/github-publisher.js');

const root = path.resolve(__dirname, '..');
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.png': 'image/png', '.svg': 'image/svg+xml' };

(async () => {
  const gh = createFakeGithub();
  await new Promise(r => gh.server.listen(0, '127.0.0.1', r));
  const base = 'http://127.0.0.1:' + gh.server.address().port;
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'amazface-e2e-'));
  const store = createConfigStore({ dir, platform: 'linux' });
  const publisher = createPublisher({ store, apiBase: base, rawBase: base + '/raw', cdnPollMs: 300, cdnTimeoutMs: 6000, pauseBetweenUploadsMs: 0, backoffMs: 20 });
  const routes = createGithubRoutes({ store, publisher });
  const bridge = http.createServer((req, res) => {
    if (routes.matches(req)) return routes.handle(req, res);
    res.writeHead(404); res.end();
  });
  await new Promise(r => bridge.listen(17865, '127.0.0.1', r));

  const web = http.createServer((req, res) => {
    const u = new URL(req.url, 'http://x');
    if (u.pathname === '/__ctl') {
      if (u.searchParams.has('rawLag')) gh.rawLag = Number(u.searchParams.get('rawLag'));
      if (u.searchParams.has('failPut')) { const sfx = u.searchParams.get('failPut'); let left = Number(u.searchParams.get('times') || 1); gh.hooks.put = (fp) => (fp.endsWith(sfx) && left-- > 0) ? { status: 403, body: { message: 'Resource not accessible by personal access token' } } : null; }
      if (u.searchParams.has('clearHooks')) gh.hooks.put = null;
      if (u.searchParams.has('private')) gh.repo.private = u.searchParams.get('private') === '1';
      res.writeHead(200); return res.end('ok');
    }
    if (u.pathname === '/__state') {
      const zpk = [...gh.files.entries()].find(([k]) => k.endsWith('.zpk'));
      res.writeHead(200, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ files: [...gh.files.keys()], putCount: gh.putCount, zpkSha256: zpk ? crypto.createHash('sha256').update(zpk[1].bytes).digest('hex') : null, zpkSize: zpk ? zpk[1].bytes.length : 0, token: TOKEN, anyTokenInRepo: [...gh.files.values()].some(f => f.bytes.includes(Buffer.from(TOKEN))) }));
    }
    let p = decodeURIComponent(u.pathname); if (p === '/') p = '/index.html';
    const f = path.join(root, p);
    if (!f.startsWith(root) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); return res.end('nf'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream' });
    fs.createReadStream(f).pipe(res);
  });
  await new Promise(r => web.listen(5173, '127.0.0.1', r));
  console.log('READY key=' + routes.bridgeKey() + ' token=' + TOKEN);
})();
