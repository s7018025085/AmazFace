// Проверка экспорта компонента «Дуга»: генерируется валидный JS, нужные импорты и виджеты.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.resolve(__dirname, '..');
const ctx = { console, Math, Date, JSON, window: {} };
vm.createContext(ctx);
const load = (rel) => vm.runInContext(fs.readFileSync(path.join(root, rel), 'utf8'), ctx, { filename: rel });
// top-level const из классических скриптов не попадают в global — добавляем экспорт в context.
for (const rel of ['src/util/slug.js', 'src/components/registry.js', 'src/exporter/index-js-exporter.js']) {
  const src = fs.readFileSync(path.join(root, rel), 'utf8');
  vm.runInContext(src + '\n;globalThis.__ex = Object.assign(globalThis.__ex || {}, {' +
    ['REGISTRY', 'exportIndexJs', 'exportIndexJsDual'].filter((n) => src.includes(`const ${n}`) || src.includes(`function ${n}`)).join(',') + '});', ctx, { filename: rel });
}
const { REGISTRY, exportIndexJs } = ctx.__ex;

function mk(props, id = 'arc1') {
  return { id, defId: 'arc', x: 20, y: 20, w: 200, h: 200, props: Object.assign({}, props) };
}
function run(comps) {
  const project = { device: { w: 480, h: 480 }, components: comps, assets: [], fonts: [], background: {} };
  return exportIndexJs(project, {}, {}, {});
}
let failed = 0;
function check(name, cond, extra) { if (!cond) { failed++; console.error('FAIL:', name, extra || ''); } else console.log('ok:', name); }
function syntaxOk(code) { try { new vm.Script(code.replace(/^import .*$/gm, '')); return true; } catch (e) { return e.message; } }

// 1. Статическая дуга — как раньше
let r = run([mk({ start_angle: 0, end_angle: 270 })]);
check('static: syntax', syntaxOk(r.code) === true, syntaxOk(r.code));
check('static: angles shifted by -90 (0°=12h → -90, 270° → 180)', /widget\.ARC, \{[^}]*start_angle: -90[^}]*end_angle: 180/.test(r.code), r.code.match(/widget\.ARC.*/)?.[0]);
check('static: no timers', !r.code.includes('_set('));

// 2. Батарея + подложка + скругление + альфа + анимация
r = run([mk({ data_source: 'BATTERY', rounded_ends: true, alpha: 60, track_enabled: true, anim_enabled: true, anim_type: 'FADE_FILL', anim_duration: 900 })]);
check('battery: syntax', syntaxOk(r.code) === true, syntaxOk(r.code));
check('battery: Battery import', /import \{[^}]*Battery[^}]*\} from '@zos\/sensor'/.test(r.code));
check('battery: timer import', r.code.includes("from '@zos/timer'"));
check('battery: track widget', r.code.includes('_track = createWidget(widget.ARC'));
check('battery: no Date.now / setAlpha(0)', !r.code.includes('Date.now') && !r.code.includes('setAlpha(0)'));
check('battery: corner_flag', r.code.includes('corner_flag: 1'));
check('battery: _set called from sensor tick', /_tickSensors[\s\S]*_set\(/.test(r.code));
check('battery: warning about unverified', r.validation.warnings.some((w) => w.includes('ARC')));

// 3. Секунды, GROW, без анимации
r = run([mk({ data_source: 'SECOND' }), mk({ data_source: 'HOUR', anim_enabled: true, anim_type: 'GROW', anim_easing: 'LINEAR' }, 'arc2')]);
check('time: syntax', syntaxOk(r.code) === true, syntaxOk(r.code));
check('time: Time import', /import \{[^}]*Time[^}]*\} from '@zos\/sensor'/.test(r.code));
check('time: seconds expr', r.code.includes('now.getSeconds() / 60'));
check('time: grow line_width', r.code.includes('line_width: Math.max(1, Math.round('));
check('time: full prop set in MORE', /prop\.MORE, \{ x: 20, y: 20, w: 200, h: 200, start_angle: -90/.test(r.code));

// 4. Шаги с целью, OVERSHOOT, статика с анимацией
r = run([mk({ data_source: 'STEP', value_max: 8000, anim_enabled: true, anim_type: 'OVERSHOOT' }), mk({ anim_enabled: true }, 'arc3')]);
check('steps: syntax', syntaxOk(r.code) === true, syntaxOk(r.code));
check('steps: custom max', r.code.includes('/ 8000'));
check('static anim: starts via _set(1)', /_set\(1\);/.test(r.code));

// 4b. SWEEP (спидометр): до упора и откат к значению
r = run([mk({ data_source: 'BATTERY', anim_enabled: true, anim_type: 'SWEEP', anim_easing: 'EASE_IN_OUT' }), mk({ data_source: 'STEP', anim_enabled: true, anim_type: 'SWEEP', gradient_enabled: true }, 'arc4')]);
check('sweep: syntax', syntaxOk(r.code) === true, syntaxOk(r.code));
check('sweep: two-phase fill', /k < 0\.5 \?[\s\S]*1 - \(1 - \w*arc1_target\)/.test(r.code));
check('sweep: starts from 0', /arc1_draw\(0, 0, 0\)/.test(r.code));

// 5. Повтор анимации при пробуждении
r = run([mk({ data_source: 'BATTERY', anim_enabled: true, anim_replay: true })]);
check('replay: syntax', syntaxOk(r.code) === true, syntaxOk(r.code));
check('replay: replay fn', /function \w*arc1_replay\(\)/.test(r.code));
check('replay: delegate widget', r.code.includes('widget.WIDGET_DELEGATE') && /resume_call[\s\S]*arc1_replay\(\)/.test(r.code));
r = run([mk({ data_source: 'BATTERY', anim_enabled: true })]);
check('no replay: no delegate', !r.code.includes('WIDGET_DELEGATE'));

// 6. Градиент сегментами
r = run([mk({ data_source: 'STEP', gradient_enabled: true, color: '#ff0000', color2: '#0000ff', gradient_steps: 8, anim_enabled: true, anim_type: 'FADE_FILL', anim_replay: true, rounded_ends: true })]);
check('grad: syntax', syntaxOk(r.code) === true, syntaxOk(r.code));
check('grad: 8 segment colors, first red last blue', /_c = \[0xff0000,[^\]]*0x0000ff\]/.test(r.code), r.code.match(/_c = \[[^\]]*\]/)?.[0]);
check('grad: segments created in loop', r.code.includes('_segs.push(createWidget(widget.ARC'));
check('grad: draw updates only changed segments', r.code.includes('_last[') && r.code.includes('setProperty(prop.MORE'));
check('grad: fade mixes per segment', r.code.includes('_mixc('));
check('grad: no corner_flag', !r.code.includes('corner_flag'));
check('grad: replay still wired', r.code.includes('_replay()'));
r = run([mk({ gradient_enabled: true, gradient_steps: 4, start_angle: 0, end_angle: 180 })]);
check('grad static: full segments, no timers', syntaxOk(r.code) === true && !r.code.includes('_set(') && /_segs\.push/.test(r.code));

// 7. Сегменты: промежуток, скругление, подложка
r = run([mk({ segments_enabled: true, gradient_steps: 10, segment_gap: 4, segment_rounded: true, track_enabled: true, data_source: 'BATTERY', anim_enabled: true, anim_type: 'FILL' })]);
check('seg: syntax', syntaxOk(r.code) === true, syntaxOk(r.code));
check('seg: corner_flag on segments + track', (r.code.match(/corner_flag: 1/g) || []).length === 2);
check('seg: segmented track', r.code.includes('_trk.push(createWidget(widget.ARC'));
check('seg: empty rounded segment hidden via VISIBLE', r.code.includes('prop.VISIBLE'));
check('seg: single color (no gradient)', (r.code.match(/_c = \[([^\]]*)\]/)[1].split(',').map((x) => x.trim()).filter((v, i, arr) => arr.indexOf(v) === i)).length === 1);
r = run([mk({ segments_enabled: true, gradient_steps: 6, segment_gap: 5, start_angle: 0, end_angle: 270 })]);
const bs = r.code.match(/_b = \[([^\]]*)\]/)[1].split(',').map(Number), as = r.code.match(/_a = \[([^\]]*)\]/)[1].split(',').map(Number);
check('seg: gaps between segments are 5°', as.slice(1).every((a, i) => Math.abs(a - bs[i] - 5) <= 1), JSON.stringify({ as, bs }));
check('seg: first starts at -90, last ends at 180', as[0] === -90 && bs[bs.length - 1] === 180, JSON.stringify({ as, bs }));
r = run([mk({ segments_enabled: true, gradient_steps: 48, segment_gap: 30, start_angle: 0, end_angle: 90 })]);
const as2 = r.code.match(/_a = \[([^\]]*)\]/)[1].split(',').map(Number), bs2 = r.code.match(/_b = \[([^\]]*)\]/)[1].split(',').map(Number);
check('seg: huge gap is clamped (every segment keeps length)', as2.every((a, i) => bs2[i] > a - 1) && bs2[47] <= 0, JSON.stringify({ as2, bs2 }));

// 8. Повтор при поднятии руки
r = run([mk({ data_source: 'BATTERY', anim_enabled: true, anim_replay_raise: true })]);
check('raise: syntax', syntaxOk(r.code) === true, syntaxOk(r.code));
check('raise: Screen import', /import \{[^}]*Screen[^}]*\} from '@zos\/sensor'/.test(r.code));
check('raise: onChange + replay', r.code.includes('_scr.onChange(self._screenCb)') && /_raise\('screen on'\)/.test(r.code) && /_replay\(\);/.test(r.code));
check('raise: no resume delegate when only raise', !r.code.includes('WIDGET_DELEGATE'));
check('raise: cleanup in onDestroy', r.code.includes('offChange(this._screenCb)') && r.code.includes('_raiseTimer'));
r = run([mk({ data_source: 'BATTERY', anim_enabled: true })]);
check('no raise: no Screen', !r.code.includes('new Screen()'));

if (failed) { console.error(`\n${failed} проверок не прошли`); process.exit(1); }
console.log('\nВсе проверки экспорта дуги прошли.');
