// Тесты GitHub Publishing: поддельный GitHub (API + raw CDN) на loopback.
// Запуск: node scripts/test-github-publisher.js
const http = require('node:http');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const Gh = require('../src/exporter/github-paths.js');
const { createPublisher, createConfigStore, gitBlobSha } = require('../bridge/github-publisher.js');
const { createGithubRoutes } = require('../bridge/github-routes.js');

let passed = 0, failed = 0;
function ok(name, cond, extra) {
  if (cond) { passed++; console.log('ok: ' + name); }
  else { failed++; console.log('FAIL: ' + name + (extra ? ' — ' + extra : '')); }
}
const { createFakeGithub, TOKEN, OWNER, REPO } = require('./fake-github.js');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'amazface-gh-test-'));
function zipLike(label, withManifest) {
  return Buffer.concat([Buffer.from([0x50, 0x4b, 0x03, 0x04]), Buffer.from(label + (withManifest ? ' device.zip ' : ' ')), crypto.randomBytes(2048)]);
}
function artifacts(tag, o) {
  o = o || {};
  return {
    zpk: zipLike('zpk-' + tag, o.manifest !== false), deviceZip: zipLike('device-' + tag), projectZip: zipLike('project-' + tag),
    json: Buffer.from(JSON.stringify(o.json || { meta: { name: 'Hamilton' }, tag }))
  };
}
const SETTINGS = { owner: OWNER, repo: REPO, branch: 'main', folder: 'watchfaces/Balance2' };

async function waitJob(pub, id, ms) {
  const t0 = Date.now();
  for (;;) {
    const j = pub.getJob(id);
    if (j && j.status !== 'running') return j;
    if (Date.now() - t0 > (ms || 8000)) throw new Error('job timeout');
    await new Promise(r => setTimeout(r, 5));
  }
}

async function main() {
  // ───── 0. общие функции путей ─────
  ok('paths: корректная папка нормализуется', Gh.normalizeFolder('/watchfaces/Balance2/') === 'watchfaces/Balance2');
  for (const bad of ['../x', 'a/../b', 'a\\b', '.git/x', 'a b', 'a//..//b']) {
    let threw = false; try { Gh.normalizeFolder(bad); } catch (e) { threw = true; }
    ok(`paths: папка «${bad}» отклонена`, threw);
  }
  ok('paths: parseRepoRef принимает URL', JSON.stringify(Gh.parseRepoRef('https://github.com/tester/faces.git')) === JSON.stringify({ owner: 'tester', repo: 'faces' }));
  const tp = Gh.targetPaths({ folder: 'watchfaces/Balance2', slug: 'Hamilton' });
  ok('paths: структура файлов как в ТЗ', tp.files.zpk === 'watchfaces/Balance2/Hamilton/Hamilton.zpk' && tp.files.json.endsWith('Hamilton/Hamilton.watchface.json') && tp.files.deviceZip.endsWith('/device.zip') && tp.files.projectZip.endsWith('/project.zip') && tp.files.readme.endsWith('/README.md'));
  ok('paths: raw URL строится из подтверждённых частей', Gh.rawUrl({ owner: 'u', repo: 'r', branch: 'main', path: tp.files.zpk }) === 'https://raw.githubusercontent.com/u/r/main/watchfaces/Balance2/Hamilton/Hamilton.zpk');
  ok('paths: небезопасный slug очищается', Gh.normalizeSlug('../evil name') === 'evil_name');

  // ───── фикстура ─────
  const gh = createFakeGithub();
  await new Promise(r => gh.server.listen(0, '127.0.0.1', r));
  const base = 'http://127.0.0.1:' + gh.server.address().port;
  const logs = [];
  const sleeps = [];
  const store = createConfigStore({ dir: path.join(tmp, 'cfg'), platform: 'linux' });
  const pub = createPublisher({
    store, apiBase: base, rawBase: base + '/raw', log: m => logs.push(m),
    sleep: (ms, signal) => { sleeps.push(ms); if (signal && signal.aborted) return Promise.reject(Object.assign(new Error('Операция отменена.'), { code: 'cancelled' })); return new Promise(r => setImmediate(r)); },
    cdnTimeoutMs: 60000, cdnPollMs: 10000, pauseBetweenUploadsMs: 0, backoffMs: 1, apiTimeoutMs: 3000, uploadTimeoutMs: 3000
  });

  // ───── 1. подключение ─────
  let err = await pub.connect({ ...SETTINGS, token: 'github_pat_WRONGTOKEN0123456789abcdefABC' }).catch(e => e);
  ok('connect: неверный токен → понятная ошибка 401', err && err.code === 'auth' && /токен/i.test(err.message));
  ok('connect: после отказа токен не сохранён', (await pub.status()).connected === false && !store.read().secret);

  gh.repo.exists = false;
  err = await pub.connect({ ...SETTINGS, token: TOKEN }).catch(e => e);
  ok('connect: репозиторий не найден', err && err.code === 'repo_not_found');
  gh.repo.exists = true;

  gh.repo.permissions = { push: false };
  err = await pub.connect({ ...SETTINGS, token: TOKEN }).catch(e => e);
  ok('connect: нет прав на запись', err && err.code === 'no_write');
  gh.repo.permissions = { push: true };

  gh.repo.private = true;
  err = await pub.connect({ ...SETTINGS, token: TOKEN }).catch(e => e);
  ok('connect: приватный репозиторий отклонён', err && err.code === 'repo_private');
  gh.repo.private = false;

  err = await pub.connect({ ...SETTINGS, branch: 'nope', token: TOKEN }).catch(e => e);
  ok('connect: отсутствующая ветка', err && err.code === 'branch_not_found' && /nope/.test(err.message));

  err = await pub.connect({ ...SETTINGS, folder: '../x', token: TOKEN }).catch(e => e);
  ok('connect: небезопасная папка отклонена до запросов', err && /папк|путь|Недопустим/i.test(err.message));

  err = await pub.connect({ ...SETTINGS, token: 'коротко' }).catch(e => e);
  ok('connect: токен неверного вида отклонён локально', err && err.code === 'bad_token');

  let st = await pub.connect({ ...SETTINGS, token: TOKEN });
  ok('connect: успех, возвращается логин и способ хранения', st.connected && st.login === 'tester' && st.protection === 'file-0600');
  ok('connect: токен не возвращается клиенту', !JSON.stringify(st).includes(TOKEN));
  const cfgFile = store.file;
  ok('config: файл с правами 0600', (fs.statSync(cfgFile).mode & 0o777) === 0o600);
  ok('config: настройки сохранены для следующих публикаций', store.read().settings.folder === 'watchfaces/Balance2');
  const pub2 = createPublisher({ store, apiBase: base, rawBase: base + '/raw' });
  ok('config: после «перезапуска моста» подключение сохраняется без повторного ввода', (await pub2.status()).connected === true);

  // ───── 2. успешная публикация ─────
  const A1 = artifacts('v1');
  let job = await pub.startPublish({ slug: 'Hamilton', appId: 1234567, name: 'Hamilton', version: '1.0.0', artifacts: A1 });
  job = await waitJob(pub, job.id);
  ok('publish: завершена успешно', job.status === 'done', JSON.stringify(job.error));
  const P = Gh.targetPaths({ folder: 'watchfaces/Balance2', slug: 'Hamilton' });
  ok('publish: все 6 файлов в репозитории по путям из ТЗ', Object.entries(P.files).filter(([k]) => k !== 'watchQr').every(([, f]) => gh.files.has(f)));
  ok('publish: без картинки watch-qr.png не создаётся и README без картинки', !gh.files.has(P.files.watchQr) && !/watch-qr\.png/.test(gh.files.get(P.files.readme).bytes.toString('utf8')));
  ok('publish: .zpk загружен байт-в-байт', gh.files.get(P.files.zpk).bytes.equals(A1.zpk));
  ok('publish: device.zip и project.zip — свои файлы, а не .zpk', gh.files.get(P.files.deviceZip).bytes.equals(A1.deviceZip) && gh.files.get(P.files.projectZip).bytes.equals(A1.projectZip));
  ok('publish: .zpk загружается последним', gh.putLog[gh.putLog.length - 1].path === P.files.zpk && gh.putLog[0].path === P.files.marker);
  ok('publish: ссылка постоянная и из подтверждённых данных', job.result.zpkUrl === 'https://raw.githubusercontent.com/tester/faces/main/watchfaces/Balance2/Hamilton/Hamilton.zpk');
  ok('publish: deep link zpkd1://', job.result.deepLink === 'zpkd1://raw.githubusercontent.com/tester/faces/main/watchfaces/Balance2/Hamilton/Hamilton.zpk');
  const readme = gh.files.get(P.files.readme).bytes.toString('utf8');
  ok('publish: README содержит версию, дату, инструкцию и ссылку', /1\.0\.0/.test(readme) && /Опубликовано/.test(readme) && /Установка/.test(readme) && readme.includes(job.result.zpkUrl));
  ok('publish: ссылка проверялась без авторизации', gh.authSeen.filter(a => a.startsWith('raw:')).every(a => a === 'raw:'));
  ok('publish: все шаги отмечены выполненными', job.steps.every(s => s.status === 'done'));
  ok('publish: итог содержит ссылки на репозиторий и папку', /github\.com\/tester\/faces/.test(job.result.repoUrl) && /tree\/main\/watchfaces/.test(job.result.folderUrl));

  // ───── Zeus build: пакет для часов берётся из `zeus build`, а не из браузера ─────
  {
    const builtZpk = zipLike('zeus-zpk', true), builtDevice = zipLike('zeus-device');
    let gotProject = null;
    const pubZ = createPublisher({
      store, apiBase: base, rawBase: base + '/raw', log: m => logs.push(m),
      sleep: () => new Promise(r => setImmediate(r)),
      cdnTimeoutMs: 60000, cdnPollMs: 10000, pauseBetweenUploadsMs: 0, backoffMs: 1, apiTimeoutMs: 3000, uploadTimeoutMs: 3000,
      zeusBuild: async (projectZip) => { gotProject = projectZip; return { zpk: builtZpk, deviceZip: builtDevice, zabName: 'x.zab' }; }
    });
    const AZ = artifacts('browser');
    let jz = await waitJob(pubZ, (await pubZ.startPublish({ slug: 'ZeusFace', appId: 4242, name: 'ZeusFace', version: '1.0.0', artifacts: AZ })).id);
    const PZ = Gh.targetPaths({ folder: 'watchfaces/Balance2', slug: 'ZeusFace' });
    ok('zeus: публикация завершена', jz.status === 'done', JSON.stringify(jz.error));
    ok('zeus: в сборку ушёл project.zip из запроса', gotProject && gotProject.equals(AZ.projectZip));
    ok('zeus: .zpk в репозитории — из Zeus, не из браузера', gh.files.get(PZ.files.zpk).bytes.equals(builtZpk) && !gh.files.get(PZ.files.zpk).bytes.equals(AZ.zpk));
    ok('zeus: device.zip в репозитории — из Zeus', gh.files.get(PZ.files.deviceZip).bytes.equals(builtDevice));
    ok('zeus: project.zip — исходный проект', gh.files.get(PZ.files.projectZip).bytes.equals(AZ.projectZip));
    const mk = JSON.parse(gh.files.get(PZ.files.marker).bytes.toString('utf8'));
    ok('zeus: хэши в служебном файле соответствуют пакету Zeus', mk.files['ZeusFace.zpk'].sha256 === require('node:crypto').createHash('sha256').update(builtZpk).digest('hex'));
    ok('zeus: шаг сборки отмечен выполненным', jz.steps.find(x => x.id === 'zeus-build').status === 'done');

    const putsBefore = gh.putLog.length;
    const pubFail = createPublisher({
      store, apiBase: base, rawBase: base + '/raw', log: () => {}, sleep: () => new Promise(r => setImmediate(r)),
      pauseBetweenUploadsMs: 0, backoffMs: 1, apiTimeoutMs: 3000, uploadTimeoutMs: 3000,
      zeusBuild: async () => { throw Object.assign(new Error('Команда zeus не найдена в PATH.'), { code: 'zeus_missing' }); }
    });
    jz = await waitJob(pubFail, (await pubFail.startPublish({ slug: 'ZeusFace', appId: 4242, name: 'ZeusFace', version: '1.0.1', artifacts: artifacts('browser2') })).id);
    ok('zeus: нет zeus → публикация остановлена с понятной ошибкой', jz.status === 'failed' && jz.error && jz.error.code === 'zeus_missing');
    ok('zeus: при сбое сборки в репозиторий ничего не записано', gh.putLog.length === putsBefore);

    const pubBad = createPublisher({
      store, apiBase: base, rawBase: base + '/raw', log: () => {}, sleep: () => new Promise(r => setImmediate(r)),
      pauseBetweenUploadsMs: 0, backoffMs: 1, apiTimeoutMs: 3000, uploadTimeoutMs: 3000,
      zeusBuild: async () => ({ zpk: Buffer.from('not a zip'), deviceZip: builtDevice })
    });
    jz = await waitJob(pubBad, (await pubBad.startPublish({ slug: 'ZeusFace', appId: 4242, name: 'ZeusFace', version: '1.0.2', artifacts: artifacts('browser3') })).id);
    ok('zeus: мусор вместо .zpk отклонён', jz.status === 'failed' && gh.putLog.length === putsBefore);
  }

  // ───── 3. повторная публикация ─────
  const A2 = artifacts('v2');
  gh.rawLag = 2;                       // CDN отдаёт старую версию ещё 2 запроса
  gh.putLog.length = 0;
  job = await pub.startPublish({ slug: 'Hamilton', appId: 1234567, name: 'Hamilton', version: '1.1.0', artifacts: A2 });
  job = await waitJob(pub, job.id);
  ok('republish: успешно', job.status === 'done', JSON.stringify(job.error));
  ok('republish: URL .zpk не изменился', job.result.zpkUrl === 'https://raw.githubusercontent.com/tester/faces/main/watchfaces/Balance2/Hamilton/Hamilton.zpk');
  ok('republish: содержимое .zpk обновлено', gh.files.get(P.files.zpk).bytes.equals(A2.zpk));
  ok('republish: файлы обновлены (PUT с sha), а не продублированы', gh.putLog.every(p => p.update) && [...gh.files.keys()].filter(k => k.includes('/Hamilton/')).length === 6);
  ok('republish: дождались обновления кэша CDN (устаревший ответ не принят)', job.result.attempts >= 3, 'attempts=' + job.result.attempts);
  gh.rawLag = 0;

  // повтор тех же файлов: ничего не меняется, дубликатов нет
  gh.putLog.length = 0;
  job = await waitJob(pub, (await pub.startPublish({ slug: 'Hamilton', appId: 1234567, name: 'Hamilton', version: '1.1.0', artifacts: A2 })).id);
  ok('republish: идентичные файлы пропускаются (кроме служебных с датой)', job.status === 'done' && job.files.filter(f => f.status === 'unchanged').length >= 4, JSON.stringify(job.files.map(f => f.status)));

  // ───── watch-qr.png: необязательная картинка «часы + QR» ─────
  {
    const PQ = Gh.targetPaths({ folder: 'watchfaces/Balance2', slug: 'QrFace' });
    const png = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), crypto.randomBytes(1500)]);
    const link = 'zpkd1://raw.githubusercontent.com/tester/faces/main/watchfaces/Balance2/QrFace/QrFace.zpk';
    let j = await pub.startPublish({ slug: 'QrFace', appId: 7654321, name: 'QrFace', version: '1.0.1', artifacts: Object.assign(artifacts('v2'), { watchQr: png }), watchQrLink: link });
    j = await waitJob(pub, j.id);
    const rd = gh.files.get(PQ.files.readme).bytes.toString('utf8');
    ok('watch-qr: загружена байт-в-байт', j.status === 'done' && gh.files.has(PQ.files.watchQr) && gh.files.get(PQ.files.watchQr).bytes.equals(png), JSON.stringify(j.error));
    ok('watch-qr: README показывает картинку по относительному пути', rd.includes('![') && rd.includes('(watch-qr.png)'));
    ok('watch-qr: .zpk по-прежнему загружается последним', gh.putLog[gh.putLog.length - 1].path === PQ.files.zpk);
    ok('watch-qr: картинка уходит до README', gh.putLog.map(x => x.path).lastIndexOf(PQ.files.watchQr) < gh.putLog.map(x => x.path).lastIndexOf(PQ.files.readme));

    // QR на «чужую» ссылку не публикуется, но публикация проходит с предупреждением
    // не PNG → ошибка валидации
    j = await pub.startPublish({ slug: 'QrFace', appId: 7654321, name: 'QrFace', version: '1.0.2', artifacts: Object.assign(artifacts('v3'), { watchQr: crypto.randomBytes(900) }), watchQrLink: link });
    j = await waitJob(pub, j.id);
    ok('watch-qr: не-PNG отклоняется', j.status === 'failed' && j.error.code === 'bad_artifact');
    j = await pub.startPublish({ slug: 'QrFace', appId: 7654321, name: 'QrFace', version: '1.0.3', artifacts: Object.assign(artifacts('v4'), { watchQr: png }), watchQrLink: 'zpkd1://evil.example/x.zpk' });
    j = await waitJob(pub, j.id);
    ok('watch-qr: QR с несовпавшей ссылкой не загружается, публикация проходит с предупреждением', j.status === 'done' && j.result.warnings.some(w => /watch-qr\.png не загружен/.test(w)) && !/watch-qr\.png\)/.test(gh.files.get(PQ.files.readme).bytes.toString('utf8')));
  }

  // ───── 4. устаревший CDN навсегда / HTML вместо файла ─────
  const A3 = artifacts('v3');
  gh.rawLag = 1e9;
  const pubShort = createPublisher({ store, apiBase: base, rawBase: base + '/raw', sleep: () => Promise.resolve(), cdnTimeoutMs: 30000, cdnPollMs: 10000, pauseBetweenUploadsMs: 0, backoffMs: 1 });
  job = await waitJob(pubShort, (await pubShort.startPublish({ slug: 'Hamilton', appId: 1234567, name: 'Hamilton', version: '1.2.0', artifacts: A3 })).id);
  ok('cdn: вечный кэш → ошибка, QR не разрешён', job.status === 'failed' && job.error.code === 'cdn_stale' && job.error.uploaded === true && job.result === null);
  gh.rawLag = 0;

  gh.rawHtml = true;
  job = await waitJob(pubShort, (await pubShort.startPublish({ slug: 'Hamilton', appId: 1234567, name: 'Hamilton', version: '1.2.0', artifacts: A3 })).id);
  ok('cdn: HTML вместо .zpk → ошибка', job.status === 'failed' && job.error.code === 'url_unavailable' && /HTML/.test(job.error.message));
  gh.rawHtml = false;

  gh.rawMissing = true;
  job = await waitJob(pubShort, (await pubShort.startPublish({ slug: 'Hamilton', appId: 1234567, name: 'Hamilton', version: '1.2.0', artifacts: A3 })).id);
  ok('cdn: 404 по ссылке → ошибка', job.status === 'failed' && /404/.test(job.error.message));
  gh.rawMissing = false;

  // ───── 5. защита от перезаписи чужого ─────
  job = await waitJob(pub, (await pub.startPublish({ slug: 'Hamilton', appId: 999, name: 'Другой', version: '1.0.0', artifacts: artifacts('x') })).id);
  ok('collision: тот же slug у другого проекта → отказ, файлы первого проекта целы', job.status === 'failed' && job.error.code === 'foreign_project' && gh.files.get(P.files.zpk).bytes.equals(A3.zpk));
  const before = gh.putCount;
  job = await waitJob(pub, (await pub.startPublish({ slug: 'Hamilton', appId: 999, name: 'Другой', version: '1.0.0', artifacts: artifacts('y') })).id);
  ok('collision: ни одного PUT при отказе', gh.putCount === before);

  gh.files.set('watchfaces/Balance2/Manual/readme.txt', { bytes: Buffer.from('hi'), sha: gitBlobSha(Buffer.from('hi')) });
  job = await waitJob(pub, (await pub.startPublish({ slug: 'Manual', appId: 5, name: 'Manual', version: '1.0.0', artifacts: artifacts('m') })).id);
  ok('collision: чужая папка без маркера → отказ', job.status === 'failed' && job.error.code === 'foreign_folder');

  // ───── 6. частичный сбой и повтор ─────
  const A4 = artifacts('p1');
  let failOnce = true;
  gh.hooks.put = (fp) => (fp.endsWith('device.zip') && failOnce) ? { status: 403, body: { message: 'Resource not accessible by personal access token' } } : null;
  job = await waitJob(pub, (await pub.startPublish({ slug: 'Part', appId: 77, name: 'Part', version: '1.0.0', artifacts: A4 })).id);
  ok('partial: ошибка 403 → понятное сообщение про права', job.status === 'failed' && /Contents: Read and write/.test(job.error.message));
  ok('partial: статусы файлов показывают, что загружено, а что нет', job.files.some(f => f.status === 'created') && job.files.find(f => f.kind === 'deviceZip').status === 'failed' && job.files.find(f => f.kind === 'zpk').status === 'pending');
  ok('partial: .zpk не загружен, ссылка не обновлена', !gh.files.has('watchfaces/Balance2/Part/Part.zpk'));
  failOnce = false;
  const puts0 = gh.putCount;
  job = await waitJob(pub, (await pub.startPublish({ slug: 'Part', appId: 77, name: 'Part', version: '1.0.0', artifacts: A4 })).id);
  ok('partial: повтор доводит публикацию до конца', job.status === 'done', JSON.stringify(job.error));
  ok('partial: ранее загруженные файлы не перезаливаются и не дублируются', job.files.filter(f => f.status === 'unchanged').length >= 1 && gh.putCount - puts0 <= 5, 'puts=' + (gh.putCount - puts0));
  gh.hooks.put = null;

  // ───── 7. конфликты, сеть, rate limit ─────
  let c409 = 0;
  gh.hooks.put = (fp) => (fp.endsWith('README.md') && c409++ < 1) ? { status: 409, body: { message: 'conflict' } } : null;
  job = await waitJob(pub, (await pub.startPublish({ slug: 'Hamilton', appId: 1234567, name: 'Hamilton', version: '1.3.0', artifacts: artifacts('c') })).id);
  ok('409: конфликт SHA → перечитали состояние и повторили', job.status === 'done' && c409 >= 2, JSON.stringify(job.error));

  let cAlways = 0;
  gh.hooks.put = (fp) => fp.endsWith('README.md') ? (cAlways++, { status: 409, body: { message: 'conflict' } }) : null;
  const putsBefore = cAlways;
  job = await waitJob(pub, (await pub.startPublish({ slug: 'Hamilton', appId: 1234567, name: 'Hamilton', version: '1.4.0', artifacts: artifacts('d') })).id);
  ok('409: бесконечные повторы исключены (ограниченное число попыток)', job.status === 'failed' && cAlways - putsBefore <= 4 && /конфликт/i.test(job.error.message), 'tries=' + (cAlways - putsBefore));

  let c422 = 0;
  gh.hooks.put = (fp) => fp.endsWith('README.md') && c422++ === 0 ? { status: 422, body: { message: 'Invalid request.\n\n"sha" wasn\'t supplied.' } } : null;
  job = await waitJob(pub, (await pub.startPublish({ slug: 'Hamilton', appId: 1234567, name: 'Hamilton', version: '1.5.0', artifacts: artifacts('e') })).id);
  ok('422 (sha): повтор с актуальным sha', job.status === 'done', JSON.stringify(job.error));

  gh.hooks.put = (fp) => fp.endsWith('README.md') ? { status: 422, body: { message: 'Repository rule violations found' } } : null;
  const n422 = gh.putCount;
  job = await waitJob(pub, (await pub.startPublish({ slug: 'Hamilton', appId: 1234567, name: 'Hamilton', version: '1.6.0', artifacts: artifacts('f') })).id);
  ok('422 (прочее): не повторяется вслепую, причина показана', job.status === 'failed' && /Repository rule/.test(job.error.message) && gh.putCount - n422 <= 5);

  let nd = 0;
  gh.hooks.put = (fp) => fp.endsWith('device.zip') && nd++ === 0 ? { drop: true } : null;
  job = await waitJob(pub, (await pub.startPublish({ slug: 'Hamilton', appId: 1234567, name: 'Hamilton', version: '1.7.0', artifacts: artifacts('g') })).id);
  ok('сеть: обрыв соединения при загрузке → повтор и успех', job.status === 'done', JSON.stringify(job.error));

  let nd2 = 0;
  const A8 = artifacts('h');
  gh.hooks.put = (fp) => fp.endsWith('device.zip') && nd2++ === 0 ? { dropAfterApply: true } : null;
  job = await waitJob(pub, (await pub.startPublish({ slug: 'Hamilton', appId: 1234567, name: 'Hamilton', version: '1.8.0', artifacts: A8 })).id);
  ok('сеть: запрос дошёл, но ответ потерян → повтор не дублирует запись', job.status === 'done' && job.files.find(f => f.kind === 'deviceZip').status === 'unchanged', JSON.stringify(job.files.map(f => f.status)));

  gh.hooks.put = () => ({ drop: true });
  job = await waitJob(pub, (await pub.startPublish({ slug: 'Hamilton', appId: 1234567, name: 'Hamilton', version: '1.9.0', artifacts: artifacts('i') })).id);
  ok('сеть: постоянный обрыв → ошибка с понятным текстом, не бесконечный цикл', job.status === 'failed' && /Сетев/.test(job.error.message));
  gh.hooks.put = null;

  let r429 = 0; sleeps.length = 0;
  gh.hooks.put = (fp) => fp.endsWith('README.md') && r429++ === 0 ? { status: 429, body: { message: 'slow down' }, headers: { 'Retry-After': '2' } } : null;
  job = await waitJob(pub, (await pub.startPublish({ slug: 'Hamilton', appId: 1234567, name: 'Hamilton', version: '2.0.0', artifacts: artifacts('j') })).id);
  ok('429: ожидание Retry-After и успешный повтор', job.status === 'done' && sleeps.includes(2000), JSON.stringify(job.error));
  gh.hooks.put = (fp) => fp.endsWith('README.md') ? { status: 403, body: { message: 'You have exceeded a secondary rate limit.' }, headers: { 'Retry-After': '3000' } } : null;
  job = await waitJob(pub, (await pub.startPublish({ slug: 'Hamilton', appId: 1234567, name: 'Hamilton', version: '2.1.0', artifacts: artifacts('k') })).id);
  ok('403 rate limit: долгий лимит → понятное сообщение, а не «нет прав»', job.status === 'failed' && /частот/i.test(job.error.message) && !/Contents: Read/.test(job.error.message));
  gh.hooks.put = null;

  // токен отозван посреди работы
  const saveTokens = gh.tokens; gh.tokens = {};
  job = await waitJob(pub, (await pub.startPublish({ slug: 'Hamilton', appId: 1234567, name: 'Hamilton', version: '2.2.0', artifacts: artifacts('l') })).id);
  ok('401: отозванный токен → публикация не начинается', job.status === 'failed' && job.error.code === 'auth' && job.files.length === 0);
  gh.tokens = saveTokens;

  // ───── 8. проверка артефактов ─────
  job = await waitJob(pub, (await pub.startPublish({ slug: 'Bad', appId: 1, name: 'Bad', version: '1', artifacts: artifacts('b', { manifest: false }) })).id);
  ok('artifacts: .zpk без device.zip отклонён', job.status === 'failed' && /device\.zip/.test(job.error.message));
  const empty = artifacts('b'); empty.deviceZip = Buffer.alloc(0);
  job = await waitJob(pub, (await pub.startPublish({ slug: 'Bad', appId: 1, name: 'Bad', version: '1', artifacts: empty })).id);
  ok('artifacts: пустой файл отклонён', job.status === 'failed' && job.error.code === 'bad_artifact');
  const notZip = artifacts('b'); notZip.projectZip = Buffer.from('<html>');
  job = await waitJob(pub, (await pub.startPublish({ slug: 'Bad', appId: 1, name: 'Bad', version: '1', artifacts: notZip })).id);
  ok('artifacts: не-ZIP отклонён', job.status === 'failed' && job.error.code === 'bad_artifact');
  const leaky = artifacts('b', { json: { meta: { note: TOKEN } } });
  const putsLeak = gh.putCount;
  job = await waitJob(pub, (await pub.startPublish({ slug: 'Bad', appId: 1, name: 'Bad', version: '1', artifacts: leaky })).id);
  ok('secrets: токен в публикуемом файле → остановка до загрузки', job.status === 'failed' && job.error.code === 'secret_found' && gh.putCount === putsLeak);
  job = await waitJob(pub, (await pub.startPublish({ slug: 'Bad', appId: 1, name: 'Bad', version: '1', artifacts: artifacts('b', { json: { k: 'ghp_' + 'a'.repeat(36) } }) })).id);
  ok('secrets: шаблон чужого токена (ghp_…) тоже блокируется', job.status === 'failed' && job.error.code === 'secret_found');

  // параллельный запуск блокируется
  gh.hooks.put = () => null;
  const first = await pub.startPublish({ slug: 'Hamilton', appId: 1234567, name: 'Hamilton', version: '2.3.0', artifacts: artifacts('m1') });
  const second = await pub.startPublish({ slug: 'Hamilton', appId: 1234567, name: 'Hamilton', version: '2.3.0', artifacts: artifacts('m2') }).catch(e => e);
  ok('busy: повторный запуск во время публикации отклонён', second && second.code === 'busy');
  await waitJob(pub, first.id);

  // отмена
  const slowPub = createPublisher({ store, apiBase: base, rawBase: base + '/raw', pauseBetweenUploadsMs: 0, cdnPollMs: 50, cdnTimeoutMs: 100000 });
  gh.rawLag = 1e9;
  const cj = await slowPub.startPublish({ slug: 'Hamilton', appId: 1234567, name: 'Hamilton', version: '2.4.0', artifacts: artifacts('n') });
  await new Promise(r => setTimeout(r, 300));
  const cancelled = slowPub.cancel(cj.id);
  const cjf = await waitJob(slowPub, cj.id, 5000);
  ok('cancel: ожидание CDN можно прервать', cancelled && cjf.status === 'cancelled');
  gh.rawLag = 0;

  // ───── 9. токен не утекает ─────
  const everything = JSON.stringify({ logs, jobs: [job, cjf], status: await pub.status() }) + [...gh.files.values()].map(f => f.bytes.toString('latin1')).join('') + fs.readFileSync(cfgFile, 'utf8').replace(Buffer.from(TOKEN).toString('base64'), '');
  ok('secrets: токена нет в логах, заданиях, статусе и файлах репозитория', !everything.includes(TOKEN));
  ok('secrets: токен не передавался в URL запросов', !gh.requestLog.some(l => l.includes(TOKEN)));
  ok('secrets: токен в Authorization только у api, raw-запросы без него', gh.authSeen.filter(a => a.startsWith('raw:')).every(a => a === 'raw:'));
  ok('secrets: redact() скрывает и токен, и шаблоны', !pub._internals.redact('x ' + TOKEN + ' ghp_' + 'z'.repeat(30)).match(/github_pat_|ghp_/));
  ok('commit: сообщения коммитов содержат имя и версию', gh.putLog.some(p => /AmazFace: Hamilton v/.test(p.message)));

  // ───── 10. HTTP-слой: Origin / Host / ключ ─────
  const routes = createGithubRoutes({ store, publisher: pub });
  const bridge = http.createServer((req, res) => { if (routes.matches(req)) return routes.handle(req, res); res.writeHead(404); res.end(); });
  await new Promise(r => bridge.listen(0, '127.0.0.1', r));
  const bp = bridge.address().port;
  const call = (method, p, { headers, body, host } = {}) => new Promise((resolve, reject) => {
    const req = http.request({ host: '127.0.0.1', port: bp, path: p, method, headers: Object.assign({ Host: host || ('127.0.0.1:' + bp) }, headers || {}) }, res => {
      const ch = []; res.on('data', c => ch.push(c)); res.on('end', () => { let j = null; try { j = JSON.parse(Buffer.concat(ch).toString()); } catch (e) {} resolve({ status: res.statusCode, headers: res.headers, json: j }); });
    });
    req.on('error', reject); if (body) req.write(body); req.end();
  });
  const KEY = routes.bridgeKey();
  let r = await call('GET', '/github/ping');
  ok('http: ping доступен без ключа и сообщает keyValid=false', r.status === 200 && r.json.keyValid === false);
  r = await call('GET', '/github/status');
  ok('http: status без ключа → 401', r.status === 401);
  r = await call('GET', '/github/status', { headers: { 'X-AmazFace-Key': 'wrong' + KEY } });
  ok('http: неверный ключ → 401', r.status === 401);
  r = await call('GET', '/github/status', { headers: { 'X-AmazFace-Key': KEY, Origin: 'https://evil.example' } });
  ok('http: чужой Origin → 403 даже с верным ключом', r.status === 403 && !r.headers['access-control-allow-origin']);
  r = await call('OPTIONS', '/github/publish', { headers: { Origin: 'https://evil.example', 'Access-Control-Request-Method': 'POST' } });
  ok('http: preflight чужого сайта → 403', r.status === 403);
  r = await call('OPTIONS', '/github/publish', { headers: { Origin: 'null', 'Access-Control-Request-Method': 'POST', 'Access-Control-Request-Headers': 'x-amazface-key' } });
  ok('http: preflight от file:// разрешён и разрешает X-AmazFace-Key', r.status === 204 && /x-amazface-key/i.test(r.headers['access-control-allow-headers']) && r.headers['access-control-allow-origin'] === 'null');
  r = await call('GET', '/github/status', { headers: { 'X-AmazFace-Key': KEY }, host: 'rebind.evil.example' });
  ok('http: чужой Host (DNS rebinding) → 403', r.status === 403);
  r = await call('GET', '/github/status', { headers: { 'X-AmazFace-Key': KEY, Origin: 'http://localhost:5173' } });
  ok('http: localhost-редактор с ключом → 200, токена в ответе нет', r.status === 200 && r.json.connected === true && !JSON.stringify(r.json).includes(TOKEN) && r.headers['access-control-allow-origin'] === 'http://localhost:5173');
  r = await call('GET', '/github/unknown', { headers: { 'X-AmazFace-Key': KEY } });
  ok('http: неизвестный маршрут → 404 (никаких «выполнить команду/прочитать файл»)', r.status === 404);

  const A9 = artifacts('http');
  r = await call('POST', '/github/publish', { headers: { 'X-AmazFace-Key': KEY, 'Content-Type': 'application/json' }, body: JSON.stringify({ slug: '../../etc', appId: 1234567, name: 'Hamilton', version: '3.0.0', artifacts: Object.fromEntries(Object.entries(A9).map(([k, v]) => [k, v.toString('base64')])) }) });
  ok('http: publish принимает base64 и возвращает jobId', r.status === 202 && r.json.id);
  const hj = await waitJob(pub, r.json.id);
  ok('http: путь из запроса не влияет на место записи (slug очищен, папка из настроек)', hj.status === 'done' && [...gh.files.keys()].every(k => k.startsWith('watchfaces/Balance2/')) && !hj.files.some(f => f.path.includes('..')), JSON.stringify(hj.error));
  r = await call('GET', '/github/job?id=' + r.json.id, { headers: { 'X-AmazFace-Key': KEY } });
  ok('http: job отдаёт шаги и файлы', r.status === 200 && r.json.steps.length === 6);
  r = await call('POST', '/github/publish', { headers: { 'X-AmazFace-Key': KEY, 'Content-Type': 'application/json' }, body: '{bad json' });
  ok('http: битый JSON → 400', r.status === 400);
  r = await call('POST', '/github/disconnect', { headers: { 'X-AmazFace-Key': KEY } });
  ok('http: disconnect удаляет токен и настройки', r.status === 200 && !store.read().secret && (await pub.status()).connected === false);
  r = await call('POST', '/github/publish', { headers: { 'X-AmazFace-Key': KEY, 'Content-Type': 'application/json' }, body: JSON.stringify({ slug: 'x', appId: 1, artifacts: {} }) });
  ok('http: публикация без подключения → 409 с понятным текстом', r.status === 409 && /не подключён/.test(r.json.error));

  // ───── 11. хранилище токена ─────
  const dpapiCalls = [];
  const winStore = createConfigStore({ dir: path.join(tmp, 'win'), platform: 'win32', dpapi: { protect: async t => { dpapiCalls.push('p'); return 'ENC:' + Buffer.from(t).toString('hex'); }, unprotect: async b => Buffer.from(b.slice(4), 'hex').toString() } });
  const prot = await winStore.saveToken(TOKEN);
  ok('store(win): токен шифруется DPAPI, в файле нет открытого токена', prot === 'dpapi' && !fs.readFileSync(winStore.file, 'utf8').includes(TOKEN) && (await winStore.loadToken()) === TOKEN);
  const badWin = createConfigStore({ dir: path.join(tmp, 'win2'), platform: 'win32', dpapi: { protect: async () => { throw new Error('no ps'); }, unprotect: async () => { throw new Error('x'); } } });
  ok('store(win): если защитить нечем — токен только в памяти, на диск не пишется', (await badWin.saveToken(TOKEN)) === 'memory' && !(fs.existsSync(badWin.file) && fs.readFileSync(badWin.file, 'utf8').includes(TOKEN)) && (await badWin.loadToken()) === null);
  ok('store: bridgeKey стабилен между запусками', createConfigStore({ dir: path.join(tmp, 'cfg'), platform: 'linux' }).bridgeKey() === KEY);

  gh.server.close(); bridge.close();
  fs.rmSync(tmp, { recursive: true, force: true });
  console.log(`\nТесты GitHub Publishing: ${passed} прошло, ${failed} упало.`);
  process.exit(failed ? 1 : 0);
}
main().catch(e => { console.error('TEST CRASH', e); process.exit(2); });
