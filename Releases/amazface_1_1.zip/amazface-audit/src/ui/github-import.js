// src/ui/github-import.js
//
// Кнопка «Открыть из GitHub» на стартовом экране. Подключается ПОСЛЕ welcome.js:
// список проектов и файлы отдаёт локальный мост (маршруты /github/import/*, те же
// настройки и токен, что у публикации — редактор токена не видит и не хранит).
// Скачанное собирается в папку, а дальше проект открывается ТЕМ ЖЕ механизмом, что
// «Открыть существующую папку» (AmazWelcome.openFolder): состояние загружается из
// amazface.project.json, ресурсы лежат в assets/, автосохранение работает как обычно.
// Ничего не публикуется, не собирается и не экспортируется.

(() => {
  const btn = document.getElementById('welcome-github');
  if (!btn || typeof AmazImport === 'undefined' || !window.AmazWelcome) return;

  const KEY_STORAGE = 'amazface_bridge_key'; // код доступа к мосту (не токен GitHub), как в github-publish.js
  const BRIDGE = () => (typeof ZEUS_BRIDGE === 'string' ? ZEUS_BRIDGE : 'http://127.0.0.1:17865');
  const esc = (t) => String(t == null ? '' : t).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  let key = '';
  try { key = localStorage.getItem(KEY_STORAGE) || ''; } catch (e) { /* localStorage может быть недоступен */ }

  const supported = typeof FsProject !== 'undefined' && FsProject.supported();
  if (!supported) { btn.disabled = true; btn.title = 'Нужен браузер с File System Access API (Chrome, Edge, Opera).'; }

  // ───────── диалог ─────────
  const dlg = document.createElement('dialog');
  dlg.id = 'gh-import-dialog';
  dlg.className = 'zpk-modal ghi-modal';
  dlg.setAttribute('aria-label', 'Открыть проект из GitHub');
  dlg.innerHTML = '<div class="zpk-modal-inner"><div class="zpk-head"><b>Открыть из GitHub</b>' +
    '<button type="button" id="ghi-close" aria-label="Закрыть">✕</button></div>' +
    '<div class="zpk-body" id="ghi-body"></div></div>';
  document.body.appendChild(dlg);
  const body = dlg.querySelector('#ghi-body');
  let busy = false;
  let controller = null;

  dlg.addEventListener('cancel', (e) => { if (busy) e.preventDefault(); });
  dlg.querySelector('#ghi-close').onclick = () => { if (busy && controller) controller.abort(); else dlg.close(); };

  const say = (html) => { body.innerHTML = html; };
  const button = (id, label, cls) => `<button type="button" id="${id}" class="ghi-btn ${cls || ''}">${esc(label)}</button>`;
  const on = (id, fn) => { const el = body.querySelector('#' + id); if (el) el.onclick = fn; };

  // ───────── связь с мостом ─────────
  function bridgeError(msg, code, status) { const e = new Error(msg); e.code = code; e.status = status; return e; }
  async function bridgeFetch(pathname) {
    let res;
    try {
      res = await fetch(BRIDGE() + pathname, { headers: { 'X-AmazFace-Key': key || '' }, signal: controller ? controller.signal : undefined });
    } catch (e) {
      if (e && e.name === 'AbortError') throw e;
      throw bridgeError('Локальный мост не отвечает. Запустите bridge/start-zeus-bridge.bat и оставьте окно открытым.', 'bridge_down');
    }
    if (!res.ok) {
      let j = null; try { j = await res.json(); } catch (e) { /* пустой ответ */ }
      throw bridgeError((j && j.error) || `Ошибка моста (${res.status}).`, j && j.code, res.status);
    }
    return res;
  }
  const bridgeJson = async (p) => (await bridgeFetch(p)).json();
  const bridgeBytes = async (p) => new Uint8Array(await (await bridgeFetch(p)).arrayBuffer());

  // ───────── экраны ─────────
  function renderLoading(text) { say(`<p class="ghi-state"><span class="ghi-spin" aria-hidden="true"></span>${esc(text)}</p>`); }

  function renderError(err, retry) {
    const needKey = err.code === 'key';
    const needConnect = err.code === 'not_connected';
    say(`<p class="ghi-state err">${esc(err.message || String(err))}</p>` +
      (needKey ? '<p class="ghi-hint">Код доступа напечатан в окне моста. Введите его один раз:</p>' +
        '<div class="ghi-row"><input id="ghi-key" type="password" autocomplete="off" placeholder="Код доступа к мосту" aria-label="Код доступа к мосту"> ' + button('ghi-key-ok', 'Продолжить', 'primary') + '</div>' : '') +
      (needConnect ? '<p class="ghi-hint">Репозиторий и токен настраиваются один раз в окне публикации (кнопка «Опубликовать на GitHub» в редакторе). Для импорта используются те же настройки, ветка — <code>main</code>.</p>' : '') +
      '<div class="ghi-row">' + (needKey ? '' : button('ghi-retry', 'Повторить', 'primary')) + '</div>');
    on('ghi-retry', retry);
    on('ghi-key-ok', () => {
      key = (body.querySelector('#ghi-key').value || '').trim();
      try { localStorage.setItem(KEY_STORAGE, key); } catch (e) { /* без сохранения */ }
      load();
    });
  }

  function renderList(data) {
    const rows = data.projects.map((p, i) =>
      `<button type="button" class="ghi-item" data-i="${i}"><span class="ghi-ico" aria-hidden="true">⌚</span>` +
      `<span class="ghi-text"><b>${esc(p.folder)}</b><small>${p.name && p.name !== p.folder ? 'Проект: ' + esc(p.name) + ' · ' : ''}${esc(p.dir)}</small></span></button>`).join('');
    const bad = data.invalid.map((p) =>
      `<div class="ghi-item bad" aria-disabled="true"><span class="ghi-ico" aria-hidden="true">⚠</span>` +
      `<span class="ghi-text"><b>${esc(p.folder)}</b><small>${esc(p.error)} Выберите другой проект.</small></span></div>`).join('');
    if (!data.projects.length && !data.invalid.length) {
      say(`<p class="ghi-state">В ветке <code>${esc(data.branch)}</code> репозитория <code>${esc(data.repo)}</code> не найдено проектов AmazFace.</p>` +
        '<p class="ghi-hint">Проект появляется там после публикации: в его папке лежит файл <code>.watchface.json</code>.</p>' +
        '<div class="ghi-row">' + button('ghi-retry', 'Обновить', 'primary') + '</div>');
      on('ghi-retry', load);
      return;
    }
    say(`<p class="ghi-hint">Репозиторий <code>${esc(data.repo)}</code>, ветка <code>${esc(data.branch)}</code>. Выберите проект — затем папку на диске, куда его скачать.</p>` +
      (data.note ? `<p class="ghi-hint warn">${esc(data.note)}</p>` : '') +
      `<div class="ghi-list">${rows}${bad}</div>` +
      '<div class="ghi-row">' + button('ghi-retry', 'Обновить список') + '</div>');
    on('ghi-retry', load);
    body.querySelectorAll('.ghi-item[data-i]').forEach((el) => {
      el.onclick = () => choose(data, data.projects[Number(el.dataset.i)]);
    });
  }

  // ───────── сценарии ─────────
  async function load() {
    controller = new AbortController(); busy = true;
    renderLoading('Подключаюсь к мосту и читаю репозиторий…');
    try {
      const ping = await bridgeJson('/github/ping');
      if (!ping.keyValid) throw bridgeError(key ? 'Код доступа к мосту не подошёл.' : 'Нужен код доступа к мосту.', 'key');
      const st = await bridgeJson('/github/status');
      if (!st.connected) throw bridgeError('GitHub не подключён.', 'not_connected');
      renderLoading('Ищу проекты AmazFace в ветке main…');
      renderList(await bridgeJson('/github/import/projects'));
    } catch (e) {
      if (e && e.name === 'AbortError') { dlg.close(); return; }
      renderError(e, load);
    } finally { busy = false; controller = null; }
  }

  const pickParent = () => window.showDirectoryPicker({ id: 'amazface-import-parent', mode: 'readwrite' });

  // Вызывается прямо из клика по проекту — диалог выбора папки требует действия пользователя.
  async function choose(data, project) {
    let parent;
    try { parent = await pickParent(); }
    catch (e) { if (e && e.name === 'AbortError') return; renderError(e, () => renderList(data)); return; }
    await prepare(data, project, parent);
  }

  async function prepare(data, project, parent) {
    const name = AmazImport.safeFolderName(project.name || project.folder, project.folder);
    try {
      if (await AmazImport.destinationExists(parent, name)) { renderExists(data, project, parent, name); return; }
    } catch (e) { renderError(e, () => renderList(data)); return; }
    await run(data, project, parent, name, false);
  }

  function renderExists(data, project, parent, name) {
    say(`<p class="ghi-state warn">В папке «${esc(parent.name)}» уже есть «${esc(name)}». Ничего не изменено.</p>` +
      '<div class="ghi-row">' + button('ghi-other', 'Выбрать другую папку', 'primary') + button('ghi-replace', 'Заменить существующую', 'danger') + button('ghi-back', 'Назад') + '</div>');
    on('ghi-back', () => renderList(data));
    on('ghi-other', async () => {
      let p2;
      try { p2 = await pickParent(); } catch (e) { if (e && e.name === 'AbortError') return; renderError(e, () => renderList(data)); return; }
      await prepare(data, project, p2);
    });
    on('ghi-replace', () => renderConfirm(data, project, parent, name));
  }

  function renderConfirm(data, project, parent, name) {
    say(`<p class="ghi-state err">Папка «${esc(parent.name)}/${esc(name)}» будет удалена вместе со всем содержимым и заменена проектом из GitHub. Это действие нельзя отменить.</p>` +
      '<p class="ghi-hint">Новая версия сначала целиком скачивается и проверяется; старая папка не тронута, пока всё не готово.</p>' +
      '<div class="ghi-row">' + button('ghi-yes', 'Да, заменить', 'danger') + button('ghi-no', 'Отмена', 'primary') + '</div>');
    on('ghi-no', () => renderExists(data, project, parent, name));
    on('ghi-yes', () => run(data, project, parent, name, true));
  }

  async function run(data, project, parent, name, replace) {
    controller = new AbortController(); busy = true;
    renderLoading('Скачиваю проект…');
    const q = (p) => `dir=${encodeURIComponent(project.dir)}` + (p === undefined ? '' : `&path=${encodeURIComponent(p)}`);
    try {
      const staged = await AmazImport.stageImport({
        fetchManifest: () => bridgeJson(`/github/import/manifest?${q()}`),
        fetchFile: (p) => bridgeBytes(`/github/import/file?${q(p)}`),
        unzip: (bytes) => readZipEntries(bytes),
        makeAppJson: (text) => buildAppJson(migrateProject(JSON.parse(text))),
        onProgress: (done, total) => renderLoading(`Скачиваю проект… ${done} из ${total}`),
        signal: controller.signal
      });
      renderLoading(replace ? 'Заменяю папку…' : 'Записываю на диск…');
      // После начала записи отмена уже не нужна: запись либо завершится, либо откатится.
      const dir = await AmazImport.commitImport({ parent, name, files: staged.files, replace });
      renderLoading('Открываю проект…');
      busy = false;
      dlg.close();
      await window.AmazWelcome.openFolder(dir);
      const st = store.state;
      const comps = (st.scenes && st.scenes.normal && st.scenes.normal.components || st.components || []).length;
      const ok = comps === staged.info.componentCount && (st.assets || []).length === staged.info.assetCount;
      window.AmazWelcome.toast(ok
        ? `Проект «${st.meta.name}» импортирован: компонентов ${comps}, ресурсов ${(st.assets || []).length}. Папка: ${name}`
        : `Проект открыт, но данные отличаются от файла в GitHub (компонентов ${comps} из ${staged.info.componentCount}). Проверьте проект.`, ok ? 'ok' : 'warn');
    } catch (e) {
      busy = false;
      if (e && e.name === 'AbortError') { dlg.close(); return; }
      if (!dlg.open) dlg.showModal();
      renderError(e, () => renderList(data));
      // «Повторить» после ошибки вернёт к списку: проект не открыт, диск не изменён (или откатан).
      const retry = body.querySelector('#ghi-retry'); if (retry) retry.textContent = 'Назад к списку';
    } finally { busy = false; controller = null; }
  }

  btn.onclick = () => { if (!dlg.open) dlg.showModal(); load(); };
})();
