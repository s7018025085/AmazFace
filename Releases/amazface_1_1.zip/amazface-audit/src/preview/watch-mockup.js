// src/preview/watch-mockup.js
//
// Компоновщик «превью часов»: актуальный циферблат проекта вставляется в корпус
// пользователя (assets/mockup/watch-case.png — корпус и ремешок с прозрачным окном
// под экран). Корпус не перерисовывается: берётся именно это изображение.
//
// Порядок слоёв: фон/тень → циферблат (круглая обрезка по экрану) → корпус с окном →
// лёгкая тень у края экрана и блик стекла. Циферблат берётся тем же растровым движком,
// что и обычное превью (WatchfacePreviewRenderer.draw), и масштабируется равномерно —
// без растяжения. Ресурс шаблона грузится локально (data URL), без сети.

(function () {
  'use strict';

  const TEMPLATE_SRC = 'assets/mockup/watch-case-data.js';
  const TAU = Math.PI * 2;
  let templatePromise = null;

  function loadScript(src) {
    return new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = src; s.onload = resolve;
      s.onerror = () => reject(new Error('Не найден шаблон корпуса: ' + src));
      document.head.appendChild(s);
    });
  }

  // Шаблон: { width, height, screen:{cx,cy,r}, image } — грузится один раз.
  function loadTemplate() {
    if (!templatePromise) {
      templatePromise = (async () => {
        if (!window.WATCH_CASE_TEMPLATE) await loadScript(TEMPLATE_SRC);
        const t = window.WATCH_CASE_TEMPLATE;
        if (!t || !t.dataUrl) throw new Error('Шаблон корпуса повреждён');
        const image = new Image();
        image.src = t.dataUrl;
        await image.decode();
        return { width: t.width, height: t.height, screen: t.screen, image };
      })().catch(e => { templatePromise = null; throw e; });
    }
    return templatePromise;
  }

  function makeCanvas(w, h) {
    const c = document.createElement('canvas');
    c.width = w; c.height = h;
    return c;
  }

  // Рендер актуального циферблата тем же движком, что и обычное превью.
  async function renderDial(project, size) {
    const cv = makeCanvas(size, size);
    await WatchfacePreviewRenderer.draw(project, cv, { size, previewMode: true, highQuality: true });
    return cv;
  }

  /**
   * Собирает изображение часов с актуальным циферблатом проекта.
   * @param {object} project  текущее состояние редактора (store.state)
   * @param {{transparent?: boolean}} [opts]  transparent — без фона и тени
   * @returns {Promise<HTMLCanvasElement>} canvas размером с шаблон корпуса
   */
  async function buildWatchMockupCanvas(project, opts = {}) {
    const tpl = await loadTemplate();
    const { width: W, height: H, screen, image } = tpl;
    const { cx, cy, r } = screen;
    const dw = Number(project.device?.w) || 480, dh = Number(project.device?.h) || 480;

    // 1. актуальный циферблат (квадратный canvas; экран занимает dw×dh в левом верхнем углу)
    const dialPx = Math.round(r * 2);
    const dial = await renderDial(project, dialPx);

    const out = makeCanvas(W, H);
    const ctx = out.getContext('2d');
    ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';

    // 2. фон (нейтральный) и мягкая тень корпуса; в прозрачном режиме ничего не рисуется
    if (!opts.transparent) {
      const g = ctx.createRadialGradient(cx, cy, r * 0.3, cx, cy, Math.max(W, H) * 0.8);
      g.addColorStop(0, '#f4f5f7'); g.addColorStop(1, '#c8cbd1');
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
      ctx.save();
      ctx.shadowColor = 'rgba(0,0,0,0.38)'; ctx.shadowBlur = 36; ctx.shadowOffsetX = 12; ctx.shadowOffsetY = 18;
      ctx.drawImage(image, 0, 0);
      ctx.restore();
    }

    // 3. циферблат: единый масштаб по осям, круглая обрезка чуть шире окна (края прячет корпус)
    ctx.save();
    ctx.beginPath(); ctx.arc(cx, cy, r + 2, 0, TAU); ctx.clip();
    ctx.fillStyle = '#000'; ctx.fillRect(cx - r - 2, cy - r - 2, (r + 2) * 2, (r + 2) * 2);
    const k = dialPx / Math.max(dw, dh);          // шкала движка превью
    const sw = dw * k, sh = dh * k;               // реальная область экрана в рендере
    const fit = Math.min((2 * r) / sw, (2 * r) / sh);
    const outW = sw * fit, outH = sh * fit;
    ctx.drawImage(dial, 0, 0, sw, sh, cx - outW / 2, cy - outH / 2, outW, outH);
    ctx.restore();

    // 4. корпус и ремешок поверх — в шаблоне настоящее прозрачное окно под экран
    ctx.drawImage(image, 0, 0);

    // 5. стекло: затенение у кромки и мягкий блик (слабые, читаемость не страдает)
    ctx.save();
    ctx.beginPath(); ctx.arc(cx, cy, r, 0, TAU); ctx.clip();
    const edge = ctx.createRadialGradient(cx, cy, r * 0.93, cx, cy, r);
    edge.addColorStop(0, 'rgba(0,0,0,0)'); edge.addColorStop(1, 'rgba(0,0,0,0.30)');
    ctx.fillStyle = edge; ctx.fillRect(cx - r, cy - r, r * 2, r * 2);
    const gl = ctx.createLinearGradient(cx - r, cy - r, cx + r, cy + r);
    gl.addColorStop(0, 'rgba(255,255,255,0.10)'); gl.addColorStop(0.35, 'rgba(255,255,255,0.03)');
    gl.addColorStop(0.55, 'rgba(255,255,255,0)'); gl.addColorStop(1, 'rgba(255,255,255,0.04)');
    ctx.fillStyle = gl; ctx.fillRect(cx - r, cy - r, r * 2, r * 2);
    ctx.restore();
    return out;
  }

  function canvasToBlob(canvas) {
    return new Promise((resolve, reject) => canvas.toBlob(b => b ? resolve(b) : reject(new Error('Не удалось получить PNG')), 'image/png'));
  }

  window.WatchMockup = { buildWatchMockupCanvas, canvasToBlob, loadTemplate };
})();
