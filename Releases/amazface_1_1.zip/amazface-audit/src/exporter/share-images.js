// src/exporter/share-images.js
//
// Три PNG для публикации циферблата (например, на 4PDA):
//   1. qr        — только QR-код установки (белая тихая зона, целые пиксели на модуль);
//   2. watch     — часы с актуальным циферблатом в корпусе и на ремешке, без QR;
//   3. combined  — часы + QR-код + название циферблата и модель часов на тёмном фоне.
//
// Часы рисует существующий WatchMockup (шаблон корпуса и ремешка не меняется),
// QR — матрица из qrEncodeToMatrix. Ничего не отправляется в сеть.
// Файл подключается после watch-mockup.js и qr-encoder.js.

(function () {
  'use strict';

  const FONT = '"Segoe UI", "Helvetica Neue", Arial, sans-serif';
  const QUIET = 4; // модулей тихой зоны — как в qrMatrixToPngDataUrl

  function makeCanvas(w, h) {
    const c = document.createElement('canvas');
    c.width = w; c.height = h;
    return c;
  }

  function toBlob(canvas) {
    return new Promise((resolve, reject) =>
      canvas.toBlob(b => b ? resolve(b) : reject(new Error('Не удалось получить PNG')), 'image/png'));
  }

  function roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  // Рисует QR (с тихой зоной) в левый верхний угол (x, y); размер — целое число пикселей на модуль.
  function drawQr(ctx, matrix, x, y, moduleSize) {
    const n = matrix.size;
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(x, y, (n + QUIET * 2) * moduleSize, (n + QUIET * 2) * moduleSize);
    ctx.fillStyle = '#000000';
    for (let r = 0; r < n; r++) {
      for (let c = 0; c < n; c++) {
        if (matrix.modules[r][c]) ctx.fillRect(x + (c + QUIET) * moduleSize, y + (r + QUIET) * moduleSize, moduleSize, moduleSize);
      }
    }
  }

  // Подбирает размер шрифта, чтобы строка влезла в maxWidth.
  function fitFont(ctx, text, weight, maxPx, minPx, maxWidth) {
    let size = maxPx;
    for (; size > minPx; size -= 2) {
      ctx.font = `${weight} ${size}px ${FONT}`;
      if (ctx.measureText(text).width <= maxWidth) break;
    }
    ctx.font = `${weight} ${size}px ${FONT}`;
    return size;
  }

  // «Amazfit Balance 2 (480×480)» → «Amazfit Balance 2»
  function deviceLabel(project) {
    const raw = String(project.device?.name || '').replace(/\s*\(.*?\)\s*/g, ' ').replace(/\s*[—–-]\s*target.*$/i, '').trim();
    return raw || 'Zepp OS';
  }

  function faceName(project) {
    return String(project.meta?.name || '').trim() || 'Watch Face';
  }

  // 1. Только QR
  async function buildQrCanvas(matrix) {
    const total = matrix.size + QUIET * 2;
    const m = Math.max(4, Math.round(800 / total));
    const cv = makeCanvas(total * m, total * m);
    drawQr(cv.getContext('2d'), matrix, 0, 0, m);
    return cv;
  }

  // 2. Только часы
  async function buildWatchCanvas(project, opts = {}) {
    return WatchMockup.buildWatchMockupCanvas(project, { transparent: !!opts.transparent });
  }

  // 3. Часы + QR + названия. 1600×1200 (4:3), тёмный графитовый фон.
  async function buildCombinedCanvas(project, matrix) {
    const W = 1600, H = 1200;
    const watch = await WatchMockup.buildWatchMockupCanvas(project, { transparent: true });
    const cv = makeCanvas(W, H);
    const ctx = cv.getContext('2d');
    ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';

    // фон: графит с холодным свечением за часами
    const bg = ctx.createLinearGradient(0, 0, W, H);
    bg.addColorStop(0, '#0b0f16'); bg.addColorStop(1, '#1a2230');
    ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);
    const glow = ctx.createRadialGradient(420, 600, 40, 420, 600, 640);
    glow.addColorStop(0, 'rgba(70,150,255,0.22)'); glow.addColorStop(1, 'rgba(70,150,255,0)');
    ctx.fillStyle = glow; ctx.fillRect(0, 0, W, H);

    // часы слева, во всю высоту с небольшим полем
    const wh = 1040, ww = watch.width * (wh / watch.height);
    const wx = 24, wy = (H - wh) / 2;
    ctx.save();
    ctx.shadowColor = 'rgba(0,0,0,0.55)'; ctx.shadowBlur = 50; ctx.shadowOffsetX = 14; ctx.shadowOffsetY = 24;
    ctx.drawImage(watch, wx, wy, ww, wh);
    ctx.restore();

    // правая колонка
    const colX = 830, colW = W - colX - 70, cx = colX + colW / 2;
    ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';

    ctx.fillStyle = 'rgba(150,190,255,0.85)';
    ctx.font = `600 26px ${FONT}`;
    if ('letterSpacing' in ctx) ctx.letterSpacing = '5px';
    ctx.fillText('СКАНИРУЙТЕ В ZEPP APP', cx, 250);
    if ('letterSpacing' in ctx) ctx.letterSpacing = '0px';

    // QR на белой карточке
    const total = matrix.size + QUIET * 2;
    const m = Math.max(3, Math.floor(470 / total));
    const qrPx = total * m, pad = 22;
    const qx = Math.round(cx - qrPx / 2), qy = 285;
    ctx.save();
    ctx.shadowColor = 'rgba(0,0,0,0.45)'; ctx.shadowBlur = 36; ctx.shadowOffsetY = 12;
    ctx.fillStyle = '#ffffff';
    roundRect(ctx, qx - pad, qy - pad, qrPx + pad * 2, qrPx + pad * 2, 26); ctx.fill();
    ctx.restore();
    drawQr(ctx, matrix, qx, qy, m);

    // акцентная линия
    const lineY = qy + qrPx + pad + 70;
    const lg = ctx.createLinearGradient(cx - 90, 0, cx + 90, 0);
    lg.addColorStop(0, 'rgba(70,150,255,0)'); lg.addColorStop(0.5, 'rgba(110,180,255,1)'); lg.addColorStop(1, 'rgba(70,150,255,0)');
    ctx.fillStyle = lg; ctx.fillRect(cx - 90, lineY, 180, 3);

    // название циферблата и модель часов
    ctx.fillStyle = '#f2f5fa';
    fitFont(ctx, faceName(project), 700, 70, 30, colW);
    ctx.fillText(faceName(project), cx, lineY + 80);
    ctx.fillStyle = 'rgba(190,200,215,0.9)';
    fitFont(ctx, deviceLabel(project), 400, 40, 22, colW);
    ctx.fillText(deviceLabel(project), cx, lineY + 135);

    return cv;
  }

  /**
   * Собирает все три картинки.
   * @param {object} project  store.state
   * @param {object} matrix   матрица QR (qrEncodeToMatrix)
   * @param {{transparentWatch?: boolean}} [opts]
   * @returns {Promise<Array<{id:string,label:string,suffix:string,blob:Blob,width:number,height:number}>>}
   */
  async function buildAll(project, matrix, opts = {}) {
    const defs = [
      { id: 'qr', label: 'QR-код', suffix: 'qr', canvas: await buildQrCanvas(matrix) },
      { id: 'watch', label: 'Часы с корпусом и ремешком', suffix: 'watch', canvas: await buildWatchCanvas(project, { transparent: opts.transparentWatch }) },
      { id: 'combined', label: 'Часы + QR-код', suffix: 'watch-qr', canvas: await buildCombinedCanvas(project, matrix) }
    ];
    const out = [];
    for (const d of defs) out.push({ id: d.id, label: d.label, suffix: d.suffix, blob: await toBlob(d.canvas), width: d.canvas.width, height: d.canvas.height });
    return out;
  }

  /** Только картинка «часы + QR» (для публикации на GitHub как watch-qr.png). */
  async function buildCombinedBlob(project, matrix) {
    return toBlob(await buildCombinedCanvas(project, matrix));
  }

  // ───────── сохранение ─────────
  const aborted = (e) => e && (e.name === 'AbortError' || e.code === 20);

  function downloadBlob(blob, filename) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 5000);
  }

  /** «Сохранить как…» с выбором места (Chrome/Edge); иначе обычная загрузка. Возвращает 'picked' | 'download' | 'cancelled'. */
  async function saveBlob(blob, filename) {
    if (typeof window.showSaveFilePicker === 'function') {
      try {
        const h = await window.showSaveFilePicker({ suggestedName: filename, types: [{ description: 'PNG', accept: { 'image/png': ['.png'] } }] });
        const w = await h.createWritable(); await w.write(blob); await w.close();
        return 'picked';
      } catch (e) {
        if (aborted(e)) return 'cancelled';
        // прочие ошибки (например, запрет в iframe) — запасной путь ниже
      }
    }
    downloadBlob(blob, filename);
    return 'download';
  }

  /** Все файлы в выбранную папку (Chrome/Edge); иначе последовательные загрузки. */
  async function saveAll(files) {
    if (typeof window.showDirectoryPicker === 'function') {
      try {
        const dir = await window.showDirectoryPicker({ mode: 'readwrite' });
        for (const f of files) {
          const fh = await dir.getFileHandle(f.name, { create: true });
          const w = await fh.createWritable(); await w.write(f.blob); await w.close();
        }
        return 'folder';
      } catch (e) {
        if (aborted(e)) return 'cancelled';
      }
    }
    for (const f of files) { downloadBlob(f.blob, f.name); await new Promise(r => setTimeout(r, 250)); }
    return 'download';
  }

  window.ShareImages = { buildAll, buildQrCanvas, buildWatchCanvas, buildCombinedCanvas, buildCombinedBlob, saveBlob, saveAll, deviceLabel, faceName };
})();
