'use strict';
// bridge/github-import.js
//
// Импорт проектов AmazFace из GitHub: только ЧТЕНИЕ (GET). Использует тот же
// GitHub-клиент и те же сохранённые настройки/токен, что и публикация
// (createPublisher передаёт сюда свой `api` и `getToken`). Токен не покидает мост.
//
// Что считается проектом: папка, в которой лежит файл `.watchface.json` или
// `<Имя>.watchface.json` (его кладёт публикация) с корректным состоянием редактора.
// Список строится по одному запросу git/trees (рекурсивно) к ветке `main`.
//
// Безопасность: путь папки и путь файла проверяются и, кроме того, сверяются со
// списком из репозитория — запросить можно только то, что реально лежит в
// найденной папке проекта. Произвольных URL нет: адреса строятся из owner/repo
// сохранённых настроек и sha, полученных от самого GitHub.

const crypto = require('crypto');
const gitBlobSha = (bytes) => crypto.createHash('sha1').update(`blob ${bytes.length}\0`).update(bytes).digest('hex');

const IMPORT_BRANCH = 'main';
const STATE_FILE_RE = /^(?:.*\.)?watchface\.json$/i;
const MAX_STATE_BYTES = 60 * 1024 * 1024;
const MAX_FILE_BYTES = 95 * 1024 * 1024;
const MAX_TOTAL_BYTES = 250 * 1024 * 1024;
const MAX_FILES = 3000;
const MAX_CANDIDATES = 40;
const MAX_DEPTH = 12;
const MANIFEST_TTL_MS = 10 * 60 * 1000;
const BLOB_TIMEOUT_MS = 180000;

// В папку проекта не нужно тянуть то, что редактору не требуется:
// установочные пакеты, README, служебный файл публикации, мусор ОС.
const SKIP_FILE_RE = /(^|\/)(device\.zip|README\.md|amazface-publish\.json|\.DS_Store|Thumbs\.db)$|\.zpk$/i;

function createImporter(deps) {
  const { api, getToken, store, GhError } = deps;
  const log = deps.log || (() => {});
  const now = deps.now || (() => Date.now());
  const manifests = new Map(); // dir → { at, files: Map(path → entry) }

  // ---- проверка путей ----
  function segmentsOk(segs) {
    return segs.length > 0 && segs.length <= MAX_DEPTH && segs.every((s) =>
      s && s !== '.' && s !== '..' && s.toLowerCase() !== '.git' && s.length <= 255 && !/[\u0000-\u001f\\]/.test(s));
  }
  /** Папка проекта в репозитории: «a/b/c», без «..», «.git», обратных слэшей и абсолютных путей. */
  function cleanRepoDir(dir) {
    if (typeof dir !== 'string' || !dir || dir.startsWith('/') || dir.endsWith('/') || dir.length > 1000) {
      throw new GhError('Недопустимый путь папки проекта.', { code: 'bad_path', status: 400 });
    }
    const segs = dir.split('/');
    if (!segmentsOk(segs)) throw new GhError('Недопустимый путь папки проекта.', { code: 'bad_path', status: 400 });
    return segs.join('/');
  }
  function cleanRelPath(p) {
    if (typeof p !== 'string' || !p || p.startsWith('/') || p.endsWith('/') || p.length > 1000) {
      throw new GhError('Недопустимый путь файла.', { code: 'bad_path', status: 400 });
    }
    const segs = p.split('/');
    if (!segmentsOk(segs)) throw new GhError('Недопустимый путь файла.', { code: 'bad_path', status: 400 });
    return segs.join('/');
  }

  function connection() {
    const cfg = store.read().settings;
    return { cfg };
  }
  async function need() {
    const { cfg } = connection();
    const tok = await getToken();
    if (!cfg || !tok) throw new GhError('GitHub не подключён: откройте «Экспорт → Опубликовать на GitHub» и подключите репозиторий. Те же настройки используются для импорта.', { code: 'not_connected', status: 409 });
    return { cfg, tok };
  }

  // ---- дерево репозитория ----
  async function loadTree(cfg, tok) {
    let res;
    try {
      res = await api('GET', `/repos/${cfg.owner}/${cfg.repo}/git/trees/${IMPORT_BRANCH}?recursive=1`, { token: tok, timeoutMs: 60000 });
    } catch (e) {
      if (e.code === 'not_found') throw new GhError(`Ветка «${IMPORT_BRANCH}» или репозиторий ${cfg.owner}/${cfg.repo} не найдены (или у токена нет доступа). Для импорта используется ветка ${IMPORT_BRANCH}.`, { status: 404, code: 'branch_not_found' });
      if (e.status === 409) throw new GhError('Репозиторий пуст: в нём пока нет ни одного коммита.', { status: 409, code: 'empty_repo' });
      throw e;
    }
    const json = res.json || {};
    const tree = Array.isArray(json.tree) ? json.tree.filter((t) => t && t.type === 'blob' && typeof t.path === 'string') : [];
    return { tree, truncated: !!json.truncated };
  }

  /** Папки-кандидаты: есть файл .watchface.json. Для каждой — её файлы без вложенных проектов. */
  function groupCandidates(tree) {
    const dirs = new Map(); // dir → { states: [entry] }
    for (const t of tree) {
      const i = t.path.lastIndexOf('/');
      if (i <= 0) continue; // файлы в корне репозитория — не папки проектов
      const dir = t.path.slice(0, i), name = t.path.slice(i + 1);
      if (!STATE_FILE_RE.test(name)) continue;
      if (!segmentsOk(dir.split('/'))) continue;
      if (!dirs.has(dir)) dirs.set(dir, { states: [] });
      dirs.get(dir).states.push(t);
    }
    const byLen = [...dirs.keys()].sort((a, b) => b.length - a.length);
    for (const d of dirs.values()) d.files = [];
    for (const t of tree) {
      const owner = byLen.find((d) => t.path.startsWith(d + '/'));
      if (owner) dirs.get(owner).files.push(t);
    }
    return dirs;
  }

  async function readBlob(cfg, tok, entry, limit) {
    if (typeof entry.size === 'number' && entry.size > limit) {
      throw new GhError(`Файл «${entry.path}» слишком большой (${Math.round(entry.size / 1048576)} МБ).`, { code: 'too_big', status: 413 });
    }
    const res = await api('GET', `/repos/${cfg.owner}/${cfg.repo}/git/blobs/${encodeURIComponent(entry.sha)}`, { token: tok, timeoutMs: BLOB_TIMEOUT_MS });
    const j = res.json || {};
    if (j.encoding !== 'base64' || typeof j.content !== 'string') throw new GhError(`GitHub вернул файл «${entry.path}» в неожиданном виде.`, { code: 'bad_response' });
    const bytes = Buffer.from(j.content, 'base64');
    if (gitBlobSha(bytes) !== entry.sha) throw new GhError(`Файл «${entry.path}» скачался с ошибкой (не совпала контрольная сумма). Повторите.`, { code: 'corrupt_download' });
    return bytes;
  }

  /** Проверяет, что JSON — состояние редактора AmazFace. */
  function inspectState(text) {
    let obj;
    try { obj = JSON.parse(text); } catch (e) { return { ok: false, error: 'Файл состояния повреждён: это не корректный JSON.' }; }
    if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return { ok: false, error: 'Файл состояния повреждён: ожидался объект проекта.' };
    const hasScenes = obj.scenes && typeof obj.scenes === 'object' && obj.scenes.normal && Array.isArray(obj.scenes.normal.components);
    if (!Array.isArray(obj.components) && !hasScenes) return { ok: false, error: 'Файл не похож на состояние редактора AmazFace (нет списка компонентов).' };
    const name = obj.meta && typeof obj.meta.name === 'string' ? obj.meta.name.trim() : '';
    return { ok: true, name };
  }

  async function pool(items, n, fn) {
    const out = new Array(items.length);
    let next = 0;
    await Promise.all(Array.from({ length: Math.min(n, items.length) }, async () => {
      while (next < items.length) { const i = next++; out[i] = await fn(items[i], i); }
    }));
    return out;
  }

  // ───────── Список проектов ─────────
  async function listProjects() {
    const { cfg, tok } = await need();
    const { tree, truncated } = await loadTree(cfg, tok);
    const dirs = groupCandidates(tree);
    const all = [...dirs.keys()].sort();
    const limited = all.slice(0, MAX_CANDIDATES);
    const projects = [], invalid = [];
    await pool(limited, 4, async (dir) => {
      const folder = dir.slice(dir.lastIndexOf('/') + 1);
      const g = dirs.get(dir);
      if (g.states.length > 1) {
        invalid.push({ dir, folder, error: 'В папке несколько файлов .watchface.json — непонятно, какой из них проект.' });
        return;
      }
      const st = g.states[0];
      try {
        const bytes = await readBlob(cfg, tok, st, MAX_STATE_BYTES);
        const r = inspectState(bytes.toString('utf8'));
        if (r.ok) projects.push({ dir, folder, name: r.name, stateFile: st.path.slice(dir.length + 1), size: st.size });
        else invalid.push({ dir, folder, error: r.error });
      } catch (e) {
        // Сеть/лимиты прерывают весь список: показывать «пустой» результат было бы неправдой.
        if (e.network || e.code === 'rate_limit' || e.code === 'auth' || e.code === 'forbidden') throw e;
        invalid.push({ dir, folder, error: e.message });
      }
    });
    projects.sort((a, b) => a.dir.localeCompare(b.dir));
    invalid.sort((a, b) => a.dir.localeCompare(b.dir));
    log(`Импорт: найдено проектов ${projects.length}, повреждённых ${invalid.length} в ${cfg.owner}/${cfg.repo}@${IMPORT_BRANCH}`);
    return {
      repo: `${cfg.owner}/${cfg.repo}`, branch: IMPORT_BRANCH, projects, invalid,
      truncated: truncated || all.length > limited.length,
      note: truncated ? 'Репозиторий слишком большой: GitHub вернул неполный список.' : (all.length > limited.length ? `Показаны первые ${MAX_CANDIDATES} папок.` : '')
    };
  }

  // ───────── Манифест файлов выбранной папки ─────────
  async function buildManifest(dir) {
    const { cfg, tok } = await need();
    const { tree } = await loadTree(cfg, tok);
    const g = groupCandidates(tree).get(dir);
    if (!g) throw new GhError('Папка не найдена в репозитории или в ней нет файла .watchface.json.', { code: 'not_project', status: 404 });
    if (g.states.length !== 1) throw new GhError('В папке несколько файлов .watchface.json — импорт невозможен.', { code: 'not_project', status: 400 });
    const stateEntry = g.states[0];
    const files = new Map();
    let total = 0;
    for (const t of g.files) {
      const rel = t.path.slice(dir.length + 1);
      if (!segmentsOk(rel.split('/'))) continue;
      const isState = t.path === stateEntry.path;
      if (!isState && SKIP_FILE_RE.test(rel)) continue;
      if (!isState && STATE_FILE_RE.test(rel.split('/').pop())) continue;
      const role = isState ? 'state' : rel === 'project.zip' ? 'project-zip' : 'file';
      files.set(rel, { path: rel, repoPath: t.path, sha: t.sha, size: t.size || 0, role });
      total += t.size || 0;
    }
    if (files.size > MAX_FILES) throw new GhError(`В папке слишком много файлов (${files.size}).`, { code: 'too_big', status: 413 });
    if (total > MAX_TOTAL_BYTES) throw new GhError(`Папка слишком большая (${Math.round(total / 1048576)} МБ).`, { code: 'too_big', status: 413 });
    manifests.set(dir, { at: now(), files });
    return { dir, files, total };
  }

  async function getManifest(dirRaw) {
    const dir = cleanRepoDir(dirRaw);
    const m = await buildManifest(dir);
    return {
      dir, total: m.total,
      files: [...m.files.values()].map((f) => ({ path: f.path, size: f.size, role: f.role }))
    };
  }

  async function getFile(dirRaw, pathRaw) {
    const dir = cleanRepoDir(dirRaw);
    const rel = cleanRelPath(pathRaw);
    let m = manifests.get(dir);
    if (!m || now() - m.at > MANIFEST_TTL_MS) m = await buildManifest(dir);
    const entry = m.files.get(rel);
    if (!entry) throw new GhError('Такого файла нет в папке проекта.', { code: 'bad_path', status: 404 });
    const { cfg, tok } = await need();
    return readBlob(cfg, tok, { path: entry.repoPath, sha: entry.sha, size: entry.size }, entry.role === 'state' ? MAX_STATE_BYTES : MAX_FILE_BYTES);
  }

  return { listProjects, getManifest, getFile, _internals: { cleanRepoDir, cleanRelPath, inspectState, groupCandidates, STATE_FILE_RE, SKIP_FILE_RE } };
}

module.exports = { createImporter, IMPORT_BRANCH };
