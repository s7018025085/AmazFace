// Больше шрифт — больше рамка: надпись не должна обрезаться на часах.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const ctx = { console, Math, Date, JSON, Set, Map, Uint8Array, window: {}, requestAnimationFrame: () => 1, cancelAnimationFrame: () => {} };
vm.createContext(ctx);
for (const rel of ['src/util/slug.js', 'src/components/registry.js', 'src/components/text-box-grow.js', 'src/project/project.js']) {
  vm.runInContext(fs.readFileSync(path.join(root, rel), 'utf8'), ctx, { filename: rel });
}
vm.runInContext('globalThis.__S = ProjectStore; globalThis.__G = TextBoxGrow;', ctx);
const { __S: ProjectStore, __G: G } = ctx;
// Без DOM ширина = 0.6 × размер × число символов (в браузере измеряется реальным шрифтом).
const mk = (props, geo) => {
  const s = new ProjectStore();
  const c = s.addComponent('text', 100, 100);
  Object.assign(c, { x: 100, y: 100, w: 100, h: 30 }, geo || {});
  Object.assign(c.props, { data_source: 'NONE', text: 'Привет', text_size: 20, align_h: 'CENTER_H', align_v: 'CENTER_V' }, props || {});
  return { s, c };
};
const W = (n, size) => Math.ceil(n * size * 0.6 + size * G.PAD_X);

// Рост шрифта растит рамку; текст по центру остаётся по центру.
{
  const { s, c } = mk();
  const cx = c.x + c.w / 2, cy = c.y + c.h / 2;
  s.updateComponentProp(c.id, 'text_size', 60);
  assert.equal(c.w, W(6, 60), 'ширина = ширина надписи + запас');
  assert.equal(c.h, Math.ceil(60 * 1.2), 'высота = строка шрифта');
  assert.ok(Math.abs(c.x + c.w / 2 - cx) <= 1 && Math.abs(c.y + c.h / 2 - cy) <= 1, 'центр рамки не сместился');
}
// Выравнивание: LEFT/TOP держат левый/верхний край, RIGHT/BOTTOM — правый/нижний.
{
  const { s, c } = mk({ align_h: 'LEFT', align_v: 'TOP' });
  s.updateComponentProp(c.id, 'text_size', 60);
  assert.equal(c.x, 100); assert.equal(c.y, 100);
  const r = mk({ align_h: 'RIGHT', align_v: 'BOTTOM' }, { x: 250, y: 200 });
  r.s.updateComponentProp(r.c.id, 'text_size', 60);
  assert.equal(r.c.x + r.c.w, 350); assert.equal(r.c.y + r.c.h, 230);
}
// Уменьшение шрифта рамку не сжимает; вручную увеличенная рамка не трогается.
{
  const { s, c } = mk({ text_size: 40 }, { w: 300, h: 100 });
  s.updateComponentProp(c.id, 'text_size', 20);
  assert.deepEqual([c.w, c.h], [300, 100], 'уменьшение не меняет рамку');
  s.updateComponentProp(c.id, 'text_size', 30);
  assert.deepEqual([c.w, c.h], [300, 100], 'надпись и так помещается — рамка не растёт');
}
// Набор «6» → «60» даёт ровно то же, что ввод «60» сразу (расчёт не копит ошибок).
{
  const a = mk(), b = mk();
  for (const v of [6, 60]) a.s.updateComponentProp(a.c.id, 'text_size', v);
  b.s.updateComponentProp(b.c.id, 'text_size', 60);
  assert.deepEqual([a.c.x, a.c.y, a.c.w, a.c.h], [b.c.x, b.c.y, b.c.w, b.c.h]);
}
// Рамка не вылезает за экран.
{
  const { s, c } = mk({ align_h: 'LEFT' }, { x: 400, y: 10, w: 60, h: 30 });
  s.updateComponentProp(c.id, 'text_size', 200);
  const d = s.state.device;
  assert.ok(c.x >= 0 && c.y >= 0 && c.x + c.w <= d.w && c.y + c.h <= d.h, 'рамка в пределах экрана');
}
// Масштаб по X/Y и межбуквенный интервал учитываются; другие виджеты не трогаются.
assert.ok(G.grownBox({ x: 0, y: 0, w: 10, h: 10, props: { text_size: 20, scale_x: 2 } }, 100, null).w >= 200);
{
  const s = new ProjectStore();
  const r = s.addComponent('fill_rect', 10, 10);
  const before = [r.x, r.y, r.w, r.h];
  s.updateComponentProp(r.id, 'text_size', 90);
  assert.deepEqual([r.x, r.y, r.w, r.h], before, 'не-текстовые компоненты не меняются');
}
// Прочие свойства (цвет и т.п.) рамку не трогают.
{
  const { s, c } = mk();
  s.updateComponentProp(c.id, 'color', '#ff0000');
  assert.deepEqual([c.w, c.h], [100, 30]);
}
console.log('Text box grow tests passed.');
