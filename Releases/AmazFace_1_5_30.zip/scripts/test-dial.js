// Проверка компонента «Циферблат (шкала)»: геометрия меток и цифр, SVG для редактора,
// запись в реестре, запекание в PNG при экспорте и предупреждение без запекания.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.resolve(__dirname, '..');
const calls = [];
const mkCanvas = () => {
  const c = { width: 0, height: 0, getContext: () => new Proxy({}, { get: (_, k) => (k === 'canvas' ? c : (...a) => { calls.push([k, a]); }), set: (_, k, v) => { calls.push(['set:' + k, [v]]); return true; } }), toDataURL: () => 'data:image/png;base64,AAAA' };
  return c;
};
const ctx = { console, Math, Date, JSON, window: {}, document: { createElement: mkCanvas } };
vm.createContext(ctx);
const names = ['REGISTRY', 'exportIndexJs', 'DialModel', 'AOD_EXPORT_TYPES', 'prepareDialExportProject'];
for (const rel of ['src/util/slug.js', 'src/components/dial.js', 'src/components/registry.js', 'src/exporter/index-js-exporter.js', 'src/exporter/aod-exporter.js', 'src/exporter/project-exporter.js']) {
  const src = fs.readFileSync(path.join(root, rel), 'utf8');
  vm.runInContext(src + '\n;globalThis.__ex = Object.assign(globalThis.__ex || {}, {' +
    names.filter((n) => src.includes(`const ${n}`) || src.includes(`function ${n}`)).join(',') + '});', ctx, { filename: rel });
}
const { REGISTRY, exportIndexJs, DialModel, AOD_EXPORT_TYPES, prepareDialExportProject } = ctx.__ex;

let failed = 0;
function check(name, cond, extra) { if (!cond) { failed++; console.error('FAIL:', name, extra || ''); } else console.log('ok:', name); }
const mk = (props, id = 'dial1', box = {}) => ({ id, defId: 'dial', x: 40, y: 40, w: 400, h: 400, props: Object.assign({}, props), ...box });

// 1. Реестр
const def = REGISTRY.dial;
check('registry: компонент есть в «Фигуры»', def && def.category === 'Фигуры' && def.widgetId === 'WATCH_DIAL');
const keys = def.properties.map((p) => p.key);
check('registry: есть метки, цифры, шрифт, размер и цвет цифр',
  ['sections', 'minor_per_major', 'minor_shape', 'minor_color', 'major_shape', 'major_color', 'num_style', 'font', 'num_size', 'num_color'].every((k) => keys.includes(k)));
check('registry: виды меток — палочка и кружок', ['LINE', 'DOT'].every((v) => def.properties.find((p) => p.key === 'major_shape').options.some((o) => o.value === v)));
check('registry: шрифт — kind font', def.properties.find((p) => p.key === 'font').kind === 'font');

// 2. Метки: 12 секций × 5 = 60 делений, 12 основных
let t = DialModel.ticks(mk({}));
check('ticks: 60 меток по умолчанию', t.length === 60, t.length);
check('ticks: 12 основных', t.filter((x) => x.kind === 'major').length === 12);
check('ticks: первая основная вверху по центру', Math.abs(t[0].x1 - 200) < 1e-6 && Math.abs(t[0].y1 - 0) < 1e-6, JSON.stringify(t[0]));
const q3 = t.find((x) => x.kind === 'major' && Math.abs(x.angle - 90) < 1e-6);
check('ticks: основная на 3 часа — справа', q3 && Math.abs(q3.x1 - 400) < 1e-6 && Math.abs(q3.y1 - 200) < 1e-6, JSON.stringify(q3));
t = DialModel.ticks(mk({ sections: 4, minor_per_major: 1 }));
check('ticks: 4 секции без мелких → 4 метки', t.length === 4 && t.every((x) => x.kind === 'major'));
t = DialModel.ticks(mk({ sections: 60, minor_per_major: 1, major_enabled: false }));
check('ticks: 60 секций, основные выключены → 60 мелких', t.length === 60 && t.every((x) => x.kind === 'minor'));
t = DialModel.ticks(mk({ minor_enabled: false }));
check('ticks: мелкие выключены → только 12 основных', t.length === 12);
t = DialModel.ticks(mk({ major_enabled: false, minor_enabled: false }));
check('ticks: всё выключено → пусто', t.length === 0);
t = DialModel.ticks(mk({ sections: 999, minor_per_major: 999 }));
check('ticks: значения ограничены (≤ 60×30)', t.length <= 1800, t.length);
check('ticks: форма и цвет применяются', DialModel.ticks(mk({ major_shape: 'DOT', major_color: '#ff0000' }))[0].shape === 'DOT'
  && DialModel.ticks(mk({ major_color: '#ff0000' }))[0].color === '#ff0000');
check('ticks: неверная форма → палочка', DialModel.ticks(mk({ major_shape: 'XYZ' }))[0].shape === 'LINE');
check('ticks: недопустимый цвет → по умолчанию', DialModel.ticks(mk({ major_color: 'javascript:1' }))[0].color === '#ffffff');
t = DialModel.ticks(mk({ start_angle: 90, minor_enabled: false }));
check('ticks: поворот шкалы на 90°', Math.abs(t[0].x1 - 400) < 1e-6);
t = DialModel.ticks(mk({}, 'r', { w: 400, h: 300 }));
check('ticks: вписывается по меньшей стороне', Math.abs(t[0].y1 - 0) < 1e-6 && Math.abs(t[0].x1 - 200) < 1e-6 && t[0].rOut === 150, JSON.stringify(t[0]));

// 3. Цифры
let L = DialModel.labels(mk({}));
check('labels: 12 арабских, вверху 12', L.length === 12 && L[0].text === '12' && L[3].text === '3' && L[11].text === '11', L.map((l) => l.text).join());
check('labels: «12» вверху по центру, «6» внизу', Math.abs(L[0].x - 200) < 1e-6 && L[0].y < 200 && L[6].y > 200);
L = DialModel.labels(mk({ num_style: 'ROMAN' }));
check('labels: римские', L[0].text === 'XII' && L[4].text === 'IV' && L[9].text === 'IX', L.map((l) => l.text).join());
L = DialModel.labels(mk({ num_style: 'MIXED12' }));
check('labels: только 12·3·6·9', L.map((l) => l.text).join() === '12,3,6,9', L.map((l) => l.text).join());
check('labels: без цифр', DialModel.labels(mk({ num_style: 'NONE' })).length === 0);
L = DialModel.labels(mk({ num_count: 4 }));
check('labels: 4 цифры по кругу (4,1,2,3)', L.length === 4 && L[0].text === '4', L.map((l) => l.text).join());
L = DialModel.labels(mk({ num_size: 50, num_color: '#00ff00' }));
check('labels: размер и цвет цифр', L[0].size === 50 && L[0].color === '#00ff00');
const rIn = (c) => Math.hypot(c.x - 200, c.y - 200);
check('labels: цифры внутри меток (не вылезают за шкалу)', DialModel.labels(mk({})).every((l) => rIn(l) < 200 - 22));
check('labels: сдвиг от авто-позиции работает', rIn(DialModel.labels(mk({ num_offset: 10 }))[0]) > rIn(DialModel.labels(mk({}))[0]));
L = DialModel.labels(mk({ num_rotate: true }));
check('labels: поворот по кругу, снизу не вверх ногами', L[3].rot === 90 && L[6].rot === 0 && L[9].rot === -90, L.map((l) => l.rot).join());

// 4. SVG для редактора
const svg = DialModel.toSvg(mk({}), { cssFamily: 'ProjectFont_x', name: 'My' });
check('svg: метки и цифры, свой шрифт', svg.includes('data-dial="1"') && svg.includes('ProjectFont_x') && (svg.match(/<text /g) || []).length === 12);
check('svg: без цифр нет <text>', !DialModel.toSvg(mk({ num_style: 'NONE' }), null).includes('<text'));
check('svg: цвет не ломает разметку', !DialModel.toSvg(mk({ major_color: '"><script>' }), null).includes('<script'));


// 4a. Скрытие отдельных цифр
L = DialModel.labels(mk({ num_hidden: '1, 2' }));
check('hidden: «1, 2» убирает 1 и 2, остальные на месте', L.length === 10 && !L.some((l) => l.text === '1' || l.text === '2') && L.some((l) => l.text === '12' && l.angle === 0) && L.some((l) => l.text === '10'), L.map((l) => l.text).join());
check('hidden: «12» не задевает 1 и 2', DialModel.labels(mk({ num_hidden: '12' })).map((l) => l.text).join() === '1,2,3,4,5,6,7,8,9,10,11');
check('hidden: римские по тексту, регистр не важен', !DialModel.labels(mk({ num_style: 'ROMAN', num_hidden: 'i;ii xii' })).some((l) => ['I', 'II', 'XII'].includes(l.text)) && DialModel.labels(mk({ num_style: 'ROMAN', num_hidden: 'i;ii xii' })).length === 9);
check('hidden: оставшиеся цифры не сдвигаются', DialModel.labels(mk({ num_hidden: '1,2' })).find((l) => l.text === '3').x === DialModel.labels(mk({})).find((l) => l.text === '3').x);
check('hidden: метки остаются', DialModel.ticks(mk({ num_hidden: '1,2' })).length === 60);
check('registry: поле «Скрыть цифры»', def.properties.some((p) => p.key === 'num_hidden' && p.kind === 'text'));

// 4b. Тени: у меток и у цифр отдельные
check('registry: настройки тени меток и цифр', ['tick_shadow', 'num_shadow'].every((pre) => ['_enabled', '_color', '_alpha', '_blur', '_dx', '_dy'].every((k) => keys.includes(pre + k))));
check('shadow: по умолчанию выключены', DialModel.params(mk({})).tickShadow.on === false && DialModel.params(mk({})).numShadow.on === false);
const shp = DialModel.params(mk({ tick_shadow_enabled: true, tick_shadow_blur: 999, tick_shadow_dx: -999, tick_shadow_alpha: 50, tick_shadow_color: 'bad' })).tickShadow;
check('shadow: значения ограничены, плохой цвет → чёрный', shp.on && shp.blur === 40 && shp.dx === -40 && shp.alpha === 0.5 && shp.color === '#000000', JSON.stringify(shp));
const svgS = DialModel.toSvg(mk({ tick_shadow_enabled: true }), null);
check('svg: тень меток — фильтр только на метках', svgS.includes('feDropShadow') && (svgS.match(/<filter /g) || []).length === 1 && /<g filter="url\(#dsh-dial1-t\)">/.test(svgS) && !svgS.includes('dsh-dial1-n'));
const svgN = DialModel.toSvg(mk({ num_shadow_enabled: true, num_shadow_color: '#ff0000' }), null);
check('svg: тень цифр — отдельный фильтр со своим цветом', /<g filter="url\(#dsh-dial1-n\)">/.test(svgN) && !svgN.includes('dsh-dial1-t') && svgN.includes('flood-color="#ff0000"'));
check('svg: без тени нет фильтров', !DialModel.toSvg(mk({}), null).includes('<filter'));
check('svg: фильтры разных циферблатов не пересекаются', DialModel.toSvg(mk({ tick_shadow_enabled: true }, 'a1'), null).includes('dsh-a1-t') && DialModel.toSvg(mk({ tick_shadow_enabled: true }, 'b2'), null).includes('dsh-b2-t'));
{
  // порядок вызовов canvas: тень меток не должна попадать на цифры и наоборот
  const log = [];
  const cx = new Proxy({}, { get: (_, k) => (...a) => { log.push([k, a]); }, set: (_, k, v) => { log.push(['set:' + k, v]); return true; } });
  DialModel.paint(cx, mk({ tick_shadow_enabled: true, tick_shadow_blur: 6, tick_shadow_dx: 3, num_shadow_enabled: false }), null, 2, 0, 0);
  const firstText = log.findIndex((c) => c[0] === 'fillText');
  const tickShadowSet = log.findIndex((c) => c[0] === 'set:shadowBlur');
  const firstRestoreAfterTicks = log.findIndex((c, i) => c[0] === 'restore' && i > log.findIndex((x) => x[0] === 'fillRect'));
  check('paint: тень меток задана до меток и сброшена перед цифрами', tickShadowSet >= 0 && tickShadowSet < log.findIndex((c) => c[0] === 'fillRect') && firstRestoreAfterTicks < firstText);
  check('paint: размытие и смещение умножаются на масштаб', log.find((c) => c[0] === 'set:shadowBlur')[1] === 12 && log.find((c) => c[0] === 'set:shadowOffsetX')[1] === 6);
  check('paint: тень цифр выключена — на цифры тени нет', log.slice(firstRestoreAfterTicks).every((c) => c[0] !== 'set:shadowBlur'));
  log.length = 0;
  DialModel.paint(cx, mk({ num_shadow_enabled: true, num_shadow_color: '#112233', num_shadow_alpha: 100 }), null, 1, 0, 0);
  check('paint: тень цифр ставится на каждую цифру', log.filter((c) => c[0] === 'set:shadowColor').length === 12 && log.find((c) => c[0] === 'set:shadowColor')[1] === 'rgba(17,34,51,1)');
}


// 4c. Размер по умолчанию, шаг, особые метки, скругление, свои подписи, контур, доли пикселя
check('registry: размер по умолчанию 480×480 и центрирование', def.defaultSize.w === 480 && def.defaultSize.h === 480 && def.centerOnAdd === true);
check('registry: у всех числовых полей шкалы шаг 1 (без сотых) и целые границы', def.properties.filter((p) => p.kind === 'number' && /^(minor|major|cardinal|num|ring|tick_shadow|num_shadow|start_angle|alpha)/.test(p.key)).every((p) => (p.step === undefined || p.step === 1) && (p.min === undefined || Number.isInteger(p.min))));
check('registry: нет шага 0.01 ни в одном поле круга', [1, 6].every((k) => def.properties.filter((p) => p.key.startsWith('ring' + k + '_') && p.kind === 'number').every((p) => p.step === 1 && Number.isInteger(p.min))));
check('registry: поля особых меток, скругления, подписей, контура', ['cardinal_enabled', 'cardinal_shape', 'cardinal_color', 'minor_round', 'major_round', 'num_custom', 'num_italic', 'num_radius', 'num_stroke_enabled', 'num_stroke_width'].every((k) => keys.includes(k)));
check('доли пикселя: толщина 0.35 и длина 7.25 сохраняются', (() => { const x = DialModel.ticks(mk({ minor_width: 0.35, minor_length: 7.25 })).find((q) => q.kind === 'minor'); return x.width === 0.35 && x.len === 7.25; })());
{
  const c = DialModel.ticks(mk({ cardinal_enabled: true, cardinal_color: '#ff0000', cardinal_shape: 'TRIANGLE', cardinal_length: 40 }));
  const cards = c.filter((x) => x.kind === 'cardinal');
  check('cardinal: 4 особые метки на 12·3·6·9, остальных основных 8', cards.length === 4 && cards.map((x) => x.angle).join() === '0,90,180,270' && c.filter((x) => x.kind === 'major').length === 8 && c.length === 60, cards.map((x) => x.angle).join());
  check('cardinal: свой вид, цвет и длина', cards.every((x) => x.shape === 'TRIANGLE' && x.color === '#ff0000' && x.len === 40));
  check('cardinal: выключено по умолчанию', DialModel.ticks(mk({})).every((x) => x.kind !== 'cardinal'));
  check('cardinal: работает и при выключенных основных', DialModel.ticks(mk({ cardinal_enabled: true, major_enabled: false, minor_enabled: false })).length === 4);
  check('cardinal: число делений не кратно 4 → не рисуются', DialModel.ticks(mk({ cardinal_enabled: true, sections: 6, minor_per_major: 1 })).every((x) => x.kind !== 'cardinal'));
  check('cardinal: цифры уходят от длинных меток', rIn(DialModel.labels(mk({ cardinal_enabled: true, cardinal_length: 60 }))[0]) < rIn(DialModel.labels(mk({}))[0]));
}
check('round: скруглённые концы палочки (SVG rx, canvas arcTo)', DialModel.toSvg(mk({ major_round: true }), null).includes(' rx="') && !DialModel.toSvg(mk({}), null).includes(' rx="'));
{
  const log = [];
  const cx = new Proxy({}, { get: (_, k) => (...a) => { log.push(k); }, set: () => true });
  DialModel.paint(cx, mk({ major_round: true, minor_enabled: false }), null, 1, 0, 0);
  check('round: canvas рисует скруглённые палочки через arcTo', log.filter((k) => k === 'arcTo').length === 12 * 4 && !log.includes('fillRect'));
}
L = DialModel.labels(mk({ num_count: 4, num_custom: 'N,E,S,W' }));
check('custom: свои подписи N,E,S,W', L.map((l) => l.text).join() === 'N,E,S,W', L.map((l) => l.text).join());
L = DialModel.labels(mk({ num_count: 4, num_custom: 'N,,S' }));
check('custom: пропуск и короткий список → позиции без подписи', L.map((l) => l.text).join() === 'N,S' && L[1].angle === 180);
check('custom: скрытие работает и по своим подписям', DialModel.labels(mk({ num_count: 4, num_custom: 'N,E,S,W', num_hidden: 'e,w' })).map((l) => l.text).join() === 'N,S');
check('radius: явный радиус цифр', Math.abs(rIn(DialModel.labels(mk({ num_radius: 123.5 }))[0]) - 123.5) < 1e-6);
const svgT = DialModel.toSvg(mk({ num_stroke_enabled: true, num_stroke_color: '#ff00ff', num_stroke_width: 1.5, num_italic: true }), null);
check('stroke/italic: контур и курсив в SVG', svgT.includes('stroke="#ff00ff"') && svgT.includes('stroke-width="3"') && svgT.includes('paint-order="stroke"') && svgT.includes('font-style="italic"'));
{
  const log = [];
  const cx = new Proxy({}, { get: (_, k) => (...a) => { log.push([k, a]); }, set: (_, k, v) => { log.push(['set:' + k, v]); return true; } });
  DialModel.paint(cx, mk({ num_stroke_enabled: true, num_stroke_width: 2 }), null, 2, 0, 0);
  const iS = log.findIndex((c) => c[0] === 'strokeText'), iF = log.findIndex((c) => c[0] === 'fillText');
  check('stroke: контур рисуется под заливкой, ширина 2× и масштаб', iS >= 0 && iS < iF && log.filter((c) => c[0] === 'strokeText').length === 12 && log.find((c) => c[0] === 'set:lineWidth' && c[1] === 8));
}
// центрирование при добавлении (project.js: addComponent)
{
  const src = fs.readFileSync(path.join(root, 'src/project/project.js'), 'utf8');
  check('addComponent: центрирует компоненты с centerOnAdd', /def\.centerOnAdd/.test(src) && /device\.w - def\.defaultSize\.w\) \/ 2/.test(src));
}
const insp = fs.readFileSync(path.join(root, 'src/inspector/inspector.js'), 'utf8');
check('инспектор: поддерживает step у числовых полей', /p\.step !== undefined/.test(insp));


// 4d. Минутная шкала как на примере: 05…60 с ведущим нулём, повёрнутая по касательной; круги; контурные треугольники
L = DialModel.labels(mk({ num_start: 5, num_step: 5, num_pad: 2 }));
check('seq: 05,10,…,55,60 (вверху 60)', L.map((l) => l.text).join() === '60,05,10,15,20,25,30,35,40,45,50,55', L.map((l) => l.text).join());
L = DialModel.labels(mk({ num_start: 5, num_step: 5, num_pad: 2, num_top_first: true }));
check('seq: вверху 00, дальше 05,10…55', L.map((l) => l.text).join() === '00,05,10,15,20,25,30,35,40,45,50,55', L.map((l) => l.text).join());
check('seq: по умолчанию 12,1,2…11 (без нулей)', DialModel.labels(mk({})).map((l) => l.text).join() === '12,1,2,3,4,5,6,7,8,9,10,11');
check('seq: шаг 10 из 24 цифр', DialModel.labels(mk({ num_count: 6, num_start: 10, num_step: 10 })).map((l) => l.text).join() === '60,10,20,30,40,50');
check('seq: 12·3·6·9 с шагом 5 → 60,15,30,45', DialModel.labels(mk({ num_style: 'MIXED12', num_start: 5, num_step: 5 })).map((l) => l.text).join() === '60,15,30,45');
check('hidden: «5» скрывает «05», «00» и «0» — одно и то же', DialModel.labels(mk({ num_start: 5, num_step: 5, num_pad: 2, num_hidden: '5, 60' })).map((l) => l.text).join() === '10,15,20,25,30,35,40,45,50,55');
check('registry: поля ряда цифр и режим поворота', ['num_start', 'num_step', 'num_pad', 'num_top_first', 'num_rotate_mode'].every((k) => keys.includes(k)));
{
  const mode = (m) => DialModel.labels(mk({ num_rotate_mode: m })).map((l) => l.rot);
  check('rotate: FULL — верх наружу, без переворота (180° внизу)', mode('FULL')[3] === 90 && mode('FULL')[6] === 180 && mode('FULL')[9] === -90, mode('FULL').join());
  check('rotate: UPRIGHT — внизу читаемо', mode('UPRIGHT')[6] === 0 && mode('UPRIGHT')[3] === 90 && mode('UPRIGHT')[9] === -90);
  check('rotate: NONE и по умолчанию — прямо', mode('NONE').every((r) => r === 0) && DialModel.labels(mk({})).every((l) => l.rot === 0));
}
// круги
check('rings: по умолчанию кругов нет', DialModel.params(mk({})).rings.length === 0 && !DialModel.toSvg(mk({}), null).includes('<circle'));
check('registry: кольца 1–6 с отступом, цветом, тенью', [1, 6].every((k) => ['inset', 'width', 'color', 'alpha', 'fill', 'dash', 'gap', 'shadow_enabled', 'shadow_color', 'shadow_blur', 'shadow_dx', 'shadow_dy'].every((f) => keys.includes('ring' + k + '_' + f))) && keys.includes('rings_count'));
{
  const rp = DialModel.params(mk({ rings_count: 3, ring2_inset: 25.5, ring2_color: '#ff0000', ring2_width: 1.25, ring2_shadow_enabled: true }));
  check('rings: число кругов, смещение, цвет, толщина, тень', rp.rings.length === 3 && rp.rings[1].inset === 25.5 && rp.rings[1].color === '#ff0000' && rp.rings[1].width === 1.25 && rp.rings[1].shadow.on && !rp.rings[0].shadow.on);
  check('rings: не больше 6', DialModel.params(mk({ rings_count: 99 })).rings.length === 6);
  const sv = DialModel.toSvg(mk({ rings_count: 2, ring1_inset: 10, ring1_width: 4, ring1_dash: 6, ring1_gap: 3, ring2_fill: true, ring2_inset: 40, ring2_shadow_enabled: true }), null);
  check('rings svg: радиус = R − смещение − половина толщины, пунктир', sv.includes('r="188"') && sv.includes('stroke-dasharray="6 3"') && sv.includes('r="160"'), sv.slice(0, 600));
  check('rings svg: у круга своя тень (фильтр r2), у первого нет', sv.includes('dsh-dial1-r2') && !sv.includes('dsh-dial1-r1'));
  const log = [];
  const cx = new Proxy({}, { get: (_, k) => (...a) => { log.push([k, a]); }, set: (_, k, v) => { log.push(['set:' + k, v]); return true; } });
  DialModel.paint(cx, mk({ rings_count: 2, ring1_inset: 10, ring1_width: 4, ring1_dash: 6, ring1_gap: 3, ring2_fill: true, ring2_inset: 40 }), null, 2, 0, 0);
  const arcs = log.filter((c) => c[0] === 'arc'), iFirstTick = log.findIndex((c) => c[0] === 'fillRect');
  check('rings canvas: радиус и масштаб, пунктир, заливка, кольца под метками', arcs[0][1][2] === 376 && arcs[1][1][2] === 320 && log.some((c) => c[0] === 'setLineDash' && c[1][0].join() === '12,6') && log.findIndex((c) => c[0] === 'fill') < iFirstTick && log.findIndex((c) => c[0] === 'stroke') < iFirstTick, JSON.stringify(arcs.map((a) => a[1][2])));
}
// контурные и обращённые треугольники
{
  const tin = DialModel.ticks(mk({ major_shape: 'TRIANGLE_IN', major_outline: 1.5 })).find((x) => x.kind === 'major');
  check('outline: контур; старое значение TRIANGLE_IN = треугольник остриём внутрь', tin.shape === 'TRIANGLE' && tin.triDir === 'IN' && tin.outline === 1.5);
  const sv = DialModel.toSvg(mk({ major_shape: 'TRIANGLE_IN', major_outline: 1.5, major_color: '#ff0000', minor_enabled: false }), null);
  check('outline svg: fill none + stroke', sv.includes('fill="none" stroke="#ff0000" stroke-width="1.5"') && sv.includes('points="0,'));
  const log = [];
  const cx = new Proxy({}, { get: (_, k) => (...a) => { log.push(k); }, set: () => true });
  DialModel.paint(cx, mk({ major_shape: 'DIAMOND', major_outline: 2, minor_enabled: false, num_style: 'NONE' }), null, 1, 0, 0);
  check('outline canvas: stroke вместо fill', log.filter((k) => k === 'stroke').length === 12 && !log.includes('fill'));
  check('registry: контур у мелких, основных, особых меток; треугольник внутрь в списке', ['minor_outline', 'major_outline', 'cardinal_outline'].every((k) => keys.includes(k)) && def.properties.find((p) => p.key === 'major_shape').options.some((o) => o.value === 'TRIANGLE') && keys.includes('major_tri_dir'));
}
const inspSrc = fs.readFileSync(path.join(root, 'src/inspector/inspector.js'), 'utf8');
check('инспектор: пустые группы (все поля скрыты showIf) не показываются', /props\.every\(\(p\) => typeof p\.showIf === 'function'/.test(inspSrc));


// 4e. Направление треугольников, градиент меток, несколько обводок со смещением
{
  const mkLog = () => {
    const log = [];
    const cx = new Proxy({}, {
      get: (_, k) => (...a) => { log.push([k, a]); if (k === 'createLinearGradient') { const g = { stops: [], args: a, addColorStop: (o, c) => g.stops.push([o, c]) }; log.push(['grad', g]); return g; } },
      set: (_, k, v) => { log.push(['set:' + k, v]); return true; },
    });
    return { cx, log };
  };
  const tri = (props) => DialModel.ticks(mk(Object.assign({ major_shape: 'TRIANGLE', minor_enabled: false }, props)))[0];
  check('tri: по умолчанию остриём наружу (вершина на внешнем конце)', tri({}).triDir === 'OUT' && DialModel.tickGeom(tri({})).core[0].join() === '0,-11');
  check('tri: направление «внутрь» разворачивает треугольник', tri({ major_tri_dir: 'IN' }).triDir === 'IN' && DialModel.tickGeom(tri({ major_tri_dir: 'IN' })).core[0].join() === '0,11');
  check('tri: направление берётся для своей группы меток', DialModel.ticks(mk({ major_shape: 'TRIANGLE', major_tri_dir: 'IN', cardinal_enabled: true, cardinal_shape: 'TRIANGLE', cardinal_tri_dir: 'OUT', minor_enabled: false })).filter((q) => q.kind === 'major').every((q) => q.triDir === 'IN')
    && DialModel.ticks(mk({ major_shape: 'TRIANGLE', major_tri_dir: 'IN', cardinal_enabled: true, cardinal_shape: 'TRIANGLE', cardinal_tri_dir: 'OUT', minor_enabled: false })).filter((q) => q.kind === 'cardinal').every((q) => q.triDir === 'OUT'));
  check('tri svg: вершина снаружи / внутри', DialModel.toSvg(mk({ major_shape: 'TRIANGLE', minor_enabled: false }), null).includes('points="0,-11 ') && DialModel.toSvg(mk({ major_shape: 'TRIANGLE', major_tri_dir: 'IN', minor_enabled: false }), null).includes('points="0,11 '));
  {
    const a = mkLog(); DialModel.paint(a.cx, mk({ major_shape: 'TRIANGLE', major_tri_dir: 'IN', minor_enabled: false, num_style: 'NONE' }), null, 1, 0, 0);
    const b = mkLog(); DialModel.paint(b.cx, mk({ major_shape: 'TRIANGLE', minor_enabled: false, num_style: 'NONE' }), null, 1, 0, 0);
    check('tri canvas: первая вершина внизу (внутрь) / вверху (наружу)', a.log.find((c) => c[0] === 'moveTo')[1][1] === 11 && b.log.find((c) => c[0] === 'moveTo')[1][1] === -11);
  }
  check('registry: направление, градиент, обводки у мелких, основных и 12·3·6·9', ['minor', 'major', 'cardinal'].every((k) => ['_tri_dir', '_grad', '_outlines', '_ol1_gap', '_ol1_width', '_ol1_color', '_ol3_gap', '_ol3_width', '_ol3_color'].every((f) => keys.includes(k + f))));
  check('registry: у новых числовых полей шаг 1', def.properties.filter((p) => /_(outlines|ol\d_gap|ol\d_width)$/.test(p.key)).every((p) => p.step === 1 && Number.isInteger(p.min)));
  {
    const P = (k) => def.properties.find((p) => p.key === k);
    check('registry: поле направления только у треугольника', P('major_tri_dir').showIf({ major_shape: 'TRIANGLE' }) && !P('major_tri_dir').showIf({ major_shape: 'LINE' }) && !P('major_tri_dir').showIf({ major_enabled: false, major_shape: 'TRIANGLE' }));
    check('registry: настройки обводки N показываются по числу обводок', !P('major_ol1_gap').showIf({ major_outlines: 0 }) && P('major_ol1_gap').showIf({ major_outlines: 1 }) && !P('major_ol2_gap').showIf({ major_outlines: 1 }) && P('major_ol3_gap').showIf({ major_outlines: 3 }));
    check('registry: у особых меток всё скрыто, пока они выключены', !P('cardinal_grad').showIf({}) && P('cardinal_grad').showIf({ cardinal_enabled: true }));
  }

  // градиент
  check('grad: по умолчанию нет', DialModel.ticks(mk({})).every((q) => q.grad === 'NONE') && !DialModel.toSvg(mk({}), null).includes('linearGradient'));
  check('grad: неверное значение → нет', DialModel.ticks(mk({ major_grad: 'WAT' }))[0].grad === 'NONE');
  check('grad: у каждой группы меток свой', (() => {
    const g = DialModel.ticks(mk({ minor_grad: 'OUTER_CLEAR', major_grad: 'INNER_CLEAR', cardinal_enabled: true, cardinal_grad: 'OUTER_CLEAR' }));
    return g.filter((q) => q.kind === 'minor').every((q) => q.grad === 'OUTER_CLEAR') && g.filter((q) => q.kind === 'major').every((q) => q.grad === 'INNER_CLEAR') && g.filter((q) => q.kind === 'cardinal').every((q) => q.grad === 'OUTER_CLEAR');
  })());
  {
    const sv = DialModel.toSvg(mk({ minor_grad: 'OUTER_CLEAR', major_grad: 'INNER_CLEAR', cardinal_enabled: true, cardinal_grad: 'OUTER_CLEAR' }), null);
    check('grad svg: по градиенту на группу, не по метке', (sv.match(/<linearGradient /g) || []).length === 3 && sv.includes('id="dg-dial1-minor"') && sv.includes('id="dg-dial1-major"') && sv.includes('id="dg-dial1-cardinal"'));
    check('grad svg: метки заливаются градиентом', sv.includes('fill="url(#dg-dial1-major)"') && sv.includes('fill="url(#dg-dial1-minor)"'));
    const m = /<linearGradient id="dg-dial1-major"[^>]*y1="(-?[\d.]+)"[^>]*y2="(-?[\d.]+)"><stop offset="0" stop-color="#ffffff" stop-opacity="(\d)"\/><stop offset="1" stop-color="#ffffff" stop-opacity="(\d)"\/>/.exec(sv);
    check('grad svg: «снаружи цвет → внутри прозрачный» (INNER_CLEAR): 1 → 0, вдоль метки', m && m[1] === '-11' && m[2] === '11' && m[3] === '1' && m[4] === '0', m && m.slice(1).join());
    const m2 = /<linearGradient id="dg-dial1-minor"[^>]*><stop offset="0"[^>]*stop-opacity="(\d)"\/><stop offset="1"[^>]*stop-opacity="(\d)"\/>/.exec(sv);
    check('grad svg: «снаружи прозрачный → внутри цвет» (OUTER_CLEAR): 0 → 1', m2 && m2[1] === '0' && m2[2] === '1');
    const hv = DialModel.toSvg(mk({ major_grad: 'OUTER_CLEAR', major_shape: 'DIAMOND', major_outline: 2 }), null);
    check('grad svg: у контурной фигуры градиент на обводке', hv.includes('stroke="url(#dg-dial1-major)"'));
  }
  {
    const r = mkLog(); DialModel.paint(r.cx, mk({ major_grad: 'OUTER_CLEAR', num_style: 'NONE' }), null, 2, 0, 0);
    const grads = r.log.filter((c) => c[0] === 'grad').map((c) => c[1]);
    check('grad canvas: градиент только у 12 основных, вдоль метки, с учётом масштаба', grads.length === 12 && grads[0].args.join() === '0,-22,0,22', grads[0] && grads[0].args.join());
    check('grad canvas: от прозрачного к цвету', grads[0].stops[0][1] === 'rgba(255,255,255,0)' && grads[0].stops[1][1] === '#ffffff' && grads[0].stops[0][0] === 0 && grads[0].stops[1][0] === 1);
    check('grad canvas: заливка — этим градиентом', r.log.some((c) => c[0] === 'set:fillStyle' && c[1] === grads[0]));
    const r2 = mkLog(); DialModel.paint(r2.cx, mk({ major_grad: 'INNER_CLEAR', num_style: 'NONE', minor_enabled: false }), null, 1, 0, 0);
    const g2 = r2.log.find((c) => c[0] === 'grad')[1];
    check('grad canvas: от цвета к прозрачному', g2.stops[0][1] === '#ffffff' && g2.stops[1][1] === 'rgba(255,255,255,0)');
    const r3 = mkLog(); DialModel.paint(r3.cx, mk({ num_style: 'NONE' }), null, 1, 0, 0);
    check('grad canvas: без градиента он не создаётся', !r3.log.some((c) => c[0] === 'grad'));
  }

  // обводки со смещением
  check('outlines: по умолчанию нет, число ограничено 3', DialModel.ticks(mk({}))[0].outlines.length === 0 && DialModel.ticks(mk({ major_outlines: 99 }))[0].outlines.length === 3);
  {
    const o = DialModel.ticks(mk({ major_outlines: 3, major_ol2_gap: 9, major_ol2_width: 2, major_ol2_color: '#ff0000' }))[0].outlines;
    check('outlines: у каждой своё смещение, толщина и цвет (значения по умолчанию 2, 5, 8)', o.length === 3 && o[0].gap === 2 && o[1].gap === 9 && o[2].gap === 8 && o[1].width === 2 && o[1].color === '#ff0000' && o[0].color === '#ffffff', JSON.stringify(o));
    check('outlines: у разных групп меток — свои', DialModel.ticks(mk({ major_outlines: 2, minor_outlines: 1 })).find((q) => q.kind === 'minor').outlines.length === 1 && DialModel.ticks(mk({ major_outlines: 2 })).find((q) => q.kind === 'minor').outlines.length === 0);
  }
  {
    // кружок: радиус обводки = радиус фигуры + смещение + половина толщины
    const g = DialModel.tickGeom(DialModel.ticks(mk({ major_shape: 'DOT', major_width: 6, major_length: 22, minor_enabled: false }))[0]);
    const ops = DialModel.offsetOps(g.core, g.r0 + 2 + 0.5);
    check('offset: кружок r=3, смещение 2, толщина 1 → окружность r=5.5 в той же точке', ops.length === 1 && ops[0][0] === 'C' && ops[0][1] === 0 && ops[0][2] === -8 && ops[0][3] === 5.5, JSON.stringify(ops));
    const rect = DialModel.offsetOps([[-2, -5], [2, -5], [2, 5], [-2, 5]], 2.5);
    const pts = rect.filter((o) => o[0] === 'M' || o[0] === 'L');
    check('offset: прямоугольник 4×10 со смещением 2.5 → стороны на ±4.5 и ±7.5', Math.max(...pts.map((o) => Math.abs(o[1]))) === 4.5 && Math.max(...pts.map((o) => Math.abs(o[2]))) === 7.5 && rect.filter((o) => o[0] === 'A').length === 4, JSON.stringify(rect));
    const sweep = (ops) => ops.filter((o) => o[0] === 'A').reduce((a, o) => a + (o[5] - o[4]), 0);
    const triOps = DialModel.offsetOps([[0, -11], [3, 11], [-3, 11]], 3);
    const triIn = DialModel.offsetOps([[0, 11], [3, -11], [-3, -11]], 3);
    const dia = DialModel.offsetOps([[0, -11], [4, -7], [0, -3], [-4, -7]], 3);
    check('offset: у треугольника и ромба дуги в углах суммарно полный оборот (любое направление обхода)', [triOps, triIn, dia].every((o) => Math.abs(sweep(o) - Math.PI * 2) < 1e-9) && triOps.filter((o) => o[0] === 'A').length === 3 && dia.filter((o) => o[0] === 'A').length === 4, [sweep(triOps), sweep(triIn), sweep(dia)].join());
    const cap = DialModel.offsetOps([[0, -4], [0, 4]], 3);
    check('offset: скруглённая палочка (капсула) — две полукруглые дуги', cap.filter((o) => o[0] === 'A').length === 2 && Math.abs(sweep(cap) - Math.PI * 2) < 1e-9);
    const triEdge = triOps.filter((o) => o[0] === 'L');
    check('offset: сторона треугольника смещена наружу на 3 (расстояние от вершины до линии)', triEdge.every((o) => Math.hypot(o[1], o[2]) > 0) && Math.abs(Math.hypot(triOps[0][1] - 0, triOps[0][2] - -11) - 3) < 1e-9, JSON.stringify(triOps[0]));
    const sv = DialModel.toSvg(mk({ major_shape: 'DOT', major_width: 6, major_outlines: 1, minor_enabled: false }), null);
    check('outline svg: окружность r=5.5 с цветом и толщиной обводки', sv.includes('r="5.5" fill="none" stroke="#ffffff" stroke-width="1"'), sv.slice(0, 700));
    const sl = DialModel.toSvg(mk({ major_outlines: 1, major_ol1_gap: 2, major_ol1_color: '#ff00ff', minor_enabled: false }), null);
    check('outline svg: у палочки обводка — контур с дугами', /<path d="M[^"]*A[^"]*Z" fill="none" stroke="#ff00ff"/.test(sl));
    const r = mkLog(); DialModel.paint(r.cx, mk({ major_outlines: 2, major_ol2_color: '#00ff00', minor_enabled: false, num_style: 'NONE' }), null, 2, 0, 0);
    const strokes = r.log.filter((c) => c[0] === 'stroke').length;
    check('outline canvas: 2 обводки на каждую из 12 основных, цвет и толщина с учётом масштаба', strokes === 24 && r.log.some((c) => c[0] === 'set:strokeStyle' && c[1] === '#00ff00') && r.log.some((c) => c[0] === 'set:lineWidth' && c[1] === 2), String(strokes));
    check('outline canvas: без обводок stroke не вызывается', (() => { const q = mkLog(); DialModel.paint(q.cx, mk({ num_style: 'NONE' }), null, 1, 0, 0); return !q.log.some((c) => c[0] === 'stroke'); })());
    const shadowOl = DialModel.toSvg(mk({ major_outlines: 1, tick_shadow_enabled: true }), null);
    check('outline svg: тень меток включает и обводки (они внутри той же группы)', /<g filter="url\(#dsh-dial1-t\)">.*stroke-linejoin="round"\/><\/g>/.test(shadowOl));
  }
}


// 4f. Градиент «цвет → цвет»
{
  const mkLog = () => {
    const log = [];
    const cx = new Proxy({}, {
      get: (_, k) => (...a) => { log.push([k, a]); if (k === 'createLinearGradient') { const g = { stops: [], args: a, addColorStop: (o, c) => g.stops.push([o, c]) }; log.push(['grad', g]); return g; } },
      set: (_, k, v) => { log.push(['set:' + k, v]); return true; },
    });
    return { cx, log };
  };
  const P = (k) => def.properties.find((p) => p.key === k);
  check('2цвета: режим в списке и в модели', DialModel.GRADIENTS.includes('TWO_COLORS') && P('major_grad').options.some((o) => o.value === 'TWO_COLORS'));
  check('2цвета: второй цвет у каждой группы, поле видно только в этом режиме', ['minor', 'major', 'cardinal'].every((k) => keys.includes(k + '_grad_color2'))
    && !P('major_grad_color2').showIf({ major_grad: 'OUTER_CLEAR' }) && P('major_grad_color2').showIf({ major_grad: 'TWO_COLORS' }) && !P('major_grad_color2').showIf({ major_enabled: false, major_grad: 'TWO_COLORS' })
    && !P('cardinal_grad_color2').showIf({ cardinal_grad: 'TWO_COLORS' }) && P('cardinal_grad_color2').showIf({ cardinal_enabled: true, cardinal_grad: 'TWO_COLORS' }));
  const t2 = DialModel.ticks(mk({ major_grad: 'TWO_COLORS', major_color: '#ff0000', major_grad_color2: '#0000ff', minor_grad: 'TWO_COLORS', minor_grad_color2: '#00ff00' }));
  check('2цвета: у каждой группы свой второй цвет', t2.find((q) => q.kind === 'major').gradColor === '#0000ff' && t2.find((q) => q.kind === 'minor').gradColor === '#00ff00');
  check('2цвета: плохой цвет → значение по умолчанию', DialModel.ticks(mk({ major_grad: 'TWO_COLORS', major_grad_color2: 'x' }))[0].gradColor === '#ff9f1a');
  const sv = DialModel.toSvg(mk({ major_grad: 'TWO_COLORS', major_color: '#ff0000', major_grad_color2: '#0000ff', minor_enabled: false }), null);
  const m = /<linearGradient id="dg-dial1-major"[^>]*y1="(-?[\d.]+)"[^>]*y2="(-?[\d.]+)"><stop offset="0" stop-color="(#\w+)" stop-opacity="(\d)"\/><stop offset="1" stop-color="(#\w+)" stop-opacity="(\d)"\/>/.exec(sv);
  check('2цвета svg: от цвета метки (снаружи) к второму цвету (внутри), оба непрозрачные', m && m[1] === '-11' && m[2] === '11' && m[3] === '#ff0000' && m[5] === '#0000ff' && m[4] === '1' && m[6] === '1', m && m.slice(1).join());
  check('2цвета svg: метки залиты градиентом', sv.includes('fill="url(#dg-dial1-major)"'));
  const r = mkLog(); DialModel.paint(r.cx, mk({ major_grad: 'TWO_COLORS', major_color: '#ff0000', major_grad_color2: '#0000ff', minor_enabled: false, num_style: 'NONE' }), null, 2, 0, 0);
  const grads = r.log.filter((c) => c[0] === 'grad').map((c) => c[1]);
  check('2цвета canvas: 12 градиентов вдоль метки, стопы цвет → цвет', grads.length === 12 && grads[0].args.join() === '0,-22,0,22' && grads[0].stops.length === 2 && grads[0].stops[0].join() === '0,#ff0000' && grads[0].stops[1].join() === '1,#0000ff', grads[0] && JSON.stringify(grads[0].stops));
  check('2цвета canvas: цвет метки без второго не размывается прозрачностью', !JSON.stringify(grads[0].stops).includes('rgba'));
  const hv = DialModel.toSvg(mk({ major_grad: 'TWO_COLORS', major_shape: 'DIAMOND', major_outline: 2 }), null);
  check('2цвета: у контурной фигуры градиент на линии контура', hv.includes('stroke="url(#dg-dial1-major)"'));
  check('2цвета: прежние режимы не изменились (прозрачный → цвет)', (() => { const q = mkLog(); DialModel.paint(q.cx, mk({ major_grad: 'OUTER_CLEAR', num_style: 'NONE', minor_enabled: false }), null, 1, 0, 0); const g = q.log.find((c) => c[0] === 'grad')[1]; return g.stops[0][1] === 'rgba(255,255,255,0)' && g.stops[1][1] === '#ffffff'; })());
}

// 5. Рисование в canvas
calls.length = 0;
DialModel.paint(new Proxy({}, { get: (_, k) => (...a) => { calls.push([k, a]); }, set: (_, k, v) => { calls.push(['set:' + k, [v]]); return true; } }), mk({}), null, 1, 0, 0);
check('paint: рисует метки и 12 цифр', calls.filter((c) => c[0] === 'fillText').length === 12 && calls.filter((c) => c[0] === 'fillRect').length === 60);

// 6. Запекание в PNG
(async () => {
  const proj = { assets: [], fonts: [], components: [mk({}, 'd1')], scenes: { aod: { components: [mk({ num_style: 'NONE' }, 'd2')] } } };
  const out = await prepareDialExportProject(proj);
  check('запекание: исходный проект не изменён', proj.components[0].defId === 'dial' && proj.assets.length === 0);
  check('запекание: компоненты → image, ассеты PNG нужного размера', out.components[0].defId === 'image' && out.scenes.aod.components[0].defId === 'image'
    && out.assets.length === 2 && out.assets.every((a) => a.width === 400 && a.height === 400 && a.format === 'PNG' && a.generated));
  check('запекание: src указывает на ассет', out.components[0].props.src === out.assets[0].id);

  // 7. Без запекания — предупреждение, валидный код
  const r = exportIndexJs({ device: { w: 480, h: 480 }, components: [mk({}, 'd1')], assets: [], fonts: [], background: {} }, {}, {}, {});
  check('экспорт без запекания: предупреждение, не падает', r.validation.warnings.some((w) => w.includes('Циферблат')), JSON.stringify(r.validation.warnings));
  check('AOD: тип image', AOD_EXPORT_TYPES.WATCH_DIAL === 'image');

  if (failed) { console.error(`\n${failed} проверок не пройдено`); process.exit(1); }
  console.log('\nВсе проверки циферблата пройдены.');
})();
