'use strict';
// Градиентная заливка прямоугольника: модель направлений/переходов и запекание в PNG при экспорте.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert');
const root = path.resolve(__dirname, '..');

let failed = 0;
function check(name, ok, extra) {
  if (ok) console.log('ok  ' + name);
  else { failed++; console.log('FAIL ' + name + (extra ? ' :: ' + extra : '')); }
}

// Рисующий контекст, который записывает вызовы градиентов.
function makeCtx(log) {
  const ctx = {
    save() {}, restore() {}, clip() { log.push(['clip']); }, translate(x, y) { log.push(['translate', x, y]); },
    scale(x, y) { log.push(['scale', x, y]); }, beginPath() {}, closePath() {}, moveTo() {}, arcTo() {},
    rect(x, y, w, h) { log.push(['rect', x, y, w, h]); }, clearRect() {}, ellipse() {},
    fillRect(x, y, w, h) { log.push(['fillRect', x, y, w, h]); },
    createLinearGradient(...a) { const g = { kind: 'linear', a, stops: [], addColorStop(o, c) { this.stops.push([o, c]); } }; log.push(['grad', g]); return g; },
    createRadialGradient(...a) { const g = { kind: 'radial', a, stops: [], addColorStop(o, c) { this.stops.push([o, c]); } }; log.push(['grad', g]); return g; },
  };
  return ctx;
}
const grads = (log) => log.filter((e) => e[0] === 'grad').map((e) => e[1]);

const sandbox = { console, Math, JSON, Number, String, Array, Set, Object, window: {}, module: { exports: {} } };
sandbox.document = { createElement: () => { const log = []; const c = { width: 0, height: 0, __log: log, getContext: () => makeCtx(log), toDataURL: () => 'data:image/png;base64,AAAA' }; return c; } };
vm.createContext(sandbox);
const load = (rel, names) => {
  const src = fs.readFileSync(path.join(root, rel), 'utf8');
  vm.runInContext(src + `\n;Object.assign(globalThis, {${names.join(',')}});`, sandbox, { filename: rel });
};
load('src/components/rect-gradient.js', ['RectGradient']);
load('src/exporter/project-exporter.js', ['prepareGradientExportProject']);
const RG = sandbox.RectGradient;

// 1. Направления линейного градиента
const dirs = { lr: [10, 40, 110, 40], rl: [110, 40, 10, 40], tb: [60, 20, 60, 60], bt: [60, 60, 60, 20], diag: [10, 20, 110, 60] };
for (const [dir, expect] of Object.entries(dirs)) {
  const log = []; RG.paint(makeCtx(log), 10, 20, 100, 40, 0, { gradient_enabled: true, gradient_dir: dir, color: '#ff0000', gradient_to: '#0000ff' });
  const g = grads(log)[0];
  check(`направление ${dir}`, g && g.kind === 'linear' && JSON.stringify(g.a) === JSON.stringify(expect), g && JSON.stringify(g.a));
}

// 2. Режимы: цвет → цвет 2, прозрачный → цвет, цвет → прозрачный
const stopsFor = (props) => { const log = []; RG.paint(makeCtx(log), 0, 0, 100, 50, 0, Object.assign({ gradient_enabled: true, color: '#ff8000' }, props)); return grads(log)[0].stops; };
let st = stopsFor({ gradient_mode: 'two', gradient_to: '#00ff00' });
check('режим two: цвет → цвет 2', st[0][1] === 'rgba(255,128,0,1)' && st[1][1] === 'rgba(0,255,0,1)', JSON.stringify(st));
st = stopsFor({ gradient_mode: 'fade_in', gradient_to: '#00ff00' });
check('режим fade_in: прозрачный → цвет (цвет 2 игнорируется)', st[0][1] === 'rgba(255,128,0,0)' && st[1][1] === 'rgba(255,128,0,1)', JSON.stringify(st));
st = stopsFor({ gradient_mode: 'fade_out' });
check('режим fade_out: цвет → прозрачный', st[0][1] === 'rgba(255,128,0,1)' && st[1][1] === 'rgba(255,128,0,0)', JSON.stringify(st));
check('прозрачный стоп того же цвета (нет тёмной каймы)', st[1][1].startsWith('rgba(255,128,0,'));

// 3. Радиальный: из центра / к центру, вписан в прямоугольник
{
  const log = []; RG.paint(makeCtx(log), 20, 30, 200, 100, 0, { gradient_enabled: true, gradient_dir: 'radial', gradient_mode: 'fade_out', color: '#ffffff' });
  const g = grads(log)[0];
  const tr = log.find((e) => e[0] === 'translate'), sc = log.find((e) => e[0] === 'scale');
  check('radial: эллипс по размеру прямоугольника', g.kind === 'radial' && tr[1] === 120 && tr[2] === 80 && sc[1] === 100 && sc[2] === 50);
  check('radial: центр непрозрачный, край прозрачный', g.stops[0][1].endsWith(',1)') && g.stops[1][1].endsWith(',0)'), JSON.stringify(g.stops));
  const log2 = []; RG.paint(makeCtx(log2), 0, 0, 100, 100, 0, { gradient_enabled: true, gradient_dir: 'radial_in', gradient_mode: 'fade_out', color: '#ffffff' });
  const g2 = grads(log2)[0];
  check('radial_in: край непрозрачный, центр прозрачный', g2.stops[0][1].endsWith(',0)') && g2.stops[1][1].endsWith(',1)'), JSON.stringify(g2.stops));
}

// 4. Скругление клипует заливку
{
  const log = []; RG.paint(makeCtx(log), 0, 0, 100, 50, 12, { gradient_enabled: true, color: '#fff' });
  check('скругление: заливка обрезается по контуру (clip)', log.some((e) => e[0] === 'clip'));
}

// 5. Неизвестные значения → значения по умолчанию (старые проекты)
{
  const q = RG.params({ gradient_enabled: true, gradient_dir: 'bogus', gradient_mode: 'nope' });
  check('неизвестные dir/mode → lr/two', q.dir === 'lr' && q.mode === 'two');
  check('без gradient_enabled градиента нет', RG.params({ color: '#fff' }).enabled === false);
}

// 6. Запекание в PNG: подмена на image в обеих сценах, исходный проект не тронут
{
  const mk = (id, props, w = 120, h = 60) => ({ id, defId: 'fill_rect', name: id, x: 5, y: 6, w, h, visible: true, props });
  const proj = {
    assets: [],
    components: [mk('g1', { gradient_enabled: true, gradient_dir: 'tb', gradient_mode: 'fade_in', color: '#112233', radius: 10, alpha: 80 }), mk('plain', { color: '#fff' })],
    scenes: { aod: { components: [mk('g2', { gradient_enabled: true, color: '#fff' })] } },
  };
  const out = vm.runInContext('prepareGradientExportProject', sandbox)(proj);
  check('запекание: исходный проект не изменён', proj.components[0].defId === 'fill_rect' && proj.assets.length === 0);
  check('запекание: градиентный прямоугольник → image', out.components[0].defId === 'image' && out.scenes.aod.components[0].defId === 'image');
  check('запекание: обычный прямоугольник остался FILL_RECT', out.components[1].defId === 'fill_rect');
  const a = out.assets.find((x) => x.generatedFrom === 'g1');
  check('запекание: PNG-ассет размером w×h', a && a.width === 120 && a.height === 60 && a.format === 'PNG' && a.generated && a.dataUrl.startsWith('data:image/png'));
  check('запекание: src и общая прозрачность перенесены', out.components[0].props.src === a.id && out.components[0].props.alpha === 80);
  check('запекание: позиция сохранена', out.components[0].x === 5 && out.components[0].y === 6);
}

// 6b. Круг: эллиптический клип, запекание по центру и радиусу
{
  const log = []; const ctx = makeCtx(log); const ell = []; ctx.ellipse = (...a) => ell.push(a);
  RG.paint(ctx, 10, 20, 80, 80, 0, { gradient_enabled: true, color: '#fff' }, { ellipse: true });
  check('круг: клип по эллипсу, а не по прямоугольнику', ell.length === 1 && ell[0][0] === 50 && ell[0][1] === 60 && ell[0][2] === 40 && !log.some((e) => e[0] === 'rect'));
  const mkc = (id, props) => ({ id, defId: 'circle', name: id, x: 100, y: 100, w: 80, h: 80, visible: true, props });
  const proj = { assets: [], components: [mkc('c1', { gradient_enabled: true, center_x: 200, center_y: 150, radius: 30, color: '#fff', alpha: 90 }), mkc('c2', { color: '#fff' })], scenes: {} };
  const out = vm.runInContext('prepareGradientExportProject', sandbox)(proj);
  const c = out.components[0];
  check('круг: запечён в image по центру и радиусу', c.defId === 'image' && c.w === 60 && c.h === 60 && c.x === 170 && c.y === 120 && c.props.alpha === 90, JSON.stringify([c.defId, c.x, c.y, c.w, c.h]));
  check('круг: без градиента остался CIRCLE', out.components[1].defId === 'circle');
  const dflt = vm.runInContext('prepareGradientExportProject', sandbox)({ assets: [], components: [mkc('c3', { gradient_enabled: true, color: '#fff' })], scenes: {} }).components[0];
  check('круг: без center/radius берётся из рамки', dflt.x === 100 && dflt.y === 100 && dflt.w === 80);
}

// 7. Реестр: поля градиента и условная видимость
{
  const rsrc = fs.readFileSync(path.join(root, 'src/components/registry.js'), 'utf8');
  vm.runInContext(rsrc + '\n;globalThis.__REG = REGISTRY;', sandbox, { filename: 'registry.js' });
  const def = sandbox.__REG.fill_rect;
  const prop = (k) => def.properties.find((p) => p.key === k);
  check('реестр: поля градиента есть', ['gradient_enabled', 'gradient_dir', 'gradient_mode', 'gradient_to'].every((k) => prop(k)));
  check('реестр: направления и переходы — из модели', prop('gradient_dir').options.length === 7 && prop('gradient_mode').options.length === 3);
  check('реестр: параметры скрыты без галочки', !prop('gradient_dir').showIf({}) && prop('gradient_dir').showIf({ gradient_enabled: true }));
  const cdef = sandbox.__REG.circle;
  check('реестр: у круга те же поля градиента', ['gradient_enabled', 'gradient_dir', 'gradient_mode', 'gradient_to'].every((k) => cdef.properties.some((p) => p.key === k)));
  check('реестр: «Цвет 2» только для перехода цвет→цвет', prop('gradient_to').showIf({ gradient_enabled: true, gradient_mode: 'two' }) && !prop('gradient_to').showIf({ gradient_enabled: true, gradient_mode: 'fade_in' }));
}

if (failed) { console.log(`\n${failed} failed`); process.exit(1); }
console.log('\nrect-gradient: all passed');
