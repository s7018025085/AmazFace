// Контейнеры (группы слоёв): создание, перенос, удаление, сцены, сохранение/открытие.
// Запуск: node scripts/test-groups.js
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.resolve(__dirname, '..');
const context = { console, Math, Date, JSON, Set, Map, window: {}, requestAnimationFrame: () => 1, cancelAnimationFrame: () => {} };
vm.createContext(context);
for (const rel of ['src/util/slug.js', 'src/components/registry.js', 'src/project/project.js']) {
  vm.runInContext(fs.readFileSync(path.join(root, rel), 'utf8'), context, { filename: rel });
}
vm.runInContext('globalThis.__PS = ProjectStore;', context);
const ProjectStore = context.__PS;

let passed = 0, failed = 0;
const check = (n, c, x) => { if (c) { passed++; console.log('ok: ' + n); } else { failed++; console.log('FAIL: ' + n + (x ? ' — ' + x : '')); } };

const store = new ProjectStore();
check('новый проект: список контейнеров пуст', Array.isArray(store.state.groups) && store.state.groups.length === 0);

const a = store.addComponent('tap_zone', 10, 10);
const b = store.addComponent('tap_zone', 50, 50);
const c = store.addComponent('tap_zone', 90, 90);

// Создание пустого контейнера
const g1 = store.addGroup('Датчики', []);
check('addGroup: контейнер создан с именем', store.state.groups.length === 1 && g1.name === 'Датчики' && g1.collapsed === false);
check('addGroup: пустой контейнер без участников', store.getGroupMembers(g1.id).length === 0);
check('addGroup: id уникален и непустой', typeof g1.id === 'string' && g1.id.length > 0);

// Имя по умолчанию
const g2 = store.addGroup('', []);
check('addGroup: имя по умолчанию', /^Контейнер \d+$/.test(g2.name), g2.name);
const g3 = store.addGroup(undefined, []);
check('addGroup: имена по умолчанию не повторяются', g3.name !== g2.name);
store.removeGroup(g2.id); store.removeGroup(g3.id);

// Создание из выделения
store.setSelection([b.id, c.id]);
const g4 = store.addGroup('Из выделения');
check('addGroup: выделенные компоненты попадают внутрь',
  store.getGroupMembers(g4.id).map((x) => x.id).sort().join() === [b.id, c.id].sort().join());
check('addGroup: невыделенный остался снаружи', !store.state.components.find((x) => x.id === a.id).group);

// Перенос
check('setComponentsGroup: перенос в контейнер', store.setComponentsGroup([a.id], g1.id) === true && store.getGroupMembers(g1.id).length === 1);
check('setComponentsGroup: повтор ничего не меняет', store.setComponentsGroup([a.id], g1.id) === false);
check('setComponentsGroup: несуществующий контейнер отклонён', store.setComponentsGroup([a.id], 'group_nope') === false && a.group === g1.id);
store.setComponentsGroup([a.id], null);
check('setComponentsGroup: null выводит из контейнера', !('group' in store.state.components.find((x) => x.id === a.id)));

// Переименование и сворачивание
check('renameGroup: новое имя', store.renameGroup(g1.id, '  Панель датчиков ') === true && store.getGroup(g1.id).name === 'Панель датчиков');
check('renameGroup: пустое имя отклонено', store.renameGroup(g1.id, '   ') === false && store.getGroup(g1.id).name === 'Панель датчиков');
store.toggleGroupCollapsed(g1.id);
check('toggleGroupCollapsed: свёрнут', store.getGroup(g1.id).collapsed === true);

// Удаление контейнера не удаляет компоненты
const before = store.state.components.length;
store.removeGroup(g4.id);
check('removeGroup: компоненты остались', store.state.components.length === before);
check('removeGroup: ссылка на контейнер снята', store.state.components.every((x) => x.group !== g4.id));
check('removeGroup: контейнера больше нет', !store.getGroup(g4.id));
check('removeGroup: неизвестный id → false', store.removeGroup('group_nope') === false);

// Дублирование компонента из контейнера оставляет копию в том же контейнере
store.setComponentsGroup([a.id], g1.id);
store.duplicateComponents([a.id]);
check('duplicateComponents: копия остаётся в контейнере', store.getGroupMembers(g1.id).length === 2);

// Undo / redo
store.addGroup('Временный', []);
const n = store.state.groups.length;
store.undo();
check('undo: создание контейнера откатывается', store.state.groups.length === n - 1);
store.redo();
check('redo: контейнер возвращается', store.state.groups.length === n);

// Сохранение и открытие
const json = store.toJSON();
const reopened = new ProjectStore();
reopened.loadFromJSON(json);
check('сохранение/открытие: контейнеры сохранены', reopened.state.groups.length === store.state.groups.length
  && reopened.state.groups.some((g) => g.name === 'Панель датчиков' && g.collapsed === true));
check('сохранение/открытие: членство сохранено', reopened.getGroupMembers(g1.id).length === 2);

// Старый проект без контейнеров
const legacy = JSON.parse(json);
delete legacy.groups;
for (const sc of Object.values(legacy.scenes)) delete sc.groups;
legacy.components.forEach((x) => delete x.group);
const old = new ProjectStore();
old.loadFromJSON(JSON.stringify(legacy));
check('старый проект открывается без контейнеров', Array.isArray(old.state.groups) && old.state.groups.length === 0);

// Висячая ссылка на несуществующий контейнер
const dangling = JSON.parse(json);
dangling.components[0].group = 'group_deleted';
dangling.scenes.normal.components[0].group = 'group_deleted';
const dg = new ProjectStore();
dg.loadFromJSON(JSON.stringify(dangling));
check('висячая ссылка на контейнер снимается при открытии', !dg.state.components[0].group && !dg.state.scenes.normal.components[0].group);

// Сцены: контейнеры независимы
const sc = new ProjectStore();
const s1 = sc.addComponent('tap_zone', 5, 5);
const day = sc.addGroup('День', [s1.id]);
sc.switchScene('night');
check('сцена Ночь: копия дня несёт контейнеры', sc.state.groups.some((g) => g.name === 'День') && sc.state.components[0].group === day.id);
sc.addGroup('Только ночью', []);
sc.switchScene('normal');
check('сцена День: контейнер ночи не протекает', sc.state.groups.length === 1 && sc.state.groups[0].name === 'День');
sc.switchScene('aod');
check('сцена AOD: пустая, без контейнеров', sc.state.groups.length === 0);
sc.createAodFromNormal();
check('AOD из Normal: переносятся только используемые контейнеры', sc.state.groups.length === 1 && sc.state.groups[0].id === day.id);
sc.switchScene('normal');
check('после возврата в День контейнер на месте', sc.state.groups.length === 1 && sc.state.components[0].group === day.id);

// Флаг «скрыта при запуске»
{
  const hs = new ProjectStore();
  const hg = hs.addGroup('Скрываемая', []);
  check('startHidden: по умолчанию выключен', !hs.getGroup(hg.id).startHidden);
  check('setGroupStartHidden: включение', hs.setGroupStartHidden(hg.id, true) === true && hs.getGroup(hg.id).startHidden === true);
  check('setGroupStartHidden: повтор ничего не меняет', hs.setGroupStartHidden(hg.id, true) === false);
  const re = new ProjectStore();
  re.loadFromJSON(JSON.stringify(hs.state));
  check('startHidden: сохраняется и открывается', re.getGroup(hg.id) && re.getGroup(hg.id).startHidden === true);
  hs.setGroupStartHidden(hg.id, false);
  check('setGroupStartHidden: выключение убирает флаг', !('startHidden' in hs.getGroup(hg.id)));
  check('setGroupStartHidden: неизвестный контейнер отклонён', hs.setGroupStartHidden('group_nope', true) === false);
}

console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed ? 1 : 0);
