// Только необходимое: ресурсы, на которые проект не ссылается, в GitHub-исходник не попадают.
// Запуск: node scripts/test-asset-prune.js
const assert = require('node:assert/strict');
const A = require('../src/project/asset-prune.js');
const asset = (id, extra) => Object.assign({ id, name: id, dataUrl: 'data:image/png;base64,' + 'A'.repeat(100) }, extra);
const state = () => ({
  assets: [asset('a_used'), asset('a_bg'), asset('a_src'), asset('a_unused'), asset('a_sheet'), asset('a_anim')],
  fonts: [{ id: 'f_used', name: 'F', dataUrl: 'data:font/ttf;base64,AAAA' }, { id: 'f_unused', name: 'G', dataUrl: 'data:font/ttf;base64,BBBB' }],
  background: { color: '#000', imageAssetId: 'a_bg' },
  scenes: { normal: { components: [{ id: 'c1', props: { path: 'a_used', font: 'f_used' } }] }, night: { components: [] } },
});

// Лишнее убирается, нужное остаётся.
{
  const st = state();
  const r = A.pruneState(st);
  const ids = r.state.assets.map((a) => a.id);
  assert.deepEqual(ids.sort(), ['a_bg', 'a_used']);
  assert.deepEqual(r.state.fonts.map((f) => f.id), ['f_used']);
  assert.equal(r.removed.length, 5, 'убраны: a_src, a_unused, a_sheet, a_anim, f_unused');
  assert.equal(st.assets.length, 6, 'исходное состояние не меняется');
}
// Ссылка внутри нужного ресурса (исходник, из которого собран PNG) удерживает исходник.
{
  const st = state();
  st.assets.find((a) => a.id === 'a_bg').sourceId = 'a_src';
  const ids = A.pruneState(st).state.assets.map((a) => a.id);
  assert.ok(ids.includes('a_src'), 'исходник нужного ресурса остаётся');
  assert.ok(!ids.includes('a_unused'));
}
// Ссылка из другой сцены и из кадров анимации фона тоже считается использованием.
{
  const st = state();
  st.scenes.night.components.push({ id: 'c2', props: { frames: ['a_anim'] } });
  assert.ok(A.pruneState(st).state.assets.some((a) => a.id === 'a_anim'));
}
// Текст JSON: если убирать нечего, текст возвращается как есть; иначе уменьшается.
{
  const full = JSON.stringify(state());
  const r = A.pruneJsonText(full);
  assert.ok(r.text.length < full.length && r.removed.length === 5);
  const clean = A.pruneState(state()).state;
  const same = JSON.stringify(clean);
  assert.equal(A.pruneJsonText(same).text, same);
  assert.equal(A.pruneJsonText('не json').text, 'не json');
}
console.log('Asset prune tests passed.');
