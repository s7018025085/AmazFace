// Проверка /fs/* моста: реальный HTTP-сервер + клиентский BridgeFs + FsProject + swap.
const http = require('http'), fs = require('fs'), os = require('os'), path = require('path'), assert = require('assert');
const { createFsRoutes } = require('../bridge/fs-routes');
const KEY = 'k'.repeat(32);
const routes = createFsRoutes({ key: () => KEY });
const server = http.createServer((q, s) => routes.matches(q) ? routes.handle(q, s) : (s.writeHead(404), s.end()));
const store = {};
global.window = global; global.localStorage = { getItem: (k) => store[k] || null, setItem: (k, v) => { store[k] = v; } };
let n = 0; const ok = (m) => { n++; console.log('ok:', m); };

server.listen(0, '127.0.0.1', async () => {
  global.ZEUS_BRIDGE = `http://127.0.0.1:${server.address().port}`;
  store.amazface_bridge_key = KEY;
  require('../src/project/bridge-fs.js');
  eval(fs.readFileSync(path.join(__dirname, '../src/project/fs-project.js'), 'utf8') + ';global.FsProject=FsProject;');
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'af-fs-'));
  try {
    const root = await BridgeFs.open(tmp);
    ok('open: папка зарегистрирована');
    await assert.rejects(() => BridgeFs.open(path.parse(tmp).root), /Корень диска/); ok('корень диска запрещён');

    const p = new FsProject(root);
    await p.write('app.json', '{"app":1}');
    await p.write('assets/a/b.png', new Uint8Array([1, 2, 3, 250]));
    fs.mkdirSync(path.join(tmp, 'node_modules')); fs.writeFileSync(path.join(tmp, 'node_modules/x.js'), 'x');
    assert.deepStrictEqual([...fs.readFileSync(path.join(tmp, 'assets/a/b.png'))], [1, 2, 3, 250]); ok('write: вложенные папки, байты');

    const p2 = new FsProject(await BridgeFs.open(tmp));
    await p2.scan();
    assert.deepStrictEqual([...p2.files.keys()].sort(), ['app.json', 'assets/a/b.png']); ok('scan одним запросом, node_modules пропущен');
    assert.strictEqual(p2.readText('app.json'), '{"app":1}'); ok('readText');
    assert.strictEqual(await p2.write('app.json', '{"app":1}'), false); ok('одинаковый файл не перезаписывается');

    assert.strictEqual(await p2.exists('assets/a/b.png'), true);
    assert.strictEqual(await p2.remove('assets/a/b.png'), true);
    assert.ok(!fs.existsSync(path.join(tmp, 'assets/a')), 'пустые папки убраны'); ok('remove + чистка пустых папок');
    assert.strictEqual(await p2.remove('nope.txt'), false); ok('remove отсутствующего — не ошибка');

    for (const bad of ['../x', '/etc/passwd', 'a\\b', 'C:/x']) {
      await assert.rejects(() => root.getFileHandle(bad, { create: true }).then((h) => h.createWritable()).then((w) => w.close()), undefined, bad);
    }
    ok('пути вне корня отклоняются');

    // swap: создание и замена
    const tmpA = 'proj.amazface-import-tmp-a';
    const t1 = await root.getDirectoryHandle(tmpA, { create: true });
    const w = await (await t1.getFileHandle('amazface.project.json', { create: true })).createWritable(); await w.write('v1'); await w.close();
    const made = await BridgeFs.swap(root, tmpA, 'proj', false);
    assert.strictEqual(fs.readFileSync(path.join(tmp, 'proj/amazface.project.json'), 'utf8'), 'v1');
    assert.strictEqual(made.name, 'proj'); ok('swap: новая папка');
    const t2 = await root.getDirectoryHandle('proj.amazface-import-tmp-b', { create: true });
    const w2 = await (await t2.getFileHandle('amazface.project.json', { create: true })).createWritable(); await w2.write('v2'); await w2.close();
    await assert.rejects(() => BridgeFs.swap(root, 'proj.amazface-import-tmp-b', 'proj', false), /уже существует/);
    assert.strictEqual(fs.readFileSync(path.join(tmp, 'proj/amazface.project.json'), 'utf8'), 'v1'); ok('swap без replace не трогает существующее');
    await BridgeFs.swap(root, 'proj.amazface-import-tmp-b', 'proj', true);
    assert.strictEqual(fs.readFileSync(path.join(tmp, 'proj/amazface.project.json'), 'utf8'), 'v2');
    assert.deepStrictEqual(fs.readdirSync(tmp).filter((x) => /old-|tmp-/.test(x)), []); ok('swap replace: без мусора рядом');

    // выбор папки: подставной диалог (zenity) печатает путь; журнал /fs/log и сведения о папке
    if (process.platform === 'linux') {
      const bin = fs.mkdtempSync(path.join(os.tmpdir(), 'af-bin-'));
      fs.writeFileSync(path.join(bin, 'zenity'), `#!/bin/sh\nprintf '%s' '${tmp}'\n`, { mode: 0o755 });
      const oldPath = process.env.PATH; process.env.PATH = bin + path.delimiter + oldPath;
      try {
        const picked = await BridgeFs.pick('t');
        assert.strictEqual(picked.bridgePath, tmp); ok('pick: путь из диалога получен, а не «отмена»');
        fs.writeFileSync(path.join(bin, 'zenity'), '#!/bin/sh\nexit 1\n', { mode: 0o755 });
        await assert.rejects(() => BridgeFs.pick('t'), (e) => e.name === 'AbortError' && /без/.test(e.reason)); ok('pick: отмена даёт причину');
      } finally { process.env.PATH = oldPath; fs.rmSync(bin, { recursive: true, force: true }); }
    }

    // без ключа
    store.amazface_bridge_key = 'bad'; global.prompt = () => '';
    await assert.rejects(() => BridgeFs.open(tmp), /код доступа/i); ok('без кода доступа — отказ');
    console.log(`\nBridge FS: ${n} проверок прошло.`);
  } catch (e) { console.error('FAIL', e); process.exitCode = 1; }
  finally { fs.rmSync(tmp, { recursive: true, force: true }); server.close(); }
});
