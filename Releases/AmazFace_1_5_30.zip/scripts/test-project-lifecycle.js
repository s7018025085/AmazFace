// Сквозная проверка: создать проект → сохранить → открыть → переключить сцены → подготовить экспорт.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');

const root = path.resolve(__dirname, '..');
const context = {
  console, Math, Date, JSON, Set, Map, Uint8Array,
  window: {},
  requestAnimationFrame: () => 1,
  cancelAnimationFrame: () => {},
};
vm.createContext(context);
for (const rel of [
  'src/util/slug.js',
  'src/components/registry.js',
  'src/project/project.js',
  'src/assets/weather-icons.js',
  'src/exporter/index-js-exporter.js',
]) {
  vm.runInContext(fs.readFileSync(path.join(root, rel), 'utf8'), context, { filename: rel });
}
vm.runInContext(`
  globalThis.__ProjectStore = ProjectStore;
  globalThis.__WeatherIcons = WeatherIcons;
  globalThis.__Export = { computeAssetFilenames, exportIndexJsDual };
`, context);

const ProjectStore = context.__ProjectStore;
const WeatherIcons = context.__WeatherIcons;
const Export = context.__Export;
const PNG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/p1sAAAAASUVORK5CYII=';
const store = new ProjectStore();
assert.strictEqual(store.state.watchSettings.hourlyVibration, undefined, 'hourly vibration was removed from the project settings');

// Сохраняем обычный фон и два слота погодных иконок как обычные ресурсы проекта.
store.state.assets.push(
  { id: 'asset_dial_bg', name: 'dial-background', dataUrl: PNG, width: 480, height: 480, format: 'PNG', size: 68 },
  { id: 'asset_weather_sunny', name: 'weather_sunny', dataUrl: PNG, width: 64, height: 64, format: 'PNG', size: 68, weatherIcon: 'sunny' },
  { id: 'asset_weather_cloudy', name: 'weather_cloudy', dataUrl: PNG, width: 64, height: 64, format: 'PNG', size: 68, weatherIcon: 'cloudy' },
);
store.state.background.imageAssetId = 'asset_dial_bg';
const weather = store.addComponent('weather_icon', 80, 100);
store.updateComponentProp(weather.id, 'src', 'sunny');
store.addComponent('time_hm', 100, 30);
store.commit();

// AOD начинается как копия Normal, затем правится отдельно.
assert.strictEqual(store.createAodFromNormal({ filter: (c) => c.defId === 'weather_icon' }), 1);
const aodWeather = store.state.components.find((c) => c.defId === 'weather_icon');
store.updateComponentProp(aodWeather.id, 'src', 'cloudy');
store.switchScene('normal');
assert.strictEqual(store.state.mode, 'normal');
assert.strictEqual(store.state.components.find((c) => c.defId === 'weather_icon').props.src, 'sunny');
assert.strictEqual(store.state.background.imageAssetId, 'asset_dial_bg');
store.switchScene('aod');
assert.strictEqual(store.state.mode, 'aod');
assert.strictEqual(store.state.components.find((c) => c.defId === 'weather_icon').props.src, 'cloudy');

// JSON round-trip must reopen in Normal while retaining the independent AOD scene and resources.
const saved = store.toJSON();
const reopened = new ProjectStore();
reopened.loadFromJSON(saved);
assert.strictEqual(reopened.state.mode, 'normal', 'opening a saved project starts in Normal');
assert.strictEqual(reopened.state.components.find((c) => c.defId === 'weather_icon').props.src, 'sunny');
assert.strictEqual(reopened.state.background.imageAssetId, 'asset_dial_bg');
assert.ok(reopened.state.assets.some((a) => a.id === 'asset_weather_sunny' && a.weatherIcon === 'sunny'));
assert.ok(reopened.state.assets.some((a) => a.id === 'asset_weather_cloudy' && a.weatherIcon === 'cloudy'));
reopened.switchScene('aod');
assert.strictEqual(reopened.state.components.find((c) => c.defId === 'weather_icon').props.src, 'cloudy');

// AOD composition picker can add/remove a Normal layer without sharing objects across scenes.
const pickerStore = new ProjectStore();
const pickerTime = pickerStore.addComponent('time_hm', 80, 40);
pickerStore.switchScene('aod');
assert.strictEqual(pickerStore.toggleAodComponentFromNormal(pickerTime.id), true, 'Normal layer can be added to AOD');
const pickerAodTime = pickerStore.state.components.find((c) => c.id === pickerTime.id);
assert.ok(pickerAodTime && pickerAodTime !== pickerTime, 'AOD layer is an independent component copy');
pickerStore.updateComponentProp(pickerAodTime.id, 'text_size', 64);
pickerStore.switchScene('normal');
assert.notStrictEqual(pickerStore.state.components.find((c) => c.id === pickerTime.id).props.text_size, 64, 'editing the AOD copy does not change Normal');
pickerStore.switchScene('aod');
assert.strictEqual(pickerStore.toggleAodComponentFromNormal(pickerTime.id), false, 'included Normal layer can be removed from AOD');
assert.ok(!pickerStore.state.components.some((c) => c.id === pickerTime.id), 'removed layer disappears from AOD');

// Export preflight inputs: normal image maps as an asset; weather images stay in weather slots.
const assetMap = Export.computeAssetFilenames(reopened.state);
assert.ok(assetMap.asset_dial_bg, 'regular image is assigned an export filename');
assert.ok(!assetMap.asset_weather_sunny && !assetMap.asset_weather_cloudy, 'weather images are excluded from root asset files');
assert.strictEqual(WeatherIcons.dataUrlFor(reopened.state, 3), PNG, 'sunny slot exports its saved image');
assert.strictEqual(WeatherIcons.dataUrlFor(reopened.state, 0), PNG, 'cloudy slot exports its saved image');
const generated = Export.exportIndexJsDual(reopened.state, assetMap, {});
assert.ok(generated.code.includes('weather/'), 'dual-scene export contains weather resource paths');
assert.strictEqual(generated.validation.errors.length, 0, 'dual-scene export has no validation errors');
assert.ok(!generated.code.includes('__afHourlyCheck'), 'no hourly vibration code is generated');
// Старый проект с включённой почасовой вибрацией открывается без неё: миграция удаляет настройку,
// а экспорт не создаёт ни таймера, ни датчика вибрации.
const legacyRaw = reopened.toJSON();
const legacyObj = typeof legacyRaw === 'string' ? JSON.parse(legacyRaw) : JSON.parse(JSON.stringify(legacyRaw));
legacyObj.watchSettings = Object.assign({}, legacyObj.watchSettings, { hourlyVibration: true });
const legacyStore = new ProjectStore();
legacyStore.loadFromJSON(typeof legacyRaw === 'string' ? JSON.stringify(legacyObj) : legacyObj);
assert.strictEqual(legacyStore.state.watchSettings.hourlyVibration, undefined, 'legacy hourlyVibration flag is dropped on open');
const legacyGenerated = Export.exportIndexJsDual(legacyStore.state, assetMap, {});
assert.ok(!legacyGenerated.code.includes('__afHourlyCheck') && !legacyGenerated.code.includes('hmSensor.id.VIBRATE'), 'legacy project exports without hourly vibration');
assert.strictEqual(legacyGenerated.validation.errors.length, 0, 'legacy project export has no generator errors');

// A settings action is a normal child tap-zone property and survives project save/reopen.
const settingsProject = new ProjectStore();
const settingsComponent = settingsProject.addComponent('fill_rect', 80, 80);
const settingsZone = settingsProject.addTapZone(settingsComponent.id);
settingsProject.updateTapZone(settingsComponent.id, settingsZone.id, { props: { tap_action: 'SETTINGS' } });
const settingsReopened = new ProjectStore();
settingsReopened.loadFromJSON(settingsProject.toJSON());
assert.strictEqual(settingsReopened.state.components[0].tapZones[0].props.tap_action, 'SETTINGS', 'settings action survives save and reopen');
const settingsExport = Export.exportIndexJsDual(settingsReopened.state, {}, {});
assert.ok(settingsExport.code.includes('__afOpenSettings();'), 'saved settings action reaches the watchface export');
assert.strictEqual(settingsExport.validation.errors.length, 0, 'settings action passes export validation');

console.log('Project lifecycle smoke test passed (create/save/reopen/Normal+AOD/weather/assets/export).');
