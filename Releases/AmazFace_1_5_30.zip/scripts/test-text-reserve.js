// Запас под самое длинное значение: рамка текста с живыми данными растёт, чтобы на часах не появлялось «...».
// Запуск: node scripts/test-text-reserve.js
const path = require('node:path');
const vm = require('node:vm');
const fx = require('./export-fixtures.js');
const root = path.resolve(__dirname, '..');
const { exportIndexJs } = fx.loadExporter(root);

let passed = 0, failed = 0;
const check = (n, c, x) => { if (c) { passed++; console.log('ok: ' + n); } else { failed++; console.log('FAIL: ' + n + (x ? ' — ' + x : '')); } };

function textWidgets(code) {
  const widgets = [];
  const mk = (type, params) => { const w = { type, params, setProperty() {}, setAlpha() {} }; widgets.push(w); return w; };
  const proxy = new Proxy({}, { get: (_, k) => String(k) });
  let built = null;
  const sb = { console, Math, Date, JSON, Map, Set, createWidget: mk, widget: proxy, align: proxy, text_style: proxy, prop: proxy, show_level: proxy, data_type: proxy,
    system_status: proxy, anim_status: proxy, launchApp() {}, setInterval: () => 1, clearInterval() {}, setTimeout: () => 1, clearTimeout() {},
    Time: function () { this.getTime = () => 0; }, Battery: function () {}, Step: function () {}, Calorie: function () {}, HeartRate: function () {}, Distance: function () {},
    Screen: function () {}, WatchFace: (o) => { built = o; }, getAutoBrightness: () => false, getBrightness: () => 50, setAutoBrightness() {}, setBrightness() {} };
  vm.createContext(sb);
  vm.runInContext(code.replace(/^import .*$/gm, ''), sb, { filename: 'index.js' });
  built.build.call({});
  return widgets.filter((w) => /TEXT/.test(w.type) && w.params && w.params.text_size);
}

const txt = (id, props, geo) => fx.mk(id, 'text', Object.assign({ text_size: 36, align_h: 'LEFT', align_v: 'CENTER_V', text_style: 'NONE' }, props), Object.assign({ x: 90, y: 260, w: 110, h: 50 }, geo));
const build = (comp) => textWidgets(exportIndexJs(fx.project([comp]), {}, {}, {}).code)[0].params;

// Шаги: 5 цифр + значок помещаются, рамка растёт вправо, левый край не двигается.
{
  const p = build(txt('s1', { data_source: 'STEP', prefix: '🚶' }));
  check('шаги: рамка шире исходной', p.w > 110, 'w=' + p.w);
  check('шаги: левый край на месте', p.x === 90, 'x=' + p.x);
  check('шаги: высота и вертикаль не меняются', p.h === 50 && p.y === 260, `h=${p.h} y=${p.y}`);
}
// Выравнивание по центру: рамка растёт в обе стороны, центр остаётся.
{
  const p = build(txt('s2', { data_source: 'STEP', align_h: 'CENTER_H' }));
  check('центр: рамка шире', p.w > 110);
  check('центр: центр рамки прежний', Math.abs((p.x + p.w / 2) - (90 + 55)) <= 1, `cx=${p.x + p.w / 2}`);
}
// Правый край держится при выравнивании RIGHT.
{
  const p = build(txt('s3', { data_source: 'STEP', align_h: 'RIGHT' }));
  check('справа: правый край прежний', p.x + p.w === 200, `right=${p.x + p.w}`);
}
// Температура: «-99°» не влезает в 50 px.
{
  const p = build(txt('t1', { data_source: 'WEATHER_TEMP' }, { x: 350, y: 265, w: 50, h: 40 }));
  check('температура: рамка шире 50', p.w > 50, 'w=' + p.w);
}
// Без изменений: статический текст и уже широкая рамка.
{
  const p1 = build(txt('n1', { data_source: 'NONE', text: 'Привет' }));
  check('статический текст: рамка прежняя', p1.w === 110 && p1.x === 90);
  // «Вместить в границы» подбирает кегль через canvas браузера — в node не проверяется; запас там не добавляется (ранний выход в reserveTextBox).
  const p3 = build(txt('n3', { data_source: 'STEP' }, { w: 300 }));
  check('широкая рамка не сжимается и не растёт', p3.w === 300);
}
// Рамка не вылезает за экран.
{
  const p = build(txt('e1', { data_source: 'STEP' }, { x: 420, w: 60 }));
  check('край экрана: рамка внутри 480', p.x >= 0 && p.x + p.w <= 480, `x=${p.x} w=${p.w}`);
}

console.log(`${passed} passed, ${failed} failed`);
if (failed) process.exit(1);
console.log('Text reserve tests passed.');
