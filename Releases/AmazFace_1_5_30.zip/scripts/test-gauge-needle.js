// Проверка компонента «Стрелочный датчик»: модель углов, реестр и экспорт на часы.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.resolve(__dirname, '..');
const ctx = { console, Math, Date, JSON, window: {} };
vm.createContext(ctx);
for (const rel of ['src/util/slug.js', 'src/components/gauge-needle.js', 'src/components/registry.js', 'src/exporter/index-js-exporter.js']) {
  const src = fs.readFileSync(path.join(root, rel), 'utf8');
  vm.runInContext(src + '\n;globalThis.__ex = Object.assign(globalThis.__ex || {}, {' +
    ['REGISTRY', 'exportIndexJs', 'GaugeNeedleModel'].filter((n) => src.includes(`const ${n}`) || src.includes(`function ${n}`)).join(',') + '});', ctx, { filename: rel });
}
const { REGISTRY, exportIndexJs, GaugeNeedleModel: M } = ctx.__ex;

let failed = 0;
const check = (name, cond, extra) => { if (!cond) { failed++; console.error('FAIL:', name, extra || ''); } else console.log('ok:', name); };
const syntaxOk = (code) => { try { new vm.Script(code.replace(/^import .*$/gm, '')); return true; } catch (e) { return e.message; } };
const near = (a, b) => Math.abs(a - b) < 1e-9;
const ASSET = { id: 'needle', name: 'needle.png', width: 38, height: 200, format: 'PNG', dataUrl: 'data:image/png;base64,AAAA' };
const mk = (props, extra) => Object.assign({ id: 'g1', defId: 'gauge_needle', x: 221, y: 40, w: 38, h: 200,
  props: Object.assign({ path: 'needle', center_x: 240, center_y: 240, pos_x: 19, pos_y: 100 }, props) }, extra);
const run = (comps) => exportIndexJs({ device: { w: 480, h: 480 }, components: comps, assets: [ASSET], fonts: [], background: {} }, { needle: 'needle.png' }, {}, {});

// 1. Реестр
const def = REGISTRY.gauge_needle;
check('реестр: компонент есть, виджет GAUGE_NEEDLE', !!def && def.widgetId === 'GAUGE_NEEDLE');
check('реестр: в категории аналоговых стрелок', def.category === 'Аналоговые стрелки');
const keys = def.properties.map((q) => q.key);
check('реестр: ключи уникальны', new Set(keys).size === keys.length);
check('реестр: есть PNG, углы от/до, центр и опора',
  ['path', 'start_angle', 'end_angle', 'center_x', 'center_y', 'pos_x', 'pos_y'].every((k) => keys.includes(k)));
check('реестр: не single (можно поставить несколько датчиков)', !def.single);
check('реестр: path — ресурс-картинка', def.properties.find((q) => q.key === 'path').kind === 'asset');

// 2. Модель углов
check('углы: начало/конец диапазона', near(M.angleAt(mk({ start_angle: -120, end_angle: 120 }), 0), -120) && near(M.angleAt(mk({ start_angle: -120, end_angle: 120 }), 1), 120));
check('углы: середина диапазона', near(M.angleAt(mk({ start_angle: -120, end_angle: 120 }), 0.5), 0));
check('углы: обратное направление (до < от)', near(M.angleAt(mk({ start_angle: 90, end_angle: -90 }), 0.25), 45));
check('углы: доля вне 0..1 обрезается', near(M.angleAt(mk({ start_angle: 0, end_angle: 100 }), 5), 100) && near(M.angleAt(mk({ start_angle: 0, end_angle: 100 }), -2), 0));
check('углы: «мусорные» значения → по умолчанию', (() => { const q = M.params(mk({ start_angle: 'abc', end_angle: '', data_source: 'XXX' })); return q.start === -120 && q.end === 120 && q.source === 'NONE'; })());
check('предпросмотр: датчик — по «% диапазона»', near(M.previewAngle(mk({ data_source: 'HEART', start_angle: 0, end_angle: 200, preview_percent: 25 })), 50));
check('предпросмотр: время — по часам (минуты, 30 мин = половина)', near(M.previewAngle(mk({ data_source: 'MINUTE', start_angle: 0, end_angle: 360 }), new Date(2026, 0, 1, 10, 30, 0)), 180));
check('предпросмотр: часы 10:00 → 10/12 круга', near(M.previewAngle(mk({ data_source: 'HOUR', start_angle: 0, end_angle: 360 }), new Date(2026, 0, 1, 10, 0, 0)), 300));
check('диапазон: пульс без value_max → 200 по умолчанию', M.params(mk({ data_source: 'HEART', value_min: 0, value_max: 0 })).vMax === 200);
check('диапазон: свои пределы 60…160', (() => { const q = M.params(mk({ data_source: 'HEART', value_min: 60, value_max: 160 })); return q.vMin === 60 && q.vMax === 160 && q.span === 100; })());
check('опора: рамка = центр − опора', (() => { const v = M.pivot(mk({})); return v.left === 221 && v.top === 140; })());

// 3. Экспорт: пульс 60..160, углы -130..130
let r = run([mk({ data_source: 'HEART', value_min: 60, value_max: 160, start_angle: -130, end_angle: 130 })]);
check('экспорт: валидный JS', syntaxOk(r.code) === true, syntaxOk(r.code));
check('экспорт: без ошибок', r.validation && Array.isArray(r.validation.errors) && r.validation.errors.length === 0, JSON.stringify(r.validation));
check('экспорт: стрелка — IMG с осью вращения', /createWidget\(widget\.IMG/.test(r.code) && /center_x: 240/.test(r.code) && /center_y: 240/.test(r.code));
check('экспорт: позиция PNG = центр − опора', /pos_x: 221/.test(r.code) && /pos_y: 140/.test(r.code));
check('экспорт: PNG стрелки подключён', r.code.includes('needle.png'));
check('экспорт: диапазон углов -130 + 260 × доля', /-130 \+ \(260\) \* r/.test(r.code), (r.code.match(/const a = .*/) || [''])[0]);
check('экспорт: значение (v − 60) / 100', /\(v - 60\) \/ 100/.test(r.code));
check('экспорт: чтение пульса и поворот через prop.MORE', /_heartVal/.test(r.code) && /prop\.MORE, \{ angle:/.test(r.code));
check('экспорт: пульс подключает датчик HeartRate', /HeartRate/.test(r.code));
check('экспорт: обновление раз в 5 с (_tickSensors)', /_tickSensors/.test(r.code));
check('экспорт: поворот IMG помечен как непроверенный (⚠)', r.validation.warnings.some((w) => /GAUGE_NEEDLE/.test(w)));

// 4. Шаги 0..10000, время, статика
r = run([mk({ data_source: 'STEP', value_min: 0, value_max: 8000, start_angle: 200, end_angle: 340 })]);
check('шаги: валидный JS, Step-датчик, (v − 0) / 8000', syntaxOk(r.code) === true && /Step/.test(r.code) && /\(v - 0\) \/ 8000/.test(r.code));
check('шаги: диапазон 200 + 140 × доля', /200 \+ \(140\) \* r/.test(r.code));
r = run([mk({ data_source: 'BATTERY', value_min: 0, value_max: 0 })]);
check('батарея: значение «полно» по умолчанию = 100', syntaxOk(r.code) === true && /\(v - 0\) \/ 100/.test(r.code));
r = run([mk({ data_source: 'SECOND', start_angle: 0, end_angle: 360 })]);
check('секунды: _tick раз в секунду, доля now.getSeconds() / 60', syntaxOk(r.code) === true && /_tick\(\)/.test(r.code) && /now\.getSeconds\(\) \/ 60/.test(r.code));
r = run([mk({ data_source: 'NONE', start_angle: 0, end_angle: 100, preview_percent: 40 })]);
check('статика: стоит на 40 % диапазона, таймеров нет', syntaxOk(r.code) === true && /angle: 40\b/.test(r.code) && !/_set\(/.test(r.code) && !/_tickSensors/.test(r.code));
r = run([mk({ data_source: 'HEART', alpha: 50 })]);
check('прозрачность: setAlpha при < 100 %', /setAlpha\(/.test(r.code));

// 5. Два датчика на одном циферблате (как на скриншоте) — разные переменные, оба обновляются
r = run([
  mk({ data_source: 'HEART', value_min: 60, value_max: 160, start_angle: -130, end_angle: 130, center_x: 240, center_y: 100 }, { id: 'g1' }),
  mk({ data_source: 'STEP', value_min: 0, value_max: 10000, start_angle: -130, end_angle: 130, center_x: 240, center_y: 380 }, { id: 'g2' }),
]);
const setFns = r.code.match(/function \w+_set\(r\)/g) || [];
check('два датчика: валидный JS', syntaxOk(r.code) === true, syntaxOk(r.code));
check('два датчика: две независимые функции обновления', setFns.length === 2 && new Set(setFns).size === 2, setFns.join());
check('два датчика: оба подключены к _tickSensors', /_heartVal/.test(r.code) && /_step/.test(r.code));

// 6. Ошибки: нет PNG — экспорт сообщает, а не падает
r = run([mk({ path: '', data_source: 'HEART' })]);
check('нет PNG: ошибка экспорта «не выбрано изображение» (не падение)', r.validation.errors.some((e) => /не выбрано изображение/.test(e)) && syntaxOk(r.code) === true);

// 7. Отрицательные / большие углы нормализуются в 0..360
r = run([mk({ data_source: 'NONE', start_angle: -90, end_angle: 90, preview_percent: 0 })]);
check('нормализация: -90° → 270° в createWidget', /angle: 270\b/.test(r.code));

console.log(failed ? `\n${failed} проверок не прошло` : '\nВсе проверки компонента «Стрелочный датчик» пройдены');
process.exit(failed ? 1 : 0);
