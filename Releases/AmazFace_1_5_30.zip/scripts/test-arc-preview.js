// Проверка ArcModel (предпросмотр дуги): заполнение против часовой, градиент с конца, слои контура и тени.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');
const win = {};
const ctx = { console, Math, Date, JSON, window: win, document: { createElement: () => ({}) }, navigator: {}, requestAnimationFrame: () => 0 };
win.window = win;
vm.createContext(ctx);
let src = fs.readFileSync(path.join(root, 'src/preview/renderer.js'), 'utf8');
try { vm.runInContext(src, ctx, { filename: 'renderer.js' }); } catch (e) { /* DOM-часть может не стартовать — нужен только ArcModel */ }
const M = ctx.window.ArcModel;
let failed = 0;
function check(name, cond, extra) { if (!cond) { failed++; console.error('FAIL:', name, extra || ''); } else console.log('ok:', name); }
check('ArcModel загружен', !!M && !!M.fillRange && !!M.decoLayers);
const near = (a, b) => Math.abs(a - b) < 1e-9;

let r = M.fillRange({}, 0, 270, 0.5);
check('forward: 0 → 135', near(r[0], 0) && near(r[1], 135), JSON.stringify(r));
r = M.fillRange({ reverse_fill: true }, 0, 270, 0.5);
check('reverse: от конца (270) назад до 135', near(r[0], 135) && near(r[1], 270), JSON.stringify(r));
r = M.fillRange({ reverse_fill: true }, 0, 270, 1);
check('reverse 100 %: весь диапазон', near(r[0], 0) && near(r[1], 270));

// сегменты
const base = { gradient_enabled: true, gradient_steps: 4, color: '#ff0000', color2: '#0000ff', segment_gap: 0 };
let segs = M.segs(base, 0, 240, 0.5, false);
check('forward segs: 2 сегмента от 0 до 120', segs.length === 2 && near(segs[0].a, 0) && near(segs[1].b, 120), JSON.stringify(segs));
segs = M.segs({ ...base, reverse_fill: true }, 0, 240, 0.5, false);
// Перекрытие стыков 1° может оставить у соседнего сегмента «хвост» в 1° — он перекрыт следующим сегментом (рисуется позже).
const big = segs.filter((sg) => Math.abs(sg.b - sg.a) > 1.5);
check('reverse segs: 2 последних сегмента, заканчиваются на 240', big.length === 2 && near(big[big.length - 1].b, 240) && near(big[0].a, 120), JSON.stringify(segs));
check('reverse segs: у конца дуги цвет начала градиента (красный)', segs[segs.length - 1].color === '#ff0000', segs[segs.length - 1].color);
segs = M.segs({ ...base, reverse_fill: true }, 0, 240, 1, true);
check('reverse track: подложка целиком (4 сегмента)', segs.length === 4);

// слои декора
check('нет декора по умолчанию', M.decoLayers({}, 100, 100).length === 0);
let l = M.decoLayers({ outline_enabled: true, outline_width: 3, outline_color: '#fff' }, 100, 100);
check('outline: один слой s=3, выступ за концы > 0 (прямые концы)', l.length === 1 && l[0].s === 3 && l[0].ext > 0, JSON.stringify(l));
l = M.decoLayers({ outline_enabled: true, rounded_ends: true }, 100, 100);
check('outline + скругление: выступ 0', l[0].ext === 0);
l = M.decoLayers({ shadow_enabled: true, shadow_blur: 0, shadow_alpha: 50, shadow_dx: 1, shadow_dy: 2 }, 100, 100);
check('shadow hard: 1 слой, alpha 0.5, сдвиг', l.length === 1 && near(l[0].alpha, 0.5) && l[0].dx === 1 && l[0].dy === 2, JSON.stringify(l));
l = M.decoLayers({ shadow_enabled: true, shadow_blur: 10, shadow_alpha: 60, outline_enabled: true, outline_width: 2 }, 100, 100);
check('shadow soft + outline: 5 слоёв тени + контур, порядок: широкие → узкие → контур', l.length === 6 && l[0].s === 12 && l[4].s === 2 && l[5].kind === 'outline' && l[0].kind === 'shadow', JSON.stringify(l.map((x) => x.kind + x.s)));
check('shadow soft: суммарная alpha слоёв = shadow_alpha', near(l.slice(0, 5).reduce((a, x) => a + x.alpha, 0), 0.6));
if (failed) { console.error(`\n${failed} проверок не прошли`); process.exit(1); }
console.log('\nВсе проверки предпросмотра дуги прошли.');
