// Стрелки «выше/ниже» в панели слоёв: компоненты и контейнеры двигаются так, как это видно в панели.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const ctx = { console, Math, Date, JSON, Set, Map, Uint8Array, window: {}, requestAnimationFrame: () => 1, cancelAnimationFrame: () => {} };
vm.createContext(ctx);
for (const rel of ['src/util/slug.js', 'src/components/registry.js', 'src/project/project.js']) {
  vm.runInContext(fs.readFileSync(path.join(root, rel), 'utf8'), ctx, { filename: rel });
}
vm.runInContext('globalThis.__S = ProjectStore;', ctx);
const ProjectStore = ctx.__S;

// Проект из компонентов с именами-метками, массив снизу вверх (как z-order).
const make = (labels, groups = {}) => {
  const s = new ProjectStore();
  s.state.components.length = 0;
  const byLabel = {};
  for (const l of labels) { const c = s.addComponent('fill_rect', 10, 10); c.name = l; byLabel[l] = c; }
  s.state.components.length = 0;
  for (const l of labels) s.state.components.push(byLabel[l]);
  const gids = {};
  for (const [gname, members] of Object.entries(groups)) gids[gname] = s.addGroup(gname, members.map((l) => byLabel[l].id)).id;
  return { s, c: byLabel, g: gids };
};
const order = (s) => s.state.components.map((c) => c.name).join('');
const panel = (s) => s.getLayerUnits().map((u) => (u.type === 'group' ? `[${u.comps.map((c) => c.name).join('')}]` : u.comps[0].name)).join(' ');

// 1. Обычные компоненты: шаг на один слой, у краёв стрелки неактивны.
{
  const { s, c } = make(['A', 'B', 'C']);
  assert.equal(panel(s), 'C B A');
  assert.equal(s.canStepLayer(c.C.id, 'up'), false); assert.equal(s.canStepLayer(c.C.id, 'down'), true);
  assert.equal(s.canStepLayer(c.A.id, 'down'), false); assert.equal(s.canStepLayer(c.A.id, 'up'), true);
  assert.equal(s.stepLayer(c.B.id, 'up'), true); assert.equal(order(s), 'ACB');
  assert.equal(s.stepLayer(c.B.id, 'up'), false, 'выше уже некуда'); assert.equal(order(s), 'ACB');
  assert.equal(s.stepLayer(c.B.id, 'down'), true); assert.equal(order(s), 'ABC');
}
// 2. Контейнер двигается целиком, порядок внутри сохраняется.
{
  const { s, g } = make(['Y', 'g1', 'g2', 'X'], { G: ['g1', 'g2'] });
  assert.equal(panel(s), 'X [g1g2] Y');
  assert.equal(s.stepGroup(g.G, 'up'), true);
  assert.equal(order(s), 'Yxg1g2'.replace('x', 'X')); assert.equal(panel(s), '[g1g2] X Y');
  assert.equal(s.canStepGroup(g.G, 'up'), false, 'контейнер уже самый верхний');
  assert.equal(s.stepGroup(g.G, 'up'), false);
  assert.equal(s.stepGroup(g.G, 'down'), true); assert.equal(panel(s), 'X [g1g2] Y');
  assert.equal(s.stepGroup(g.G, 'down'), true); assert.equal(panel(s), 'X Y [g1g2]');
  assert.equal(order(s), 'g1g2YX');
  assert.equal(s.canStepGroup(g.G, 'down'), false, 'контейнер уже самый нижний');
}
// 3. Обычный компонент перешагивает контейнер целиком и внутрь него не попадает.
{
  const { s, c } = make(['g1', 'g2', 'X'], { G: ['g1', 'g2'] });
  s.stepLayer(c.X.id, 'down'); assert.equal(order(s), 'Xg1g2'); assert.equal(c.X.group, undefined);
  s.stepLayer(c.X.id, 'up'); assert.equal(order(s), 'g1g2X'); assert.equal(c.X.group, undefined);
}
// 4. Участник контейнера двигается среди участников и не выходит из контейнера.
{
  const { s, c } = make(['g1', 'g2', 'g3', 'X'], { G: ['g1', 'g2', 'g3'] });
  assert.equal(s.canStepLayer(c.g3.id, 'up'), false, 'верхний участник: выше только выход из папки — это перетаскиванием');
  assert.equal(s.canStepLayer(c.g1.id, 'down'), false);
  assert.equal(s.stepLayer(c.g2.id, 'up'), true); assert.equal(order(s), 'g1g3g2X');
  assert.equal(s.stepLayer(c.g3.id, 'down'), true); assert.equal(order(s), 'g3g1g2X');
  assert.ok(s.state.components.filter((x) => x.name.startsWith('g')).every((x) => x.group));
}
// 5. Контейнер с «разрозненными» участниками собирается в блок при перемещении.
{
  const { s, g } = make(['g1', 'X', 'g2'], { G: ['g1', 'g2'] });
  assert.equal(panel(s), '[g1g2] X');
  assert.equal(s.stepGroup(g.G, 'down'), true);
  assert.equal(order(s), 'g1g2X'); assert.equal(panel(s), 'X [g1g2]');
}
// 6. Два контейнера меняются местами целиком; пустые контейнеры в z-порядке не участвуют.
{
  const { s, g } = make(['a1', 'a2', 'b1', 'b2'], { A: ['a1', 'a2'], B: ['b1', 'b2'] });
  s.addGroup('Пустой', []);
  assert.equal(panel(s), '[b1b2] [a1a2]');
  assert.equal(s.stepGroup(g.B, 'down'), true); assert.equal(order(s), 'b1b2a1a2'); assert.equal(panel(s), '[a1a2] [b1b2]');
  assert.equal(s.canStepGroup(g.B, 'down'), false);
}
// 7. Массив и коммит: идентичность массива сохраняется, неудачный шаг ничего не коммитит; moveLayer up/down — тот же шаг.
{
  const { s, c, g } = make(['A', 'B', 'C'], {});
  const arr = s.state.components; let commits = 0; const orig = s.commit.bind(s); s.commit = () => { commits++; return orig(); };
  s.stepLayer(c.C.id, 'up'); assert.equal(commits, 0, 'неудачный шаг не коммитит');
  s.stepLayer(c.A.id, 'up'); assert.equal(commits, 1); assert.strictEqual(s.state.components, arr);
  s.moveLayer(c.A.id, 'down'); assert.equal(order(s), 'ABC');
  s.moveLayer(c.A.id, 'top'); assert.equal(order(s), 'BCA');
  s.moveLayer(c.A.id, 'bottom'); assert.equal(order(s), 'ABC');
  assert.equal(s.stepLayer('нет-такого', 'up'), false); assert.equal(s.stepGroup('нет-такой', 'up'), false);
}
// 8. Разметка панели: у каждой строки компонента и контейнера есть ▲/▼, на краях списка они отключены.
{
  vm.runInContext(fs.readFileSync(path.join(root, 'src/editor/layers.js'), 'utf8') + '\n;globalThis.__LP = LayersPanel;', ctx, { filename: 'src/editor/layers.js' });
  const { s, c, g } = make(['g1', 'g2', 'X'], { G: ['g1', 'g2'] });
  const root_ = { innerHTML: '', querySelectorAll: () => [], set ondragover(v) {}, set ondrop(v) {} };
  new ctx.__LP(root_, s).render();
  const rowOf = (id) => root_.innerHTML.split('<div class="layer-row').find((chunk) => chunk.includes(`data-id="${id}"`));
  const btn = (row, act) => row.match(new RegExp(`<button[^>]*data-act="${act}"[^>]*>`))[0];
  const rx = rowOf(c.X.id), rg = rowOf('group:' + g.G);
  assert.ok(btn(rx, 'up').includes('disabled'), 'самый верхний слой: ▲ отключена');
  assert.ok(!btn(rx, 'down').includes('disabled'), 'X можно опустить');
  assert.ok(!btn(rg, 'up').includes('disabled') && btn(rg, 'down').includes('disabled'), 'контейнер: вверх можно, вниз уже некуда');
  assert.ok(rx.includes('▲') && rx.includes('▼') && rg.includes('▲') && rg.includes('▼'));
}
console.log('Layer step tests passed.');
