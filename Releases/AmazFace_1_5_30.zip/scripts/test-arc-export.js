// Проверка экспорта компонента «Дуга»: генерируется валидный JS, нужные импорты и виджеты.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.resolve(__dirname, '..');
const ctx = { console, Math, Date, JSON, window: {} };
vm.createContext(ctx);
const load = (rel) => vm.runInContext(fs.readFileSync(path.join(root, rel), 'utf8'), ctx, { filename: rel });
// top-level const из классических скриптов не попадают в global — добавляем экспорт в context.
for (const rel of ['src/util/slug.js', 'src/components/registry.js', 'src/exporter/index-js-exporter.js']) {
  const src = fs.readFileSync(path.join(root, rel), 'utf8');
  vm.runInContext(src + '\n;globalThis.__ex = Object.assign(globalThis.__ex || {}, {' +
    ['REGISTRY', 'exportIndexJs', 'exportIndexJsDual'].filter((n) => src.includes(`const ${n}`) || src.includes(`function ${n}`)).join(',') + '});', ctx, { filename: rel });
}
const { REGISTRY, exportIndexJs } = ctx.__ex;

function mk(props, id = 'arc1') {
  return { id, defId: 'arc', x: 20, y: 20, w: 200, h: 200, props: Object.assign({}, props) };
}
function run(comps) {
  const project = { device: { w: 480, h: 480 }, components: comps, assets: [], fonts: [], background: {} };
  return exportIndexJs(project, {}, {}, {});
}
let failed = 0;
function check(name, cond, extra) { if (!cond) { failed++; console.error('FAIL:', name, extra || ''); } else console.log('ok:', name); }
function syntaxOk(code) { try { new vm.Script(code.replace(/^import .*$/gm, '')); return true; } catch (e) { return e.message; } }

// 1. Статическая дуга — как раньше
let r = run([mk({ start_angle: 0, end_angle: 270 })]);
check('static: syntax', syntaxOk(r.code) === true, syntaxOk(r.code));
check('static: angles shifted by -90 (0°=12h → -90, 270° → 180)', /widget\.ARC, \{[^}]*start_angle: -90[^}]*end_angle: 180/.test(r.code), r.code.match(/widget\.ARC.*/)?.[0]);
check('static: no timers', !r.code.includes('_set('));

// 2. Батарея + подложка + скругление + альфа + анимация
r = run([mk({ data_source: 'BATTERY', rounded_ends: true, alpha: 60, track_enabled: true, anim_enabled: true, anim_type: 'FADE_FILL', anim_duration: 900 })]);
check('battery: syntax', syntaxOk(r.code) === true, syntaxOk(r.code));
check('battery: Battery import', /import \{[^}]*Battery[^}]*\} from '@zos\/sensor'/.test(r.code));
check('battery: timer import', r.code.includes("from '@zos/timer'"));
check('battery: track widget', r.code.includes('_track = createWidget(widget.ARC'));
check('battery: no Date.now / setAlpha(0)', !r.code.includes('Date.now') && !r.code.includes('setAlpha(0)'));
check('battery: corner_flag', r.code.includes('corner_flag: 1'));
check('battery: _set called from sensor tick', /_tickSensors[\s\S]*_set\(/.test(r.code));
check('battery: warning about unverified', r.validation.warnings.some((w) => w.includes('ARC')));

// 3. Секунды, GROW, без анимации
r = run([mk({ data_source: 'SECOND' }), mk({ data_source: 'HOUR', anim_enabled: true, anim_type: 'GROW', anim_easing: 'LINEAR' }, 'arc2')]);
check('time: syntax', syntaxOk(r.code) === true, syntaxOk(r.code));
check('time: Time import', /import \{[^}]*Time[^}]*\} from '@zos\/sensor'/.test(r.code));
check('time: seconds expr', r.code.includes('now.getSeconds() / 60'));
check('time: grow line_width', r.code.includes('line_width: Math.max(1, Math.round('));
check('time: full prop set in MORE', /prop\.MORE, \{ x: 20, y: 20, w: 200, h: 200, start_angle: -90/.test(r.code));

// 4. Шаги с целью, OVERSHOOT, статика с анимацией
r = run([mk({ data_source: 'STEP', value_max: 8000, anim_enabled: true, anim_type: 'OVERSHOOT' }), mk({ anim_enabled: true }, 'arc3')]);
check('steps: syntax', syntaxOk(r.code) === true, syntaxOk(r.code));
check('steps: custom max', r.code.includes('/ 8000'));
check('static anim: starts via _set(1)', /_set\(1\);/.test(r.code));

// 4b. SWEEP (спидометр): до упора и откат к значению
r = run([mk({ data_source: 'BATTERY', anim_enabled: true, anim_type: 'SWEEP', anim_easing: 'EASE_IN_OUT' }), mk({ data_source: 'STEP', anim_enabled: true, anim_type: 'SWEEP', gradient_enabled: true }, 'arc4')]);
check('sweep: syntax', syntaxOk(r.code) === true, syntaxOk(r.code));
check('sweep: two-phase fill', /k < 0\.5 \?[\s\S]*1 - \(1 - \w*arc1_target\)/.test(r.code));
check('sweep: starts from 0', /arc1_draw\(0, 0, 0\)/.test(r.code));

// 5. Повтор анимации при пробуждении
r = run([mk({ data_source: 'BATTERY', anim_enabled: true, anim_replay: true })]);
check('replay: syntax', syntaxOk(r.code) === true, syntaxOk(r.code));
check('replay: replay fn', /function \w*arc1_replay\(\)/.test(r.code));
check('replay: delegate widget', r.code.includes('widget.WIDGET_DELEGATE') && /resume_call[\s\S]*arc1_replay\(\)/.test(r.code));
r = run([mk({ data_source: 'BATTERY', anim_enabled: true })]);
check('no replay: no delegate', !r.code.includes('WIDGET_DELEGATE'));

// 6. Градиент сегментами
r = run([mk({ data_source: 'STEP', gradient_enabled: true, color: '#ff0000', color2: '#0000ff', gradient_steps: 8, anim_enabled: true, anim_type: 'FADE_FILL', anim_replay: true, rounded_ends: true })]);
check('grad: syntax', syntaxOk(r.code) === true, syntaxOk(r.code));
check('grad: 8 segment colors, first red last blue', /_c = \[0xff0000,[^\]]*0x0000ff\]/.test(r.code), r.code.match(/_c = \[[^\]]*\]/)?.[0]);
check('grad: segments created in loop', r.code.includes('_segs.push(createWidget(widget.ARC'));
check('grad: draw updates only changed segments', r.code.includes('_last[') && r.code.includes('setProperty(prop.MORE'));
check('grad: fade mixes per segment', r.code.includes('_mixc('));
check('grad: no corner_flag', !r.code.includes('corner_flag'));
check('grad: replay still wired', r.code.includes('_replay()'));
r = run([mk({ gradient_enabled: true, gradient_steps: 4, start_angle: 0, end_angle: 180 })]);
check('grad static: full segments, no timers', syntaxOk(r.code) === true && !r.code.includes('_set(') && /_segs\.push/.test(r.code));

// 7. Сегменты: промежуток, скругление, подложка
r = run([mk({ segments_enabled: true, gradient_steps: 10, segment_gap: 4, segment_rounded: true, track_enabled: true, data_source: 'BATTERY', anim_enabled: true, anim_type: 'FILL' })]);
check('seg: syntax', syntaxOk(r.code) === true, syntaxOk(r.code));
check('seg: corner_flag on segments + track', (r.code.match(/corner_flag: 1/g) || []).length === 2);
check('seg: segmented track', r.code.includes('_trk.push(createWidget(widget.ARC'));
check('seg: empty rounded segment hidden via VISIBLE', r.code.includes('prop.VISIBLE'));
check('seg: single color (no gradient)', (r.code.match(/_c = \[([^\]]*)\]/)[1].split(',').map((x) => x.trim()).filter((v, i, arr) => arr.indexOf(v) === i)).length === 1);
r = run([mk({ segments_enabled: true, gradient_steps: 6, segment_gap: 5, start_angle: 0, end_angle: 270 })]);
const bs = r.code.match(/_b = \[([^\]]*)\]/)[1].split(',').map(Number), as = r.code.match(/_a = \[([^\]]*)\]/)[1].split(',').map(Number);
check('seg: gaps between segments are 5°', as.slice(1).every((a, i) => Math.abs(a - bs[i] - 5) <= 1), JSON.stringify({ as, bs }));
check('seg: first starts at -90, last ends at 180', as[0] === -90 && bs[bs.length - 1] === 180, JSON.stringify({ as, bs }));
r = run([mk({ segments_enabled: true, gradient_steps: 48, segment_gap: 30, start_angle: 0, end_angle: 90 })]);
const as2 = r.code.match(/_a = \[([^\]]*)\]/)[1].split(',').map(Number), bs2 = r.code.match(/_b = \[([^\]]*)\]/)[1].split(',').map(Number);
check('seg: huge gap is clamped (every segment keeps length)', as2.every((a, i) => bs2[i] > a - 1) && bs2[47] <= 0, JSON.stringify({ as2, bs2 }));

// 8. Повтор при поднятии руки
r = run([mk({ data_source: 'BATTERY', anim_enabled: true, anim_replay_raise: true })]);
check('raise: syntax', syntaxOk(r.code) === true, syntaxOk(r.code));
check('raise: Screen import', /import \{[^}]*Screen[^}]*\} from '@zos\/sensor'/.test(r.code));
check('raise: onChange + replay', r.code.includes('_scr.onChange(self._screenCb)') && /_raise\('screen on'\)/.test(r.code) && /_replay\(\);/.test(r.code));
check('raise: no resume delegate when only raise', !r.code.includes('WIDGET_DELEGATE'));
check('raise: cleanup in onDestroy', r.code.includes('offChange(this._screenCb)') && r.code.includes('_raiseTimer'));
r = run([mk({ data_source: 'BATTERY', anim_enabled: true })]);
check('no raise: no Screen', !r.code.includes('new Screen()'));

// 9. Градиент с прозрачностью: прозрачный → цвет и цвет → прозрачный
for (const mode of ['fade_in', 'fade_out']) {
  r = run([mk({ gradient_enabled: true, gradient_mode: mode, gradient_steps: 4, color: '#ff0000', color2: '#0000ff' })]);
  check(mode + ': syntax', syntaxOk(r.code) === true, syntaxOk(r.code));
  const al = (r.code.match(/_al = \[([^\]]*)\]/) || [])[1];
  const alv = al ? al.split(',').map(Number) : [];
  check(mode + ': 4 alphas, ' + (mode === 'fade_in' ? 'растут' : 'убывают'), alv.length === 4 && (mode === 'fade_in' ? alv[0] < alv[3] : alv[0] > alv[3]), al);
  const cs = (r.code.match(/_c = \[([^\]]*)\]/) || [])[1] || '';
  check(mode + ': все сегменты одного цвета (цвет 2 не используется)', new Set(cs.split(',').map((x) => x.trim())).size === 1, cs);
  check(mode + ': setAlpha у каждого сегмента', /_segs\[[^\]]*\]\.setAlpha\(Math\.max\(1, Math\.round\(255 \* [^)]*_al\[/.test(r.code));
  check(mode + ': без перекрытия стыков 1°', !/_b = \[[^\]]*\]/.test(r.code) || (() => { const a = (r.code.match(/_a = \[([^\]]*)\]/) || [])[1].split(',').map(Number), b = (r.code.match(/_b = \[([^\]]*)\]/) || [])[1].split(',').map(Number); return a[1] === b[0]; })());
}
r = run([mk({ gradient_enabled: true, gradient_mode: 'two', gradient_steps: 4 })]);
check('two: массива прозрачностей нет', !/_al = \[/.test(r.code));

// 10. Пустые сегменты скрываются (start == end у ARC может дать полный круг) — не только со скруглением
r = run([mk({ data_source: 'BATTERY', gradient_enabled: true, gradient_steps: 6 })]);
check('empty: syntax', syntaxOk(r.code) === true, syntaxOk(r.code));
check('empty: пустой сегмент скрывается при создании', /_segs\[[^\]]*\]\.setProperty\(prop\.VISIBLE, false\)/.test(r.code));
check('empty: в draw пустой сегмент скрывается', /if \(end === a\) \{ if \(/.test(r.code));
check('empty: нет скрытия без скругления раньше (регрессия) — corner_flag не нужен', !r.code.includes('corner_flag'));

// 11. Заполнение против часовой стрелки
r = run([mk({ data_source: 'BATTERY', reverse_fill: true, start_angle: -130, end_angle: -10 })]);
check('reverse: syntax', syntaxOk(r.code) === true, syntaxOk(r.code));
check('reverse: начало дуги двигается, конец неподвижен (-100)', /start_angle: Math\.round\(-100 \+ \(-120\) \* r\), end_angle: -100/.test(r.code), r.code.match(/function \w*arc1_draw[\s\S]*?\n    \}/)?.[0]);
check('reverse: в нулевом состоянии длина 0 у конца (-100)', /createWidget\(widget\.ARC, \{ x: 20, y: 20, w: 200, h: 200, start_angle: -100, end_angle: -100/.test(r.code));
r = run([mk({ data_source: 'BATTERY', start_angle: -130, end_angle: -10 })]);
check('forward: без изменений', /start_angle: -220, end_angle: Math\.round\(-220 \+ \(120\) \* r\)/.test(r.code));
r = run([mk({ reverse_fill: true, start_angle: 0, end_angle: 270 })]);
check('reverse static: полная дуга как раньше', syntaxOk(r.code) === true && /start_angle: -90, end_angle: 180/.test(r.code));
// сегменты + reverse: градиент начинается с конца дуги, пустые сегменты скрываются по b
r = run([mk({ data_source: 'STEP', reverse_fill: true, gradient_enabled: true, color: '#ff0000', color2: '#0000ff', gradient_steps: 4, anim_enabled: true })]);
check('reverse seg: syntax', syntaxOk(r.code) === true, syntaxOk(r.code));
const rc = (r.code.match(/_c = \[([^\]]*)\]/) || [])[1] || '';
check('reverse seg: цвет в НАЧАЛЕ массива — цвет 2 (заполнение идёт с конца)', rc.split(',')[0].trim() === '0x0000ff' && rc.split(',').pop().trim() === '0xff0000', rc);
check('reverse seg: draw пишет start_angle: end, end_angle: b', /start_angle: end, end_angle: b/.test(r.code) && /if \(end === b\)/.test(r.code));
check('reverse seg: cur считается от конца', /const cur = 180 \+ \(-270\) \* r;/.test(r.code), r.code.match(/const cur = .*/)?.[0]);

// 12. Контур и тень
r = run([mk({ outline_enabled: true, outline_color: '#ffffff', outline_width: 3 })]);
check('outline: syntax', syntaxOk(r.code) === true, syntaxOk(r.code));
check('outline: слой шире на 2×3 и под основной дугой', /_dl = \[\[3, 0, 0, 0xffffff, 255, \d+\]\]/.test(r.code) && r.code.indexOf('_dec.push(createWidget(widget.ARC') < r.code.search(/const \w*arc1 = createWidget\(widget\.ARC/));
check('outline: бокс расширен: x - s, w + 2s, line_width + 2s', /x: 20 \+ d\[1\] - d\[0\][^}]*w: 200 \+ 2 \* d\[0\][^}]*line_width: 8 \+ 2 \* d\[0\]/.test(r.code));
check('outline: прямые концы — выступ за концы дуги > 0°', Number(r.code.match(/_dl = \[\[3, 0, 0, 0xffffff, 255, (\d+)\]\]/)[1]) > 0);
check('outline: статичная дуга — слой виден сразу, draw не нужен', !r.code.includes('_decDraw'));
r = run([mk({ outline_enabled: true, rounded_ends: true })]);
check('outline rounded: выступ 0° и corner_flag слоя', /_dl = \[\[2, 0, 0, 0x000000, 255, 0\]\]/.test(r.code) && (r.code.match(/corner_flag: 1/g) || []).length === 2);
r = run([mk({ shadow_enabled: true, shadow_dx: 2, shadow_dy: 4, shadow_blur: 0, shadow_alpha: 50, shadow_color: '#112233' })]);
check('shadow hard: один слой, сдвиг и прозрачность', /_dl = \[\[0, 2, 4, 0x112233, 128, \d+\]\]/.test(r.code), r.code.match(/_dl = .*/)?.[0]);
r = run([mk({ shadow_enabled: true, shadow_blur: 10, shadow_alpha: 50, outline_enabled: true, outline_width: 2 })]);
const rows = (r.code.match(/_dl = (\[\[.*\]\]);/) || [])[1] || '';
check('shadow soft: 5 слоёв тени + контур, ширина убывает к центру', (rows.match(/\], \[|\],\[/g) || []).length === 5 && /^\[\[12,/.test(rows), rows);
r = run([mk({ data_source: 'HEART', reverse_fill: true, shadow_enabled: true, outline_enabled: true, anim_enabled: true, anim_type: 'FADE_FILL' })]);
check('deco dynamic: syntax', syntaxOk(r.code) === true, syntaxOk(r.code));
check('deco dynamic: decDraw вызывается из draw, fade-смешивание, скрытие при r<=0', /_decDraw\(r, f, g\);/.test(r.code) && r.code.includes('_dmix(d[3], f)') && /if \(r <= 0\)/.test(r.code));
check('deco dynamic: слои скрыты при создании', /_dec\[\w+\]\.setProperty\(prop\.VISIBLE, false\)/.test(r.code));
check('deco: в предупреждения попадает setAlpha/контур', r.validation.warnings.some((w) => w.includes('контур')));
r = run([mk({ data_source: 'STEP', gradient_enabled: true, gradient_steps: 6, outline_enabled: true, shadow_enabled: true, anim_enabled: true })]);
check('deco + segments: syntax', syntaxOk(r.code) === true, syntaxOk(r.code));
check('deco + segments: decDraw вызывается в draw сегментов', /function \w*arc1_draw[\s\S]*?_decDraw\(r, f, g\)/.test(r.code));

// 13. Контур на весь диапазон: слои статичны и лежат под подложкой
r = run([mk({ data_source: 'BATTERY', outline_enabled: true, outline_full: true, shadow_enabled: true, track_enabled: true, anim_enabled: true })]);
check('outline full: syntax', syntaxOk(r.code) === true, syntaxOk(r.code));
check('outline full: слои не обновляются (нет decDraw, не скрыты)', !r.code.includes('_decDraw') && !/_dec\[\w+\]\.setProperty\(prop\.VISIBLE, false\)/.test(r.code));
check('outline full: порядок — контур, подложка, основная дуга', (() => { const a = r.code.indexOf('_dec.push('), b = r.code.indexOf('_track = createWidget'), c = r.code.search(/const \w*arc1 = createWidget/); return a > 0 && a < b && b < c; })());
r = run([mk({ data_source: 'STEP', gradient_enabled: true, outline_enabled: true, outline_full: true, track_enabled: true })]);
check('outline full + segments: контур раньше сегментной подложки', syntaxOk(r.code) === true && r.code.indexOf('_dec.push(') < r.code.indexOf('_trk.push('));
r = run([mk({ data_source: 'BATTERY', outline_full: true, anim_enabled: true })]);
check('outline_full без включённого контура — ничего не меняется', !r.code.includes('_dec'));

if (failed) { console.error(`\n${failed} проверок не прошли`); process.exit(1); }
console.log('\nВсе проверки экспорта дуги прошли.');
