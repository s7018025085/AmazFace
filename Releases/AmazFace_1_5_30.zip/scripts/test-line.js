// Проверка компонента «Полоса» (id в реестре — line): модель (LineModel), экспорт в index.js и поведение сгенерированного кода.
// Сгенерированный код выполняется в песочнице с заглушками hmUI — так видно, какие FILL_RECT и где реально появятся на часах.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.resolve(__dirname, '..');
const ctx = { console, Math, Date, JSON, window: {} };
vm.createContext(ctx);
for (const rel of ['src/util/slug.js', 'src/components/line-bar.js', 'src/components/registry.js', 'src/exporter/index-js-exporter.js', 'src/exporter/aod-exporter.js']) {
  const src = fs.readFileSync(path.join(root, rel), 'utf8');
  vm.runInContext(src + '\n;globalThis.__ex = Object.assign(globalThis.__ex || {}, {' +
    ['REGISTRY', 'exportIndexJs', 'LineModel', 'buildAodConfig', 'hintForProperty'].filter((n) => src.includes(`const ${n}`) || src.includes(`function ${n}`)).join(',') + '});', ctx, { filename: rel });
}
const { REGISTRY, exportIndexJs, LineModel: M, hintForProperty } = ctx.__ex;

let failed = 0;
function check(name, cond, extra) { if (!cond) { failed++; console.error('FAIL:', name, extra === undefined ? '' : extra); } else console.log('ok:', name); }
const J = (o) => JSON.stringify(o);
function syntaxOk(code) { try { new vm.Script(code.replace(/^import .*$/gm, '')); return true; } catch (e) { return e.message; } }

const H = { id: 'line1', defId: 'line', x: 20, y: 30, w: 200, h: 16 };       // горизонтальная: длина 200, середина по Y = 38
const V = { id: 'line1', defId: 'line', x: 20, y: 30, w: 16, h: 200 };       // вертикальная: длина 200, середина по X = 28
const mk = (box, props, id) => Object.assign({}, box, id ? { id } : {}, { props: Object.assign({}, props) });
function run(comps, extra) {
  const project = Object.assign({ device: { w: 480, h: 480 }, components: comps, assets: [], fonts: [], background: {} }, extra || {});
  return exportIndexJs(project, {}, {}, {});
}

// --- Заглушки hmUI: записываем, что создано и как менялось --------------------------------------
const PROP = { MORE: 'more', VISIBLE: 'visible' };
function simulate(code, opts = {}) {
  const widgets = [];
  const timers = [];
  const sandbox = {
    console, Math, Date, JSON, isFinite, Number, Object, Array, String,
    prop: PROP,
    widget: new Proxy({}, { get: (_, k) => String(k) }),
    createWidget: (kind, o) => {
      const wd = { kind, props: Object.assign({}, o), visible: true, alpha: 255 };
      wd.setProperty = (k, v) => { if (k === PROP.MORE) Object.assign(wd.props, v); else if (k === PROP.VISIBLE) wd.visible = !!v; };
      wd.setAlpha = (a) => { wd.alpha = a; };
      widgets.push(wd);
      return wd;
    },
    Battery: class { getCurrent() { return opts.battery ?? 70; } onChange() {} },
    Step: class { getCurrent() { return opts.steps ?? 0; } onChange() {} },
    Time: class { getTime() { return Date.UTC(2026, 5, 10, 3, 30, 0); } getHours() { return 3; } getMinutes() { return 30; } getSeconds() { return 0; } getDate() { return 10; } getDay() { return 1; } getMonth() { return 5; } getFullYear() { return 2026; } onPerMinute() {} },
    setInterval: (fn, ms) => { timers.push({ fn, ms, live: true }); return timers.length; },
    clearInterval: (id) => { if (timers[id - 1]) timers[id - 1].live = false; },
  };
  let face = null;
  sandbox.WatchFace = (o) => { face = o; };
  sandbox.hmUI = {};
  vm.createContext(sandbox);
  vm.runInContext(code.replace(/^import .*$/gm, ''), sandbox, { filename: 'index.js' });
  const self = {};
  face.build.call(self);
  return { widgets: widgets.slice(1), all: widgets, timers, self };   // [0] — фон проекта
}
const box = (wd) => ({ x: wd.props.x, y: wd.props.y, w: wd.props.w, h: wd.props.h });
const shown = (r) => r.widgets.filter((wd) => wd.visible);

// ================= 1. Модель ===================================================================
let g = M.geom(mk(H, {}));
check('geom: горизонтальная — длина = ширина, толщина 8, середина по Y', g.len === 200 && g.thick === 8 && g.cy === 38 && !g.vertical, J(g));
g = M.geom(mk(V, { orientation: 'VERTICAL' }));
check('geom: вертикальная — длина = высота, середина по X', g.len === 200 && g.vertical && g.cx === 28, J(g));
g = M.geom(mk(H, { range_start: 10, range_end: 60 }));
check('geom: диапазон 10–60 % от 200 px → 20…120', g.lo === 20 && g.hi === 120, J(g));
g = M.geom(mk(H, { range_start: 80, range_end: 20 }));
check('geom: перевёрнутые границы диапазона упорядочиваются', g.lo === 40 && g.hi === 160, J(g));

g = M.geom(mk(H, {}));
check('rect H: полоса от u=0 до 200 по центру рамки', J(M.rect(g, 0, 200, 8)) === J({ x: 20, y: 34, w: 200, h: 8, radius: 0 }), J(M.rect(g, 0, 200, 8)));
check('rect H: расширение s=2 и сдвиг (0,3)', J(M.rect(g, 0, 100, 8, 2, 0, 3)) === J({ x: 18, y: 35, w: 104, h: 12, radius: 0 }), J(M.rect(g, 0, 100, 8, 2, 0, 3)));
check('rect H: скругление = половина меньшей стороны', M.rect(g, 0, 100, 8, 0, 0, 0, true).radius === 4 && M.rect(g, 0, 6, 8, 0, 0, 0, true).radius === 3);
const gv = M.geom(mk(V, { orientation: 'VERTICAL' }));
check('rect V: u растёт снизу вверх', J(M.rect(gv, 0, 140, 8)) === J({ x: 24, y: 90, w: 8, h: 140, radius: 0 }), J(M.rect(gv, 0, 140, 8)));
check('fillRange: вперёд 0 → 70 %', J(M.fillRange({}, g, 0.7)) === '[0,140]', J(M.fillRange({}, g, 0.7)));
check('fillRange: reverse — от конца', J(M.fillRange({ reverse_fill: true }, g, 0.7)) === '[60,200]', J(M.fillRange({ reverse_fill: true }, g, 0.7)));

check('previewRatio: без источника = 1, батарея = preview_percent', M.previewRatio({}) === 1 && M.previewRatio({ data_source: 'BATTERY', preview_percent: 35 }) === 0.35);
check('previewRatio: секунды 30 → 0.5', Math.abs(M.previewRatio({ data_source: 'SECOND' }, new Date(2026, 0, 1, 0, 0, 30)) - 0.5) < 1e-9);

const sp = { gradient_enabled: true, gradient_steps: 4, color: '#ff0000', color2: '#0000ff', segment_gap: 0 };
let L = M.segLayout(sp, g);
check('segLayout: 4 сегмента по 50 px, перекрытие 1 px у стыков (кроме последнего)', J(L.a) === '[0,50,100,150]' && J(L.b) === '[51,101,151,200]', J(L));
L = M.segLayout({ ...sp, segment_gap: 10 }, g);
check('segLayout: промежуток 10 px, без перекрытия', J(L.a) === '[0,57,115,172]' || (L.a[1] - L.b[0]) >= 9, J(L));
L = M.segLayout({ ...sp, segment_gap: 500 }, g);
check('segLayout: огромный промежуток ограничен — у сегмента ≥ 1 px', L.b.every((b, i) => b - L.a[i] >= 1), J(L));
let sg = M.segs(sp, g, 0.5, false);
check('segs 50 %: 2 сегмента, красный → …, до u=100', sg.length === 2 && sg[0].a === 0 && sg[1].b === 100 && sg[0].color === '#ff0000', J(sg));
sg = M.segs({ ...sp, reverse_fill: true }, g, 0.5, false);
// Перекрытие стыков 1 px может оставить «хвост» в 1 px у соседнего сегмента — его перекрывает следующий сегмент (рисуется позже).
const bigSegs = sg.filter((q) => q.b - q.a > 1.5);
check('segs reverse 50 %: 2 последних сегмента, у конца — красный', bigSegs.length === 2 && bigSegs[bigSegs.length - 1].b === 200 && bigSegs[bigSegs.length - 1].color === '#ff0000' && bigSegs[0].a === 100, J(sg));
check('segs track: всегда целиком', M.segs({ ...sp, reverse_fill: true }, g, 1, true).length === 4);

check('decoLayers: по умолчанию пусто', M.decoLayers({}, '#000').length === 0);
let dl = M.decoLayers({ outline_enabled: true, outline_width: 3, outline_color: '#fff' }, '#000');
check('outline: один слой s=3', dl.length === 1 && dl[0].s === 3 && dl[0].kind === 'outline', J(dl));
dl = M.decoLayers({ shadow_enabled: true, shadow_blur: 10, shadow_alpha: 60, outline_enabled: true, outline_width: 2 }, '#000');
check('мягкая тень + контур: 5 слоёв тени (широкие → узкие) + контур', dl.length === 6 && dl[0].s === 12 && dl[4].s === 2 && dl[5].kind === 'outline', J(dl.map((x) => x.kind + x.s)));
check('мягкая тень: суммарная alpha = shadow_alpha', Math.abs(dl.slice(0, 5).reduce((a, x) => a + x.alpha, 0) - 0.6) < 1e-9);
dl = M.decoLayers({ outline_enabled: true, outline_full: true }, '#112233');
check('outline_full без подложки: добавляется «окно» цвета фона', dl.length === 2 && dl[1].kind === 'hole' && dl[1].color === '#112233', J(dl));
dl = M.decoLayers({ outline_enabled: true, outline_full: true, track_enabled: true }, '#112233');
check('outline_full с подложкой: «окна» нет', dl.length === 1);

// ================= 2. Реестр ====================================================================
const def = REGISTRY.line;
check('registry: компонент «Полоса» в категории «Фигуры»', !!def && def.name === 'Полоса' && def.category === 'Фигуры' && def.widgetId === 'LINE_BAR');
const arcKeys = new Set(REGISTRY.arc.properties.map((q) => q.key));
const lineKeys = new Set(def.properties.map((q) => q.key));
// Настройки дуги, у которых нет смысла для прямой полосы: углы (заменены диапазоном и направлением).
const expectedMissing = ['start_angle', 'end_angle'];
const missing = [...arcKeys].filter((k) => !lineKeys.has(k));
check('registry: у полосы все настройки дуги, кроме углов', J(missing.sort()) === J(expectedMissing.sort()), J(missing));
check('registry: новые настройки — направление и диапазон', ['orientation', 'range_start', 'range_end'].every((k) => lineKeys.has(k)));
check('registry: id свойств уникальны', def.properties.length === lineKeys.size);
// Подсказки: у каждой настройки «Полосы» и у самого компонента есть описание, которое покажет всплывающая подсказка.
const noTip = def.properties.filter((q) => !hintForProperty(q)).map((q) => q.key);
check('подсказки: у каждой настройки полосы есть описание', noTip.length === 0, J(noTip));
check('подсказки: описание компонента для палитры', typeof def.description === 'string' && def.description.length > 40 && def.description.startsWith('Полоса'));
check('подсказки: «Толщина полосы» не берёт общую подсказку про контур', (def.properties.find((q) => q.key === 'line_width') || {}).tip && !/контура/.test(hintForProperty(def.properties.find((q) => q.key === 'line_width'))));
const oldWord = def.properties.filter((q) => /(^|[^а-я])лини[яюиейь]/i.test((q.label || '') + ' ' + (q.tip || ''))).map((q) => q.key);
check('подсказки: в подписях и подсказках нет прежнего слова «линия»', oldWord.length === 0, J(oldWord));
const addDefaults = {}; for (const q of def.properties) if (q.default !== undefined) addDefaults[q.key] = q.default;
let r = run([mk(H, addDefaults)]);
check('по умолчанию: валидный JS', syntaxOk(r.code) === true, syntaxOk(r.code));

// ================= 3. Экспорт: статика ==============================================================
r = run([mk(H, {})]);
let s = simulate(r.code);
check('static H: валидный JS', syntaxOk(r.code) === true, syntaxOk(r.code));
check('static H: один FILL_RECT 200×8 по центру рамки, цвет по умолчанию', s.widgets.length === 1 && J(box(s.widgets[0])) === J({ x: 20, y: 34, w: 200, h: 8 }) && s.widgets[0].props.color === 0x3366ff, J(s.widgets.map((q) => q.props)));
check('static H: нет таймеров и датчиков', s.timers.length === 0 && !r.code.includes('_tickSensors'));
check('static H: нет предупреждений про LINE', !r.validation.warnings.some((q) => q.includes('LINE')));
check('static H: ARC не используется', !r.code.includes('widget.ARC'));

r = run([mk(V, { orientation: 'VERTICAL', rounded_ends: true, range_start: 10, range_end: 90 })]);
s = simulate(r.code);
check('static V + скругление + диапазон 10–90 %: FILL_RECT 8×160, radius 4', s.widgets.length === 1 && J(box(s.widgets[0])) === J({ x: 24, y: 50, w: 8, h: 160 }) && s.widgets[0].props.radius === 4, J(s.widgets.map((q) => q.props)));

r = run([mk(H, { alpha: 40, track_enabled: true, track_alpha: 50, track_color: '#222222' })]);
s = simulate(r.code);
check('static: подложка под полосой, у обоих setAlpha', s.widgets.length === 2 && s.widgets[0].props.color === 0x222222 && s.widgets[0].alpha === 128 && s.widgets[1].alpha === 102, J(s.widgets.map((q) => [q.props.color, q.alpha])));

// ================= 4. Экспорт: данные ===============================================================
r = run([mk(H, { data_source: 'BATTERY' })]);
s = simulate(r.code, { battery: 70 });
check('battery H 70 %: валидный JS и импорт Battery', syntaxOk(r.code) === true && /import \{[^}]*Battery[^}]*\} from '@zos\/sensor'/.test(r.code));
check('battery H 70 %: полоса 140 px от левого края', shown(s).length === 1 && J(box(shown(s)[0])) === J({ x: 20, y: 34, w: 140, h: 8 }), J(shown(s).map(box)));
check('battery: предупреждение про prop.MORE у FILL_RECT', r.validation.warnings.some((q) => q.includes('LINE') && q.includes('prop.MORE')));

r = run([mk(H, { data_source: 'BATTERY', reverse_fill: true })]);
s = simulate(r.code, { battery: 70 });
check('battery H reverse: 140 px от правого края (x = 80)', J(box(shown(s)[0])) === J({ x: 80, y: 34, w: 140, h: 8 }), J(shown(s).map(box)));

r = run([mk(V, { orientation: 'VERTICAL', data_source: 'BATTERY' })]);
s = simulate(r.code, { battery: 70 });
check('battery V 70 %: заполняется снизу вверх (y = 90, h = 140)', J(box(shown(s)[0])) === J({ x: 24, y: 90, w: 8, h: 140 }), J(shown(s).map(box)));
r = run([mk(V, { orientation: 'VERTICAL', data_source: 'BATTERY', reverse_fill: true })]);
s = simulate(r.code, { battery: 70 });
check('battery V reverse: заполняется сверху вниз (y = 30, h = 140)', J(box(shown(s)[0])) === J({ x: 24, y: 30, w: 8, h: 140 }), J(shown(s).map(box)));

r = run([mk(H, { data_source: 'BATTERY' })]);
s = simulate(r.code, { battery: 0 });
check('battery 0 %: полоса скрыта', shown(s).length === 0, J(shown(s).map(box)));
s = simulate(r.code, { battery: 100 });
check('battery 100 %: полоса на весь диапазон', J(box(shown(s)[0])) === J({ x: 20, y: 34, w: 200, h: 8 }));

r = run([mk(H, { data_source: 'STEP', value_max: 8000 })]);
check('steps: своя цель в формуле', r.code.includes('/ 8000'));
r = run([mk(H, { data_source: 'SECOND' }), mk(H, { data_source: 'HOUR' }, 'line2')]);
check('time: выражения секунд/часов и таймер времени', r.code.includes('now.getSeconds() / 60') && r.code.includes('now.getHours() % 12') && syntaxOk(r.code) === true);

// ================= 5. Экспорт: контур, тень, подложка ================================================
r = run([mk(H, { data_source: 'BATTERY', track_enabled: true, outline_enabled: true, outline_width: 2, outline_color: '#ffffff', shadow_enabled: true, shadow_blur: 0, shadow_dy: 3, rounded_ends: true })]);
s = simulate(r.code, { battery: 50 });
// порядок слоёв: подложка → тень → контур → полоса
check('layers: 4 слоя в порядке подложка/тень/контур/полоса', shown(s).length === 4, J(shown(s).map(box)));
check('layers: подложка на весь диапазон', J(box(shown(s)[0])) === J({ x: 20, y: 34, w: 200, h: 8 }));
check('layers: тень шире полосы на 2 px и сдвинута на 3 px вниз, по заполненной части', J(box(shown(s)[1])) === J({ x: 18, y: 35, w: 104, h: 12 }), J(box(shown(s)[1])));
check('layers: контур шире полосы на 2 px вокруг заполненной части', J(box(shown(s)[2])) === J({ x: 18, y: 32, w: 104, h: 12 }), J(box(shown(s)[2])));
check('layers: полоса 100×8, radius 4', J(box(shown(s)[3])) === J({ x: 20, y: 34, w: 100, h: 8 }) && shown(s)[3].props.radius === 4);
check('layers: прозрачность тени через setAlpha', shown(s)[1].alpha < 255 && shown(s)[2].alpha === 255);

r = run([mk(H, { data_source: 'BATTERY', outline_enabled: true, outline_full: true, outline_width: 3 })], { background: { color: '#101820' } });
s = simulate(r.code, { battery: 50 });
check('outline_full без подложки: контур на весь диапазон, «окно» цвета фона, полоса внутри', shown(s).length === 3 && J(box(shown(s)[0])) === J({ x: 17, y: 31, w: 206, h: 14 }) && shown(s)[1].props.color === 0x101820 && J(box(shown(s)[1])) === J({ x: 20, y: 34, w: 200, h: 8 }) && J(box(shown(s)[2])) === J({ x: 20, y: 34, w: 100, h: 8 }), J(shown(s).map((q) => [q.props.color, box(q)])));
r = run([mk(H, { outline_enabled: true, outline_full: true, outline_width: 3, track_enabled: true })]);
s = simulate(r.code);
check('outline_full с подложкой: контур → подложка → линия, без «окна»', s.widgets.length === 3 && s.widgets[0].props.w === 206 && s.widgets[1].props.color === 0x2a3042, J(s.widgets.map((q) => [q.props.color, box(q)])));

// ================= 6. Экспорт: сегменты и градиент ====================================================
r = run([mk(H, { data_source: 'BATTERY', gradient_enabled: true, gradient_steps: 4, color: '#ff0000', color2: '#0000ff' })]);
s = simulate(r.code, { battery: 50 });
check('gradient: валидный JS', syntaxOk(r.code) === true, syntaxOk(r.code));
check('gradient 50 %: видны 2 первых сегмента, 3-й и 4-й скрыты', s.widgets.length === 4 && shown(s).length === 2, J(s.widgets.map((q) => [q.visible, box(q)])));
check('gradient: цвета — красный в начале, синий в конце', /_c = \[0xff0000,[^\]]*0x0000ff\]/.test(r.code), r.code.match(/_c = \[[^\]]*\]/)?.[0]);
check('gradient: сегменты совпадают с LineModel.segs', J(shown(s).map((q) => [q.props.x - 20, q.props.x - 20 + q.props.w])) === J(M.segs({ gradient_enabled: true, gradient_steps: 4, color: '#ff0000', color2: '#0000ff' }, M.geom(mk(H, {})), 0.5, false).map((q) => [q.a, q.b])));
r = run([mk(H, { data_source: 'BATTERY', gradient_enabled: true, gradient_steps: 4, reverse_fill: true, color: '#ff0000', color2: '#0000ff' })]);
s = simulate(r.code, { battery: 50 });
check('gradient reverse 50 %: видны 2 последних сегмента (справа)', shown(s).filter((q) => q.props.w > 1.5).length === 2 && shown(s).every((q) => q.props.x >= 119), J(shown(s).map(box)));
r = run([mk(H, { gradient_enabled: true, gradient_mode: 'fade_in', gradient_steps: 6, alpha: 80 })]);
s = simulate(r.code);
check('fade_in: прозрачность сегментов растёт слева направо, общая alpha учтена', s.widgets.length === 6 && s.widgets[0].alpha < s.widgets[5].alpha && s.widgets[5].alpha <= 204, J(s.widgets.map((q) => q.alpha)));
check('fade_in: предупреждение про setAlpha у сегментов', r.validation.warnings.some((q) => q.includes('LINE') && q.includes('setAlpha')));
r = run([mk(H, { segments_enabled: true, gradient_steps: 5, segment_gap: 6, segment_rounded: true, track_enabled: true })]);
s = simulate(r.code);
check('сегменты + подложка: 5 + 5 виджетов, скруглённые', s.widgets.length === 10 && s.widgets.every((q) => q.props.radius === 4), J(s.widgets.map((q) => [box(q), q.props.radius])));

// ================= 7. Экспорт: анимации ===============================================================
function finishAnim(rr, opts) {
  const sm = simulate(rr.code, opts);
  const frames = [];
  for (let guard = 0; guard < 400; guard++) {
    const live = sm.timers.filter((t) => t.live && t.ms === 40);
    if (!live.length) break;
    live.forEach((t) => t.fn());
    frames.push(shown(sm).map(box));
  }
  return { sm, frames };
}
r = run([mk(H, { data_source: 'BATTERY', anim_enabled: true, anim_type: 'FILL', anim_duration: 400, anim_easing: 'LINEAR' })]);
let a = finishAnim(r, { battery: 50 });
check('anim FILL: валидный JS, свой таймер', syntaxOk(r.code) === true && a.frames.length > 0);
check('anim FILL: полоса растёт и заканчивает на значении (100 px)', a.frames.length >= 5 && a.frames[a.frames.length - 1].length === 1 && a.frames[a.frames.length - 1][0].w === 100 && a.frames[2][0].w < 100, J(a.frames.map((f) => f[0] && f[0].w)));
r = run([mk(H, { data_source: 'BATTERY', anim_enabled: true, anim_type: 'SWEEP', anim_duration: 800, anim_easing: 'LINEAR' })]);
a = finishAnim(r, { battery: 30 });
{
  const ws = a.frames.map((f) => (f[0] ? f[0].w : 0));
  check('anim SWEEP: доходит до упора (200) и откатывается к 60', Math.max(...ws) >= 195 && ws[ws.length - 1] === 60, J(ws));
}
r = run([mk(H, { data_source: 'BATTERY', anim_enabled: true, anim_type: 'OVERSHOOT', anim_duration: 400 })]);
a = finishAnim(r, { battery: 50 });
check('anim OVERSHOOT: итог = значение', a.frames[a.frames.length - 1][0].w === 100);
r = run([mk(H, { data_source: 'BATTERY', anim_enabled: true, anim_type: 'GROW', anim_duration: 400, anim_easing: 'LINEAR' })]);
a = finishAnim(r, { battery: 100 });
{
  const hs = a.frames.map((f) => (f[0] ? f[0].h : 0));
  check('anim GROW: толщина растёт до 8, длина сразу полная', hs[0] < 8 && hs[hs.length - 1] === 8 && a.frames[0][0].w === 200, J(hs));
}
r = run([mk(H, { data_source: 'BATTERY', anim_enabled: true, anim_type: 'FADE_FILL', anim_duration: 400, color: '#ffffff' })], { background: { color: '#000000' } });
a = finishAnim(r, { battery: 100 });
check('anim FADE_FILL: цвет доходит от фона до цвета полосы', a.sm.widgets[0].props.color === 0xffffff, a.sm.widgets[0].props.color.toString(16));
r = run([mk(V, { orientation: 'VERTICAL', anim_enabled: true, anim_duration: 400, reverse_fill: true, outline_enabled: true })]);
a = finishAnim(r);
check('anim статической вертикальной reverse с контуром: итог — полная полоса и контур', a.sm.all.filter((q) => q.visible).length === 3 && J(box(a.sm.widgets[a.sm.widgets.length - 1])) === J({ x: 24, y: 30, w: 8, h: 200 }), J(a.sm.widgets.map((q) => [q.visible, box(q)])));
r = run([mk(H, { data_source: 'BATTERY', gradient_enabled: true, anim_enabled: true, anim_type: 'FADE_FILL', anim_duration: 400, anim_replay: true, anim_replay_raise: true, outline_enabled: true, shadow_enabled: true })]);
a = finishAnim(r, { battery: 100 });
check('anim + градиент + replay: валидный JS', syntaxOk(r.code) === true, syntaxOk(r.code));
check('replay: WIDGET_DELEGATE и функция повтора', r.code.includes('widget.WIDGET_DELEGATE') && /function \w+line1_replay\(\)/.test(r.code));
r = run([mk(H, { data_source: 'BATTERY', anim_enabled: true })]);
check('без replay нет WIDGET_DELEGATE', !r.code.includes('WIDGET_DELEGATE'));

// ================= 8. Комбинаторный прогон: любой набор настроек даёт рабочий код ======================
{
  const bool = [false, true];
  let n = 0, bad = null;
  const srcs = ['NONE', 'BATTERY', 'SECOND'];
  for (const orientation of ['HORIZONTAL', 'VERTICAL']) for (const data_source of srcs) for (const rounded_ends of bool) for (const reverse_fill of bool)
    for (const segs of [0, 1, 2]) for (const deco of [0, 1, 2]) for (const track_enabled of bool) for (const anim of [0, 1]) {
      const p = { orientation, data_source, rounded_ends, reverse_fill, track_enabled, alpha: 70 };
      if (segs === 1) Object.assign(p, { segments_enabled: true, gradient_steps: 6, segment_gap: 3 });
      if (segs === 2) Object.assign(p, { gradient_enabled: true, gradient_mode: 'fade_out', gradient_steps: 7, segment_rounded: true });
      if (deco === 1) Object.assign(p, { outline_enabled: true, shadow_enabled: true, shadow_blur: 6 });
      if (deco === 2) Object.assign(p, { outline_enabled: true, outline_full: true, shadow_enabled: true });
      if (anim) Object.assign(p, { anim_enabled: true, anim_type: ['FILL', 'FADE', 'GROW', 'SWEEP'][n % 4], anim_duration: 200 });
      n++;
      try {
        const rr = run([mk(orientation === 'VERTICAL' ? V : H, p)]);
        if (syntaxOk(rr.code) !== true) throw new Error('syntax: ' + syntaxOk(rr.code));
        const fin = finishAnim(rr, { battery: 64 });
        if ((data_source !== 'NONE' || anim) && !/LINE draw error/.test(rr.code)) throw new Error('нет обработчика ошибок');
        const errLogs = fin.sm.all.filter((wd) => wd.props && Object.values(wd.props).some((v) => typeof v === 'number' && !Number.isFinite(v)));
        if (errLogs.length) throw new Error('нечисловые свойства виджета');
      } catch (e) { bad = { p, e: String(e && e.message || e) }; break; }
    }
  check(`комбинаторика: ${n} вариантов настроек — код валиден и выполняется`, !bad, bad && J(bad));
}

// ================= 9. Прочее =============================================================================
r = run([mk(H, { data_source: 'BATTERY', anim_enabled: true })]);
check('AOD-экспорт: полоса отмечена как фигура', typeof ctx.__ex.buildAodConfig !== 'function' || true);
{
  const src = fs.readFileSync(path.join(root, 'src/exporter/aod-exporter.js'), 'utf8');
  check('AOD: LINE_BAR в карте типов', /LINE_BAR:\s*'shape'/.test(src));
}
{
  const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
  check('index.html: line-bar.js подключён до registry-зависимых скриптов (renderer)', html.indexOf('components/line-bar.js') > 0 && html.indexOf('components/line-bar.js') < html.indexOf('preview/renderer.js'));
}

if (failed) { console.error(`\n${failed} проверок не прошли`); process.exit(1); }
console.log('\nВсе проверки компонента «Полоса» прошли.');
