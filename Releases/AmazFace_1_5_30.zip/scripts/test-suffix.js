// Суффикс/единица: то, что показывает холст редактора, должно совпадать с тем, что выводят часы.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert');
const fx = require('./export-fixtures.js');
const root = path.resolve(__dirname, '..');

const ctx = { console, Math, Date, JSON, window: {} };
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(root, 'src/components/registry.js'), 'utf8')
  + '\n;globalThis.__r = { sensorPreviewText, nativePreviewText, sensorAffixes, REGISTRY };', ctx);
const { sensorPreviewText, nativePreviewText } = ctx.__r;
const ex = fx.loadExporter(root, ['src/anim/text-anim.js', 'src/anim/text-anim-export.js']);
const code = (props, defId = 'text') => ex.exportIndexJs(fx.project([fx.mk('t1', defId, Object.assign({ text_size: 30, color: '#fff' }, props))]), {}, {}, {}).code;

// Для каждого датчика: что стоит в поле «Суффикс» — то и на холсте, и на часах.
const sensors = ['BATTERY', 'STEP', 'HEART', 'CALORIE', 'DISTANCE', 'ALTITUDE', 'AIR_PRESSURE'];
for (const src of sensors) {
  for (const suffix of [' ZZ', '']) {
    const props = { data_source: src, prefix: '', suffix };
    const preview = sensorPreviewText(src, props);
    assert.ok(preview.endsWith(suffix), `${src}: на холсте суффикс «${suffix}» → «${preview}»`);
    if (suffix === '') assert.ok(/\d$/.test(preview), `${src}: пустой суффикс должен убирать суффикс на холсте → «${preview}»`);
    assert.ok(code(props).includes(`+ ${JSON.stringify(suffix)}`), `${src}: на часах суффикс «${suffix}»`);
  }
}
// Префикс тоже виден на холсте.
for (const src of sensors) assert.ok(sensorPreviewText(src, { prefix: '>>', suffix: '' }).startsWith('>>'), src + ': префикс на холсте');

// Батарея: пустой суффикс больше не превращается в «%» на холсте.
assert.strictEqual(sensorPreviewText('BATTERY', { suffix: '' }), '82');
assert.strictEqual(sensorPreviewText('BATTERY', { suffix: '%' }), '82%');
// Пульс и дистанция: суффикс виден на холсте (раньше не отображался).
assert.strictEqual(sensorPreviewText('HEART', { prefix: '♥ ', suffix: ' bpm' }), '♥ 72 bpm');
assert.strictEqual(sensorPreviewText('DISTANCE', { suffix: ' км' }), '4.20 км');
// Дистанция: ' km' по умолчанию следует за единицей, как у давления.
assert.strictEqual(sensorPreviewText('DISTANCE', { suffix: ' km', distance_unit: 'mi' }), '2.61 mi');
assert.ok(code({ data_source: 'DISTANCE', suffix: ' km', distance_unit: 'mi' }).includes('" mi"'));
// Пресет «Расстояние»: галочка show_unit убирает суффикс и на холсте, и на часах.
assert.strictEqual(sensorPreviewText('DISTANCE', { unit: 'km', show_unit: false }), '4.20');
assert.ok(code({ unit: 'km', show_unit: false }, 'distance').includes('+ "" });'));
// Давление: единица подставляется автоматически, а пустой суффикс — это «без суффикса».
assert.strictEqual(sensorPreviewText('AIR_PRESSURE', { suffix: ' hPa', pressure_unit: 'mmHg' }), '760 мм рт.ст.');
assert.strictEqual(sensorPreviewText('AIR_PRESSURE', { suffix: '' }), '1013');
// Шаги: разделитель тысяч совпадает с экспортом (toLocaleString('en-US')).
assert.strictEqual(sensorPreviewText('STEP', { step_thousands_sep: true, suffix: '' }), '8,452');

// Нативные данные: «Жиросжигание» без единицы — просто число, с единицей — «35 мин».
assert.strictEqual(nativePreviewText('FAT_BURNING', { native_show_unit: false }), '35');
assert.strictEqual(nativePreviewText('FAT_BURNING', { native_show_unit: true }), '35 мин');
assert.strictEqual(nativePreviewText('FAT_BURNING', {}), '35 мин');
assert.strictEqual(nativePreviewText('FAT_BURNING_TARGET', { native_show_unit: false }), '60');
assert.strictEqual(nativePreviewText('HUMIDITY', { native_show_unit: false }), '42');
assert.strictEqual(nativePreviewText('PAI_DAILY', {}), '42');           // у PAI единица выключена по умолчанию
assert.strictEqual(nativePreviewText('BODY_TEMP', { native_show_unit: false }), '36.5');
const unitType = (props) => code(props).match(/unit_type:\s*(\d)/)[1];
assert.strictEqual(unitType({ data_source: 'FAT_BURNING', native_show_unit: false }), '0');
assert.strictEqual(unitType({ data_source: 'FAT_BURNING' }), '1');

// Баг «% не появляется»: в инспекторе у батареи стоит «%» по умолчанию, но пока пользователь
// сам не сотрёт и не введёт его заново, props.suffix не задан. Холст и часы должны показывать «%».
const textDef = ctx.__r.REGISTRY.text;
assert.strictEqual(sensorPreviewText('BATTERY', {}, textDef), '82%', 'батарея: незаданный суффикс → «%» как в инспекторе');
assert.strictEqual(sensorPreviewText('BATTERY', { suffix: '' }, textDef), '82', 'батарея: явная пустая строка → без «%»');
assert.strictEqual(sensorPreviewText('BATTERY', { suffix: undefined }, textDef), '82%');
assert.strictEqual(sensorPreviewText('HEART', {}, textDef), '♥ 72', 'пульс: префикс по умолчанию тоже виден');
assert.strictEqual(sensorPreviewText('CALORIE', {}, textDef), '340 kcal');
assert.strictEqual(sensorPreviewText('STEP', {}, ctx.__r.REGISTRY.steps), '8452 шагов', 'пресет «Шаги»: суффикс по умолчанию из пресета');
assert.ok(code({ data_source: 'BATTERY' }).includes('+ "%"'), 'на часах: незаданный суффикс батареи = «%»');
assert.ok(code({ data_source: 'BATTERY', suffix: '' }).includes('+ ""'), 'на часах: пустой суффикс батареи остаётся пустым');
console.log('Suffix tests passed.');
