// Панель настроек на часах (тап-зона SETTINGS): открытие/закрытие, профиль «День и ночь», сохранение.
// Почасовая вибрация из панели убрана (см. migrateProject) — тест проверяет и её отсутствие.
// Запуск: node scripts/test-watch-settings-panel.js
const assert = require('node:assert/strict');
const vm = require('node:vm');
const fx = require('./export-fixtures.js');

const exporter = fx.loadExporter(process.cwd());
function makeProject(withNight) {
  const component = fx.mk('dial', 'fill_rect', { color: '#334455' });
  component.tapZones = [{
    id: 'settings-zone', name: 'Настройки', x: 0, y: 0, w: 100, h: 60, visible: true,
    props: { tap_action: 'SETTINGS' },
  }];
  const project = fx.project([component], [
    fx.mk('aod_time', 'time_hm', { text_size: 40, color: '#888888', format: 'HH:MM' }, { x: 80, y: 80, w: 220, h: 60 }),
  ]);
  project.app.appId = 1234567;
  project.meta = { name: 'Settings panel test', createdAt: 123456789 };
  project.watchSettings = withNight ? { dayNightEnabled: true, dayNightStart: 22, dayNightEnd: 7 } : {};
  if (withNight) project.scenes.night = { components: [fx.mk('night_dial', 'fill_rect', { color: '#001122' })], background: { color: '#000510' } };
  return project;
}

// ── 1. Проект без ночного профиля ──
let generated = exporter.exportIndexJsDual(makeProject(false), {}, {});
assert.equal(generated.validation.errors.length, 0, generated.validation.errors.join('\n'));
assert.match(generated.code, /__afOpenSettings\(\)/, 'tap-zone action opens the settings panel');
assert.match(generated.code, /show_level: show_level\.ONLY_NORMAL/, 'interactive panel is restricted to the normal face');
assert.doesNotMatch(generated.code, /__afHourly|Почасовая вибрация|__afVibrate|Vibrator|VIBRATE/, 'hourly vibration is fully removed from the panel');
assert.doesNotMatch(generated.code, /__afTrackAodWidget|__afSetAodWidgetVisible|aodDisplay|Настройки AOD/, 'the AOD settings page and its widget tracking are removed');

const files = new Map();
const current = { hour: 10, minute: 15, second: 0 };
const vibrations = [];
let nextHandle = 1;
let screenType = 1;
function TestDate() {}
TestDate.prototype.getMinutes = () => current.minute;
TestDate.prototype.getSeconds = () => current.second;
TestDate.prototype.getHours = () => current.hour;
TestDate.prototype.getFullYear = () => 2026;
TestDate.prototype.getMonth = () => 9;
TestDate.prototype.getDate = () => 31;

function buildRuntime(overrides = {}) {
  const widgets = [];
  const intervals = [];
  const handles = new Map();
  const enumProxy = new Proxy({}, { get: (_, key) => String(key) });
  const hmFS = {
    O_RDONLY: 1, O_RDWR: 2, O_CREAT: 4, O_TRUNC: 8,
    stat: (path) => files.has(path) ? [{ size: files.get(path).length }, 0] : [null, -1],
    open: (path, flags) => {
      if (!files.has(path) && (flags & 4)) files.set(path, new Uint8Array());
      if (!files.has(path)) return -1;
      const fd = nextHandle++;
      handles.set(fd, path);
      if (flags & 8) files.set(path, new Uint8Array());
      return fd;
    },
    read: (fd, buffer, position, length) => {
      const bytes = files.get(handles.get(fd)) || new Uint8Array();
      new Uint8Array(buffer).set(bytes.slice(0, length), position);
      return 0;
    },
    write: (fd, buffer, position, length) => {
      files.set(handles.get(fd), new Uint8Array(buffer).slice(position, position + length));
      return 0;
    },
    close: (fd) => { handles.delete(fd); return 0; },
  };
  const sandbox = {
    console, Math, Date: TestDate, JSON, Uint8Array, ArrayBuffer,
    createWidget: (type, params) => {
      const w = { type, params, visible: true, props: {}, alpha: null };
      w.setAlpha = (alpha) => { w.alpha = alpha; };
      w.setProperty = (key, value) => {
        if (key === 'VISIBLE') w.visible = !!value;
        else if (key === 'MORE') Object.assign(w.params, value);
        else w.props[key] = value;
      };
      widgets.push(w);
      return w;
    },
    widget: enumProxy, align: enumProxy, text_style: enumProxy, prop: enumProxy, show_level: enumProxy, data_type: enumProxy,
    hmFS,
    hmSetting: { screen_type: { WATCHFACE: 1, AOD: 2 }, getScreenType: () => screenType },
    hmSensor: {
      id: { VIBRATE: 99 },
      createSensor: () => ({
        scene: 0,
        start() { vibrations.push({ scene: this.scene, hour: current.hour, screenType }); },
        stop() {},
      }),
    },
    setInterval: (fn, delay) => { intervals.push({ fn, delay }); return intervals.length; },
    clearInterval: () => {}, setTimeout: () => 1, clearTimeout: () => {},
    WatchFace: (definition) => { sandbox.watchFace = definition; },
  };
  for (const [key, value] of Object.entries(overrides)) {
    if (value === null) delete sandbox[key]; else sandbox[key] = value;
  }
  vm.createContext(sandbox);
  vm.runInContext(generated.code.replace(/^import .*$/gm, ''), sandbox, { filename: 'watchface-settings-test.js' });
  const self = {};
  sandbox.watchFace.build.call(self);
  return { widgets, intervals, self, sandbox };
}

function visibleText(runtime, text) {
  return runtime.widgets.find((w) => w.visible && w.params.text === text);
}

function assertInsideRoundedScreen(widget, message) {
  const { x, y, w, h } = widget.params;
  const insetAt = (vertical) => {
    const normalized = Math.max(-1, Math.min(1, (vertical - 240) / 240));
    return 240 * (1 - Math.sqrt(Math.max(0, 1 - normalized * normalized)));
  };
  const safeInset = Math.max(insetAt(y), insetAt(y + h)) + 12;
  assert.ok(x >= safeInset - 1, `${message}: left edge stays inside the rounded screen`);
  assert.ok(x + w <= 480 - safeInset + 1, `${message}: right edge stays inside the rounded screen`);
}

function open(rt) {
  const zone = rt.widgets.find((w) => w.alpha === 0 && w.params.w === 100 && typeof w.params.click_func === 'function');
  assert.ok(zone, 'the SETTINGS tap zone is created');
  zone.params.click_func();
}
const panelShown = (rt) => rt.widgets.some((w) => w.visible && w.type === 'FILL_RECT' && w.params.color === 0x111923);

let runtime = buildRuntime();
assert.ok(!panelShown(runtime), 'panel is hidden until the zone is tapped');
open(runtime);
assert.ok(panelShown(runtime), 'tap opens the settings panel');
assertInsideRoundedScreen(visibleText(runtime, '⚙'), 'panel title');
const close = visibleText(runtime, '×  Закрыть');
assert.ok(close, 'panel has a close button');
assert.ok(!visibleText(runtime, 'День и ночь  ›'), 'no day/night entry without a night scene');
assert.ok(!runtime.widgets.some((w) => w.visible && /вибрац/i.test(String(w.params.text))), 'no vibration rows in the menu');
close.params.click_func();
assert.ok(!panelShown(runtime), 'close hides the panel');

// ── 2. Проект с ночным профилем ──
generated = exporter.exportIndexJsDual(makeProject(true), {}, {});
assert.equal(generated.validation.errors.length, 0, generated.validation.errors.join('\n'));
assert.doesNotMatch(generated.code, /__afHourly|Vibrator|VIBRATE/, 'night profile project has no vibration code either');

files.clear();
runtime = buildRuntime();
open(runtime);
const entry = visibleText(runtime, 'День и ночь  ›');
assert.ok(entry, 'menu has the day/night entry when a night scene exists');
assert.ok(entry.params.h >= 36, 'menu rows provide a larger touch target');
assertInsideRoundedScreen(entry, 'main menu item');
entry.params.click_func();
assert.ok(visibleText(runtime, 'Ночной профиль с 22:00'), 'night start shows the project default');
assert.ok(visibleText(runtime, 'Дневной профиль с 07:00'), 'day start shows the project default');
const back = visibleText(runtime, '‹ Назад');
assert.ok(back, 'subpage has a back button');
assertInsideRoundedScreen(back, 'back button');
back.params.click_func();
assert.ok(visibleText(runtime, 'День и ночь  ›'), 'back returns to the settings menu');
visibleText(runtime, '×  Закрыть').params.click_func();
assert.ok(!panelShown(runtime), 'close hides the panel');

console.log('Watch settings panel test passed (open/close, no vibration, day/night page, rounded-screen-safe controls).');
