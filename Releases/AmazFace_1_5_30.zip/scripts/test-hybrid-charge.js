// Проверка компонентов «HybridCharge» и «BioCharge»: только число, без дуги и подписи.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.resolve(__dirname, '..');
const ctx = { console, Math, Date, JSON, window: {} };
vm.createContext(ctx);
for (const rel of ['src/util/slug.js', 'src/components/hybrid-charge.js', 'src/components/registry.js', 'src/exporter/index-js-exporter.js']) {
  const src = fs.readFileSync(path.join(root, rel), 'utf8');
  vm.runInContext(src + '\n;globalThis.__ex = Object.assign(globalThis.__ex || {}, {' +
    ['REGISTRY', 'exportIndexJs', 'HybridChargeModel'].filter((n) => src.includes(`const ${n}`) || src.includes(`function ${n}`)).join(',') + '});', ctx, { filename: rel });
}
const { REGISTRY, exportIndexJs, HybridChargeModel: M } = ctx.__ex;

let failed = 0;
const check = (name, cond, extra) => { if (!cond) { failed++; console.error('FAIL:', name, extra || ''); } else console.log('ok:', name); };
const syntaxOk = (code) => { try { new vm.Script(code.replace(/^import .*$/gm, '')); return true; } catch (e) { return e.message; } };
const mk = (props, extra) => Object.assign({ id: 'hc1', defId: 'hybrid_charge', x: 20, y: 20, w: 200, h: 80, props: Object.assign({}, props) }, extra);
const mkBio = (props, extra) => mk(props, Object.assign({ id: 'bc1', defId: 'bio_charge' }, extra));
const run = (comps) => exportIndexJs({ device: { w: 480, h: 480 }, components: comps, assets: [], fonts: [], background: {} }, {}, {}, {});

// 1. Реестр
for (const [id, wid] of [['hybrid_charge', 'HYBRID_CHARGE'], ['bio_charge', 'BIO_CHARGE']]) {
  const def = REGISTRY[id];
  check(`реестр: ${id} есть, виджет ${wid}`, !!def && def.widgetId === wid);
  const keys = def.properties.map((q) => q.key);
  check(`реестр: ${id} ключи уникальны`, new Set(keys).size === keys.length);
  check(`реестр: ${id} все ключи модели описаны`, Object.keys(M.DEFAULTS).every((k) => keys.includes(k)), Object.keys(M.DEFAULTS).filter((k) => !keys.includes(k)).join(','));
  check(`реестр: ${id} без подписи и кольца`, !keys.some((k) => /^(caption_|ring_|zone_|start_angle|end_angle|line_width)/.test(k)));
}

// 2. Модель
const q = M.props(mk({ number_size: 'x', data_source: 'junk', preview_value: 500 }));
check('модель: «мусорные» значения приводятся', q.number_size === 56 && q.data_source === 'AUTO' && q.preview_value === 100);
const bx = M.boxes(mk({}));
check('рамка: число совпадает с рамкой компонента', bx.number.x === 20 && bx.number.w === 200 && bx.number.h === 80);
check('рамка: сдвиг dx/dy', (() => { const b = M.boxes(mk({ number_dx: 5, number_dy: -3 })); return b.number.x === 25 && b.number.y === 17; })());
check('тип: явный источник', M.typeExpr(mk({ data_source: 'READINESS' }), 'HYBRID_CHARGE') === 'data_type.READINESS');
check('тип: авто — цепочка заканчивается READINESS', /data_type\.READINESS\)+$/.test(M.typeExpr(mk({}), 'HYBRID_CHARGE')));
check('тип: авто BioCharge начинает с BIO_CHARGE', M.typeExpr(mkBio({}), 'BIO_CHARGE').startsWith('(data_type.BIO_CHARGE !== undefined'));

// 3. Экспорт
let r = run([mk({})]);
check('экспорт: валидный JS', syntaxOk(r.code) === true, syntaxOk(r.code));
check('экспорт: только TEXT_FONT, без ARC и TEXT', /widget\.TEXT_FONT/.test(r.code) && !/widget\.ARC/.test(r.code) && !/text: "HybridCharge"/.test(r.code));
check('экспорт: unit_type 0 по умолчанию', /unit_type: 0/.test(r.code));
check('экспорт: предупреждение о непроверенном data_type', r.validation.warnings.some((w) => /HybridCharge/.test(w)));
r = run([mk({ data_source: 'READINESS', number_unit: true })]);
check('экспорт: явный READINESS + unit_type 1', /type: data_type\.READINESS, unit_type: 1/.test(r.code));
r = run([mk({}), mkBio({}, { x: 260 })]);
check('экспорт: два компонента, валидный JS', syntaxOk(r.code) === true && (r.code.match(/widget\.TEXT_FONT/g) || []).length === 2, syntaxOk(r.code));

if (failed) { console.error(`\n${failed} проверок не прошли`); process.exit(1); }
console.log('\nHybridCharge/BioCharge: все проверки прошли.');
