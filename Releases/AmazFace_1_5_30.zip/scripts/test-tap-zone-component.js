// Самостоятельный компонент «Тап-зона»: реестр, экспорт кнопки без визуального виджета, миграция.
// Запуск: node scripts/test-tap-zone-component.js
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const fx = require('./export-fixtures.js');

const root = path.resolve(__dirname, '..');
const ex = fx.loadExporter(root);
const { REGISTRY, exportIndexJs } = ex;

let passed = 0, failed = 0;
const check = (n, c, x) => { if (c) { passed++; console.log('ok: ' + n); } else { failed++; console.log('FAIL: ' + n + (x ? ' — ' + x : '')); } };

function run(code) {
  const widgets = [];
  const mk = (type, params) => { const w = { type, params, visible: true, alpha: null }; w.setAlpha = (a) => { w.alpha = a; }; w.setProperty = (k, v) => { if (k === 'VISIBLE') w.visible = !!v; }; widgets.push(w); return w; };
  const proxy = new Proxy({}, { get: (_, k) => String(k) });
  let built = null;
  const calls = [];
  const sb = { console, Math, Date, JSON, createWidget: mk, widget: proxy, align: proxy, text_style: proxy, prop: proxy, show_level: proxy, data_type: proxy,
    system_status: proxy, anim_status: proxy, launchApp: (o) => calls.push(o), SYSTEM_APP_HR: 'SYSTEM_APP_HR', setInterval: () => 1, clearInterval: () => {},
    Time: function () { this.getTime = () => 0; }, Battery: function () {}, Step: function () {}, WatchFace: (o) => { built = o; },
    getAutoBrightness: () => false, getBrightness: () => 50, setAutoBrightness: () => {}, setBrightness: () => {} };
  vm.createContext(sb);
  vm.runInContext(code.replace(/^import .*$/gm, ''), sb, { filename: 'index.js' });
  built.build.call({});
  widgets.calls = calls;
  return widgets;
}
const tz = (id, props, geo) => fx.mk(id, 'tap_zone', Object.assign({ tap_action: 'NONE' }, props), Object.assign({ x: 30, y: 40, w: 90, h: 70 }, geo || {}));

// 1. Реестр
{
  const d = REGISTRY.tap_zone;
  check('реестр: компонент tap_zone существует', !!d && d.widgetId === 'TAP_ZONE');
  check('реестр: есть геометрия и действие по тапу', ['x', 'y', 'w', 'h', 'tap_action', 'tap_metric'].every((k) => d.properties.some((p) => p.key === k)));
  check('реестр: tap_action не продублирован', d.properties.filter((p) => p.key === 'tap_action').length === 1);
  const metric = d.properties.find((p) => p.key === 'tap_metric');
  check('реестр: выбор экрана виден только для METRIC', metric.showIf({ tap_action: 'METRIC' }) === true && metric.showIf({ tap_action: 'NONE' }) === false);
  check('реестр: категория «Управление»', d.category === 'Управление');
}

// 2. Экспорт: одна кнопка, без визуальных виджетов
{
  const r = exportIndexJs(fx.project([tz('z1', { tap_action: 'METRIC', tap_metric: 'HR' })]), {}, {}, {});
  check('экспорт: нет ошибок', r.validation.errors.length === 0, r.validation.errors.join('; '));
  const ws = run(r.code);
  const btns = ws.filter((w) => w.type === 'BUTTON');
  check('рантайм: ровно одна кнопка', btns.length === 1, String(btns.length));
  check('рантайм: кнопка на рамке компонента и прозрачна', btns[0].params.x === 30 && btns[0].params.y === 40 && btns[0].params.w === 90 && btns[0].params.h === 70 && btns[0].alpha === 0);
  check('рантайм: никаких визуальных виджетов от самой зоны', !ws.some((w) => ['TEXT', 'IMG', 'ARC', 'CIRCLE'].includes(w.type) || (w.type === 'FILL_RECT' && w.params.x === 30)));
  btns[0].params.click_func();
  check('рантайм: тап открывает пульс', ws.calls.length === 1 && ws.calls[0].appId === 'SYSTEM_APP_HR');
}

// 3. NONE — кнопки нет; невидимая зона — кнопки нет
{
  const ws = run(exportIndexJs(fx.project([tz('z1', { tap_action: 'NONE' })]), {}, {}, {}).code);
  check('NONE: кнопка не создаётся', ws.filter((w) => w.type === 'BUTTON').length === 0);
  const hidden = tz('z2', { tap_action: 'METRIC', tap_metric: 'HR' }); hidden.visible = false;
  const ws2 = run(exportIndexJs(fx.project([hidden]), {}, {}, {}).code);
  check('скрытая зона: кнопка не создаётся', ws2.filter((w) => w.type === 'BUTTON').length === 0);
}

// 4. Фонарик через самостоятельную зону
{
  const ws = run(exportIndexJs(fx.project([tz('z1', { tap_action: 'FLASHLIGHT' })]), {}, {}, {}).code);
  const btns = ws.filter((w) => w.type === 'BUTTON');
  const overlay = ws.find((w) => w.type === 'FILL_RECT' && w.params.w === 480);
  check('фонарик: зона + кнопка «закрыть»', btns.length === 2 && !!overlay);
  btns[0].params.click_func();
  check('фонарик: тап включает белый экран', overlay.visible === true);
}

// 5. Смесь с обычным компонентом: у него по-прежнему свои дочерние зоны
{
  const t = fx.mk('t1', 'text', { data_source: 'NONE', text: 'A', text_size: 30, color: '#fff' }, { x: 0, y: 0, w: 100, h: 40 });
  t.tapZones = [{ id: 'tap_001', name: 'z', x: 0, y: 0, w: 50, h: 40, visible: true, locked: false, props: { tap_action: 'METRIC', tap_metric: 'SLEEP' } }];
  const ws = run(exportIndexJs(fx.project([t, tz('z1', { tap_action: 'METRIC', tap_metric: 'HR' })]), {}, {}, {}).code);
  check('смесь: две кнопки (дочерняя зона и самостоятельная)', ws.filter((w) => w.type === 'BUTTON').length === 2);
}

// 6. Миграция проекта: у tap_zone не создаётся дублирующая дочерняя зона
{
  const src = fs.readFileSync(path.join(root, 'src/project/project.js'), 'utf8');
  check("миграция: для tap_zone дочерняя зона не создаётся", src.includes("migrated.defId !== 'tap_zone'"));
  const insp = fs.readFileSync(path.join(root, 'src/inspector/inspector.js'), 'utf8');
  check('инспектор: поля действия видны у tap_zone', insp.includes("def.widgetId !== 'TAP_ZONE'"));
  const cv = fs.readFileSync(path.join(root, 'src/editor/canvas.js'), 'utf8');
  check('редактор: рамка tap-zone-component и без кнопки ⊕', cv.includes("'tap-zone-component'") && cv.includes("if (def.widgetId !== 'TAP_ZONE') this.frame.appendChild(addTap)"));
}

console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed ? 1 : 0);
