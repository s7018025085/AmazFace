// Карта тап-зон: зоны со всеми действиями (в т.ч. «Показать/скрыть контейнер») попадают в картинку с подписью.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const ctx = { console, Math, Date, JSON, Set, Map, Array, Object, Number, String, window: {}, document: {} };
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(root, 'src/exporter/share-images.js'), 'utf8'), ctx, { filename: 'share-images.js' });
const { collectTapZones } = ctx.window.ShareImages;
const z = (id, props, extra = {}) => Object.assign({ id, name: id, x: 0, y: 0, w: 50, h: 50, props }, extra);
const project = {
  device: { w: 480, h: 480 },
  groups: [{ id: 'g1', name: 'Погода' }],
  components: [{ id: 'c1', name: 'Кнопка', x: 10, y: 10, tapZones: [
    z('a', { tap_action: 'TOGGLE_GROUP', tap_group: 'g1', tap_group_mode: 'TOGGLE' }),
    z('b', { tap_action: 'SETTINGS' }),
    z('c', { tap_action: 'NONE' }),
    z('d', { tap_action: 'FLASHLIGHT' }, { visible: false }),
  ] }],
};
project.components.push({ id: 'tz1', defId: 'tap_zone', name: 'Тап-зона', x: 200, y: 280, w: 80, h: 80, visible: true,
  props: { tap_action: 'TOGGLE_GROUP', tap_group: 'g1', tap_group_mode: 'TOGGLE' }, tapZones: [] });
project.components.push({ id: 'tz2', defId: 'tap_zone', name: 'Тап-зона', x: 300, y: 216, w: 180, h: 50, visible: true,
  props: { tap_action: 'METRIC', tap_metric: 'CALENDAR' }, tapZones: [] });
project.components.push({ id: 'tz3', defId: 'tap_zone', name: 'Пустая', x: 0, y: 0, w: 50, h: 50, visible: true, props: { tap_action: 'NONE' } });
const { zones } = collectTapZones(project);
assert.equal(zones.length, 4, 'вложенные + отдельные зоны; NONE и скрытые не попадают на карту');
assert.match(zones[0].label, /Погода/, 'подпись контейнера');
assert.equal(zones[1].label, 'Настройки циферблата');
const st = zones.find((q) => q.x === 200 && q.y === 280 && q.w === 80);
assert.ok(st && /Погода/.test(st.label), 'отдельный компонент «Тап-зона» попадает на карту целиком по своей рамке');
console.log('Tap zone map tests passed.');
