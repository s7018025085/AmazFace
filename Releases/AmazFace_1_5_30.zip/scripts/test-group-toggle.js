// Контейнеры: действие тап-зоны «Показать/скрыть контейнер» и флаг «скрыта при запуске».
// Запуск: node scripts/test-group-toggle.js
const path = require('node:path');
const vm = require('node:vm');
const fx = require('./export-fixtures.js');

const root = path.resolve(__dirname, '..');
const ex = fx.loadExporter(root);
const { REGISTRY, exportIndexJs, exportIndexJsDual } = ex;

let passed = 0, failed = 0;
const check = (n, c, x) => { if (c) { passed++; console.log('ok: ' + n); } else { failed++; console.log('FAIL: ' + n + (x ? ' — ' + x : '')); } };

function run(code, timers) {
  const widgets = [];
  const mk = (type, params) => { const w = { type, params, visible: true, alpha: null }; w.setAlpha = (a) => { w.alpha = a; }; w.setProperty = (k, v) => { if (k === 'VISIBLE') w.visible = !!v; }; widgets.push(w); return w; };
  const proxy = new Proxy({}, { get: (_, k) => String(k) });
  let built = null;
  const sb = { console, Math, Date, JSON, Map, Set, createWidget: mk, widget: proxy, align: proxy, text_style: proxy, prop: proxy, show_level: proxy, data_type: proxy,
    system_status: proxy, anim_status: proxy, launchApp: () => {}, setInterval: (fn) => { if (timers) { timers.list.push({ fn, on: true }); return timers.list.length; } return 1; }, clearInterval: (id) => { if (timers && timers.list[id - 1]) timers.list[id - 1].on = false; },
    Time: function () { this.getTime = () => 0; }, Battery: function () {}, Step: function () {}, Screen: function () {}, WatchFace: (o) => { built = o; },
    getAutoBrightness: () => false, getBrightness: () => 50, setAutoBrightness: () => {}, setBrightness: () => {} };
  vm.createContext(sb);
  vm.runInContext(code.replace(/^import .*$/gm, ''), sb, { filename: 'index.js' });
  built.build.call({});
  return widgets;
}

const rect = (id, group, x) => Object.assign(fx.mk(id, 'fill_rect', { color: '#334455' }, { x, y: 10, w: 40, h: 40 }), group ? { group } : {});
const tz = (id, props, group) => Object.assign(fx.mk(id, 'tap_zone', Object.assign({ tap_action: 'NONE' }, props), { x: 300, y: 300, w: 60, h: 60 }), group ? { group } : {});
const withGroups = (comps, groups) => Object.assign(fx.project(comps), { groups });
const g1 = { id: 'group_a', name: 'Датчики', collapsed: false };

// Реестр
{
  const d = REGISTRY.tap_zone;
  check('реестр: действие TOGGLE_GROUP есть в списке', d.properties.find((p) => p.key === 'tap_action').options.some((o) => o.value === 'TOGGLE_GROUP'));
  const pg = d.properties.find((p) => p.key === 'tap_group');
  check('реестр: выбор контейнера виден только для TOGGLE_GROUP', !!pg && pg.showIf({ tap_action: 'TOGGLE_GROUP' }) === true && pg.showIf({ tap_action: 'NONE' }) === false);
}

// Переключение
{
  const comps = [rect('r1', 'group_a', 10), rect('r2', 'group_a', 60), rect('r3', null, 110), tz('z1', { tap_action: 'TOGGLE_GROUP', tap_group: 'group_a' })];
  const r = exportIndexJs(withGroups(comps, [g1]), {}, {}, {});
  check('экспорт: нет ошибок', r.validation.errors.length === 0, r.validation.errors.join('; '));
  const ws = run(r.code);
  const rects = ws.filter((w) => w.type === 'FILL_RECT' && w.params.w === 40);
  const btn = ws.find((w) => w.type === 'BUTTON');
  check('рантайм: все виджеты на месте и видны', rects.length === 3 && rects.every((w) => w.visible));
  btn.params.click_func();
  check('тап: участники контейнера скрыты', !rects[0].visible && !rects[1].visible);
  check('тап: компонент вне контейнера остался', rects[2].visible);
  btn.params.click_func();
  check('повторный тап: участники снова видны', rects[0].visible && rects[1].visible);
}

// Режимы SHOW / HIDE
{
  const mkRun = (mode) => {
    const comps = [rect('r1', 'group_a', 10), tz('z1', { tap_action: 'TOGGLE_GROUP', tap_group: 'group_a', tap_group_mode: mode })];
    const ws = run(exportIndexJs(withGroups(comps, [g1]), {}, {}, {}).code);
    return { rect: ws.find((w) => w.type === 'FILL_RECT' && w.params.w === 40), btn: ws.find((w) => w.type === 'BUTTON') };
  };
  const h = mkRun('HIDE'); h.btn.params.click_func(); h.btn.params.click_func();
  check('HIDE: сколько ни тапай — скрыто', !h.rect.visible);
  const s = mkRun('SHOW'); s.btn.params.click_func();
  check('SHOW: на видимом ничего не меняется', s.rect.visible);
}

// Скрыта при запуске
{
  const comps = [rect('r1', 'group_a', 10), rect('r3', null, 110), tz('z1', { tap_action: 'TOGGLE_GROUP', tap_group: 'group_a', tap_group_mode: 'SHOW' })];
  const ws = run(exportIndexJs(withGroups(comps, [Object.assign({}, g1, { startHidden: true })]), {}, {}, {}).code);
  const rects = ws.filter((w) => w.type === 'FILL_RECT' && w.params.w === 40);
  check('startHidden: контейнер стартует скрытым, остальное видно', !rects[0].visible && rects[1].visible);
  ws.find((w) => w.type === 'BUTTON').params.click_func();
  check('startHidden: тап «показать» открывает контейнер', rects[0].visible);
}

// Без действия и без флага экспорт контейнеров не меняется
{
  const comps = [rect('r1', 'group_a', 10)];
  const a = exportIndexJs(withGroups(comps, [g1]), {}, {}, {}).code;
  const b = exportIndexJs(fx.project([rect('r1', null, 10)]), {}, {}, {}).code;
  check('контейнер без действий не попадает в код', a === b && !a.includes('__afGrp'));
}

// Висячая ссылка и пустая группа
{
  const r1 = exportIndexJs(withGroups([rect('r1', null, 10), tz('z1', { tap_action: 'TOGGLE_GROUP', tap_group: 'group_gone' })], []), {}, {}, {});
  check('удалённый контейнер: предупреждение, кнопки нет', r1.validation.warnings.some((w) => w.includes('контейнер')) && run(r1.code).filter((w) => w.type === 'BUTTON').length === 0);
  const r2 = exportIndexJs(withGroups([tz('z0', {}, 'group_a'), tz('z1', { tap_action: 'TOGGLE_GROUP', tap_group: 'group_a' })], [g1]), {}, {}, {});
  check('пустой контейнер: предупреждение', r2.validation.warnings.some((w) => w.includes('нет компонентов')));
}

// Дуга: собственное скрытие сегментов не ломается группой
{
  const comps = [Object.assign(fx.mk('a1', 'arc', { data_source: 'BATTERY', track_enabled: true }, { w: 200, h: 200 }), { group: 'group_a' }), tz('z1', { tap_action: 'TOGGLE_GROUP', tap_group: 'group_a' })];
  const r = exportIndexJs(withGroups(comps, [g1]), {}, {}, {});
  check('дуга в контейнере: экспорт без ошибок', r.validation.errors.length === 0, r.validation.errors.join('; '));
  const ws = run(r.code);
  const arcs = ws.filter((w) => w.type === 'ARC');
  const btn = ws.find((w) => w.type === 'BUTTON');
  btn.params.click_func();
  check('дуга в контейнере: все ARC скрыты', arcs.length > 0 && arcs.every((w) => !w.visible));
  btn.params.click_func();
  check('дуга в контейнере: после показа видны', arcs.every((w) => w.visible) || arcs.some((w) => w.visible));
}

// Dual (День/Ночь/AOD): группы берутся из своей сцены
{
  const comps = [rect('r1', 'group_a', 10), tz('z1', { tap_action: 'TOGGLE_GROUP', tap_group: 'group_a' })];
  const proj = fx.project(comps);
  proj.mode = 'normal'; proj.groups = [g1]; proj.scenes.normal.groups = [g1];
  const r = exportIndexJsDual(proj, {}, {}, {});
  check('dual: нет ошибок', r.validation.errors.length === 0, r.validation.errors.join('; '));
  check('dual: в коде есть переключатель группы', r.code.includes('__afGrpSet'));
  let ws = null;
  try { ws = run(r.code); } catch (e) { check('dual: код запускается', false, e.message); }
  if (ws) {
    const rr = ws.find((w) => w.type === 'FILL_RECT' && w.params.w === 40);
    const bb = ws.find((w) => w.type === 'BUTTON');
    bb.params.click_func();
    check('dual: тап скрывает участника', !!rr && !rr.visible);
  }
}

// Плавное появление и затухание (галочка у тап-зоны)
{
  const mkAnim = (extra, grp) => {
    const comps = [rect('r1', 'group_a', 10), tz('z1', Object.assign({ tap_action: 'TOGGLE_GROUP', tap_group: 'group_a', tap_group_anim: true, tap_group_anim_ms: 200 }, extra))];
    const timers = { list: [] };
    const r = exportIndexJs(withGroups(comps, [grp || g1]), {}, {}, {});
    const ws = run(r.code, timers);
    const rr = ws.find((w) => w.type === 'FILL_RECT' && w.params.w === 40);
    const btn = ws.find((w) => w.type === 'BUTTON');
    const tick = (n) => { for (let i = 0; i < n; i++) timers.list.filter((t) => t.on).forEach((t) => t.fn()); };
    return { r, rr, btn, tick, timers };
  };
  const a = mkAnim({});
  check('анимация: нет ошибок экспорта', a.r.validation.errors.length === 0, a.r.validation.errors.join('; '));
  check('анимация: в коде есть __afGrpFade и импорт таймеров', a.r.code.includes('__afGrpFade') && /import \{ setInterval, clearInterval \}/.test(a.r.code));
  a.btn.params.click_func();
  check('затухание: сразу после тапа виджет ещё виден', a.rr.visible);
  a.tick(5);
  check('затухание: на полпути прозрачность снижена, виджет виден', a.rr.visible && a.rr.alpha !== null && a.rr.alpha > 0 && a.rr.alpha < 255, 'alpha=' + a.rr.alpha);
  a.tick(6);
  check('затухание: в конце виджет скрыт', !a.rr.visible);
  check('затухание: таймер остановлен', a.timers.list.every((t) => !t.on));
  a.btn.params.click_func();
  check('появление: виджет сразу виден, но прозрачен', a.rr.visible && a.rr.alpha === 0, 'alpha=' + a.rr.alpha);
  a.tick(5);
  check('появление: на полпути полупрозрачен', a.rr.alpha > 0 && a.rr.alpha < 255, 'alpha=' + a.rr.alpha);
  a.tick(6);
  check('появление: в конце полностью непрозрачен', a.rr.visible && a.rr.alpha === 255, 'alpha=' + a.rr.alpha);
  // повторный тап посреди затухания разворачивает анимацию
  a.btn.params.click_func(); a.tick(4);
  const mid = a.rr.alpha;
  a.btn.params.click_func(); a.tick(2);
  check('прерывание: тап посреди затухания разворачивает анимацию', a.rr.visible && a.rr.alpha > mid, mid + ' -> ' + a.rr.alpha);
  // скрыта при запуске + анимация
  const h = mkAnim({ tap_group_mode: 'SHOW' }, Object.assign({}, g1, { startHidden: true }));
  check('startHidden+анимация: стартует скрытым', !h.rr.visible);
  h.btn.params.click_func(); h.tick(11);
  check('startHidden+анимация: тап плавно показывает контейнер', h.rr.visible && h.rr.alpha === 255, 'alpha=' + h.rr.alpha);
  // без галочки — прежнее поведение
  const n = mkAnim({ tap_group_anim: false });
  check('без галочки: кода анимации нет, скрытие мгновенное', !n.r.code.includes('__afGrpFade'));
  n.btn.params.click_func();
  check('без галочки: тап скрывает сразу', !n.rr.visible);
}

console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed ? 1 : 0);
