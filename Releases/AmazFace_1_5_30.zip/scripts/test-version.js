// Версия и иконка: версия живёт в одном месте (src/version.js), всё остальное её только читает.
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const { APP_NAME, APP_VERSION, APP_TITLE } = require(path.join(root, 'src/version.js'));
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));

assert.match(APP_VERSION, /^\d+\.\d+\.\d+$/, 'версия в формате X.Y.Z');
assert.equal(APP_NAME, 'AmazFace');
assert.equal(pkg.version, APP_VERSION, 'package.json.version должен совпадать с src/version.js');
assert.ok(APP_TITLE.includes('v' + APP_VERSION), 'заголовок содержит версию');

// В index.html номера версии вручную нет — только подстановка из version.js.
assert.ok(!/v\d+\.\d+\.\d+/.test(html), 'в index.html не должно быть зашитой версии');
const scripts = [...html.matchAll(/<script src="([^"]+)"/g)].map((m) => m[1]);
assert.equal(scripts[0], 'src/version.js', 'version.js подключается первым');
assert.ok(/data-app-version/.test(html), 'версия выводится в шапке');
assert.ok((html.match(/data-app-version/g) || []).length >= 2, 'версия есть и в шапке, и на экране приветствия');

// Иконка проекта: favicon + картинка в шапке, файлы на месте.
for (const f of ['icon.svg', 'icon-192.png', 'icon-512.png', 'apple-touch-icon.png', 'favicon.ico']) {
  assert.ok(fs.existsSync(path.join(root, 'assets/icons', f)), 'нет assets/icons/' + f);
}
assert.ok(/rel="icon"[^>]*assets\/icons\/icon\.svg/.test(html), 'favicon подключён');
assert.ok(/class="brand-icon"/.test(html), 'иконка в шапке');
assert.ok(fs.readFileSync(path.join(root, 'assets/icons/icon-512.png')).subarray(1, 4).toString() === 'PNG', 'icon-512.png — настоящий PNG');

// Подстановка в браузере: заголовок и все [data-app-version] получают версию.
const els = { ver: [{}, {}], name: [{}] };
const doc = { title: '', querySelectorAll: (sel) => (sel === '[data-app-version]' ? els.ver : els.name) };
delete require.cache[require.resolve(path.join(root, 'src/version.js'))];
global.document = doc; global.window = {};
require(path.join(root, 'src/version.js'));
assert.equal(doc.title, APP_TITLE);
assert.ok(els.ver.every((e) => e.textContent === 'v' + APP_VERSION));
assert.equal(global.window.AMAZFACE.version, APP_VERSION);
console.log('Version tests passed (v' + APP_VERSION + ').');
