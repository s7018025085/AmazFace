// Единственный источник правды о названии и версии редактора.
// Менять версию нужно ТОЛЬКО здесь (и в package.json — это проверяет scripts/test-version.js).
// Используется: заголовок вкладки, шапка редактора, экран приветствия (всё, что помечено data-app-version).
const APP_NAME = 'AmazFace';
const APP_VERSION = '1.5.29';
const APP_TITLE = `${APP_NAME} v${APP_VERSION} — Zepp OS Watch Face Designer`;

if (typeof window !== 'undefined') window.AMAZFACE = Object.freeze({ name: APP_NAME, version: APP_VERSION, title: APP_TITLE });
if (typeof document !== 'undefined') {
  document.title = APP_TITLE;
  document.querySelectorAll('[data-app-version]').forEach((el) => { el.textContent = 'v' + APP_VERSION; });
  document.querySelectorAll('[data-app-name]').forEach((el) => { el.textContent = APP_NAME; });
}
if (typeof module !== 'undefined' && module.exports) module.exports = { APP_NAME, APP_VERSION, APP_TITLE };
