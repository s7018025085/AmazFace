// src/ui/github-import.js
//
// Кнопка «Открыть из GitHub» на стартовом экране. Подключается ПОСЛЕ welcome.js:
// список папок и выбранные файлы отдаёт локальный мост (маршруты /github/import/*, те же
// настройки и токен, что у публикации — редактор токена не видит и не хранит).
// Скачанное собирается в папку, а дальше проект открывается ТЕМ ЖЕ механизмом, что
// «Открыть существующую папку» (AmazWelcome.openFolder): состояние загружается из
// amazface.project.json, ресурсы лежат в assets/, автосохранение работает как обычно.
// Ничего не публикуется, не собирается и не экспортируется.
// В списке у каждой папки показывается миниатюра циферблата: мост отдаёт файл превью
// (<имя>-watch-200.png), который публикация кладёт рядом с проектом; если его нет — значок папки.

(() => {
  const btn = document.getElementById('welcome-github');
  if (!btn || typeof AmazImport === 'undefined' || !window.AmazWelcome) return;

  const KEY_STORAGE = 'amazface_bridge_key'; // код доступа к мосту (не токен GitHub), как в github-publish.js
  const BRIDGE = () => (typeof ZEUS_BRIDGE === 'string' ? ZEUS_BRIDGE : 'http://127.0.0.1:17865');
  const esc = (t) => String(t == null ? '' : t).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  let key = '';
  try { key = localStorage.getItem(KEY_STORAGE) || ''; } catch (e) { /* localStorage может быть недоступен */ }

  // Папки выбираются и записываются локальным мостом (bridge-fs.js), не браузером.
  if (!window.BridgeFs) { btn.disabled = true; btn.title = 'Не загружен src/project/bridge-fs.js.'; }

  // ───────── диалог ─────────
  const dlg = document.createElement('dialog');
  dlg.id = 'gh-import-dialog';
  dlg.className = 'zpk-modal ghi-modal';
  dlg.setAttribute('aria-label', 'Открыть проект из GitHub');
  dlg.innerHTML = '<div class="zpk-modal-inner"><div class="zpk-head"><b>Открыть из GitHub</b>' +
    '<button type="button" id="ghi-close" aria-label="Закрыть">✕</button></div>' +
    '<div class="zpk-body" id="ghi-body"></div>' +
    '</div>';
  document.body.appendChild(dlg);
  const body = dlg.querySelector('#ghi-body');
  let busy = false;
  let controller = null;
  // Миниатюры: dir → blob-URL (null = превью нет). Живут, пока открыт диалог.
  const thumbs = new Map();
  let thumbCtl = null;
  const stopThumbs = () => { if (thumbCtl) { thumbCtl.abort(); thumbCtl = null; } };
  const freeThumbs = () => { stopThumbs(); for (const u of thumbs.values()) if (u) URL.revokeObjectURL(u); thumbs.clear(); };
  dlg.addEventListener('close', freeThumbs);

  dlg.addEventListener('cancel', (e) => { if (busy) e.preventDefault(); });
  dlg.querySelector('#ghi-close').onclick = () => { if (busy && controller) controller.abort(); else dlg.close(); };

  const say = (html) => { body.innerHTML = html; };
  const button = (id, label, cls) => `<button type="button" id="${id}" class="ghi-btn ${cls || ''}">${esc(label)}</button>`;
  const on = (id, fn) => { const el = body.querySelector('#' + id); if (el) el.onclick = fn; };

  // ───────── связь с мостом ─────────
  function bridgeError(msg, code, status) { const e = new Error(msg); e.code = code; e.status = status; return e; }
  async function bridgeFetch(pathname, signal) {
    let res;
    try {
      res = await fetch(BRIDGE() + pathname, { headers: { 'X-AmazFace-Key': key || '' }, signal: signal || (controller ? controller.signal : undefined) });
    } catch (e) {
      if (e && e.name === 'AbortError') throw e;
      throw bridgeError('Локальный мост не отвечает. Запустите bridge/start-zeus-bridge.bat и оставьте окно открытым.', 'bridge_down');
    }
    if (!res.ok) {
      let j = null; try { j = await res.json(); } catch (e) { /* пустой ответ */ }
      throw bridgeError((j && j.error) || `Ошибка моста (${res.status}).`, j && j.code, res.status);
    }
    return res;
  }
  const bridgeJson = async (p) => (await bridgeFetch(p)).json();
  const bridgeBytes = async (p) => new Uint8Array(await (await bridgeFetch(p)).arrayBuffer());

  // Миниатюра папки: 204 — превью нет. Любая другая ошибка тоже не мешает выбору папки.
  async function fetchThumb(dir, signal) {
    const res = await bridgeFetch(`/github/import/thumb?dir=${encodeURIComponent(dir)}`, signal);
    if (res.status === 204) return null;
    const bytes = await res.arrayBuffer();
    return bytes.byteLength ? URL.createObjectURL(new Blob([bytes], { type: 'image/png' })) : null;
  }
  const thumbHtml = (dir) => {
    const u = thumbs.get(dir);
    return u ? `<img src="${u}" alt="" draggable="false">` : (thumbs.has(dir) ? '<span class="ghi-ico" aria-hidden="true">📁</span>' : '<span class="ghi-spin" aria-hidden="true"></span>');
  };
  // Подгружает миниатюры по 3 штуки за раз; уже загруженные не запрашиваются повторно.
  function loadThumbs(data) {
    stopThumbs();
    const ctl = thumbCtl = new AbortController();
    const queue = data.projects.filter((p) => !thumbs.has(p.dir));
    const worker = async () => {
      while (queue.length && !ctl.signal.aborted) {
        const p = queue.shift();
        let url = null;
        try { url = await fetchThumb(p.dir, ctl.signal); }
        catch (e) { if (e && e.name === 'AbortError') return; /* нет превью — останется значок папки */ }
        if (ctl.signal.aborted) { if (url) URL.revokeObjectURL(url); return; }
        thumbs.set(p.dir, url);
        const el = body.querySelector(`.ghi-item[data-dir="${CSS.escape(p.dir)}"] .ghi-thumb`);
        if (el) el.innerHTML = thumbHtml(p.dir);
      }
    };
    for (let i = 0; i < 3; i++) worker();
  }

  // ───────── экраны ─────────
  function renderLoading(text) { say(`<p class="ghi-state"><span class="ghi-spin" aria-hidden="true"></span>${esc(text)}</p>`); }

  function renderError(err, retry) {
    const needKey = err.code === 'key';
    const needConnect = err.code === 'not_connected';
    say(`<p class="ghi-state err">${esc(err.message || String(err))}</p>` +
      (needKey ? '<p class="ghi-hint">Код доступа напечатан в окне моста. Введите его один раз:</p>' +
        '<div class="ghi-row"><input id="ghi-key" type="password" autocomplete="off" placeholder="Код доступа к мосту" aria-label="Код доступа к мосту"> ' + button('ghi-key-ok', 'Продолжить', 'primary') + '</div>' : '') +
      (needConnect ? '<p class="ghi-hint">Репозиторий и токен настраиваются один раз в окне публикации (кнопка «Опубликовать на GitHub» в редакторе). Для импорта используются те же настройки, ветка — <code>main</code>.</p>' : '') +
      '<div class="ghi-row">' + (needKey ? '' : button('ghi-retry', 'Повторить', 'primary')) + '</div>');
    on('ghi-retry', retry);
    on('ghi-key-ok', () => {
      key = (body.querySelector('#ghi-key').value || '').trim();
      try { localStorage.setItem(KEY_STORAGE, key); } catch (e) { /* без сохранения */ }
      load();
    });
  }

  function renderList(data) {
    const rows = data.projects.map((p, i) =>
      `<button type="button" class="ghi-item" data-i="${i}" data-dir="${esc(p.dir)}" title="${esc(p.dir)}">` +
      `<span class="ghi-thumb">${thumbHtml(p.dir)}</span>` +
      `<span class="ghi-text"><b>${esc(p.folder)}</b></span></button>`).join('');
    if (!data.projects.length) {
      say(`<p class="ghi-state">В папке <code>${esc(data.root || '/')}</code> репозитория <code>${esc(data.repo)}</code> не найдено вложенных папок.</p>` +
        '<div class="ghi-row">' + button('ghi-retry', 'Обновить', 'primary') + '</div>');
      on('ghi-retry', load);
      return;
    }
    say(`<p class="ghi-hint">Репозиторий <code>${esc(data.repo)}</code>, ветка <code>${esc(data.branch)}</code>. Выберите циферблат: содержимое и наличие рабочего проекта проверятся после выбора.</p>` +
      (data.note ? `<p class="ghi-hint warn">${esc(data.note)}</p>` : '') +
      `<div class="ghi-list">${rows}</div>` +
      '<div class="ghi-row">' + button('ghi-retry', 'Обновить список') + '</div>');
    on('ghi-retry', load);
    body.querySelectorAll('.ghi-item[data-i]').forEach((el) => {
      el.onclick = () => inspectFolder(data, data.projects[Number(el.dataset.i)]);
    });
    loadThumbs(data);
  }

  function renderInspection(data, project, manifest, notice) {
    const size = manifest.total < 1024 * 1024
      ? `${Math.ceil(manifest.total / 1024)} КБ`
      : `${(manifest.total / 1024 / 1024).toFixed(1)} МБ`;
    const big = thumbs.get(project.dir);
    say((big ? `<div class="ghi-preview"><img src="${big}" alt="" draggable="false"></div>` : '') +
      `<p class="ghi-state">Папка «${esc(project.folder)}» проверена: найден рабочий проект${manifest.projectName ? ` «${esc(manifest.projectName)}»` : ''}.</p>` +
      `<p class="ghi-hint">Файлов: ${manifest.files.length}, общий размер: ${size}. Теперь выберите папку на компьютере для сохранения.</p>` +
      (notice ? `<p class="ghi-hint warn">${esc(notice)}</p>` : '') +
      '<div class="ghi-row">' + button('ghi-destination', 'Выбрать папку для сохранения', 'primary') + button('ghi-back', 'К списку папок') + '</div>');
    on('ghi-destination', () => choose(data, project, manifest));
    on('ghi-back', () => renderList(data));
  }

  // ───────── сценарии ─────────
  async function load() {
    controller = new AbortController(); busy = true;
    renderLoading('Подключаюсь к мосту и читаю репозиторий…');
    try {
      const ping = await bridgeJson('/github/ping');
      if (!ping.keyValid) throw bridgeError(key ? 'Код доступа к мосту не подошёл.' : 'Нужен код доступа к мосту.', 'key');
      const st = await bridgeJson('/github/status');
      if (!st.connected) throw bridgeError('GitHub не подключён.', 'not_connected');
      renderLoading('Сканирую папки в ветке main…');
      renderList(await bridgeJson('/github/import/projects'));
    } catch (e) {
      if (e && e.name === 'AbortError') { dlg.close(); return; }
      renderError(e, load);
    } finally { busy = false; controller = null; }
  }

  const pickParent = () => BridgeFs.pick('Выберите папку, куда сохранить проект из GitHub');

  // Запись через мост: сначала всё во временную папку рядом, потом атомарная подмена на стороне моста.
  async function commitViaBridge(parent, name, files, replace) {
    const tmp = `${name}${AmazImport.TMP_MARK}${Date.now().toString(36)}`;
    const tmpDir = await parent.getDirectoryHandle(tmp, { create: true });
    try {
      for (const [p, data] of files) {
        AmazImport.validateRelPath(p);
        const parts = p.split('/'); const fname = parts.pop();
        let d = tmpDir;
        for (const seg of parts) d = await d.getDirectoryHandle(seg, { create: true });
        const w = await (await d.getFileHandle(fname, { create: true })).createWritable();
        await w.write(data); await w.close();
      }
      const done = await BridgeFs.swap(parent, tmp, name, replace);
      return done;
    } catch (e) {
      try { await parent.removeEntry(tmp, { recursive: true }); } catch (e2) { /* уже нет */ }
      if (e && e.name === 'InvalidModificationError') { const x = new Error(`Папка «${name}» уже существует.`); x.code = 'exists'; throw x; }
      throw e;
    }
  }

  // Содержимое GitHub читается только после выбора конкретной папки.
  async function inspectFolder(data, project) {
    controller = new AbortController(); busy = true;
    renderLoading(`Проверяю папку «${project.folder}»…`);
    try {
      const manifest = await bridgeJson(`/github/import/manifest?dir=${encodeURIComponent(project.dir)}`);
      renderInspection(data, project, manifest);
    } catch (e) {
      if (e && e.name === 'AbortError') { dlg.close(); return; }
      renderError(e, () => renderList(data));
    } finally { busy = false; controller = null; }
  }

  // Выбор папки назначения делается отдельным нажатием, как требует браузерный API.
  async function choose(data, project, manifest) {
    let parent;
    renderLoading('Жду выбор папки в окне Windows… Если окна не видно, найдите его на панели задач (оно может быть за браузером).');
    try { parent = await pickParent(); }
    catch (e) {
      if (e && e.name === 'AbortError') {
        // Раньше здесь было молчаливое возвращение — теперь причина видна на экране.
        renderInspection(data, project, manifest, `Папка не выбрана: ${e.reason || 'выбор отменён'}. Подробности — в журнале ниже. Нажмите «Выбрать папку для сохранения» ещё раз.`);
        return;
      }
      renderError(e, () => renderList(data)); return;
    }
    await prepare(data, project, parent, manifest);
  }

  async function prepare(data, project, parent, manifest) {
    const name = AmazImport.safeFolderName(manifest.projectName || project.folder, project.folder);
    try {
      const exists = await AmazImport.destinationExists(parent, name);
      if (exists) { renderExists(data, project, parent, name, manifest); return; }
    } catch (e) { renderError(e, () => renderList(data)); return; }
    await run(data, project, parent, name, false, manifest);
  }

  function renderExists(data, project, parent, name, manifest) {
    say(`<p class="ghi-state warn">В папке «${esc(parent.name)}» уже есть «${esc(name)}». Ничего не изменено.</p>` +
      '<div class="ghi-row">' + button('ghi-other', 'Выбрать другую папку', 'primary') + button('ghi-replace', 'Заменить существующую', 'danger') + button('ghi-back', 'Назад') + '</div>');
    on('ghi-back', () => renderInspection(data, project, manifest));
    on('ghi-other', async () => {
      let p2;
      try { p2 = await pickParent(); } catch (e) { if (e && e.name === 'AbortError') { return; } renderError(e, () => renderList(data)); return; }
      await prepare(data, project, p2, manifest);
    });
    on('ghi-replace', () => renderConfirm(data, project, parent, name, manifest));
  }

  function renderConfirm(data, project, parent, name, manifest) {
    say(`<p class="ghi-state err">Папка «${esc(parent.name)}/${esc(name)}» будет удалена вместе со всем содержимым и заменена проектом из GitHub. Это действие нельзя отменить.</p>` +
      '<p class="ghi-hint">Новая версия сначала целиком скачивается и проверяется; старая папка не тронута, пока всё не готово.</p>' +
      '<div class="ghi-row">' + button('ghi-yes', 'Да, заменить', 'danger') + button('ghi-no', 'Отмена', 'primary') + '</div>');
    on('ghi-no', () => renderExists(data, project, parent, name, manifest));
    on('ghi-yes', () => run(data, project, parent, name, true, manifest));
  }

  async function run(data, project, parent, name, replace, manifest) {
    controller = new AbortController(); busy = true;
    renderLoading('Скачиваю проект…');
    const q = (p) => `dir=${encodeURIComponent(project.dir)}` + (p === undefined ? '' : `&path=${encodeURIComponent(p)}`);
    try {
      const staged = await AmazImport.stageImport({
        fetchManifest: async () => manifest,
        fetchFile: (p) => bridgeBytes(`/github/import/file?${q(p)}`),
        unzip: (bytes) => readZipEntries(bytes),
        makeAppJson: (text) => buildAppJson(migrateProject(JSON.parse(text))),
        onProgress: (done, total) => renderLoading(`Скачиваю проект… ${done} из ${total}`),
        signal: controller.signal
      });
      renderLoading(replace ? 'Заменяю папку…' : 'Записываю на диск…');
      // После начала записи отмена уже не нужна: запись либо завершится, либо откатится.
      const dir = await commitViaBridge(parent, name, staged.files, replace);
      renderLoading('Открываю проект…');
      busy = false;
      dlg.close();
      await window.AmazWelcome.openFolder(dir);
      const st = store.state;
      const comps = (st.scenes && st.scenes.normal && st.scenes.normal.components || st.components || []).length;
      const ok = comps === staged.info.componentCount && (st.assets || []).length === staged.info.assetCount;
      window.AmazWelcome.toast(ok
        ? `Проект «${st.meta.name}» импортирован: компонентов ${comps}, ресурсов ${(st.assets || []).length}. Папка: ${name}`
        : `Проект открыт, но данные отличаются от файла в GitHub (компонентов ${comps} из ${staged.info.componentCount}). Проверьте проект.`, ok ? 'ok' : 'warn');
    } catch (e) {
      busy = false;
      if (e && e.name === 'AbortError') { dlg.close(); return; }
      if (!dlg.open) dlg.showModal();
      renderError(e, () => renderList(data));
      // «Повторить» после ошибки вернёт к списку: проект не открыт, диск не изменён (или откатан).
      const retry = body.querySelector('#ghi-retry'); if (retry) retry.textContent = 'Назад к списку';
    } finally { busy = false; controller = null; }
  }

  btn.onclick = () => { if (!dlg.open) dlg.showModal(); load(); };
})();
