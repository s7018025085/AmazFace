// Отбор «нужных проекту» ресурсов. Всё, на что в проекте никто не ссылается (старые листы стрелок,
// исходники фонов, неиспользуемые шрифты), в публикуемые файлы не попадает: ни в GitHub-исходник,
// ни в упаковщик. В самом редакторе и в локальной папке проекта ничего не удаляется.
//
// Ресурс считается нужным, если его id встречается в проекте за пределами списков assets/fonts
// (свойства компонентов, фон, кадры анимации фона, настройки фона), а также в описании другого
// нужного ресурса (например, исходник, из которого собран PNG).
const AssetPrune = (() => {
  const dropData = (k, v) => (typeof v === 'string' && v.startsWith('data:') ? undefined : v);
  const metaOf = (item) => JSON.stringify(item, dropData);

  function usedIds(state) {
    const assets = Array.isArray(state && state.assets) ? state.assets : [];
    const fonts = Array.isArray(state && state.fonts) ? state.fonts : [];
    const rest = Object.assign({}, state);
    delete rest.assets; delete rest.fonts; delete rest.preview;
    const used = new Set();
    const all = assets.concat(fonts).filter((x) => x && x.id);
    let haystack = JSON.stringify(rest, dropData);
    let changed = true;
    while (changed) {
      changed = false;
      for (const item of all) {
        if (used.has(item.id) || !haystack.includes(item.id)) continue;
        used.add(item.id);
        haystack += metaOf(item);   // ссылки, которые лежат внутри уже нужного ресурса
        changed = true;
      }
    }
    return used;
  }

  // Копия состояния без лишних ресурсов; исходный объект не меняется.
  function pruneState(state) {
    if (!state || typeof state !== 'object') return { state, removed: [] };
    const used = usedIds(state);
    const removed = [];
    const keep = (list) => (Array.isArray(list) ? list.filter((x) => {
      if (!x || !x.id || used.has(x.id)) return true;
      removed.push({ id: x.id, name: x.name || x.filename || x.id, bytes: (x.dataUrl || '').length });
      return false;
    }) : list);
    const out = Object.assign({}, state);
    if (Array.isArray(state.assets)) out.assets = keep(state.assets);
    if (Array.isArray(state.fonts)) out.fonts = keep(state.fonts);
    return { state: out, removed };
  }

  // Для текста JSON проекта (то, что уходит на GitHub как <имя>.watchface.json).
  function pruneJsonText(text) {
    let parsed;
    try { parsed = JSON.parse(text); } catch (e) { return { text, removed: [] }; }
    const r = pruneState(parsed);
    return { text: r.removed.length ? JSON.stringify(r.state) : text, removed: r.removed };
  }

  return { usedIds, pruneState, pruneJsonText };
})();
if (typeof module !== 'undefined' && module.exports) module.exports = AssetPrune;
