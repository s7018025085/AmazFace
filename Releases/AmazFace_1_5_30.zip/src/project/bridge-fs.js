// src/project/bridge-fs.js
//
// Доступ к папкам через локальный мост (/fs/*) вместо File System Access API.
// Делает объекты, похожие на FileSystemDirectoryHandle/FileHandle (entries,
// getDirectoryHandle, getFileHandle, getFile, createWritable, removeEntry), поэтому
// FsProject, импорт из GitHub и экспорт работают без изменений. Всё реальное
// чтение/запись диска выполняет мост (bridge/fs-routes.js).

(function (root) {
  const KEY_STORAGE = 'amazface_bridge_key'; // тот же код доступа, что и для публикации на GitHub
  const LAST_STORAGE = 'amazface_last_folder';
  const base = () => (typeof ZEUS_BRIDGE === 'string' ? ZEUS_BRIDGE : 'http://127.0.0.1:17865');
  const lsGet = (k) => { try { return localStorage.getItem(k) || ''; } catch (e) { return ''; } };
  const lsSet = (k, v) => { try { localStorage.setItem(k, v); } catch (e) { /* без сохранения */ } };

  function fsError(message, name, status) {
    const e = new Error(message); e.name = name || 'Error'; e.status = status; return e;
  }

  async function request(method, route, params, body, retried) {
    const qs = params ? '?' + Object.entries(params).map(([k, v]) => `${k}=${encodeURIComponent(v)}`).join('&') : '';
    let res;
    try {
      res = await fetch(base() + route + qs, {
        method,
        headers: Object.assign({ 'X-AmazFace-Key': lsGet(KEY_STORAGE) },
          body !== undefined && !(body instanceof Uint8Array) ? { 'Content-Type': 'application/json' } : {}),
        body: body === undefined ? undefined : (body instanceof Uint8Array ? body : JSON.stringify(body))
      });
    } catch (e) {
      throw fsError('Локальный мост не отвечает. Запустите bridge/start-zeus-bridge.bat и оставьте окно открытым. Если мост запущен, проверьте в Chrome разрешение «Доступ к локальной сети» для этой страницы.', 'BridgeDown');
    }
    if (res.status === 401 && !retried) {
      const k = (root.prompt ? root.prompt('Введите код доступа к мосту (он напечатан в окне моста):', '') : '') || '';
      if (!k.trim()) throw fsError('Нужен код доступа к мосту.', 'NotAllowedError', 401);
      lsSet(KEY_STORAGE, k.trim());
      return request(method, route, params, body, true);
    }
    if (!res.ok) {
      let j = null; try { j = await res.json(); } catch (e) { /* пусто */ }
      if (res.status === 404 && j && j.code === 'route') throw fsError('Мост устарел: нет файловых маршрутов. Перезапустите bridge/start-zeus-bridge.bat из этой версии.', 'BridgeOld', 404);
      throw fsError((j && j.error) || `Ошибка моста (${res.status}).`, (j && j.code) || 'Error', res.status);
    }
    return res;
  }
  const json = async (m, r, p, b) => (await request(m, r, p, b)).json();

  class BridgeFile {
    constructor(rootId, rel, name) { this.kind = 'file'; this.rootId = rootId; this.rel = rel; this.name = name; }
    async getFile() {
      const st = await json('GET', '/fs/stat', { root: this.rootId, path: this.rel });
      if (st.kind !== 'file') throw fsError('Это не файл.', 'TypeMismatchError');
      const self = this;
      return { name: this.name, size: st.size, arrayBuffer: async () => (await request('GET', '/fs/read', { root: self.rootId, path: self.rel })).arrayBuffer() };
    }
    async createWritable() {
      const self = this; const chunks = [];
      return {
        async write(data) {
          if (typeof Blob !== 'undefined' && data instanceof Blob) data = new Uint8Array(await data.arrayBuffer());
          else if (data instanceof ArrayBuffer) data = new Uint8Array(data);
          chunks.push(typeof data === 'string' ? new TextEncoder().encode(data) : new Uint8Array(data.buffer ? data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength) : data));
        },
        async close() {
          let total = 0; for (const c of chunks) total += c.length;
          const all = new Uint8Array(total); let o = 0; for (const c of chunks) { all.set(c, o); o += c.length; }
          await request('POST', '/fs/write', { root: self.rootId, path: self.rel }, all);
        }
      };
    }
  }

  class BridgeDir {
    constructor(rootId, rel, name, info) {
      this.kind = 'directory'; this.rootId = rootId; this.rel = rel; this.name = name;
      if (info) { this.bridgePath = info.path; }
    }
    _child(name) { return this.rel ? `${this.rel}/${name}` : name; }
    async *entries() {
      const j = await json('GET', '/fs/list', { root: this.rootId, path: this.rel });
      for (const e of j.entries) {
        yield [e.name, e.kind === 'directory' ? new BridgeDir(this.rootId, this._child(e.name), e.name) : new BridgeFile(this.rootId, this._child(e.name), e.name)];
      }
    }
    async _stat(name) {
      try { return await json('GET', '/fs/stat', { root: this.rootId, path: this._child(name) }); }
      catch (e) { if (e.name === 'NotFoundError') return null; throw e; }
    }
    async getDirectoryHandle(name, opts) {
      const st = await this._stat(name);
      if (!st) {
        if (!(opts && opts.create)) throw fsError(`Не найдено: ${name}`, 'NotFoundError', 404);
        await request('POST', '/fs/mkdir', { root: this.rootId, path: this._child(name) });
      } else if (st.kind !== 'directory') throw fsError(`«${name}» — файл, а не папка.`, 'TypeMismatchError', 409);
      return new BridgeDir(this.rootId, this._child(name), name);
    }
    async getFileHandle(name, opts) {
      const st = await this._stat(name);
      if (!st && !(opts && opts.create)) throw fsError(`Не найдено: ${name}`, 'NotFoundError', 404);
      if (st && st.kind !== 'file') throw fsError(`«${name}» — папка, а не файл.`, 'TypeMismatchError', 409);
      return new BridgeFile(this.rootId, this._child(name), name); // файл создаётся при записи
    }
    async removeEntry(name, opts) {
      await request('POST', '/fs/remove', { root: this.rootId, path: this._child(name), recursive: opts && opts.recursive ? '1' : '0' });
    }
    async requestPermission() { return 'granted'; } // права выдаёт мост при выборе папки
    async queryPermission() { return 'granted'; }

    /** Вся папка одним запросом: [{path, size, bytes|null}] (bytes=null — файл крупнее maxBytes). */
    async bundle(maxBytes) {
      const buf = new Uint8Array(await (await request('GET', '/fs/bundle', { root: this.rootId, maxBytes })).arrayBuffer());
      const dv = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
      const dec = new TextDecoder(); const out = []; let o = 0;
      while (o < buf.length) {
        const pl = dv.getUint32(o, true); o += 4;
        const path = dec.decode(buf.subarray(o, o + pl)); o += pl;
        const big = buf[o]; o += 1;
        const size = dv.getUint32(o, true); o += 4;
        let bytes = null;
        if (!big) { bytes = buf.slice(o, o + size); o += size; }
        out.push({ path, size, bytes });
      }
      return out;
    }
  }

  const toHandle = (r) => new BridgeDir(r.id, '', r.name, r);

  const BridgeFs = {
    /** Диалог выбора папки на компьютере (открывает мост). Отмена → AbortError. */
    async pick(title) {
      const r = await json('POST', '/fs/pick', null, { title: title || 'Выберите папку проекта' });
      if (r.cancelled) {
        const e = new Error('Выбор папки отменён.'); e.name = 'AbortError'; e.reason = r.reason || ''; throw e;
      }
      return toHandle(r);
    },
    /** Открыть папку по пути (для «Продолжить последний» и после импорта). */
    async open(path) {
      const r = await json('POST', '/fs/open', null, { path });
      return toHandle(r);
    },
    /** Атомарно заменить/создать parent/name из parent/tmp. */
    async swap(parent, tmp, name, replace) { return toHandle(await json('POST', '/fs/swap', null, { root: parent.rootId, tmp, name, replace: !!replace })); },
    remember(handle) { if (handle && handle.bridgePath) lsSet(LAST_STORAGE, JSON.stringify({ path: handle.bridgePath, name: handle.name })); },
    last() { try { const j = JSON.parse(lsGet(LAST_STORAGE) || 'null'); return j && j.path ? j : null; } catch (e) { return null; } },
    async ping() { try { return await json('GET', '/fs/ping'); } catch (e) { return null; } }
  };
  root.BridgeFs = BridgeFs;
})(typeof window !== 'undefined' ? window : globalThis);
