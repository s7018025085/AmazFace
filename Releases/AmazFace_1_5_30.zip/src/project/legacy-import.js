// src/project/legacy-import.js
//
// Старые проекты (экспорт прежних версий Watch Face Designer) лежат в папке без
// amazface.project.json: есть только watchface/index.js, digital-displays.json и assets/.
// Здесь макет восстанавливается из сгенерированного кода: каждый виджет в index.js
// называется <сцена>_w_<порядок>_<тип>_<номер>[...], по этим именам и геометрии
// собираем компоненты. Модуль не знает о редакторе — возвращает чистые данные.
(function (root) {
  'use strict';

  const hex = (n) => '#' + (Number(n) >>> 0).toString(16).padStart(6, '0').slice(-6);

  function parseProps(body) {
    const out = {};
    const re = /(\w+):\s*("(?:[^"\\]|\\.)*"|\[[^\]]*\]|[^,}\n]+)/g;
    let m;
    while ((m = re.exec(body))) {
      let v = m[2].trim();
      if (/^"/.test(v)) { try { v = JSON.parse(v); } catch (e) { v = v.slice(1, -1); } }
      else if (/^0x[0-9a-f]+$/i.test(v)) v = { color: hex(parseInt(v, 16)) };
      else if (/^-?\d+(\.\d+)?$/.test(v)) v = Number(v);
      out[m[1]] = v;
    }
    return out;
  }
  const col = (p, d) => (p && p.color && p.color.color) || d;
  const num = (v, d) => (typeof v === 'number' && isFinite(v) ? v : d);
  const round = (v) => Math.round(num(v, 0) * 100) / 100;
  const align = (v, d) => (typeof v === 'string' ? v.replace(/^align\./, '') : d);
  const norm = (a) => ((Math.round(a) % 360) + 360) % 360;

  /**
   * @param {string} src            watchface/index.js
   * @param {Array}  digitalDisplays содержимое digital-displays.json (может быть пустым)
   * @returns {{scenes:Object}|null} scenes[name] = { background:{color,imageName,alpha}, components:[{defId,x,y,w,h,props,digitalId}] }
   */
  function parse(src, digitalDisplays) {
    if (!/createWidget\s*\(/.test(src)) return null;
    const dd = new Map();
    for (const d of Array.isArray(digitalDisplays) ? digitalDisplays : []) if (d && d.id && !dd.has(d.id)) dd.set(d.id, d);

    const scenes = {};
    const sc = (n) => scenes[n] || (scenes[n] = { background: { color: '#000000', imageName: '', alpha: 100 }, components: [], _dig: new Map(), _arcTrack: new Map() });

    const re = /const\s+(\w+)\s*=\s*createWidget\(widget\.(\w+),\s*\{([\s\S]*?)\}\s*\);|createWidget\(widget\.(TEXT_FONT),\s*\{([\s\S]*?)\}\s*\);/g;
    let m, lastOrder = 0;
    while ((m = re.exec(src))) {
      const name = m[1] || '', kind = m[2] || m[4];
      const p = parseProps(m[3] || m[5] || '');
      const sceneName = /ONLY_AOD/.test(m[0]) ? 'aod' : /ONLY_NIGHT|NIGHT/.test(m[0]) && /^night_/.test(name) ? 'night' : (name.match(/^(normal|night|aod)_/) || name.match(/^__bg\w+?_(normal|night|aod)_/) || [0, /ONLY_AOD/.test(m[0]) ? 'aod' : 'normal'])[1];
      const S = sc(sceneName);

      if (/^__bgColor_/.test(name)) { S.background.color = col(p, '#000000'); continue; }
      if (/^__bgImage_/.test(name)) { if (p.src) S.background.imageName = String(p.src).replace(/\.(png|jpe?g)$/i, '').split('/').pop(); continue; }

      const wm = name.match(/^(?:normal|night|aod)_w_(\d+)_(.+)$/);
      const order = wm ? Number(wm[1]) : (/TEXT_FONT/.test(m[0]) ? lastOrder + 0.5 : 1e6 + S.components.length);
      if (wm) lastOrder = order;
      const rest = wm ? wm[2] : '';
      const geom = { x: round(p.x), y: round(p.y), w: round(p.w), h: round(p.h) };

      if (kind === 'IMG' && /digital_display_\d+_g_\d+$/.test(rest)) {
        const id = rest.match(/(digital_display_\d+)_g_(\d+)$/)[1];
        const key = order + ':' + id;
        const g = S._dig.get(key) || { order, id, boxes: [], src: [] };
        g.boxes.push(geom); g.src.push(p.src || ''); S._dig.set(key, g);
        continue;
      }
      if (kind === 'ARC') {
        const base = rest.replace(/_track$/, '');
        if (/_track$/.test(rest)) { S._arcTrack.set(order + ':' + base, p); continue; }
        S.components.push({ order, defId: 'arc', ...geom, arcKey: order + ':' + base, raw: p, tail: src.slice(re.lastIndex, re.lastIndex + 900) });
        continue;
      }
      if (kind === 'IMG_LEVEL' && /weather_icon/.test(rest)) { S.components.push({ order, defId: 'weather_icon', ...geom, props: {} }); continue; }
      if (kind === 'TEXT_FONT' && /WEATHER_CURRENT/.test(m[0])) {
        S.components.push({ order, defId: 'weather_temp', ...geom, props: {
          text_size: num(p.text_size, 32), color: col(p, '#ffffff'), align_h: align(p.align_h, 'CENTER_H'), align_v: align(p.align_v, 'CENTER_V'), weather_temp_source: 'CURRENT' } });
        continue;
      }
      if (kind === 'TEXT') {
        const t = rest.replace(/_\d+$/, '');
        if (!/^(battery|steps|calories|heart_rate|distance|weekday|date_full|time_hm|text)$/.test(t)) continue;
        const props = { text_size: num(p.text_size, 28), color: col(p, '#ffffff'), align_h: align(p.align_h, 'CENTER_H'), align_v: align(p.align_v, 'CENTER_V') };
        if (t === 'weekday') {
          const f = src.match(new RegExp(name + '\\.setProperty\\([^)]*formatWeekday\\(now,\\s*"(\\w+)",\\s*"(\\w+)"'));
          if (f) { props.format = f[1]; props.weekday_locale = f[2]; }
        } else if (t === 'date_full') {
          const f = src.match(new RegExp(name + '\\.setProperty\\([^)]*formatDate\\(now,\\s*"([^"]+)",\\s*"(\\w+)"'));
          if (f) { props.format = f[1]; props.date_locale = f[2]; }
        } else if (t === 'battery') {
          const f = src.match(new RegExp(name + '\\.setProperty\\(prop\\.MORE,\\s*\\{ text: \\(typeof v === \'number\' \\? "([^"]*)" \\+ v \\+ "([^"]*)"'));
          if (f) props.suffix = f[2];
        }
        S.components.push({ order, defId: t === 'text' ? 'text' : t, ...geom, props });
      }
    }

    // Цифровые табло: рамка = объединение глифов, остальное — из digital-displays.json.
    for (const S of Object.values(scenes)) {
      for (const g of S._dig.values()) {
        const x0 = Math.min(...g.boxes.map((b) => b.x)), y0 = Math.min(...g.boxes.map((b) => b.y));
        const x1 = Math.max(...g.boxes.map((b) => b.x + b.w)), y1 = Math.max(...g.boxes.map((b) => b.y + b.h));
        const meta = dd.get(g.id) || {};
        const ds = meta.data_source || 'TIME';
        const gh = g.boxes[0].h, gw = g.boxes[0].w;
        const fmt = ds === 'HOUR' ? 'HH' : ds === 'MINUTE' ? 'MM' : ds === 'SECOND' ? 'SS'
          : (ds === 'TIME' || ds === 'DATE') ? (meta.format || 'HH:MM') : (g.boxes.length >= 5 ? '00000' : '0000');
        const gap0 = g.boxes.length > 1 ? Math.max(0, g.boxes[1].x - (g.boxes[0].x + g.boxes[0].w)) : 0;
        const gap = gap0;
        // Значение выводится слева направо с первого слота: для HH/MM/SS достаточно двух.
        const slots = /^(HH|MM|SS)$/.test(fmt) ? 2 : g.boxes.length;
        const bw = slots * gw + (slots - 1) * gap;
        const natH = num(meta.digit_height, 70);
        S.components.push({
          order: g.order, defId: 'digital_display', x: round(x0), y: round(y0), w: round(slots < g.boxes.length ? bw : x1 - x0), h: round(y1 - y0), digitalId: g.id, sampleSrc: g.src[0],
          props: { data_source: ds, format: fmt, separator: meta.separator != null ? meta.separator : ':', digit_width: Math.round(gw), digit_height: Math.round(gh),
            separator_width: Math.max(4, Math.round(num(meta.separator_width, 20) * gw / num(meta.digit_width, 64))), spacing: Math.round(gap),
            text_size: Math.max(4, Math.round(gh * 64 / natH)), align_h: 'CENTER_H', align_v: 'CENTER_V' }
        });
      }
      for (const c of S.components) {
        if (c.defId !== 'arc') continue;
        const p = c.raw, trk = S._arcTrack.get(c.arcKey);
        const ds = (c.tail.match(/источника\s+(\w+)/) || [])[1];
        const sa = num(p.start_angle, 0), ea = num(p.end_angle, 0);
        // На часах 0° = 3 часа, в редакторе 0° = 12 часов: S = угол редактора − 90.
        c.props = { data_source: ds || 'NONE', start_angle: norm(sa + 90), end_angle: norm(ea + 90), line_width: num(p.line_width, 8), color: col(p, '#3366ff'),
          rounded_ends: !!p.corner_flag };
        const sw = c.tail.match(/Math\.round\((-?[\d.]+)\s*\+\s*\((-?[\d.]+)\)\s*\*\s*r\)/);
        if (sw) c.props.end_angle = norm(Number(sw[1]) + Number(sw[2]) + 90);
        if (trk) { c.props.track_enabled = true; c.props.track_color = col(trk, '#2a3042'); }
        delete c.raw; delete c.tail; delete c.arcKey;
      }
      S.components.sort((a, b) => a.order - b.order);
      delete S._dig; delete S._arcTrack;
    }
    return { scenes };
  }

  root.LegacyImport = { parse };
})(typeof window !== 'undefined' ? window : globalThis);
