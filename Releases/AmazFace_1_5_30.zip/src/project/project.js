// src/project/project.js

// Профили устройств.
//
// ВАЖНО: `targetKey` и `deviceSources` — это идентификаторы конкретной модели
// из app.json, которые Zeus CLI подставляет сам при `zeus create`. Выдумывать
// их для моделей, которых мы не видели, нельзя (см. правило «не выдумывать
// Zepp API»), поэтому кроме проверенного профиля Balance 2 здесь только
// ГЕОМЕТРИЧЕСКИЕ пресеты: размер/форма заданы, а targetKey/deviceSource
// пользователь вписывает вручную из app.json своего zeus-шаблона.
// Незаполненные поля блокируют экспорт проекта ошибкой валидации.
const DEVICES = {
  amazfit_balance_2: {
    id: 'amazfit_balance_2', name: 'Amazfit Balance 2 (480×480)', w: 480, h: 480, shape: 'round',
    // Данные для сборки app.json ("targets" по документации Zepp OS SDK).
    targetKey: '480x480-amazfit-balance-2',
    deviceSources: [9568512, 9568513, 9568515],
    designWidth: 480,
  },
  round_480: {
    id: 'round_480', name: 'Круглый 480×480 — target вручную', w: 480, h: 480, shape: 'round',
    targetKey: '', deviceSources: [], designWidth: 480,
  },
  round_466: {
    id: 'round_466', name: 'Круглый 466×466 — target вручную', w: 466, h: 466, shape: 'round',
    targetKey: '', deviceSources: [], designWidth: 466,
  },
  square_390_450: {
    id: 'square_390_450', name: 'Прямоугольный 390×450 — target вручную', w: 390, h: 450, shape: 'square',
    targetKey: '', deviceSources: [], designWidth: 390,
  },
  custom: {
    id: 'custom', name: 'Другое устройство (все поля вручную)', w: 480, h: 480, shape: 'round',
    targetKey: '', deviceSources: [], designWidth: 480,
  },
};

function makeDevice(deviceId) {
  const base = DEVICES[deviceId] || DEVICES.amazfit_balance_2;
  return JSON.parse(JSON.stringify(base));
}

// App ID должен отличаться у разных циферблатов: Zeus/Zepp использует его
// как идентификатор приложения. Если каждый новый проект получает один и тот
// же ID, zeus preview воспринимает новый циферблат как обновление предыдущего.
// Для локальной разработки генерируем новый числовой ID при создании проекта.
// Перед публикацией реальный App ID из Zepp Developer Console можно указать
// вручную в «Устройство и сборка».
const PLACEHOLDER_APP_ID = 10001;
const APP_ID_MIN = 1000000;
const APP_ID_MAX = 9999999;

function generateUniqueAppId() {
  // 7 цифр — достаточно для локальных проектов и удобно для app.json.
  // Math.random + timestamp дают новый ID даже при очень быстром создании
  // нескольких проектов подряд в одной вкладке.
  const entropy = Date.now() + Math.floor(Math.random() * 0x7fffffff);
  const range = APP_ID_MAX - APP_ID_MIN + 1;
  return APP_ID_MIN + (Math.abs(entropy) % range);
}

function defaultAppMeta() {
  return { appId: generateUniqueAppId(), vendor: 'designer', versionName: '1.0.0', versionCode: 1 };
}

let uidSequence = 0;
const issuedUids = new Set();
function uid(prefix) {
  const cryptoApi = typeof globalThis !== 'undefined' ? globalThis.crypto : null;
  let id;
  do {
    const token = cryptoApi && typeof cryptoApi.randomUUID === 'function'
      ? cryptoApi.randomUUID().replace(/-/g, '')
      : `${Date.now().toString(36)}_${(++uidSequence).toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
    id = `${prefix}_${token}`;
  } while (issuedUids.has(id));
  issuedUids.add(id);
  return id;
}

function defaultProject() {
  return {
    meta: { name: 'AmazFace Watch Face', createdAt: Date.now() },
    apiLevel: '3.0',
    device: makeDevice('amazfit_balance_2'),
    app: defaultAppMeta(),
    watchSettings: { dayNightEnabled: false, dayNightStart: 22, dayNightEnd: 7 },
    background: { color: '#000000', imageAssetId: null, alpha: 100 },
    components: [],
    groups: [],
    assets: [],
    weatherIconsColor: null,
    fonts: [],
    nextIndex: {},
    preview: { dataUrl: null, width: 324, height: 324, handsTime: '10:10' },
    mode: 'normal',
    scenes: {
      aod: {
        components: [],
        background: { color: '#000000', imageAssetId: null, alpha: 100 },
        settings: {
          width: 480, height: 480, background: '#000000',
          previewMode: 'AOD', brightness: 100, showSeconds: false,
          testTime: '10:10', testDate: '18.09.2026',
          sensorValues: { battery: 85, steps: 8452, heart: 72 }
        }
      }
    }
  };
}

class ProjectStore {
  constructor() {
    this.state = defaultProject();
    this.history = [];
    this.future = [];
    this.selection = new Set();
    this.listeners = new Set();
    this._pushHistory(true);
    this._emitScheduled = false;
    this._emitFrame = null;
  }

  subscribe(fn) {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  _emit() {
    if (this._emitScheduled) return;
    this._emitScheduled = true;
    this._emitFrame = requestAnimationFrame(() => {
      for (const l of this.listeners) l(this.state, this.selection);
      this._emitScheduled = false;
    });
  }

  _snapshot() {
    // Ассеты (PNG/JPEG в виде base64 dataURL) намеренно НЕ попадают в снапшот
    // истории: иначе каждый шаг undo хранил бы полную копию всех картинок, и
    // при десятке изображений история из 100 шагов съедала бы сотни мегабайт.
    // Плата за это — добавление/удаление ресурса не откатывается через undo
    // (управляется отдельно в панели «Ресурсы»).
    const { assets, fonts, ...rest } = this.state;
    return JSON.stringify({ state: rest, selection: [...this.selection] });
  }

  // Восстанавливает состояние из снапшота, подставляя АКТУАЛЬНЫЙ список
  // ресурсов (он вне истории, см. _snapshot).
  _restore(snapshotJson) {
    const snap = JSON.parse(snapshotJson);
    const assets = this.state.assets || [];
    const fonts = this.state.fonts || [];
    this.state = Object.assign({}, snap.state, { assets, fonts });
    this.selection = new Set(snap.selection);
    this._emit();
  }

  _pushHistory(initial = false) {
    if (!initial) this.future = [];
    this.history.push(this._snapshot());
    if (this.history.length > 100) this.history.shift();
  }

  commit() {
    this._saveActiveScene();
    this._pushHistory();
    this._emit();
  }

  undo() {
    if (this.history.length <= 1) return;
    this.future.push(this.history.pop());
    this._restore(this.history[this.history.length - 1]);
  }

  redo() {
    if (this.future.length === 0) return;
    const snap = this.future.pop();
    this.history.push(this._snapshot());
    this._restore(snap);
  }

  // ---- components ----
  addComponent(defId, x = 100, y = 100) {
    const def = REGISTRY[defId];
    if (!def) return null;
    const idx = (this.state.nextIndex[defId] || 0) + 1;
    this.state.nextIndex[defId] = idx;
    const id = `${defId}_${String(idx).padStart(3, '0')}`;
    const props = {};
    for (const p of def.properties) {
      if (p.default !== undefined) props[p.key] = p.default;
    }
    // Крупные компоненты (циферблат 480×480) сразу встают по центру экрана, а не со смещением от клика.
    if (def.centerOnAdd && this.state.device) {
      x = Math.round((this.state.device.w - def.defaultSize.w) / 2);
      y = Math.round((this.state.device.h - def.defaultSize.h) / 2);
    }
    const comp = {
      id,
      defId,
      name: def.name,
      x, y,
      w: def.defaultSize.w,
      h: def.defaultSize.h,
      visible: true,
      locked: false,
      props,
    };
    this._syncGaugeFrame(comp);
    this.state.components.push(comp);
    this.selection = new Set([id]);
    this.commit();
    return comp;
  }

  removeComponents(ids) {
    this.state.components = this.state.components.filter((c) => !ids.includes(c.id));
    for (const id of ids) this.selection.delete(id);
    this.commit();
  }

  addTapZone(parentId, zone = {}) {
    const c = this.state.components.find((x) => x.id === parentId);
    if (!c) return null;
    c.tapZones = Array.isArray(c.tapZones) ? c.tapZones : [];
    const n = c.tapZones.length + 1;
    const id = zone.id || `tap_${String(n).padStart(3, '0')}`;
    const z = Object.assign({
      id, name: `Тап-зона ${n}`,
      x: 0, y: 0,
      w: Math.max(20, Number(c.w) || 40),
      h: Math.max(20, Number(c.h) || 40),
      visible: true, locked: false,
      props: { tap_action: 'NONE', tap_metric: 'STATUS', tap_app_id: 0, tap_app_url: 'pages/index', tap_flash_bright: true }
    }, zone);
    z.props = Object.assign({ tap_action: 'NONE', tap_metric: 'STATUS', tap_app_id: 0, tap_app_url: 'pages/index', tap_flash_bright: true }, zone.props || {});
    c.tapZones.push(z);
    this.selection = new Set([`tapzone:${parentId}:${id}`]);
    this.commit();
    return z;
  }

  updateTapZone(parentId, zoneId, patch, opts = {}) {
    const c = this.state.components.find((x) => x.id === parentId);
    const z = c?.tapZones?.find((x) => x.id === zoneId);
    if (!z) return;
    // ВАЖНО: props нужно объединять ДО Object.assign(z, patch). Иначе patch.props
    // целиком подменяет z.props и остальные поля (tap_metric, tap_app_id…)
    // теряются — выбранный системный экран «сбрасывался» при смене действия.
    const { props: propsPatch, ...rest } = patch;
    Object.assign(z, rest);
    if (propsPatch) z.props = Object.assign({}, z.props || {}, propsPatch);
    if (!opts.silent) this.commit(); else this._emit();
  }

  removeTapZone(parentId, zoneId) {
    const c = this.state.components.find((x) => x.id === parentId);
    if (!c || !Array.isArray(c.tapZones)) return;
    c.tapZones = c.tapZones.filter((z) => z.id !== zoneId);
    this.selection.delete(`tapzone:${parentId}:${zoneId}`);
    this.commit();
  }

  getTapZoneSelection(id) {
    const m = String(id || '').match(/^tapzone:([^:]+):(.+)$/);
    if (!m) return null;
    const parent = this.state.components.find((c) => c.id === m[1]);
    const zone = parent?.tapZones?.find((z) => z.id === m[2]);
    return parent && zone ? { parent, zone } : null;
  }

  // ---- containers (groups) ----
  // Контейнер — папка в панели слоёв: { id, name, collapsed }. Принадлежность
  // компонента хранится в поле component.group (id контейнера). Контейнеры
  // живут внутри сцены (День / Ночь / AOD), как и сами компоненты.
  // Пока это только организация проекта в редакторе: на экспорт и на
  // внешний вид циферблата контейнеры не влияют.
  _groupsUsedBy(comps, groups) {
    const used = new Set((comps || []).map((c) => c && c.group).filter(Boolean));
    return JSON.parse(JSON.stringify((groups || []).filter((g) => used.has(g.id))));
  }

  getGroup(id) {
    return (this.state.groups || []).find((g) => g.id === id) || null;
  }

  // Компоненты контейнера в порядке массива (снизу вверх по z-order).
  getGroupMembers(id) {
    return (this.state.components || []).filter((c) => c.group === id);
  }

  _nextGroupName() {
    const names = new Set((this.state.groups || []).map((g) => g.name));
    let n = (this.state.groups || []).length + 1;
    while (names.has(`Контейнер ${n}`)) n++;
    return `Контейнер ${n}`;
  }

  // Создаёт контейнер. Если передан список id компонентов (по умолчанию —
  // текущее выделение), они сразу попадают в новый контейнер.
  addGroup(name, componentIds) {
    this.state.groups = Array.isArray(this.state.groups) ? this.state.groups : [];
    const used = new Set(this.state.groups.map((g) => g.id));
    let id;
    do { id = uid('group'); } while (used.has(id));
    const group = { id, name: String(name || '').trim() || this._nextGroupName(), collapsed: false };
    this.state.groups.push(group);
    const ids = Array.isArray(componentIds)
      ? componentIds
      : [...this.selection].filter((x) => this.state.components.some((c) => c.id === x));
    for (const c of this.state.components) {
      if (ids.includes(c.id)) c.group = id;
    }
    this.commit();
    return group;
  }

  renameGroup(id, name) {
    const g = this.getGroup(id);
    const clean = String(name || '').trim();
    if (!g || !clean || clean === g.name) return false;
    g.name = clean;
    this.commit();
    return true;
  }

  // Флаг «скрыта при запуске»: на часах участники контейнера стартуют невидимыми.
  setGroupStartHidden(id, hidden) {
    const g = this.getGroup(id);
    if (!g) return false;
    const next = !!hidden;
    if (!!g.startHidden === next) return false;
    if (next) g.startHidden = true; else delete g.startHidden;
    this.commit();
    return true;
  }

  toggleGroupCollapsed(id) {
    const g = this.getGroup(id);
    if (!g) return;
    g.collapsed = !g.collapsed;
    this.commit();
  }

  // Удаляет контейнер, но не компоненты: они остаются на циферблате
  // и просто выходят из папки.
  removeGroup(id) {
    if (!this.getGroup(id)) return false;
    this.state.groups = this.state.groups.filter((g) => g.id !== id);
    for (const c of this.state.components) {
      if (c.group === id) delete c.group;
    }
    this.commit();
    return true;
  }

  // Переносит компоненты в контейнер; groupId = null выводит из контейнера.
  setComponentsGroup(ids, groupId) {
    if (groupId && !this.getGroup(groupId)) return false;
    let changed = false;
    for (const c of this.state.components) {
      if (!ids.includes(c.id)) continue;
      if (groupId) { if (c.group !== groupId) { c.group = groupId; changed = true; } }
      else if (c.group) { delete c.group; changed = true; }
    }
    if (changed) this.commit();
    return changed;
  }

  duplicateComponents(ids) {
    const newIds = [];
    for (const id of ids) {
      const c = this.state.components.find((x) => x.id === id);
      if (!c) continue;
      const idx = (this.state.nextIndex[c.defId] || 0) + 1;
      this.state.nextIndex[c.defId] = idx;
      const newId = `${c.defId}_${String(idx).padStart(3, '0')}`;
      const copy = JSON.parse(JSON.stringify(c));
      copy.id = newId;
      copy.x += 20;
      copy.y += 20;
      this.state.components.push(copy);
      newIds.push(newId);
    }
    this.selection = new Set(newIds);
    this.commit();
  }

  updateComponent(id, patch, opts = {}) {
    const c = this.state.components.find((x) => x.id === id);
    if (!c) return;
    Object.assign(c, patch);
    if (!opts.silent) this.commit(); else this._emit();
  }

  updateComponentProp(id, key, value, opts = {}) {
    const c = this.state.components.find((x) => x.id === id);
    if (!c) return;
    const prev = c.props[key];
    c.props[key] = value;
    this._gaugePropChanged(c, key, prev);
    // Больший шрифт — больше рамка (иначе надпись обрезается на часах); см. text-box-grow.js
    if (key === 'text_size' && typeof TextBoxGrow !== 'undefined') TextBoxGrow.onTextSizeChanged(c, prev, this.state);
    if (!opts.silent) this.commit(); else this._emit();
  }

  // «Стрелочный датчик»: рамка в редакторе = PNG стрелки, положенный так, чтобы его точка опоры
  // совпала с осью на экране (левый верх = центр − опора). Размер рамки = размер PNG.
  _isGauge(comp) {
    const def = comp && REGISTRY[comp.defId];
    return !!def && def.widgetId === 'GAUGE_NEEDLE';
  }

  _syncGaugeFrame(comp) {
    if (!this._isGauge(comp)) return;
    const p = comp.props || {};
    if (p.center_x == null || p.pos_x == null) return;
    comp.x = Math.round(Number(p.center_x) - Number(p.pos_x));
    comp.y = Math.round(Number(p.center_y ?? 0) - Number(p.pos_y ?? 0));
  }

  _gaugePropChanged(comp, key, prev) {
    if (!this._isGauge(comp)) return;
    if (key === 'path' && comp.props.path && comp.props.path !== prev) {
      // Выбрана новая картинка: рамка берёт её размер, а точка опоры встаёт в центр картинки
      // (ось на экране остаётся там, где стояла) — дальше опору можно поправить вручную.
      const a = (this.state.assets || []).find((x) => x.id === comp.props.path);
      const w = a && Math.round(Number(a.width)), h = a && Math.round(Number(a.height));
      if (w > 0 && h > 0) {
        comp.w = w; comp.h = h;
        comp.props.pos_x = Math.round(w / 2);
        comp.props.pos_y = Math.round(h / 2);
      }
    }
    if (['path', 'center_x', 'center_y', 'pos_x', 'pos_y'].includes(key)) this._syncGaugeFrame(comp);
  }

  // Единицы панели слоёв сверху вниз — ровно в том порядке, в каком их рисует LayersPanel:
  // обычный компонент или контейнер целиком (контейнер стоит на месте своего верхнего компонента).
  // Пустые контейнеры z-порядка не имеют и в список не попадают.
  getLayerUnits() {
    const comps = this.state.components || [];
    const known = new Set((this.state.groups || []).map((g) => g.id));
    const units = [];
    const seen = new Set();
    for (let i = comps.length - 1; i >= 0; i--) {
      const c = comps[i];
      if (c.group && known.has(c.group)) {
        if (seen.has(c.group)) continue;
        seen.add(c.group);
        units.push({ type: 'group', id: c.group, comps: comps.filter((m) => m.group === c.group) });
      } else units.push({ type: 'comp', id: c.id, comps: [c] });
    }
    return units;
  }

  // Можно ли сдвинуть слой/контейнер на шаг: dir = 'up' | 'down'. Нужно для неактивных стрелок в панели.
  canStepLayer(id, dir) {
    const c = (this.state.components || []).find((x) => x.id === id);
    if (!c) return false;
    if (c.group && this.getGroup(c.group)) {
      const members = this.getGroupMembers(c.group);
      const k = members.indexOf(c);
      return !!members[dir === 'up' ? k + 1 : k - 1];
    }
    return this._canStepUnit('comp', id, dir);
  }

  canStepGroup(gid, dir) { return this._canStepUnit('group', gid, dir); }

  _canStepUnit(type, id, dir) {
    const units = this.getLayerUnits();
    const k = units.findIndex((u) => u.type === type && u.id === id);
    if (k < 0) return false;
    return !!units[dir === 'up' ? k - 1 : k + 1];
  }

  // Шаг на один слой вверх/вниз так, как это видно в панели. Обычный компонент перешагивает соседний
  // компонент или контейнер целиком (внутрь контейнера не заходит); компонент внутри контейнера
  // двигается среди его участников и из контейнера не выходит (для этого — перетаскивание).
  stepLayer(id, dir) {
    if (dir !== 'up' && dir !== 'down') return false;
    const arr = this.state.components;
    const c = arr.find((x) => x.id === id);
    if (!c) return false;
    if (c.group && this.getGroup(c.group)) {
      const members = this.getGroupMembers(c.group);
      const k = members.indexOf(c);
      const nb = members[dir === 'up' ? k + 1 : k - 1];
      if (!nb) return false;
      const i = arr.indexOf(c), j = arr.indexOf(nb);
      arr.splice(i, 1);
      arr.splice(j, 0, c);
      this.commit();
      return true;
    }
    return this._stepUnit('comp', id, dir);
  }

  // Контейнер двигается целиком: его компоненты собираются в один блок и переставляются
  // выше/ниже соседнего компонента или контейнера.
  stepGroup(gid, dir) {
    if (dir !== 'up' && dir !== 'down') return false;
    return this._stepUnit('group', gid, dir);
  }

  _stepUnit(type, id, dir) {
    const units = this.getLayerUnits();
    const k = units.findIndex((u) => u.type === type && u.id === id);
    const neighbor = k < 0 ? null : units[dir === 'up' ? k - 1 : k + 1];
    if (!neighbor) return false;
    const arr = this.state.components;
    const mine = new Set(units[k].comps);
    const rest = arr.filter((c) => !mine.has(c));
    const idx = neighbor.comps.map((c) => rest.indexOf(c));
    // Вверх — сразу над самым верхним компонентом соседа, вниз — сразу под самым нижним.
    const at = dir === 'up' ? Math.max(...idx) + 1 : Math.min(...idx);
    rest.splice(at, 0, ...units[k].comps);
    arr.splice(0, arr.length, ...rest);
    this.commit();
    return true;
  }

  moveLayer(id, direction) {
    if (direction === 'up' || direction === 'down') { this.stepLayer(id, direction); return; }
    const arr = this.state.components;
    const i = arr.findIndex((c) => c.id === id);
    if (i < 0) return;
    let j;
    if (direction === 'up') j = i + 1;
    else if (direction === 'down') j = i - 1;
    else if (direction === 'top') j = arr.length - 1;
    else if (direction === 'bottom') j = 0;
    if (j < 0 || j >= arr.length) return;
    const [item] = arr.splice(i, 1);
    arr.splice(j, 0, item);
    this.commit();
  }

  setSelection(ids) {
    this.selection = new Set(ids);
    this._emit();
  }

  // ---- Day / Night / AOD scenes ----
  _sceneSnapshot() {
    return {
      components: JSON.parse(JSON.stringify(this.state.components || [])),
      groups: JSON.parse(JSON.stringify(this.state.groups || [])),
      background: JSON.parse(JSON.stringify(this.state.background || {})),
      nextIndex: JSON.parse(JSON.stringify(this.state.nextIndex || {}))
    };
  }

  _saveActiveScene() {
    this.state.scenes = this.state.scenes || {};
    const sceneName = this.state.mode === 'aod' ? 'aod' : this.state.mode === 'night' ? 'night' : 'normal';
    const scene = Object.assign({}, this.state.scenes[sceneName] || {}, this._sceneSnapshot());
    if (sceneName === 'aod') scene.settings = Object.assign({}, scene.settings || {});
    this.state.scenes[sceneName] = scene;
  }

  switchScene(mode) {
    mode = mode === 'aod' || mode === 'night' ? mode : 'normal';
    if (mode === this.state.mode) return;
    this._saveActiveScene();
    const scenes = this.state.scenes || {};
    if (mode === 'night' && !scenes.night) {
      const day = scenes.normal || this._sceneSnapshot();
      scenes.night = JSON.parse(JSON.stringify(day));
      this.state.scenes = scenes;
      this.state.watchSettings = Object.assign({}, this.state.watchSettings || {}, { dayNightEnabled: true });
    }
    const scene = scenes[mode] || { components: [], groups: [], background: { color: '#000000', imageAssetId: null, alpha: 100 }, nextIndex: {} };
    this.state.components = JSON.parse(JSON.stringify(scene.components || []));
    this.state.groups = JSON.parse(JSON.stringify(scene.groups || []));
    this.state.background = Object.assign({ color: '#000000', imageAssetId: null, alpha: 100 }, scene.background || {});
    this.state.nextIndex = JSON.parse(JSON.stringify(scene.nextIndex || {}));
    if (mode === 'aod' && !Object.keys(scene.nextIndex || {}).length) {
      for (const c of this.state.components) {
        const n = Number(String(c.id || '').split('_').pop());
        if (c.defId && Number.isFinite(n)) this.state.nextIndex[c.defId] = Math.max(this.state.nextIndex[c.defId] || 0, n);
      }
    }
    this.state.mode = mode;
    this.selection = new Set();
    this.commit();
  }

  duplicateDayToNight() {
    // Capture any in-progress edits first, then copy the saved Day scene by value
    // so the new Night scene can be changed independently.
    this._saveActiveScene();
    const day = this.state.scenes?.normal;
    if (!day) return 0;
    const night = JSON.parse(JSON.stringify(day));
    this.state.scenes.night = night;
    this.state.watchSettings = Object.assign({}, this.state.watchSettings || {}, { dayNightEnabled: true });
    this.state.components = JSON.parse(JSON.stringify(night.components || []));
    this.state.groups = JSON.parse(JSON.stringify(night.groups || []));
    this.state.background = Object.assign({ color: '#000000', imageAssetId: null, alpha: 100 }, night.background || {});
    this.state.nextIndex = JSON.parse(JSON.stringify(night.nextIndex || {}));
    this.state.mode = 'night';
    this.selection = new Set(this.state.components.map((component) => component.id));
    this.commit();
    return this.state.components.length;
  }

  getAodSettings() {
    this.state.scenes = this.state.scenes || {};
    this.state.scenes.aod = this.state.scenes.aod || {};
    this.state.scenes.aod.settings = Object.assign({
      width: this.state.device?.w || 480, height: this.state.device?.h || 480,
      background: '#000000', previewMode: 'AOD', brightness: 100,
      showSeconds: false, testTime: '10:10', testDate: '18.09.2026',
      sensorValues: { battery: 85, steps: 8452, heart: 72 }
    }, this.state.scenes.aod.settings || {});
    return this.state.scenes.aod.settings;
  }

  updateAodSettings(patch) {
    const settings = this.getAodSettings();
    this.state.scenes.aod.settings = Object.assign({}, settings, patch);
    if (patch.background) {
      this.state.background.color = patch.background;
    }
    this.commit();
  }

  createAodFromNormal(options = {}) {
    // Always take the source from the actual Normal scene. If the user is
    // currently in Normal, first capture the live editor state. This avoids
    // copying a stale/empty scenes.normal from older projects.
    if (this.state.mode === 'normal') this._saveActiveScene();

    const normal = (this.state.scenes && this.state.scenes.normal) || {
      components: [],
      background: { color: '#000000', imageAssetId: null, alpha: 100 },
      nextIndex: {}
    };

    let comps = JSON.parse(JSON.stringify(normal.components || []));
    if (typeof options.filter === 'function') comps = comps.filter(options.filter);

    // AOD receives its own component objects. IDs may remain the same because
    // the scenes are independent; subsequent edits therefore cannot mutate
    // Normal by reference.
    this.state.scenes = this.state.scenes || {};
    this.state.scenes.aod = this.state.scenes.aod || {};
    this.state.scenes.aod.components = comps;
    this.state.scenes.aod.groups = this._groupsUsedBy(comps, normal.groups);
    this.state.scenes.aod.background = { color: '#000000', imageAssetId: null, alpha: 100 };
    this.state.scenes.aod.nextIndex = JSON.parse(JSON.stringify(normal.nextIndex || {}));

    // Load the newly created AOD scene into the live editor.
    this.state.components = JSON.parse(JSON.stringify(comps));
    this.state.groups = JSON.parse(JSON.stringify(this.state.scenes.aod.groups));
    this.state.background = JSON.parse(JSON.stringify(this.state.scenes.aod.background));
    this.state.nextIndex = JSON.parse(JSON.stringify(this.state.scenes.aod.nextIndex));
    this.state.mode = 'aod';
    this.selection = new Set(comps.map(c => c.id));
    this.commit();
    return comps.length;
  }

  toggleAodComponentFromNormal(componentId) {
    if (this.state.mode !== 'aod') return false;
    const normal = this.state.scenes?.normal?.components || [];
    const source = normal.find((c) => c && c.id === componentId);
    if (!source) return false;

    const existingIndex = this.state.components.findIndex((c) => c && c.id === componentId);
    if (existingIndex >= 0) {
      this.state.components.splice(existingIndex, 1);
      this.selection.delete(componentId);
      this.commit();
      return false;
    }
    if (source.defId === 'time_pointer_second') return false;

    // AOD gets an independent copy. Later edits in this scene must not mutate Normal.
    const copy = JSON.parse(JSON.stringify(source));
    if (copy.group) {
      const known = (this.state.groups || []).some((g) => g.id === copy.group);
      const srcGroup = (this.state.scenes?.normal?.groups || []).find((g) => g.id === copy.group);
      if (!known && srcGroup) this.state.groups = [...(this.state.groups || []), JSON.parse(JSON.stringify(srcGroup))];
      else if (!known) delete copy.group;
    }
    this.state.components.push(copy);
    this.state.nextIndex = this.state.nextIndex || {};
    const suffix = Number(String(copy.id || '').split('_').pop());
    if (copy.defId && Number.isFinite(suffix)) {
      this.state.nextIndex[copy.defId] = Math.max(this.state.nextIndex[copy.defId] || 0, suffix);
    }
    this.selection = new Set([componentId]);
    this.commit();
    return true;
  }

  clearAod() {
    this._saveActiveScene();
    this.state.scenes.aod = Object.assign({}, this.state.scenes.aod || {}, {
      components: [], groups: [], background: { color: '#000000', imageAssetId: null, alpha: 100 }, nextIndex: {}
    });
    if (this.state.mode === 'aod') {
      this.state.components = [];
      this.state.groups = [];
      this.state.background = { color: '#000000', imageAssetId: null, alpha: 100 };
      this.state.nextIndex = {};
      this.selection = new Set();
    }
    this.commit();
  }

  // ---- device & app metadata ----
  setDevice(deviceId) {
    this.state.device = makeDevice(deviceId);
    this.commit();
  }

  updateDevice(patch) {
    Object.assign(this.state.device, patch);
    // designWidth по умолчанию совпадает с шириной экрана (см. app.json targets).
    if (patch.w !== undefined && !patch.designWidth) this.state.device.designWidth = patch.w;
    this.commit();
  }

  updateApp(patch) {
    this.state.app = Object.assign({}, defaultAppMeta(), this.state.app, patch);
    this.commit();
  }

  updateWatchSettings(patch) {
    this.state.watchSettings = Object.assign({}, this.state.watchSettings || {}, patch);
    this.commit();
  }

  // ---- assets ----
  addAsset(asset) {
    this.state.assets.push(asset);
    this.commit();
    this._refreshShadows();
  }

  // Предпросмотр стрелок с тенью: в проекте лежит чистая картинка + параметры
  // тени (asset.shadow), а PNG с тенью строится в runtime-кэш и при экспорте.
  // То же для фона циферблата (asset.bg): исходник + параметры редактора, PNG 480×480 — в кэше.
  _refreshShadows() {
    const jobs = [];
    if (typeof AssetShadow !== 'undefined') jobs.push(AssetShadow.refreshAll(this.state.assets));
    if (typeof AssetBg !== 'undefined') jobs.push(AssetBg.refreshAll(this.state.assets));
    if (!jobs.length) return;
    Promise.all(jobs).then((r) => { if (r.some(Boolean)) this._emit(); }).catch(() => {});
  }

  // Заменяет содержимое существующего ресурса (id и имя сохраняются),
  // поэтому все компоненты, ссылающиеся на него, подхватят новую картинку.
  replaceAsset(id, patch) {
    const a = this.state.assets.find((x) => x.id === id);
    if (!a) return null;
    Object.assign(a, patch, { id: a.id, name: a.name });
    this.commit();
    this._refreshShadows();
    return a;
  }

  removeAsset(id) {
    this.state.assets = this.state.assets.filter((a) => a.id !== id);
    this.commit();
  }

  renameAsset(id, name) {
    const a = this.state.assets.find((x) => x.id === id);
    if (a) { a.name = name; this.commit(); }
  }

  // ---- fonts ----
  addFont(font) {
    this.state.fonts = this.state.fonts || [];
    this.state.fonts.push(font);
    this.commit();
    return font;
  }

  removeFont(id) {
    this.state.fonts = (this.state.fonts || []).filter((f) => f.id !== id);
    for (const c of this.state.components) {
      if (c.props && c.props.font === id) delete c.props.font;
    }
    this.commit();
  }

  renameFont(id, name) {
    const f = (this.state.fonts || []).find((x) => x.id === id);
    if (f) { f.name = name; this.commit(); }
  }

  // ---- project io ----
  toJSON() {
    this._saveActiveScene();
    return JSON.stringify(this.state, null, 2);
  }

  loadFromJSON(json) {
    const parsed = JSON.parse(json);
    this.state = migrateProject(parsed);
    // Открытие сохранённого проекта всегда начинается с Дня.
    // Ночь и AOD остаются в отдельных сценах проекта.
    this.state.mode = 'normal';
    const normal = this.state.scenes?.normal;
    if (normal) {
      this.state.components = JSON.parse(JSON.stringify(normal.components || []));
      this.state.groups = JSON.parse(JSON.stringify(normal.groups || []));
      this.state.background = Object.assign({ color: '#000000', imageAssetId: null, alpha: 100 }, normal.background || {});
      this.state.nextIndex = JSON.parse(JSON.stringify(normal.nextIndex || {}));
    }
    this.selection = new Set();
    this.history = [];
    this.future = [];
    this._pushHistory(true);
    for (const font of this.state.fonts || []) {
      // Старые проекты могут хранить OTF/WOFF — часы Zepp OS такие шрифты не показывают.
      // Приводим к TTF на месте (ссылки на font.id не меняются), затем регистрируем для предпросмотра.
      const ready = (typeof FontConverter !== 'undefined')
        ? FontConverter.convertFontRecord(font).catch((e) => { console.warn('Не удалось привести шрифт к TTF:', font && font.name, e); return false; })
        : Promise.resolve(false);
      ready.then((changed) => {
        if (typeof registerProjectFont === 'function') registerProjectFont(font);
        if (changed) { console.info('Шрифт переведён в TTF:', font.name); this._emit(); }
      });
    }
    this._emit();
    this._refreshShadows();
  }

  newProject() {
    this.state = defaultProject();
    this.selection = new Set();
    this.history = [];
    this.future = [];
    this._pushHistory(true);
    this._emit();
  }
}

// Подмешивает отсутствующие поля в проект, сохранённый более старой версией
// Designer: новые секции состояния и новые свойства компонентов (например,
// «ход секундной стрелки») получают значения по умолчанию из реестра,
// вместо того чтобы стать undefined и уронить рендер/экспорт.
function migrateProject(parsed) {
  const base = defaultProject();
  const state = Object.assign({}, base, parsed);
  state.meta = Object.assign({}, base.meta, parsed.meta || {});
  state.background = Object.assign({}, base.background, parsed.background || {});
  state.device = Object.assign({}, base.device, parsed.device || {});
  state.app = Object.assign({}, base.app, parsed.app || {});
  state.watchSettings = Object.assign({}, base.watchSettings, parsed.watchSettings || {});
  delete state.watchSettings.hourlyVibration;
  state.assets = Array.isArray(parsed.assets) ? parsed.assets : [];
  // Weather icons are addressed by condition id, not by asset id. Older
  // versions used a 900-value random asset id, so a weather icon could share
  // an id with the selected dial background; the preview's asset map then
  // resolved the background to the icon. Give colliding weather assets new
  // ids while preserving ids used by regular assets and background links.
  const regularAssetIds = new Set(state.assets.filter((a) => a && !a.weatherIcon && a.id).map((a) => a.id));
  const seenWeatherAssetIds = new Set();
  for (const asset of state.assets) {
    if (!asset || !asset.weatherIcon || !asset.id) continue;
    if (!regularAssetIds.has(asset.id) && !seenWeatherAssetIds.has(asset.id)) {
      seenWeatherAssetIds.add(asset.id);
      continue;
    }
    let id;
    do { id = uid('asset'); } while (regularAssetIds.has(id) || seenWeatherAssetIds.has(id));
    asset.id = id;
    seenWeatherAssetIds.add(id);
  }
  // ВАЖНО: сохраняем пользовательские шрифты при миграции старого проекта.
  // Раньше migrateProject() оставлял fonts из defaultProject() (пустой массив),
  // из-за чего ссылки font_XXX становились «сиротами» после открытия проекта.
  state.fonts = Array.isArray(parsed.fonts) ? parsed.fonts : [];
  state.nextIndex = parsed.nextIndex || {};
  // Контейнеры (группы слоёв). В старых проектах их нет — тогда пустой список.
  // Ссылка component.group на несуществующий контейнер снимается ниже.
  const cleanGroups = (list) => (Array.isArray(list) ? list : [])
    .filter((g) => g && typeof g.id === 'string' && g.id)
    .map((g) => ({ id: g.id, name: String(g.name || 'Контейнер'), collapsed: !!g.collapsed, ...(g.startHidden === true ? { startHidden: true } : {}) }));
  // Старые версии Designer могли сохранять `preview` как готовую строку
  // (а не как объект {dataUrl, width, height, handsTime}). Такой проект
  // должен открываться нормально: старое превью можно безопасно пересоздать.
  if (parsed.preview && typeof parsed.preview === 'object' && !Array.isArray(parsed.preview)) {
    state.preview = Object.assign({}, base.preview, parsed.preview);
  } else {
    state.preview = Object.assign({}, base.preview);
  }
  state.mode = parsed.mode === 'aod' || parsed.mode === 'night' ? parsed.mode : 'normal';
  state.scenes = parsed.scenes && typeof parsed.scenes === 'object' ? parsed.scenes : {};
  state.scenes.aod = Object.assign({
    components: [], background: { color: '#000000', imageAssetId: null, alpha: 100 },
    settings: { width: state.device.w, height: state.device.h, background: '#000000', previewMode: 'AOD', brightness: 100, showSeconds: false, testTime: '10:10', testDate: '18.09.2026', sensorValues: { battery: 85, steps: 8452, heart: 72 } }
  }, state.scenes.aod || {});
  state.groups = cleanGroups(parsed.groups);
  state.scenes.normal = state.scenes.normal || {
    components: JSON.parse(JSON.stringify(parsed.components || [])),
    background: Object.assign({}, base.background, parsed.background || {}),
    nextIndex: JSON.parse(JSON.stringify(parsed.nextIndex || {}))
  };
  if (state.mode === 'night' && !state.scenes.night) {
    state.scenes.night = JSON.parse(JSON.stringify(state.scenes.normal));
  }

  // IMPORTANT: normalize the Normal-scene component list as well.
  // Older projects may not have `scenes.normal`, or may have it in the old
  // component format without the new independent `tapZones` objects.
  // If we migrate only `state.components` and then restore from
  // `scenes.normal`, the migrated tap action is silently lost on open.
  const migrateComponent = (c) => {
    const def = REGISTRY[c.defId];
    if (!def) return c;
    const props = Object.assign({}, c.props);
    for (const p of def.properties) {
      if (p.default !== undefined && props[p.key] === undefined) props[p.key] = p.default;
    }
    const migrated = Object.assign({ visible: true, locked: false }, c, { props });
    // New model: tap areas are independent child objects. Preserve projects
    // created before this model by converting the old component-level tap action
    // into one child zone occupying the old component hit box.
    let zones = Array.isArray(migrated.tapZones) ? migrated.tapZones.map((z, i) => {
      const props = Object.assign({}, z.props || {});
      // Older saved projects may contain tap_metric/tap_app_* without the
      // newer explicit tap_action field. Infer the action so those zones
      // continue to export as real runtime BUTTON widgets.
      if (!props.tap_action) {
        if (props.tap_app_id || props.tap_app_url) props.tap_action = 'APP';
        else if (props.tap_metric) props.tap_action = 'METRIC';
        else props.tap_action = 'NONE';
      }
      return Object.assign({
        id: `tap_${String(i + 1).padStart(3, '0')}`,
        name: `Тап-зона ${i + 1}`, x: 0, y: 0, w: Number(migrated.w) || 40, h: Number(migrated.h) || 40,
        visible: true, locked: false, props
      }, z, { props });
    }) : [];
    if (!zones.length && migrated.defId !== 'tap_zone' && migrated.props && migrated.props.tap_action && migrated.props.tap_action !== 'NONE') {
      zones.push({
        id: 'tap_001', name: 'Тап-зона 1', x: 0, y: 0,
        w: Number(migrated.w) || 40, h: Number(migrated.h) || 40,
        visible: true, locked: false,
        props: {
          tap_action: migrated.props.tap_action,
          tap_metric: migrated.props.tap_metric || 'STATUS',
          tap_app_id: migrated.props.tap_app_id || 0,
          tap_app_url: migrated.props.tap_app_url || 'pages/index'
        }
      });
    }
    migrated.tapZones = zones;
    return migrated;
  };
  state.components = (parsed.components || []).map(migrateComponent);
  for (const sceneName of ['normal', 'night', 'aod']) {
    const scene = state.scenes[sceneName];
    if (scene && Array.isArray(scene.components)) scene.components = scene.components.map(migrateComponent);
  }
  // Контейнеры каждой сцены + снятие «висячих» ссылок на удалённые контейнеры.
  const fixGroups = (comps, groups) => {
    const ids = new Set(groups.map((g) => g.id));
    for (const c of comps || []) { if (c && c.group && !ids.has(c.group)) delete c.group; }
  };
  for (const sceneName of ['normal', 'night', 'aod']) {
    const scene = state.scenes[sceneName];
    if (!scene) continue;
    scene.groups = cleanGroups(scene.groups);
    fixGroups(scene.components, scene.groups);
  }
  // Живой список — это контейнеры активной сцены (как и components).
  const liveScene = state.mode === 'aod' ? state.scenes.aod : state.mode === 'night' ? state.scenes.night : state.scenes.normal;
  if (!(parsed.scenes && parsed.scenes[state.mode] && Array.isArray(parsed.scenes[state.mode].groups))) {
    // Проект без сохранённых контейнеров в сцене: берём верхнеуровневый список.
    liveScene.groups = JSON.parse(JSON.stringify(state.groups));
  }
  state.groups = JSON.parse(JSON.stringify(liveScene.groups));
  fixGroups(state.components, state.groups);

  // Keep the scene that was active at save time synchronized with the migrated
  // component model. `components` represents AOD when parsed.mode === 'aod';
  // always copying it into Normal would overwrite the independent Normal scene
  // when a project is reopened from AOD.
  const activeScene = state.mode === 'aod' ? state.scenes.aod : state.mode === 'night' ? state.scenes.night : state.scenes.normal;
  activeScene.components = JSON.parse(JSON.stringify(state.components));
  activeScene.groups = JSON.parse(JSON.stringify(state.groups));
  activeScene.nextIndex = JSON.parse(JSON.stringify(state.nextIndex || {}));

  return state;
}

function makeAssetId() {
  const assets = typeof store !== 'undefined' && store.state ? store.state.assets : [];
  const used = new Set((assets || []).map((a) => a && a.id).filter(Boolean));
  let id;
  do { id = uid('asset'); } while (used.has(id));
  return id;
}

function makeFontId() {
  const fonts = typeof store !== 'undefined' && store.state ? store.state.fonts : [];
  const used = new Set((fonts || []).map((f) => f && f.id).filter(Boolean));
  let id;
  do { id = uid('font'); } while (used.has(id));
  return id;
}

async function registerProjectFont(font) {
  if (!font || !font.dataUrl || !('FontFace' in window)) return;
  try {
    const face = new FontFace(font.cssFamily || font.name, `url(${font.dataUrl})`);
    await face.load();
    document.fonts.add(face);
    return face;
  } catch (e) { console.warn('Не удалось загрузить шрифт в предпросмотр:', e); }
}
