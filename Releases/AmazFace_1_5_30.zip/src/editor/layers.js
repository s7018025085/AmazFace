// src/editor/layers.js
function layerEsc(v) {
  return String(v == null ? '' : v).replace(/[&<>"']/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
}

class LayersPanel {
  constructor(root, store) {
    this.root = root;
    this.store = store;
  }

  render() {
    const comps = [...this.store.state.components].reverse();
    const bg = this.store.state.background || {};
    const rows = [];
    rows.push(`
      <div class="layer-row layer-background ${this.store.selection.has('__background__') ? 'active' : ''}" data-id="__background__">
        <span class="layer-drag">▰</span><span class="layer-name">🎨 Фон</span><span class="layer-id">BACKGROUND</span>
        <button class="layer-btn" data-act="visible" title="Показать/скрыть фон">${Number(bg.alpha ?? 100) > 0 ? '👁' : '🚫'}</button>
        <button class="layer-btn" data-act="lock" title="Фон всегда закреплён">🔒</button>
      </div>`);
    const groups = this.store.state.groups || [];
    const groupById = new Map(groups.map((g) => [g.id, g]));
    const componentRows = (c, inGroup) => {
      const out = [];
      const active = this.store.selection.has(c.id);
      out.push(`
        <div class="layer-row layer-component ${inGroup ? 'layer-in-group' : ''} ${active ? 'active' : ''}" data-id="${c.id}">
          <span class="layer-drag">☰</span><span class="layer-name">${layerEsc(c.name)}</span><span class="layer-id">${c.id}</span>
          <button class="layer-btn layer-move" data-act="up" title="Выше на один слой" ${this.store.canStepLayer(c.id, 'up') ? '' : 'disabled'}>▲</button>
          <button class="layer-btn layer-move" data-act="down" title="Ниже на один слой" ${this.store.canStepLayer(c.id, 'down') ? '' : 'disabled'}>▼</button>
          <button class="layer-btn" data-act="visible" title="Показать/скрыть">${c.visible === false ? '🚫' : '👁'}</button>
          <button class="layer-btn" data-act="lock" title="Заблокировать">${c.locked ? '🔒' : '🔓'}</button>
          <button class="layer-btn" data-act="dup" title="Дублировать">⎘</button>
          <button class="layer-btn" data-act="del" title="Удалить">🗑</button>
        </div>`);
      for (const z of (c.tapZones || [])) {
        const zid = `tapzone:${c.id}:${z.id}`;
        out.push(`
          <div class="layer-row layer-child layer-tap-zone ${inGroup ? 'layer-in-group' : ''} ${this.store.selection.has(zid) ? 'active' : ''}" data-id="${zid}" data-parent-id="${c.id}" data-zone-id="${z.id}">
            <span class="layer-drag">↳</span><span class="layer-name">🎯 ${layerEsc(z.name || z.id)}</span><span class="layer-id">TAP</span>
            <button class="layer-btn" data-act="visible" title="Показать/скрыть">${z.visible === false ? '🚫' : '👁'}</button>
            <button class="layer-btn" data-act="lock" title="Заблокировать">${z.locked ? '🔒' : '🔓'}</button>
            <button class="layer-btn" data-act="del" title="Удалить">🗑</button>
          </div>`);
      }
      return out;
    };
    const groupRow = (g, members) => {
      const selected = members.length > 0 && members.every((m) => this.store.selection.has(m.id));
      return `
        <div class="layer-row layer-group ${selected ? 'active' : ''}" data-id="group:${g.id}" data-group-id="${g.id}">
          <button class="layer-btn layer-fold" data-act="fold" title="${g.collapsed ? 'Развернуть' : 'Свернуть'}">${g.collapsed ? '▸' : '▾'}</button>
          <span class="layer-name" title="Двойной клик — переименовать">📁 ${layerEsc(g.name)}</span><span class="layer-id">${members.length}</span>
          <button class="layer-btn layer-move" data-act="up" title="Контейнер выше на один слой (целиком)" ${this.store.canStepGroup(g.id, 'up') ? '' : 'disabled'}>▲</button>
          <button class="layer-btn layer-move" data-act="down" title="Контейнер ниже на один слой (целиком)" ${this.store.canStepGroup(g.id, 'down') ? '' : 'disabled'}>▼</button>
          <button class="layer-btn" data-act="starthidden" title="${g.startHidden ? 'Скрыта на часах при запуске (нажмите, чтобы показывать)' : 'Показана на часах при запуске (нажмите, чтобы скрывать)'}">${g.startHidden ? '🚫' : '👁'}</button>
          <button class="layer-btn" data-act="ungroup" title="Удалить контейнер (компоненты останутся)">🗑</button>
        </div>`;
    };

    // Папка стоит в списке на месте своего верхнего компонента, а её участники
    // собираются под ней. Порядок слоёв (z-order) при этом не меняется.
    // Пустые контейнеры показываются сверху.
    const emitted = new Set();
    for (const g of groups) {
      if (this.store.getGroupMembers(g.id).length) continue;
      rows.push(groupRow(g, []));
      emitted.add(g.id);
    }
    for (const c of comps) {
      const g = c.group ? groupById.get(c.group) : null;
      if (!g) { rows.push(...componentRows(c, false)); continue; }
      if (emitted.has(g.id)) continue;
      emitted.add(g.id);
      const members = comps.filter((m) => m.group === g.id);
      rows.push(groupRow(g, members));
      if (!g.collapsed) for (const m of members) rows.push(...componentRows(m, true));
    }
    this.root.innerHTML = rows.join('');

    this.root.querySelectorAll('.layer-row').forEach((row) => {
      const id = row.dataset.id;
      row.addEventListener('click', (e) => {
        if (e.target.closest('.layer-btn')) return;
        if (row.classList.contains('layer-group')) return;
        if (e.shiftKey) {
          const sel = new Set(this.store.selection);
          sel.has(id) ? sel.delete(id) : sel.add(id);
          this.store.setSelection([...sel]);
        } else this.store.setSelection([id]);
      });

      if (row.classList.contains('layer-group')) {
        const gid = row.dataset.groupId;
        row.addEventListener('click', (e) => {
          if (e.target.closest('.layer-btn') || e.target.closest('.layer-rename')) return;
          // Клик по папке выделяет все её компоненты.
          this.store.setSelection(this.store.getGroupMembers(gid).map((m) => m.id));
        }, true);
        row.querySelector('[data-act="up"]').onclick = (e) => { e.stopPropagation(); this.store.stepGroup(gid, 'up'); };
        row.querySelector('[data-act="down"]').onclick = (e) => { e.stopPropagation(); this.store.stepGroup(gid, 'down'); };
        row.querySelector('[data-act="fold"]').onclick = (e) => { e.stopPropagation(); this.store.toggleGroupCollapsed(gid); };
        row.querySelector('[data-act="starthidden"]').onclick = (e) => { e.stopPropagation(); const g = this.store.getGroup(gid); this.store.setGroupStartHidden(gid, !(g && g.startHidden)); };
        row.querySelector('[data-act="ungroup"]').onclick = (e) => { e.stopPropagation(); this.store.removeGroup(gid); };
        row.querySelector('.layer-name').addEventListener('dblclick', (e) => { e.stopPropagation(); this._startRename(row, gid); });
        return;
      }

      if (id === '__background__') {
        row.querySelector('[data-act="visible"]').onclick = () => {
          const current = Number(this.store.state.background?.alpha ?? 100);
          this.store.state.background.alpha = current > 0 ? 0 : 100;
          this.store.commit();
        };
        row.querySelector('[data-act="lock"]').onclick = (e) => e.stopPropagation();
        return;
      }

      if (row.classList.contains('layer-tap-zone')) {
        const parentId = row.dataset.parentId, zoneId = row.dataset.zoneId;
        row.querySelector('[data-act="visible"]').onclick = () => {
          const s = this.store.getTapZoneSelection(id);
          if (s) this.store.updateTapZone(parentId, zoneId, { visible: s.zone.visible === false });
        };
        row.querySelector('[data-act="lock"]').onclick = () => {
          const s = this.store.getTapZoneSelection(id);
          if (s) this.store.updateTapZone(parentId, zoneId, { locked: !s.zone.locked });
        };
        row.querySelector('[data-act="del"]').onclick = () => this.store.removeTapZone(parentId, zoneId);
        return;
      }

      row.querySelector('[data-act="up"]').onclick = () => this.store.stepLayer(id, 'up');
      row.querySelector('[data-act="down"]').onclick = () => this.store.stepLayer(id, 'down');
      row.querySelector('[data-act="visible"]').onclick = () => {
        const c = this.store.state.components.find((x) => x.id === id);
        if (c) this.store.updateComponent(id, { visible: c.visible === false });
      };
      row.querySelector('[data-act="lock"]').onclick = () => {
        const c = this.store.state.components.find((x) => x.id === id);
        if (c) this.store.updateComponent(id, { locked: !c.locked });
      };
      row.querySelector('[data-act="dup"]').onclick = () => this.store.duplicateComponents([id]);
      row.querySelector('[data-act="del"]').onclick = () => confirmRemoveComponents(this.store, [id]);
    });

    // Перетаскивание. Компонент на компонент: меняет порядок и принимает
    // контейнер цели (так компонент попадает в папку или выходит из неё).
    // Компонент на папку: переносит в эту папку. Тап-зоны всегда остаются
    // под своим родителем и из иерархии не выходят.
    let draggedId = null;
    this.root.querySelectorAll('.layer-component').forEach((row) => {
      row.draggable = true;
      row.addEventListener('dragstart', () => { draggedId = row.dataset.id; });
      row.addEventListener('dragover', (e) => e.preventDefault());
      row.addEventListener('drop', (e) => {
        e.preventDefault();
        const targetId = row.dataset.id;
        if (!draggedId || draggedId === targetId) return;
        const arr = this.store.state.components;
        const from = arr.findIndex((c) => c.id === draggedId);
        const to = arr.findIndex((c) => c.id === targetId);
        if (from < 0 || to < 0) return;
        const targetGroup = arr[to].group;
        const [item] = arr.splice(from, 1);
        arr.splice(to, 0, item);
        if (targetGroup) item.group = targetGroup; else delete item.group;
        this.store.commit();
      });
    });
    this.root.querySelectorAll('.layer-group').forEach((row) => {
      row.addEventListener('dragover', (e) => e.preventDefault());
      row.addEventListener('drop', (e) => {
        e.preventDefault();
        if (!draggedId) return;
        const moving = this.store.selection.has(draggedId) ? [...this.store.selection] : [draggedId];
        this.store.setComponentsGroup(moving, row.dataset.groupId);
      });
    });
    // Корень списка: бросить компонент на пустое место = вынуть из контейнера.
    this.root.ondragover = (e) => e.preventDefault();
    this.root.ondrop = (e) => {
      if (e.target !== this.root || !draggedId) return;
      e.preventDefault();
      this.store.setComponentsGroup([draggedId], null);
    };
  }

  _startRename(row, gid) {
    const g = this.store.getGroup(gid);
    const nameEl = row.querySelector('.layer-name');
    if (!g || !nameEl) return;
    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'layer-rename';
    input.value = g.name;
    input.maxLength = 60;
    nameEl.replaceWith(input);
    input.focus();
    input.select();
    let done = false;
    const finish = (save) => {
      if (done) return;
      done = true;
      if (save && this.store.renameGroup(gid, input.value)) return; // commit перерисует панель
      this.render();
    };
    input.addEventListener('click', (e) => e.stopPropagation());
    input.addEventListener('keydown', (e) => {
      e.stopPropagation();
      if (e.key === 'Enter') finish(true);
      else if (e.key === 'Escape') finish(false);
    });
    input.addEventListener('blur', () => finish(true));
  }
}
