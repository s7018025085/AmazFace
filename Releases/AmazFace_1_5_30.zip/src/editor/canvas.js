// src/editor/canvas.js

const GRID = 10;

function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }

const WEEKDAYS_SHORT = { EN: ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'], RU: ['ВС', 'ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ'] };
const WEEKDAYS_RU_3 = ['ВОС', 'ПОН', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ'];
const WEEKDAYS_FULL = { EN: ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'], RU: ['ВОСКРЕСЕНЬЕ', 'ПОНЕДЕЛЬНИК', 'ВТОРНИК', 'СРЕДА', 'ЧЕТВЕРГ', 'ПЯТНИЦА', 'СУББОТА'] };
const MONTHS_SHORT = { EN: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'], RU: ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'] };
const MONTHS_FULL = { EN: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'], RU: ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'] };
const pad2 = (n) => String(n).padStart(2, '0');
const loc = (v) => (v === 'RU' ? 'RU' : 'EN');

// Реальное текущее время используется, чтобы предпросмотр в редакторе как можно
// точнее соответствовал тому, что покажет симулятор/устройство (там всегда
// живые данные, а не фиксированный "12:45"), а не только совпадал по размеру.
//
// ВАЖНО: названа НЕ getEffectiveDataSource — та функция уже объявлена глобально
// в src/components/registry.js с другой сигнатурой (возвращает null, когда
// источник не выбран, и учитывает def.dataBindable). Так как все скрипты этого
// проекта грузятся как classic <script> в одном общем global scope, одинаковое
// имя функции в двух файлах привело бы к тому, что второй загруженный файл
// молча подменяет первый для ВСЕХ вызывающих (в т.ч. inspector.js, который
// ожидает null и рендерит из-за этого буквально "NONE" вместо плейсхолдера).
// Здесь нужна собственная, более "мягкая" версия (всегда возвращает строку,
// в т.ч. 'NONE'), поэтому она выделена под отдельным именем.
function getCanvasPreviewDataSource(comp, def) {
  // Универсальный компонент «Текст» выбирает источник в props.data_source.
  // У специализированных текстовых пресетов источник зафиксирован в def.dataSource.
  if (def && def.dataSource) return def.dataSource;
  return comp?.props?.data_source || 'NONE';
}

// now — необязательная дата: по умолчанию реальное время; рендерер передаёт фиксированную
// (18.09.2026, 10:09:36), чтобы форматы даты/времени применялись и в статичном предпросмотре.
function componentPreviewText(comp, def, nowOverride) {
  if (def.widgetId !== 'TEXT' && def.widgetId !== 'DIGITAL_DISPLAY') return null;
  const source = getCanvasPreviewDataSource(comp, def);
  // Если выбран реальный источник данных, он всегда имеет приоритет над
  // сохранённым текстом. Иначе дефолтное значение «Привет» у TEXT блокировало
  // бы предпросмотр времени/даты/датчиков.
  if (source === 'NONE' || !source) return comp.props?.text ?? '';
  const now = nowOverride || new Date();
  if (def.widgetId === 'DIGITAL_DISPLAY') {
    const fmt = String(comp.props?.format || 'HH:MM');
    const sep = comp.props?.separator ?? ':';
    if (source === 'TIME') {
      const h24 = now.getHours(), h12 = ((h24 + 11) % 12) + 1;
      const h = fmt.startsWith('hh') ? h12 : h24;
      let out = pad2(h);
      if (fmt.includes('MM')) out += sep + pad2(now.getMinutes());
      if (fmt.includes('SS')) out += sep + pad2(now.getSeconds());
      return out;
    }
    if (source === 'DATE') {
      const dd = pad2(now.getDate());
      const mm = pad2(now.getMonth() + 1);
      const yyyy = String(now.getFullYear());
      // Формат даты определяет не только порядок частей, но и стандартный
      // разделитель. Не используем ':' из настройки времени для даты.
      // Пользовательский разделитель применяется, только если он явно выбран
      // как один из поддерживаемых для даты символов.
      const dateSep = (sep === '.' || sep === '/' || sep === ' ') ? sep : '.';
      // Форматы дня недели доступны и при источнике «Дата» в цифровом табло.
      // Язык дня недели независим от языка названий месяцев.
      if (fmt === 'EEE' || fmt === 'EEE3' || fmt === 'EEEE') {
        const weekdayLoc = loc(comp.props?.weekday_locale || comp.props?.date_locale);
        const wi = now.getDay();
        if (weekdayLoc === 'RU' && fmt === 'EEE3') return WEEKDAYS_RU_3[wi];
        return (fmt === 'EEEE' ? WEEKDAYS_FULL : WEEKDAYS_SHORT)[weekdayLoc][wi];
      }
      if (fmt === 'DD') return dd;
      if (fmt === 'MM') return mm;
      if (fmt === 'YYYY') return yyyy;
      if (fmt === 'DD.MM') return dd + dateSep + mm;
      if (fmt === 'YYYY-MM-DD') return yyyy + '-' + mm + '-' + dd;
      if (fmt === 'DD/MM') return dd + '/' + mm;
      if (fmt === 'DD.MM.YYYY') return dd + '.' + mm + '.' + yyyy;
      if (fmt === 'DD MMM') return `${dd} ${MONTHS_SHORT[loc(comp.props?.date_locale)][now.getMonth()]}`;
      if (fmt === 'MMM DD') return `${MONTHS_SHORT[loc(comp.props?.date_locale)][now.getMonth()]} ${dd}`;
      if (fmt === 'DD MMMM') return `${dd} ${MONTHS_FULL[loc(comp.props?.date_locale)][now.getMonth()]}`;
      return dd + dateSep + mm + dateSep + yyyy;
    }
    if (source === 'HOUR') {
      const h24 = now.getHours();
      const hour = fmt.startsWith('hh') ? ((h24 + 11) % 12) + 1 : h24;
      return pad2(hour);
    }
    if (source === 'MINUTE') return pad2(now.getMinutes());
    if (source === 'SECOND') return pad2(now.getSeconds());
    if (source === 'DAY') return pad2(now.getDate());
    if (source === 'MONTH') return pad2(now.getMonth()+1);
    if (source === 'YEAR') return String(now.getFullYear());
    if (source === 'BATTERY') return '82';
    if (source === 'STEP') return '8452';
    if (source === 'HEART') return '72';
    if (source === 'CALORIE') return '340';
    if (source === 'DISTANCE') return '4.2';
    if (source === 'ALTITUDE') return '185';
    if (source === 'AIR_PRESSURE') return comp.props?.pressure_unit === 'mmHg' ? '760' : '1013';
  }
  if (source === 'TIME') {
    // Универсальный «Текст» задаёт формат через time_format, а готовые
    // пресеты времени — через format. Не привязываем секунды только к ID
    // пресета time_hms: иначе TEXT + TIME + HH:MM:SS показывал бы HH:MM.
    const isPreset = def.id !== 'text';
    const fmt = String(isPreset ? (comp.props.format || 'HH:MM') : (comp.props.time_format || 'HH:MM'));
    const sep = isPreset ? ':' : String(comp.props.time_separator ?? ':');
    const h24 = now.getHours();
    const h12 = ((h24 + 11) % 12) + 1;
    const hour = fmt.startsWith('hh') ? h12 : h24;
    const leadingZero = isPreset || comp.props.time_leading_zero !== false;
    let out = leadingZero ? pad2(hour) : String(hour);
    if (fmt.includes('MM')) out += sep + pad2(now.getMinutes());
    if (fmt.includes('SS')) out += sep + pad2(now.getSeconds());
    return out;
  }
  if (source === 'AMPM') {
    const value = now.getHours() < 12 ? 'AM' : 'PM';
    return comp.props.ampm_case === 'am/pm' ? value.toLowerCase() : value;
  }
  if (source === 'DATE') {
    const dateLoc = loc(comp.props.date_locale);
    const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = now.getFullYear();
    const mmm = MONTHS_SHORT[dateLoc][now.getMonth()], mmmm = MONTHS_FULL[dateLoc][now.getMonth()];
    // Универсальный «Текст» хранит формат в date_format, готовые пресеты — в format.
    const dateFmt = def.id === 'text' ? (comp.props.date_format || 'DD.MM.YYYY') : comp.props.format;
    switch (dateFmt) {
      case 'DD': return dd;
      case 'MM': return mm;
      case 'YYYY': return String(yyyy);
      case 'DD.MM': return `${dd}.${mm}`;
      case 'DD MMM': return `${dd} ${mmm}`;
      case 'MMM DD': return `${mmm} ${dd}`;
      case 'DD/MM': return `${dd}/${mm}`;
      case 'YYYY-MM-DD': return `${yyyy}-${mm}-${dd}`;
      case 'DD MMMM': return `${dd} ${mmmm}`;
      default: return `${dd}.${mm}.${yyyy}`;
    }
  }
  if (source === 'WEEKDAY') {
    const weekdayLoc = loc(comp.props.weekday_locale);
    const wdFmt = def.id === 'text' ? (comp.props.weekday_format || 'EEE') : comp.props.format;
    if (weekdayLoc === 'RU' && wdFmt === 'EEE3') return WEEKDAYS_RU_3[now.getDay()];
    return (wdFmt === 'EEEE' ? WEEKDAYS_FULL : WEEKDAYS_SHORT)[weekdayLoc][now.getDay()];
  }
  if (source === 'HOUR') {
    const h24 = (((now.getHours() + (Math.round(Number(comp.props.time_offset)) || 0)) % 24) + 24) % 24;
    const h12 = ((h24 + 11) % 12) + 1;
    const use12h = (comp.props.hour_format || 'HH') === 'hh';
    const h = use12h ? h12 : h24;
    return comp.props.hour_leading_zero === false ? String(h) : pad2(h);
  }
  if (source === 'MINUTE') {
    const m = (((now.getMinutes() + (Math.round(Number(comp.props.time_offset)) || 0)) % 60) + 60) % 60;
    return comp.props.minute_leading_zero === false ? String(m) : pad2(m);
  }
  if (source === 'SECOND') {
    const s = (((now.getSeconds() + (Math.round(Number(comp.props.time_offset)) || 0)) % 60) + 60) % 60;
    return comp.props.second_leading_zero === false ? String(s) : pad2(s);
  }
  if (source === 'DAY') {
    const d = now.getDate();
    return comp.props.day_leading_zero === false ? String(d) : pad2(d);
  }
  if (source === 'MONTH') {
    const mIdx = now.getMonth();
    const fmt = comp.props.month_format || 'MM';
    const monthLoc = loc(comp.props.month_locale);
    if (fmt === 'M') return String(mIdx + 1);
    if (fmt === 'MMM') return MONTHS_SHORT[monthLoc][mIdx];
    if (fmt === 'MMMM') return MONTHS_FULL[monthLoc][mIdx];
    return pad2(mIdx + 1);
  }
  if (source === 'YEAR') {
    const y = now.getFullYear();
    return (comp.props.year_format === 'YY') ? String(y).slice(-2) : String(y);
  }
  // Датчики: префикс/суффикс/знаки считает общая sensorPreviewText (registry.js) — те же правила, что в экспорте.
  const sensorTxt = sensorPreviewText(source, comp.props, def);
  if (sensorTxt !== null) return sensorTxt;
  // Нативные данные: единица (мин, %, ч…) зависит от галочки «Показывать единицу», как unit_type в экспорте.
  const nativeTxt = nativePreviewText(source, comp.props);
  if (nativeTxt !== null) return nativeTxt;
  if (source === 'WEATHER_TEMP') return (({ LOW: '17', HIGH: '26' })[comp.props.weather_temp_source] || '24') + ((comp.props.weather_show_degree !== false) ? '°' : '');   // как на часах: без буквы C/F
  return def.name;
}

// Источники данных, которые в предпросмотре редактора должны «идти» сами
// (обновляются посекундным тиком без полной перерисовки сцены).
const LIVE_PREVIEW_SOURCES = new Set(['TIME', 'AMPM', 'DATE', 'WEEKDAY', 'HOUR', 'MINUTE', 'SECOND', 'DAY', 'MONTH', 'YEAR']);

class CanvasEditor {
  constructor(root, store) {
    this.root = root;
    this.store = store;
    this.zoom = 1;
    this.pan = { x: 0, y: 0 };
    this.snapGrid = true;
    this.showGrid = true;
    this.showTapZones = true;
    this.drag = null;

    this.root.innerHTML = `
      <div class="canvas-viewport">
        <div class="test-hands-toolbar">
          <button class="test-hands-btn" data-act="test-hands" title="Ускоренно прокрутить стрелки, чтобы проверить часовую, минутную и секундную">▶ Стрелки</button>
          <select class="test-speed-select" title="Скорость перемотки при проверке стрелок">
            <option value="1">1× реальное время</option>
            <option value="60">60× (мин. круг за 60 с)</option>
            <option value="360">360× (мин. круг за 10 с)</option>
            <option value="720" selected>720× (мин. круг за 5 с)</option>
            <option value="3600">3600× (час. круг за 12 с)</option>
            <option value="43200">43200× (час. круг за 1 с)</option>
          </select>
        </div>
        <div class="canvas-stage">
          <div class="device-frame"></div>
          <div class="guide guide-h"></div>
          <div class="guide guide-v"></div>
        </div>
      </div>
    `;
    this.viewport = this.root.querySelector('.canvas-viewport');
    this.stage = this.root.querySelector('.canvas-stage');
    this.frame = this.root.querySelector('.device-frame');
    this.guideH = this.root.querySelector('.guide-h');
    this.guideV = this.root.querySelector('.guide-v');
    this.testBtn = this.root.querySelector('.test-hands-btn');
    // Панель проверки стрелок переезжает в тонкую полосу над циферблатом,
    // чтобы не перекрывать сам циферблат.
    this.testToolbar = this.root.querySelector('.test-hands-toolbar');
    const strip = document.getElementById('canvas-strip');
    if (strip && this.testToolbar) strip.appendChild(this.testToolbar);

    // Сетка — отдельный полупрозрачный слой ПОВЕРХ растрового превью.
    // Раньше она рисовалась фоном device-frame, а поверх лежал непрозрачный
    // canvas с превью — поэтому сетка не была видна.
    this.gridOverlay = document.createElement('div');
    this.gridOverlay.className = 'grid-overlay';
    this.frame.appendChild(this.gridOverlay);
    this.testSpeedSelect = (this.testToolbar || this.root).querySelector('.test-speed-select');
    this.testSpeed = Number(this.testSpeedSelect.value) || 720;
    this.testBtn.onclick = () => this._toggleHandTest();
    this.testSpeedSelect.onchange = () => this._changeTestSpeed(Number(this.testSpeedSelect.value) || 720);

    // Слой тестовых стрелок: постоянные DOM-узлы поверх device-frame, которые
    // используются ТОЛЬКО во время ускоренной проверки (см. _toggleHandTest).
    // Позиционируются в 1:1 device-пикселях напрямую по center_x/center_y и
    // pos_x/pos_y (точка опоры "в изображении") и реальному размеру
    // ресурса — то есть так же, как настоящий TIME_POINTER-виджет на
    // устройстве, а не по произвольному прямоугольнику x/y/w/h редактора.
    this.testHour = document.createElement('div');
    this.testMinute = document.createElement('div');
    this.testSecond = document.createElement('div');
    for (const el of [this.testHour, this.testMinute, this.testSecond]) {
      el.className = 'test-hand';
      this.frame.appendChild(el);
    }

    this._bindToolbar();
    this._bindPan();
    this._bindKeys();
    this.testMode = false;
    // «Живое время»: текст со временем/датой и аналоговые стрелки идут по часам компьютера.
    this.liveTime = false;
    this._testRafId = null;
    this.aodBrightness = null;
    this._renderToken = 0;
    this._arcAnimOverrides = null;    // кадр предпросмотра анимации дуги (не сохраняется)
    this._textAnimOverrides = null;   // кадр предпросмотра анимации текста (не сохраняется в проект)
    this._bgFrameId = null;           // кадр предпросмотра анимации фона (не сохраняется в проект)
    window.addEventListener('arc-anim-preview', (e) => this._playArcPreview(e.detail && e.detail.id));
  }

  // Перерисовать только растровый слой (например, после пересчёта кадра при перетаскивании анимации мышью).
  redrawPreview() {
    const state = this.store.state;
    const cv = this.frame.querySelector('.shared-preview-canvas');
    if (!cv) return;
    const token = ++this._renderToken;
    WatchfacePreviewRenderer.draw(state, cv, { size: state.device.w, testMode: this.testMode && !this.liveTime && state.mode !== 'aod', previewMode: state.mode === 'aod', liveTime: this.liveTime && state.mode !== 'aod', testDate: (this.testMode && state.mode !== 'aod') ? this._testDate : null, renderToken: token, textAnim: this._textAnimOverrides, arcAnim: this._arcAnimOverrides, bgFrameId: this._bgFrameId, validateToken: () => token === this._renderToken }).catch(console.warn);
  }

  // Кадр предпросмотра покадровой анимации фона (assetId | null). В проект не пишется.
  // Перерисовывается только растровый слой, DOM-узлы редактора не пересоздаются.
  setBgFrameOverride(assetId) {
    const id = assetId || null;
    if (id === this._bgFrameId) return;
    this._bgFrameId = id;
    const state = this.store.state;
    const cv = this.frame.querySelector('.shared-preview-canvas');
    if (!cv) return;
    const token = ++this._renderToken;
    WatchfacePreviewRenderer.draw(state, cv, { size: state.device.w, testMode: this.testMode && !this.liveTime && state.mode !== 'aod', previewMode: state.mode === 'aod', liveTime: this.liveTime && state.mode !== 'aod', testDate: (this.testMode && state.mode !== 'aod') ? this._testDate : null, renderToken: token, textAnim: this._textAnimOverrides, arcAnim: this._arcAnimOverrides, bgFrameId: this._bgFrameId, validateToken: () => token === this._renderToken }).catch(console.warn);
  }

  // Предпросмотр анимации текста: подменяет кадр выбранного текста и перерисовывает
  // только растровый слой (DOM-узлы и выделение не пересоздаются).
  setTextAnimOverrides(map) {
    this._textAnimOverrides = map && Object.keys(map).length ? map : null;
    const state = this.store.state;
    const cv = this.frame.querySelector('.shared-preview-canvas');
    if (!cv) return;
    const w = state.device.w;
    const token = ++this._renderToken;
    WatchfacePreviewRenderer.draw(state, cv, { size: w, testMode: this.testMode && !this.liveTime && state.mode !== 'aod', previewMode: state.mode === 'aod', liveTime: this.liveTime && state.mode !== 'aod', testDate: (this.testMode && state.mode !== 'aod') ? this._testDate : null, renderToken: token, textAnim: this._textAnimOverrides, arcAnim: this._arcAnimOverrides, bgFrameId: this._bgFrameId, validateToken: () => token === this._renderToken }).catch(console.warn);
  }

  _toggleHandTest() {
    this.testMode = !this.testMode;
    this.testBtn.textContent = this.testMode ? '⏸ Стоп' : '▶ Стрелки';
    this.testBtn.classList.toggle('active', this.testMode);

    if (this.testMode) {
      // Скорость перемотки задаётся выбором в .test-speed-select (по
      // умолчанию 720× — минутная стрелка делает полный круг примерно за
      // 5 секунд, часовая — примерно за минуту). Несколько предустановок
      // позволяют проверить и быстрое "долистывание" суток целиком (43200×),
      // и почти естественный, неспешный ход стрелок (1×/60×) — удобно
      // заметить рывки/дрожание при плавном ходе секундной стрелки.
      this._testStartPerf = performance.now();
      this._testStartDate = new Date();
      this._testDate = this._testStartDate;
      const loop = () => {
        if (!this.testMode) return;
        const elapsedRealSec = (performance.now() - this._testStartPerf) / 1000;
        const simDate = new Date(this._testStartDate.getTime() + elapsedRealSec * this.testSpeed * 1000);
        try { this._updateTestHands(simDate); }
        catch (err) { console.error('Ошибка проверки вращения стрелок:', err); }
        this._testRafId = requestAnimationFrame(loop);
      };
      this._testRafId = requestAnimationFrame(loop);
    } else {
      if (this._testRafId) cancelAnimationFrame(this._testRafId);
      this._testRafId = null;
      this._testDate = null;
      for (const el of [this.testHour, this.testMinute, this.testSecond]) el.style.display = 'none';
    }
    this.render();
  }

  // Смена скорости во время работающей проверки: пересчитываем точку отсчёта
  // так, чтобы симулированное время осталось непрерывным (иначе стрелки
  // дёрнутся скачком в момент переключения скорости в выпадающем списке).
  _changeTestSpeed(newSpeed) {
    if (this.testMode && this._testStartPerf != null) {
      const elapsedRealSec = (performance.now() - this._testStartPerf) / 1000;
      const simDate = new Date(this._testStartDate.getTime() + elapsedRealSec * this.testSpeed * 1000);
      this._testStartDate = simDate;
      this._testStartPerf = performance.now();
    }
    this.testSpeed = newSpeed;
  }

  // Стрелки проверки рисуются тем же растровым рендером, что и обычный холст, —
  // строго на своём месте в порядке слоёв (раньше это были DOM-элементы поверх
  // всего холста, из-за чего стрелки игнорировали слои и дублировали «живое время»).
  _updateTestHands(virtualDate) {
    this._testDate = virtualDate;
    if (this._testBusy) return;   // не копим кадры: рисуем следующий, когда закончился предыдущий
    this._testBusy = true;
    Promise.resolve(this._redrawRaster()).finally(() => { this._testBusy = false; });
  }

  _bindToolbar() {
    // Use header toolbar elements from document
    const zoomInBtn = document.getElementById('zoom-in');
    const zoomOutBtn = document.getElementById('zoom-out');
    const zoomSelect = document.getElementById('zoom-select');
    const gridToggle = document.getElementById('grid-toggle');
    const snapToggle = document.getElementById('snap-toggle');
    const tapZoneToggle = document.getElementById('tap-zone-toggle');
    
    if (zoomInBtn) zoomInBtn.onclick = () => this.setZoom(this.zoom + 0.25);
    if (zoomOutBtn) zoomOutBtn.onclick = () => this.setZoom(this.zoom - 0.25);
    if (zoomSelect) {
      zoomSelect.onchange = () => this.setZoom(Number(zoomSelect.value) / 100);
      this._zoomSelect = zoomSelect;
    }
    if (gridToggle) gridToggle.onchange = (e) => { this.showGrid = e.target.checked; this._applyGrid(); };
    if (snapToggle) snapToggle.onchange = (e) => { this.snapGrid = e.target.checked; this._hideGuides(); };
    if (tapZoneToggle) tapZoneToggle.onchange = (e) => { this.showTapZones = e.target.checked; this.render(this.store.state); };
  }

  _bindPan() {
    let panning = false, start = null;
    this.viewport.addEventListener('mousedown', (e) => {
      if (e.target === this.viewport || e.target === this.stage) {
        this.store.setSelection([]);
      }
      if (e.button === 1 || e.altKey) {
        panning = true;
        start = { x: e.clientX, y: e.clientY, panX: this.pan.x, panY: this.pan.y };
        e.preventDefault();
      }
    });
    window.addEventListener('mousemove', (e) => {
      if (panning) {
        this.pan.x = start.panX + (e.clientX - start.x);
        this.pan.y = start.panY + (e.clientY - start.y);
        this._applyStageTransform();
      }
    });
    window.addEventListener('mouseup', () => { panning = false; });
    this.viewport.addEventListener('wheel', (e) => {
      if (e.ctrlKey || e.metaKey) {
        e.preventDefault();
        this.setZoom(this.zoom + (e.deltaY < 0 ? 0.1 : -0.1));
      }
    }, { passive: false });
  }

  _bindKeys() {
    window.addEventListener('keydown', (e) => {
      const tag = document.activeElement.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
      const sel = [...this.store.selection];
      const mod = e.ctrlKey || e.metaKey;
      if (mod && e.key.toLowerCase() === 'z' && !e.shiftKey) { e.preventDefault(); this.store.undo(); }
      else if (mod && (e.key.toLowerCase() === 'y' || (e.shiftKey && e.key.toLowerCase() === 'z'))) { e.preventDefault(); this.store.redo(); }
      else if (mod && e.key.toLowerCase() === 'd') { e.preventDefault(); if (sel.length) this.store.duplicateComponents(sel); }
      else if (mod && e.key.toLowerCase() === 'c') { this._clipboard = sel.map((id) => JSON.parse(JSON.stringify(this.store.state.components.find((c) => c.id === id)))); }
      else if (mod && e.key.toLowerCase() === 'v') {
        if (this._clipboard && this._clipboard.length) {
          e.preventDefault();
          const ids = [];
          for (const c of this._clipboard) {
            const idx = (this.store.state.nextIndex[c.defId] || 0) + 1;
            this.store.state.nextIndex[c.defId] = idx;
            const copy = JSON.parse(JSON.stringify(c));
            copy.id = `${c.defId}_${String(idx).padStart(3, '0')}`;
            copy.x += 20; copy.y += 20;
            this.store.state.components.push(copy);
            ids.push(copy.id);
          }
          this.store.selection = new Set(ids);
          this.store.commit();
        }
      } else if ((e.key === 'Delete' || e.key === 'Backspace') && sel.length) {
        e.preventDefault();
        const zones = sel.map(id => this.store.getTapZoneSelection(id)).filter(Boolean);
        if (zones.length && zones.length === sel.length) zones.forEach(({parent, zone}) => this.store.removeTapZone(parent.id, zone.id));
        else confirmRemoveComponents(this.store, sel.filter(id => !String(id).startsWith('tapzone:')));
      } else if (e.key.startsWith('Arrow') && sel.length) {
        e.preventDefault();
        const step = e.shiftKey ? 10 : 1;
        const dx = e.key === 'ArrowLeft' ? -step : e.key === 'ArrowRight' ? step : 0;
        const dy = e.key === 'ArrowUp' ? -step : e.key === 'ArrowDown' ? step : 0;
        for (const id of sel) {
          const zoneSel = this.store.getTapZoneSelection(id);
          if (zoneSel) { zoneSel.zone.x += dx; zoneSel.zone.y += dy; continue; }
          const c = this.store.state.components.find((x) => x.id === id);
          if (c) { c.x += dx; c.y += dy; }
        }
        this.store.commit();
      }
    });
  }

  setZoom(z) {
    this.zoom = clamp(z, 0.25, 4);
    this._zoomSelect.value = String(Math.round(this.zoom * 100));
    this._applyStageTransform();
  }

  _applyStageTransform() {
    this.stage.style.transform = `translate(${this.pan.x}px, ${this.pan.y}px) scale(${this.zoom})`;
    // Обратный масштаб — чтобы мелкие кнопки на холсте (например «＋ тап»)
    // оставались читаемыми при любом зуме.
    this.stage.style.setProperty('--inv-zoom', String(1 / this.zoom));
    this._updateCenterWidth();
  }

  // Центральная колонка подгоняется под размер циферблата, а боковые панели
  // «поджимают» её: пустое поле вокруг циферблата не нужно.
  _updateCenterWidth() {
    const body = document.querySelector('.app-body');
    const dev = this.store.state && this.store.state.device;
    if (!body || !dev) return;
    body.style.setProperty('--center-w', Math.round(dev.w * this.zoom + 40) + 'px');
  }

  _applyGrid() {
    if (this.gridOverlay) this.gridOverlay.style.display = this.showGrid ? 'block' : 'none';
  }

  _hideGuides() {
    if (this.guideH) this.guideH.style.display = 'none';
    if (this.guideV) this.guideV.style.display = 'none';
  }

  // Точечное обновление текста виджетов, привязанных ко времени. Вызывается
  // раз в секунду вместо полного render(): трогает только textContent уже
  // существующих узлов, поэтому не сбрасывает выделение, ручки resize и
  // не создаёт мусора для сборщика.
  tickLiveText() {
    if (!this.frame) return;
    for (const comp of this.store.state.components) {
      const def = REGISTRY[comp.defId];
      if (!def || def.widgetId !== 'TEXT') continue;
      const source = getCanvasPreviewDataSource(comp, def);
      if (!LIVE_PREVIEW_SOURCES.has(source)) continue; // только источники, которые меняются сами
      // При выбранном data_source текстовое поле является резервным значением и
      // не должно блокировать live-preview.
      const el = this.frame.querySelector(`.comp-node[data-id="${comp.id}"] .comp-visual`);
      if (!el) continue;
      const text = componentPreviewText(comp, def);
      if (text != null && el.textContent !== text) el.textContent = text;
    }
  }

  render() {
    const state = this.store.state;
    const { w, h, shape } = state.device;
    const aodSettings = state.mode === 'aod' && state.scenes?.aod?.settings ? state.scenes.aod.settings : null;
    this.frame.style.width = w + 'px';
    this.frame.style.height = h + 'px';
    this.frame.style.borderRadius = shape === 'round' ? '50%' : '12px';
    // Стейдж имеет реальный размер устройства и масштабируется от центра,
    // поэтому циферблат остаётся по центру при любом зуме и любом размере экрана.
    this.stage.style.width = w + 'px';
    this.stage.style.height = h + 'px';
    this.stage.style.marginLeft = (-w / 2) + 'px';
    this.stage.style.marginTop = (-h / 2) + 'px';
    this._updateCenterWidth();
    if (this.gridOverlay) {
      this.gridOverlay.style.borderRadius = shape === 'round' ? '50%' : '12px';
      this._applyGrid();
    }
    // ВАЖНО: раньше картинка фона задавалась через style.background, а следом
    // style.backgroundImage безусловно перезаписывался паттерном сетки — из-за
    // этого назначенное фоновое изображение никогда не было видно (стирался
    // именно background-image, а не background-color). Собираем оба слоя
    // (сетку и картинку) в один многослойный background-image, чтобы сетка
    // была поверх, а фото — под ней.
    const bgVisible = Number(state.background?.alpha ?? 100) > 0;
    this.frame.style.backgroundColor = bgVisible ? (state.mode === 'aod' ? (aodSettings?.background || state.background?.color || '#000000') : (state.background?.color || '#000000')) : 'transparent';
    let bgImgId = state.background.imageAssetId;
    if (!bgImgId || !(state.assets || []).some((a) => a.id === bgImgId)) {
      // нет картинки фона, но есть анимация фона — показываем её первый кадр
      const an = state.background.anim;
      const first = an && an.enabled && Array.isArray(an.frames) ? an.frames.find((id) => (state.assets || []).some((a) => a.id === id)) : null;
      if (first) bgImgId = first;
    }
    if (bgVisible && bgImgId) {
      this.frame.style.backgroundImage = `url(${this._assetUrl(bgImgId)})`;
      this.frame.style.backgroundSize = 'cover';
      this.frame.style.backgroundPosition = 'center';
      this.frame.style.backgroundRepeat = 'no-repeat';
    } else {
      this.frame.style.backgroundImage = 'none';
    }
    this.frame.style.filter = state.mode === 'aod' ? `brightness(${Math.max(0.01, Number(aodSettings?.brightness ?? 100)) / 100})` : '';

    if (this.testToolbar) this.testToolbar.style.display = state.mode === 'aod' ? 'none' : '';

    // The same raster renderer used for exported preview is the visual source here.
    let previewCanvas = this.frame.querySelector('.shared-preview-canvas');
    if (!previewCanvas) {
      previewCanvas = document.createElement('canvas');
      previewCanvas.className = 'shared-preview-canvas';
      previewCanvas.style.position = 'absolute';
      previewCanvas.style.left = '0';
      previewCanvas.style.top = '0';
      previewCanvas.style.width = w + 'px';
      previewCanvas.style.height = h + 'px';
      previewCanvas.style.pointerEvents = 'none';
      this.frame.insertBefore(previewCanvas, this.frame.firstChild);
    }
    previewCanvas.width = w; previewCanvas.height = h;
    // Рендер всегда получает текущий порядок state.components (снизу вверх).
    // Токен не даёт старому асинхронному рендеру перезаписать более новый кадр
    // после перетаскивания слоёв или быстрого изменения свойств.
    const renderToken = ++this._renderToken;
    WatchfacePreviewRenderer.draw(state, previewCanvas, { size: w, testMode: this.testMode && !this.liveTime && state.mode !== 'aod', previewMode: state.mode === 'aod', liveTime: this.liveTime && state.mode !== 'aod', testDate: (this.testMode && state.mode !== 'aod') ? this._testDate : null, renderToken, textAnim: this._textAnimOverrides, arcAnim: this._arcAnimOverrides, bgFrameId: this._bgFrameId, validateToken: () => renderToken === this._renderToken })
      .then(() => { /* Ignore stale render completion; do not recursively trigger another full render. */ })
      .catch(console.warn);

    let side = this.root.querySelector('.aod-side-preview');
    if (state.mode === 'aod' && aodSettings?.previewMode === 'SIDE') {
      if (!side) {
        side = document.createElement('div');
        side.className = 'aod-side-preview';
        side.innerHTML = '<div class="aod-side-card"><b>Normal</b><canvas class="aod-side-normal"></canvas></div><div class="aod-side-card"><b>AOD</b><canvas class="aod-side-aod"></canvas></div>';
        this.root.appendChild(side);
      }
      side.style.display = 'grid';
      const normalCanvas = side.querySelector('.aod-side-normal');
      const aodCanvas = side.querySelector('.aod-side-aod');
      normalCanvas.width = normalCanvas.height = Math.min(240, w);
      aodCanvas.width = aodCanvas.height = Math.min(240, w);
      const normalScene = Object.assign({}, state, {
        mode: 'normal',
        components: state.scenes?.normal?.components || [],
        background: state.scenes?.normal?.background || { color:'#000000' }
      });
      WatchfacePreviewRenderer.draw(normalScene, normalCanvas, { size: normalCanvas.width, previewMode: true }).catch(console.warn);
      WatchfacePreviewRenderer.draw(state, aodCanvas, { size: aodCanvas.width, previewMode: true }).catch(console.warn);
    } else if (side) {
      side.style.display = 'none';
    }

    // DOM nodes are editor-only hit targets. The actual visual scene is rendered
    // by WatchfacePreviewRenderer underneath them.
    this.frame.querySelectorAll('.comp-node, .tap-zone-node, .tap-add-button').forEach((n) => n.remove());

    for (const comp of state.components) {
      const def = REGISTRY[comp.defId];
      if (!def) continue;
      const node = document.createElement('div');
      node.className = 'comp-node';
      node.dataset.id = comp.id;
      // DOM-слой редактора синхронизирован с raster-порядком: первый элемент
      // state.components — нижний, последний — верхний. Это важно для рамок,
      // ручек и выбора перекрывающихся объектов.
      const layerIndex = state.components.indexOf(comp);
      node.style.zIndex = String(100 + Math.max(0, layerIndex));
      const isCircleLike = def.widgetId === 'CIRCLE' || def.widgetId === 'STROKE_CIRCLE';
      // Стрелка TIME_POINTER рисуется по center_x/center_y и pos_x/pos_y, поэтому
      // её рамка должна стоять там же: левый верхний угол PNG = центр − опора.
      const isGauge = def.widgetId === 'GAUGE_NEEDLE';
      const isPointer = (def.widgetId === 'TIME_POINTER' || isGauge) && comp.props.center_x != null && comp.props.pos_x != null;
      const x = isCircleLike ? (comp.props.center_x ?? comp.x) - (comp.props.radius ?? comp.w / 2)
        : isPointer ? Number(comp.props.center_x) - Number(comp.props.pos_x) : comp.x;
      const y = isCircleLike ? (comp.props.center_y ?? comp.y) - (comp.props.radius ?? comp.h / 2)
        : isPointer ? Number(comp.props.center_y) - Number(comp.props.pos_y ?? 0) : comp.y;
      const wpx = isCircleLike ? (comp.props.radius ?? comp.w / 2) * 2 : comp.w;
      const hpx = isCircleLike ? (comp.props.radius ?? comp.h / 2) * 2 : comp.h;
      node.style.left = x + 'px';
      node.style.top = y + 'px';
      node.style.width = wpx + 'px';
      node.style.height = hpx + 'px';
      if (state.mode === 'aod') {
        const rotation = Number(comp.props?.rotation || 0);
        const scale = Number(comp.props?.scale || 1);
        node.style.transformOrigin = 'center center';
        node.style.transform = `rotate(${rotation}deg) scale(${Math.max(0.05, scale)})`;
      }
      if (isGauge && state.mode !== 'aod') {
        // Рамка стрелочного датчика повёрнута вместе со стрелкой (вокруг точки опоры), чтобы
        // выделение и клик попадали ровно по нарисованной стрелке.
        const ang = GaugeNeedleModel.previewAngle(comp, new Date());
        node.style.transformOrigin = `${Number(comp.props.pos_x)}px ${Number(comp.props.pos_y ?? 0)}px`;
        node.style.transform = `rotate(${ang}deg)`;
      }
      node.style.display = (comp.visible === false || (this.testMode && def.widgetId === 'TIME_POINTER')) ? 'none' : '';
      node.style.opacity = comp.visible === false ? '0.3' : '1';

      if (def.widgetId === 'TAP_ZONE') node.classList.add('tap-zone-component');
      const inner = document.createElement('div');
      inner.className = `comp-visual comp-${def.widgetId.toLowerCase()}`;
      this._styleVisual(inner, comp, def);
      inner.style.visibility = 'hidden';
      inner.style.pointerEvents = 'none';
      node.appendChild(inner);

      if (this.store.selection.has(comp.id)) {
        node.classList.add('selected');

        // Fast, discoverable way to create an interactive child area.
        // The button belongs to the selected component and never becomes a layer.
        const addTap = document.createElement('button');
        addTap.type = 'button';
        addTap.className = 'tap-add-button';
        addTap.textContent = '⊕';
        addTap.title = 'Добавить тап-зону (прозрачную интерактивную область)';
        addTap.setAttribute('aria-label', 'Добавить тап-зону');
        // Маленькая кнопка у правого верхнего угла рамки, снаружи: ничего не
        // перекрывает. Если сверху нет места — уходит под нижний край.
        const btnSize = 20;
        const above = y - btnSize - 4;
        addTap.style.left = `${x + wpx - btnSize}px`;
        addTap.style.top = `${above >= 0 ? above : y + hpx + 4}px`;
        addTap.addEventListener('mousedown', (ev) => ev.stopPropagation());
        addTap.addEventListener('click', (ev) => {
          ev.preventDefault();
          ev.stopPropagation();
          const z = this.store.addTapZone(comp.id);
          if (z) this.render(this.store.state);
        });
        if (def.widgetId !== 'TAP_ZONE') this.frame.appendChild(addTap);

        // У стрелочного датчика размер рамки задаёт сам PNG — ручек растягивания нет.
        if (!isGauge) for (const corner of ['nw', 'ne', 'sw', 'se']) {
          const h2 = document.createElement('div');
          h2.className = `handle handle-${corner}`;
          h2.dataset.corner = corner;
          node.appendChild(h2);
        }
      }

      if (!comp.locked) node.addEventListener('mousedown', (e) => this._onNodeMouseDown(e, comp));
      else node.classList.add('locked');
      this.frame.appendChild(node);

      // Tap zones are CHILDREN of their component. Coordinates are local to the
      // component's editor box, so moving the parent automatically moves every
      // child without rewriting child coordinates.
      for (const zone of (comp.tapZones || [])) {
        if (zone.visible === false || !this.showTapZones) continue;
        const zid = `tapzone:${comp.id}:${zone.id}`;
        const zn = document.createElement('div');
        zn.className = 'tap-zone-node';
        zn.dataset.parentId = comp.id;
        zn.dataset.zoneId = zone.id;
        zn.dataset.selectionId = zid;
        zn.style.left = (x + Number(zone.x || 0)) + 'px';
        zn.style.top = (y + Number(zone.y || 0)) + 'px';
        zn.style.width = Math.max(4, Number(zone.w || 4)) + 'px';
        zn.style.height = Math.max(4, Number(zone.h || 4)) + 'px';
        zn.style.zIndex = String(110 + Math.max(0, layerIndex));
        const zoneSelected = this.store.selection.has(zid);
        zn.classList.toggle('selected', zoneSelected);
        zn.classList.toggle('locked', !!zone.locked);
        zn.classList.toggle('parent-selected', this.store.selection.has(comp.id));
        zn.title = `${zone.name || zone.id} — ${comp.name}`;
        if (this.store.selection.has(zid)) {
          for (const corner of ['nw', 'ne', 'sw', 'se']) {
            const h2 = document.createElement('div');
            h2.className = `tap-handle tap-handle-${corner}`;
            h2.dataset.corner = corner;
            zn.appendChild(h2);
          }
        }
        if (!zone.locked) zn.addEventListener('mousedown', (e) => this._onTapZoneMouseDown(e, comp, zone, { baseX: x, baseY: y }));
        this.frame.appendChild(zn);
      }
    }
  }

  _assetUrl(assetId) {
    const a = this.store.state.assets.find((x) => x.id === assetId);
    return a ? AssetBg.url(a) : '';
  }

  _styleVisual(el, comp, def) {
    switch (def.widgetId) {
      case 'TEXT': {
        el.textContent = componentPreviewText(comp, def);
        el.style.color = comp.props.color || '#ffffff';
        {
          // Затухание цветом (смешивание с цветом фона) и прозрачность — как в экспорте.
          const blend = Math.max(0, Math.min(100, Number(comp.props.text_blend ?? 0))) / 100;
          if (blend > 0) {
            const rgb = (h) => { let c = String(h || '#000000').replace('#', ''); if (/^[0-9a-f]{3}$/i.test(c)) c = c.split('').map((x) => x + x).join(''); if (!/^[0-9a-f]{6}$/i.test(c)) c = '000000'; return [0, 2, 4].map((i) => parseInt(c.slice(i, i + 2), 16)); };
            const a = rgb(comp.props.color || '#ffffff'), b = rgb(comp.props.text_blend_color || '#000000');
            el.style.color = `rgb(${a.map((v, i) => Math.round(v + (b[i] - v) * blend)).join(',')})`;
          }
          el.style.opacity = String(Math.max(0, Math.min(100, Number(comp.props.text_alpha ?? 100))) / 100);
        }
        // text_size, как и x/y/w/h, задаётся в device-пикселях, а device-frame
        // рендерится 1:1 в CSS-пикселях (см. .canvas-stage margin = -w/2). Поэтому
        // font-size должен браться напрямую, без произвольного коэффициента —
        // раньше здесь стоял множитель 0.55, из-за которого текст в редакторе
        // был заметно мельче, чем на реальном устройстве/симуляторе.
        el.style.fontSize = (comp.props.text_size || 28) + 'px';
        el.style.lineHeight = '1';
        el.style.display = 'flex';
        el.style.alignItems = (comp.props.align_v === 'TOP') ? 'flex-start' : (comp.props.align_v === 'BOTTOM') ? 'flex-end' : 'center';
        el.style.justifyContent = (comp.props.align_h === 'LEFT') ? 'flex-start' : (comp.props.align_h === 'RIGHT') ? 'flex-end' : 'center';
        el.style.whiteSpace = 'nowrap';
        el.style.overflow = 'hidden';
        const fontId = comp.props.font;
        const projectFont = (this.store.state.fonts || []).find((f) => f.id === fontId);
        if (projectFont) {
          if (typeof registerProjectFont === 'function') registerProjectFont(projectFont);
          el.style.fontFamily = `'${projectFont.cssFamily || projectFont.name}', sans-serif`;
        } else {
          el.style.fontFamily = "'Segoe UI', sans-serif";
        }
        el.style.fontWeight = String(comp.props.font_weight || '400');
        el.style.fontStyle = comp.props.font_style || 'normal';
        el.style.letterSpacing = `${Number(comp.props.letter_spacing || 0)}px`;
        el.style.lineHeight = String(comp.props.line_height || 1);
        break;
      }
      case 'GAUGE_NEEDLE':
      case 'TIME_POINTER': {
        // Стрелки хранят ресурс в props.path (а не props.src, как обычные IMG-виджеты) —
        // раньше этот case отсутствовал вовсе, поэтому назначенная картинка стрелки
        // никогда не подхватывалась и рисовалась только серая заглушка.
        const assetId = comp.props.path;
        const asset = this.store.state.assets.find((a) => a.id === assetId || a.name === assetId);
        if (asset) {
          el.style.backgroundImage = `url(${AssetBg.url(asset)})`;
          el.style.backgroundSize = 'contain';
          el.style.backgroundRepeat = 'no-repeat';
          el.style.backgroundPosition = 'center';
        } else {
          el.style.background = 'repeating-linear-gradient(45deg, #445, #445 6px, #303645 6px, #303645 12px)';
        }
        break;
      }
      case 'IMG':
      case 'IMG_STATUS': {
        const assetId = comp.props.src;
        const asset = this.store.state.assets.find((a) => a.id === assetId || a.name === assetId);
        if (asset) {
          el.style.backgroundImage = `url(${AssetBg.url(asset)})`;
          el.style.backgroundSize = 'contain';
          el.style.backgroundRepeat = 'no-repeat';
          el.style.backgroundPosition = 'center';
        } else if (isWeatherIconDef(def) && typeof WeatherIcons !== 'undefined' && WeatherIcons.previewAsset(this.store.state, comp.props.src)) {
          el.style.backgroundImage = `url(${WeatherIcons.previewAsset(this.store.state, comp.props.src).dataUrl})`;
          el.style.backgroundSize = 'contain';
          el.style.backgroundRepeat = 'no-repeat';
          el.style.backgroundPosition = 'center';
        } else if (isWeatherIconDef(def) && builtinWeatherIconUrl(comp.props.src)) {
          // Стандартная иконка (заглушка) — та же, что экспортируется на часы.
          el.style.backgroundImage = `url(${builtinWeatherIconUrl(comp.props.src)})`;
          el.style.backgroundSize = 'contain';
          el.style.backgroundRepeat = 'no-repeat';
          el.style.backgroundPosition = 'center';
        } else if (isWeatherIconDef(def)) {
          el.textContent = this._weatherGlyph(comp.props.src);
          el.style.display = 'flex'; el.style.alignItems = 'center'; el.style.justifyContent = 'center';
          el.style.fontSize = '32px';
        } else {
          el.style.background = 'repeating-linear-gradient(45deg, #333, #333 6px, #222 6px, #222 12px)';
        }
        el.style.opacity = (comp.props.alpha ?? 100) / 100;
        break;
      }
      case 'FILL_RECT':
        el.style.background = comp.props.color || '#3366ff';
        el.style.borderRadius = (comp.props.radius || 0) + 'px';
        break;
      case 'STROKE_RECT':
        el.style.border = `${comp.props.line_width || 4}px solid ${comp.props.color || '#3366ff'}`;
        el.style.borderRadius = (comp.props.radius || 0) + 'px';
        break;
      case 'CIRCLE':
        el.style.background = comp.props.color || '#3366ff';
        el.style.borderRadius = '50%';
        break;
      case 'STROKE_CIRCLE':
        el.style.border = `${comp.props.line_width || 4}px solid ${comp.props.color || '#3366ff'}`;
        el.style.borderRadius = '50%';
        break;
      case 'ARC': {
        // Дуга рисуется SVG: так доступны скруглённые концы, подложка,
        // частичное заполнение по значению источника и прозрачность.
        const pr = comp.props || {};
        const w = Math.max(1, Number(comp.w) || 1), h = Math.max(1, Number(comp.h) || 1);
        const lw = Math.max(1, Number(pr.line_width) || 8);
        const aS = Number(pr.start_angle ?? 0), aE = Number(pr.end_angle ?? 270);
        // Эллипс, вписанный в рамку w×h (как виджет ARC на часах): у вытянутого компонента дуга тоже вытянута.
        const rx = Math.max(1, w / 2 - lw / 2), ry = Math.max(1, h / 2 - lw / 2);
        const ratio = window.ArcModel ? window.ArcModel.previewRatio(pr) : 1;
        const cap = pr.rounded_ends ? 'round' : 'butt';
        const alpha = Math.max(0, Math.min(100, Number(pr.alpha ?? 100))) / 100;
        const tAlpha = Math.max(0, Math.min(100, Number(pr.track_alpha ?? 100))) / 100;
        const esc = (v) => String(v).replace(/[^#0-9a-zA-Z(),.% -]/g, '');
        const segd = !!(window.ArcModel && window.ArcModel.isSegmented(pr));
        const track = (pr.track_enabled && segd)
          ? `<g class="arc-track" opacity="${tAlpha}">${this._arcSegMarkup(pr, w / 2, h / 2, rx, ry, aS, aE, 1, lw, true)}</g>`
          : pr.track_enabled
          ? `<path class="arc-track" d="${this._arcPath(w / 2, h / 2, rx, ry, aS, aE)}" fill="none" stroke="${esc(pr.track_color || '#2a3042')}" stroke-width="${lw}" stroke-linecap="${cap}" stroke-opacity="${tAlpha}"/>`
          : '';
        const [fA, fB] = window.ArcModel ? window.ArcModel.fillRange(pr, aS, aE, ratio) : [aS, aS + (aE - aS) * ratio];
        const sgnA = aE >= aS ? 1 : -1;
        // Тень и контур: сплошные слои под основной дугой (те же, что виджеты ARC на часах).
        const dFull = !!(window.ArcModel && window.ArcModel.decoFull && window.ArcModel.decoFull(pr));
        const dA = dFull ? aS : fA, dB = dFull ? aE : fB;
        const deco = ((ratio > 0 || dFull) && window.ArcModel && window.ArcModel.decoLayers)
          ? window.ArcModel.decoLayers(pr, rx, ry, (this.store.state.background && this.store.state.background.color) || '#000000').map((ly) =>
            `<path class="arc-${ly.kind}" transform="translate(${ly.dx} ${ly.dy})" d="${this._arcPath(w / 2, h / 2, rx, ry, dA - sgnA * ly.ext, dB + sgnA * ly.ext)}" fill="none" stroke="${esc(ly.color)}" stroke-width="${lw + 2 * ly.s}" stroke-linecap="${segd ? (pr.segment_rounded ? 'round' : 'butt') : cap}" stroke-opacity="${ly.alpha}"/>`).join('')
          : '';
        const main = ratio > 0
          ? (segd
            ? `<g class="arc-main" opacity="${alpha}">${this._arcSegMarkup(pr, w / 2, h / 2, rx, ry, aS, aE, ratio, lw, false)}</g>`
            : `<path class="arc-main" d="${this._arcPath(w / 2, h / 2, rx, ry, fA, fB)}" fill="none" stroke="${esc(pr.color || '#3366ff')}" stroke-width="${lw}" stroke-linecap="${cap}" stroke-opacity="${alpha}"/>`)
          : '';
        el.innerHTML = `<svg data-arc="1" width="100%" height="100%" viewBox="0 0 ${w} ${h}" style="display:block;overflow:visible">${dFull ? deco + track : track + deco}${main}</svg>`;
        break;
      }
      case 'LINE_BAR':
        // Видимый кадр рисует растровый слой (renderer.js, LineModel); DOM-узел нужен только для выделения и перетаскивания.
        break;
      case 'HYBRID_CHARGE':
      case 'BIO_CHARGE':
        // Видимый кадр рисует растровый слой (renderer.js); DOM-узел нужен только для выделения и перетаскивания.
        break;
      case 'WATCH_DIAL': {
        const dialFont = (this.store.state.fonts || []).find((f) => f.id === comp.props.font) || null;
        if (dialFont && typeof registerProjectFont === 'function') registerProjectFont(dialFont);
        el.innerHTML = DialModel.toSvg(comp, dialFont);
        break;
      }
      case 'TRIANGLE': {
        const tri = TriangleModel.shape(comp);
        const esc = (v) => String(v).replace(/[^#0-9a-zA-Z(),.% -]/g, '');
        const pts = (list) => list.map((pt) => `${pt.x},${pt.y}`).join(' ');
        const fillAttr = tri.fill ? esc(tri.color) : 'none';
        const strokeAttr = tri.stroke ? ` stroke="${esc(tri.strokeColor)}" stroke-width="${tri.strokeWidth}" stroke-linejoin="miter" stroke-miterlimit="20"` : '';
        el.innerHTML = `<svg data-triangle="1" width="100%" height="100%" viewBox="0 0 ${tri.w} ${tri.h}" style="display:block;overflow:visible"><polygon points="${pts(tri.fillPts)}" fill="${fillAttr}"${strokeAttr}/></svg>`;
        break;
      }
      case 'CANVAS':
        el.style.background = 'repeating-linear-gradient(-45deg, #223 0, #223 6px, #1a1a26 6px, #1a1a26 12px)';
        el.style.border = '1px dashed #556';
        el.textContent = 'ХОЛСТ';
        el.style.display = 'flex'; el.style.alignItems = 'center'; el.style.justifyContent = 'center';
        el.style.color = '#889'; el.style.fontSize = '11px';
        break;
      default:
        el.style.background = '#444';
    }
  }

  // Сегментированная дуга (градиент / деления): короткие сегменты, как на часах; общая прозрачность задаётся на <g>.
  _arcSegMarkup(pr, cx, cy, rx, ry, aS, aE, ratio, lw, track) {
    if (!window.ArcModel || !window.ArcModel.segs) return '';
    const cap = pr.segment_rounded ? 'round' : 'butt';
    return window.ArcModel.segs(pr, aS, aE, ratio, !!track).map((sg) =>
      `<path d="${this._arcPath(cx, cy, rx, ry, sg.a, sg.b)}" fill="none" stroke="${sg.color}" stroke-opacity="${sg.alpha}" stroke-width="${lw}" stroke-linecap="${cap}"/>`
    ).join('');
  }

  // Путь SVG для дуги-эллипса: углы в градусах, 0° — 12 часов, по часовой стрелке (параметрический угол эллипса).
  _arcPath(cx, cy, rx, ry, aS, aE) {
    const pt = (a) => {
      const t = (a - 90) * Math.PI / 180;
      return [cx + rx * Math.cos(t), cy + ry * Math.sin(t)];
    };
    const span = aE - aS;
    if (Math.abs(span) < 0.01) { const [x0, y0] = pt(aS); return `M ${x0} ${y0} l 0.01 0`; }
    if (Math.abs(span) >= 359.99) {
      const [x0, y0] = pt(aS), [x1, y1] = pt(aS + 180);
      return `M ${x0} ${y0} A ${rx} ${ry} 0 1 1 ${x1} ${y1} A ${rx} ${ry} 0 1 1 ${x0} ${y0}`;
    }
    const [x0, y0] = pt(aS), [x1, y1] = pt(aE);
    return `M ${x0} ${y0} A ${rx} ${ry} 0 ${Math.abs(span) > 180 ? 1 : 0} ${span > 0 ? 1 : 0} ${x1} ${y1}`;
  }

  // Проигрывание анимации дуги в редакторе (кнопка в инспекторе). Ничего не
  // сохраняет в проект. DOM-узлы компонентов скрыты (visibility:hidden), видимый
  // кадр рисует растровый слой, поэтому анимация идёт через его параметры.
  setLiveTime(on) {
    on = !!on;
    if (this.liveTime === on) return;
    if (on && this.testMode) {
      this.testMode = false;
      if (this._testRafId) cancelAnimationFrame(this._testRafId);
      this._testRafId = null;
      if (this.testBtn) { this.testBtn.textContent = '▶ Стрелки'; this.testBtn.classList.remove('active'); }
      for (const el of [this.testHour, this.testMinute, this.testSecond]) el.style.display = 'none';
    }
    this.liveTime = on;
    this._liveStamp = -1;
    this.render();
  }

  // Обновляет растровый слой в живом времени; плавная секундная стрелка — до четырёх кадров/с.
  tickLiveRaster() {
    if (!this.liveTime || !this.frame || this.store.state.mode === 'aod') return false;
    const smoothSecond = this.store.state.components.some((c) => c.defId === 'time_pointer_second' && c.props?.motion === 'SMOOTH');
    const stamp = Math.floor(Date.now() / (smoothSecond ? 250 : 1000));
    if (stamp === this._liveStamp) return false;
    this._liveStamp = stamp;
    this._redrawRaster();
    return true;
  }

  _redrawRaster() {
    const state = this.store.state;
    const cv = this.frame.querySelector('.shared-preview-canvas');
    if (!cv) return;
    const token = ++this._renderToken;
    return WatchfacePreviewRenderer.draw(state, cv, { size: state.device.w, testMode: this.testMode && !this.liveTime && state.mode !== 'aod', previewMode: state.mode === 'aod', liveTime: this.liveTime && state.mode !== 'aod', testDate: (this.testMode && state.mode !== 'aod') ? this._testDate : null, renderToken: token, textAnim: this._textAnimOverrides, arcAnim: this._arcAnimOverrides, bgFrameId: this._bgFrameId, validateToken: () => token === this._renderToken }).catch(console.warn);
  }

  _playArcPreview(id) {
    const comp = this.store.state.components.find((c) => c.id === id);
    if (!comp || !window.ArcModel) return;
    const pr = comp.props || {};
    const dur = Math.max(100, Number(pr.anim_duration) || 1200), delay = Math.max(0, Number(pr.anim_delay) || 0);
    if (this._arcAnimRaf) cancelAnimationFrame(this._arcAnimRaf);
    const t0 = performance.now() + delay;
    const stop = () => { this._arcAnimRaf = null; this._arcAnimOverrides = null; this._redrawRaster(); };
    let lastDraw = 0;
    const frame = (now) => {
      const cur = this.store.state.components.find((c) => c.id === id);
      if (!cur) return stop();
      const k = Math.max(0, Math.min(1, (now - t0) / dur));
      if (k >= 1) return stop();   // финал = обычный вид дуги
      if (now - lastDraw >= 16) {
        lastDraw = now;
        this._arcAnimOverrides = { [id]: window.ArcModel.animState(cur.props || pr, k, window.ArcModel.previewRatio(cur.props || pr)) };
        this._redrawRaster();
      }
      this._arcAnimRaf = requestAnimationFrame(frame);
    };
    this._arcAnimRaf = requestAnimationFrame(frame);
  }

  _weatherGlyph(cond) {
    const id = normalizeWeatherIconId(cond);
    const entry = WEATHER_ICON_SET.find((w) => w.id === id);
    return (entry && entry.glyph) || '☀';
  }


  _onTapZoneMouseDown(e, parent, zone, box) {
    e.stopPropagation();
    e.preventDefault();
    const selectionId = `tapzone:${parent.id}:${zone.id}`;
    const isHandle = e.target.classList.contains('tap-handle');
    if (!this.store.selection.has(selectionId)) this.store.setSelection([selectionId]);

    const startMouse = { x: e.clientX, y: e.clientY };
    const startBox = { x: Number(zone.x || 0), y: Number(zone.y || 0), w: Number(zone.w || 20), h: Number(zone.h || 20) };
    const corner = isHandle ? e.target.dataset.corner : null;

    const onMove = (ev) => {
      const dx = (ev.clientX - startMouse.x) / this.zoom;
      const dy = (ev.clientY - startMouse.y) / this.zoom;
      let { x, y, w, h } = startBox;
      if (corner) {
        if (corner.includes('e')) w = startBox.w + dx;
        if (corner.includes('s')) h = startBox.h + dy;
        if (corner.includes('w')) { w = startBox.w - dx; x = startBox.x + dx; }
        if (corner.includes('n')) { h = startBox.h - dy; y = startBox.y + dy; }
        w = Math.max(4, w); h = Math.max(4, h);
      } else {
        x += dx; y += dy;
      }
      if (this.snapGrid) {
        x = Math.round(x / GRID) * GRID;
        y = Math.round(y / GRID) * GRID;
        if (corner) {
          w = Math.max(4, Math.round(w / GRID) * GRID);
          h = Math.max(4, Math.round(h / GRID) * GRID);
        }
      } else {
        x = Math.round(x); y = Math.round(y); w = Math.round(w); h = Math.round(h);
      }
      zone.x = x; zone.y = y;
      if (corner) { zone.w = w; zone.h = h; }
      this.store._emit();
    };
    const onUp = () => {
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
      this.store.commit();
    };
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
  }

  _onNodeMouseDown(e, comp) {
    e.stopPropagation();
    const isHandle = e.target.classList.contains('handle');
    const state = this.store.state;

    if (!isHandle) {
      if (e.shiftKey) {
        const sel = new Set(this.store.selection);
        if (sel.has(comp.id)) sel.delete(comp.id); else sel.add(comp.id);
        this.store.setSelection([...sel]);
      } else if (!this.store.selection.has(comp.id)) {
        this.store.setSelection([comp.id]);
      }
    }

    // A parent drag only moves real components. Child tap-zone selections are
    // intentionally excluded so a mixed selection can never corrupt geometry.
    const selectedIds = [...this.store.selection].filter(id => !String(id).startsWith('tapzone:'));
    const startPositions = selectedIds.map((id) => {
      const c = state.components.find((x) => x.id === id);
      return c ? { id, x: c.x, y: c.y } : null;
    }).filter(Boolean);
    const startMouse = { x: e.clientX, y: e.clientY };
    const corner = isHandle ? e.target.dataset.corner : null;
    const startBox = { x: comp.x, y: comp.y, w: comp.w, h: comp.h };

    const onMove = (ev) => {
      const dx = (ev.clientX - startMouse.x) / this.zoom;
      const dy = (ev.clientY - startMouse.y) / this.zoom;

      if (corner) {
        const target = state.components.find((c) => c.id === comp.id);
        let { x, y, w, h } = startBox;
        if (corner.includes('e')) w = startBox.w + dx;
        if (corner.includes('s')) h = startBox.h + dy;
        if (corner.includes('w')) { w = startBox.w - dx; x = startBox.x + dx; }
        if (corner.includes('n')) { h = startBox.h - dy; y = startBox.y + dy; }
        w = Math.max(8, w); h = Math.max(8, h);
        if (this.snapGrid) { x = Math.round(x / GRID) * GRID; y = Math.round(y / GRID) * GRID; w = Math.round(w / GRID) * GRID; h = Math.round(h / GRID) * GRID; }
        else { x = Math.round(x); y = Math.round(y); w = Math.round(w); h = Math.round(h); }
        Object.assign(target, { x, y, w, h });
        this._syncPointerPivot(target);

        this.store._emit();
      } else {
        for (const sp of startPositions) {
          const target = state.components.find((c) => c.id === sp.id);
          if (target.locked) continue;
          let nx = sp.x + dx;
          let ny = sp.y + dy;
          if (this.snapGrid) { nx = Math.round(nx / GRID) * GRID; ny = Math.round(ny / GRID) * GRID; }
          else { nx = Math.round(nx); ny = Math.round(ny); }
          target.x = nx; target.y = ny;
          this._syncPointerPivot(target);
        }
        const t = state.components.find((c) => c.id === comp.id);

        this._showCenterGuides(t);
        this._syncPointerPivot(t);
        this.store._emit();
      }
    };
    const onUp = () => {
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
      this.guideH.style.display = 'none';
      this.guideV.style.display = 'none';

      this.store.commit();
    };
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
  }

  // После перемещения стрелки переносим ось вращения (center_x/center_y)
  // вслед за рамкой, чтобы рамка и нарисованная стрелка не расходились.
  _syncPointerPivot(comp) {
    const def = REGISTRY[comp.defId];
    if (!def || (def.widgetId !== 'TIME_POINTER' && def.widgetId !== 'GAUGE_NEEDLE') || comp.props.pos_x == null) return;
    comp.props.center_x = Math.round(comp.x + Number(comp.props.pos_x));
    comp.props.center_y = Math.round(comp.y + Number(comp.props.pos_y ?? 0));
  }

  _showCenterGuides(comp) {
    // «Магнит» выключен — никакого прилипания к центру и никаких направляющих.
    if (!this.snapGrid) { this._hideGuides(); return; }
    const { w, h } = this.store.state.device;
    const ptrWidget = REGISTRY[comp.defId]?.widgetId;
    const isPtr = (ptrWidget === 'TIME_POINTER' || ptrWidget === 'GAUGE_NEEDLE') && comp.props.pos_x != null;
    // Для стрелки центрируем не рамку, а ось вращения.
    const cx = isPtr ? comp.x + Number(comp.props.pos_x) : comp.x + comp.w / 2;
    const cy = isPtr ? comp.y + Number(comp.props.pos_y ?? 0) : comp.y + comp.h / 2;
    const nearCenterX = Math.abs(cx - w / 2) < 6;
    const nearCenterY = Math.abs(cy - h / 2) < 6;
    this.guideV.style.display = nearCenterX ? 'block' : 'none';
    this.guideV.style.left = w / 2 + 'px';
    this.guideH.style.display = nearCenterY ? 'block' : 'none';
    this.guideH.style.top = h / 2 + 'px';
    if (nearCenterX) comp.x = isPtr ? w / 2 - Number(comp.props.pos_x) : w / 2 - comp.w / 2;
    if (nearCenterY) comp.y = isPtr ? h / 2 - Number(comp.props.pos_y ?? 0) : h / 2 - comp.h / 2;
  }
}
