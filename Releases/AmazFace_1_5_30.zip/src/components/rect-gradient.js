'use strict';
// ---------------------------------------------------------------------------
// RectGradient — градиентная заливка компонента «Прямоугольник (заливка)».
//
// Одна модель на предпросмотр и экспорт. FILL_RECT на часах умеет только сплошной
// цвет, поэтому при экспорте градиентный прямоугольник запекается в PNG с альфа-каналом
// (prepareGradientExportProject в project-exporter.js), а в редакторе рисуется тем же кодом.
//
// Свойства компонента (плоские, чтобы работал обычный механизм data-prop инспектора):
// Работает для «Прямоугольника (заливка)» и «Круга (заливка)».
//   gradient_enabled : boolean
//   gradient_dir     : lr | rl | tb | bt | diag | radial | radial_in
//   gradient_mode    : two | fade_in | fade_out
//   color            : основной цвет
//   gradient_to      : второй цвет (только для mode = two)
//
// Направление — это направление движения от НАЧАЛА градиента к КОНЦУ:
//   lr — слева направо, rl — справа налево, tb — сверху вниз, bt — снизу вверх,
//   diag — из левого верхнего угла в правый нижний,
//   radial — из центра к краям, radial_in — от краёв к центру.
// Режим задаёт, чем начало отличается от конца:
//   two      — цвет → цвет 2
//   fade_in  — прозрачный → цвет (цвет «проявляется»)
//   fade_out — цвет → прозрачный (цвет «растворяется»)
// ---------------------------------------------------------------------------
const RectGradient = (() => {
  const DIRS = [
    { value: 'lr', label: 'Слева направо →' },
    { value: 'rl', label: 'Справа налево ←' },
    { value: 'tb', label: 'Сверху вниз ↓' },
    { value: 'bt', label: 'Снизу вверх ↑' },
    { value: 'diag', label: 'По диагонали ↘' },
    { value: 'radial', label: 'Радиальный: из центра к краям' },
    { value: 'radial_in', label: 'Радиальный: от краёв к центру' },
  ];
  const MODES = [
    { value: 'two', label: 'Цвет → Цвет 2' },
    { value: 'fade_in', label: 'Прозрачный → цвет' },
    { value: 'fade_out', label: 'Цвет → прозрачный' },
  ];
  const DIR_SET = new Set(DIRS.map((d) => d.value));
  const MODE_SET = new Set(MODES.map((m) => m.value));

  function parseHex(hex) {
    let c = String(hex == null ? '' : hex).trim().replace('#', '');
    if (/^[0-9a-f]{3}$/i.test(c)) c = c.split('').map((x) => x + x).join('');
    if (!/^[0-9a-f]{6}$/i.test(c)) c = '000000';
    return [0, 2, 4].map((i) => parseInt(c.slice(i, i + 2), 16));
  }
  // Прозрачный стоп берём в том же цвете (rgba(r,g,b,0)), а не «прозрачным чёрным»:
  // иначе при интерполяции по краю градиента появляется тёмная кайма.
  function css(hex, alpha) {
    const [r, g, b] = parseHex(hex);
    return `rgba(${r},${g},${b},${alpha})`;
  }

  function params(p) {
    p = p || {};
    return {
      enabled: !!p.gradient_enabled,
      dir: DIR_SET.has(p.gradient_dir) ? p.gradient_dir : 'lr',
      mode: MODE_SET.has(p.gradient_mode) ? p.gradient_mode : 'two',
      color: p.color || '#3366ff',
      to: p.gradient_to || '#000000',
    };
  }

  // [цвет в начале, цвет в конце] в формате CSS
  function endpoints(q) {
    if (q.mode === 'fade_in') return [css(q.color, 0), css(q.color, 1)];
    if (q.mode === 'fade_out') return [css(q.color, 1), css(q.color, 0)];
    return [css(q.color, 1), css(q.to, 1)];
  }

  function roundRectPath(ctx, x, y, w, h, r) {
    r = Math.max(0, Math.min(r, w / 2, h / 2));
    ctx.beginPath();
    if (r <= 0) { ctx.rect(x, y, w, h); return; }
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  // Рисует градиентный прямоугольник (x, y, w, h — в пикселях canvas, radius — скругление).
  // Вызывающий сам выставляет globalAlpha и т.п.; состояние контекста сохраняется.
  // opts.ellipse = true — фигура не прямоугольник, а эллипс/круг, вписанный в x, y, w, h
  // (для компонента «Круг (заливка)»); radius при этом не используется.
  function paint(ctx, x, y, w, h, radius, props, opts) {
    const q = params(props);
    const [c0, c1] = endpoints(q);
    ctx.save();
    if (opts && opts.ellipse) {
      ctx.beginPath();
      ctx.ellipse(x + w / 2, y + h / 2, w / 2, h / 2, 0, 0, Math.PI * 2);
      ctx.closePath();
    } else roundRectPath(ctx, x, y, w, h, radius || 0);
    ctx.clip();
    let g;
    if (q.dir === 'radial' || q.dir === 'radial_in') {
      // Эллипс, вписанный в прямоугольник: у краёв ровно конечный цвет, как в CSS «closest-side».
      // Единичный круг растягивается до w/2 × h/2, поэтому заливаем единичный квадрат.
      ctx.translate(x + w / 2, y + h / 2);
      ctx.scale(Math.max(w, 1e-6) / 2, Math.max(h, 1e-6) / 2);
      g = ctx.createRadialGradient(0, 0, 0, 0, 0, 1);
      const inward = q.dir === 'radial_in';
      g.addColorStop(0, inward ? c1 : c0);
      g.addColorStop(1, inward ? c0 : c1);
      ctx.fillStyle = g;
      ctx.fillRect(-1, -1, 2, 2);
    } else {
      const cx = x + w / 2, cy = y + h / 2;
      let x0 = x, y0 = cy, x1 = x + w, y1 = cy;               // lr
      if (q.dir === 'rl') { x0 = x + w; x1 = x; }
      else if (q.dir === 'tb') { x0 = cx; y0 = y; x1 = cx; y1 = y + h; }
      else if (q.dir === 'bt') { x0 = cx; y0 = y + h; x1 = cx; y1 = y; }
      else if (q.dir === 'diag') { x0 = x; y0 = y; x1 = x + w; y1 = y + h; }
      g = ctx.createLinearGradient(x0, y0, x1, y1);
      g.addColorStop(0, c0);
      g.addColorStop(1, c1);
      ctx.fillStyle = g;
      ctx.fillRect(x, y, w, h);
    }
    ctx.restore();
  }

  // Растеризует прямоугольник w×h в прозрачный PNG. Возвращает canvas.
  function rasterize(w, h, radius, props, makeCanvas, opts) {
    const cv = makeCanvas();
    cv.width = w; cv.height = h;
    const ctx = cv.getContext('2d');
    ctx.clearRect(0, 0, w, h);
    paint(ctx, 0, 0, w, h, radius, props, opts);
    return cv;
  }

  return { DIRS, MODES, params, endpoints, paint, rasterize, roundRectPath };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = { RectGradient };
