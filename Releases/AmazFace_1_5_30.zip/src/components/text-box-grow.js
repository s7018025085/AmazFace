// Авто-рамка текста: когда размер шрифта увеличивают, рамка компонента (w/h) растёт вместе с ним,
// чтобы на часах надпись не обрезалась по краю. Рамка только растёт и только до размера надписи:
// уменьшение шрифта рамку не сжимает, а вручную увеличенную рамку функция не трогает.
// Расчёт идемпотентен (считается от самой надписи, а не от прошлого размера), поэтому
// набор «6» → «60» в поле «Размер шрифта» даёт тот же результат, что ввод «60» сразу.
const TextBoxGrow = (() => {
  const PAD_X = 0.12;   // запас по ширине, доля размера шрифта (с каждой стороны сумма)
  const LINE = 1.2;     // высота строки, доля размера шрифта

  // Чистая часть: даёт новую рамку {x, y, w, h} или null, если менять нечего.
  // textWidth — ширина надписи в px при новом размере (уже с учётом scale_x и letter_spacing).
  function grownBox(comp, textWidth, device) {
    const p = comp.props || {};
    const size = Number(p.text_size) || 0;
    if (!(size > 0) || !(textWidth >= 0)) return null;
    const sx = Number(p.scale_x || 1) || 1, sy = Number(p.scale_y || 1) || 1;
    const needW = Math.ceil(textWidth * sx + size * PAD_X);
    const needH = Math.ceil(size * Math.max(1, Number(p.line_height || 1)) * LINE * sy);
    let w = Math.max(Number(comp.w) || 0, needW);
    let h = Math.max(Number(comp.h) || 0, needH);
    if (device) { w = Math.min(w, Number(device.w) || w); h = Math.min(h, Number(device.h) || h); }
    if (w === comp.w && h === comp.h) return null;

    // Рамка растёт в сторону, противоположную выравниванию текста: у левого края — вправо,
    // у правого — влево, по центру — в обе стороны. Так надпись остаётся на месте.
    const ah = p.align_h || 'CENTER_H', av = p.align_v || 'CENTER_V';
    let x = ah === 'LEFT' ? comp.x : ah === 'RIGHT' ? comp.x + comp.w - w : comp.x + (comp.w - w) / 2;
    let y = av === 'TOP' ? comp.y : av === 'BOTTOM' ? comp.y + comp.h - h : comp.y + (comp.h - h) / 2;
    x = Math.round(x); y = Math.round(y);
    if (device) {   // не даём рамке уехать за экран
      x = Math.max(0, Math.min(x, (Number(device.w) || x + w) - w));
      y = Math.max(0, Math.min(y, (Number(device.h) || y + h) - h));
    }
    return { x, y, w: Math.round(w), h: Math.round(h) };
  }

  // Измерение надписи в браузере тем же шрифтом, каким её рисует холст.
  let _ctx = null;
  function measure(text, comp, fonts) {
    const p = comp.props || {};
    if (typeof document === 'undefined') return String(text).length * (Number(p.text_size) || 0) * 0.6;
    _ctx = _ctx || document.createElement('canvas').getContext('2d');
    const projectFont = (fonts || []).find((f) => f.id === p.font);
    const family = projectFont ? `'${projectFont.cssFamily || projectFont.name}', sans-serif` : "'Segoe UI', sans-serif";
    _ctx.font = `${p.font_style || 'normal'} ${p.font_weight || '400'} ${Number(p.text_size) || 28}px ${family}`;
    const ls = Number(p.letter_spacing || 0);
    return _ctx.measureText(String(text)).width + ls * String(text).length;
  }

  // Вызывается хранилищем после смены text_size. Возвращает true, если рамка изменилась.
  function onTextSizeChanged(comp, prevSize, state) {
    const def = REGISTRY[comp.defId];
    if (!def || def.widgetId !== 'TEXT') return false;
    const next = Number(comp.props.text_size) || 0;
    if (!(next > (Number(prevSize) || 0))) return false;       // уменьшение рамку не трогает
    let text = '';
    try { text = typeof componentPreviewText === 'function' ? componentPreviewText(comp, def) : String(comp.props.text ?? ''); }
    catch (e) { text = String(comp.props.text ?? ''); }
    if (text == null || text === '') text = String(comp.props.text ?? '');
    const box = grownBox(comp, measure(text, comp, state && state.fonts), state && state.device);
    if (!box) return false;
    Object.assign(comp, box);
    return true;
  }

  return { grownBox, measure, onTextSizeChanged, PAD_X, LINE };
})();
if (typeof module !== 'undefined' && module.exports) module.exports = TextBoxGrow;
