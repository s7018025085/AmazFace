// src/components/line-bar.js
// Модель компонента «Полоса» — ЕДИНАЯ для предпросмотра, редактора и экспорта.
//
// «Полоса» — это «Дуга», выпрямленная в горизонтальную или вертикальную полосу, с теми же настройками:
// источник данных (кольцо прогресса превращается в полосу прогресса), подложка, скруглённые концы,
// градиент и сегменты, контур, тень, прозрачность и анимации.
//
// У Zepp OS нет виджета «полоса», поэтому на часах она собирается из hmUI.widget.FILL_RECT
// (x, y, w, h, radius, color — свойства подтверждены docs.zepp.com): основная полоса, подложка,
// сегменты, слои контура и тени — это отдельные FILL_RECT, лежащие друг над другом. Скругление
// концов у полосы делается штатным свойством radius (в отличие от ARC, где нужен corner_flag).
//
// Ось. Все продольные координаты (u) — в пикселях от «начала» полосы:
//   горизонтальная — от левого края рамки компонента вправо,
//   вертикальная   — от НИЖНЕГО края рамки вверх (так растёт полоска заряда/прогресса).
// «Заполнять в обратную сторону» (reverse_fill) начинает заполнение с другого конца диапазона.
// Диапазон (range_start…range_end, % длины рамки) позволяет сделать полосу короче рамки.
//
// Классический <script> (как остальные файлы проекта); в Node подключается через vm.

const LineModel = (() => {
  const TIME_SOURCES = ['SECOND', 'MINUTE', 'HOUR', 'DAY', 'WEEKDAY', 'MONTH'];
  const SENSOR_SOURCES = ['BATTERY', 'STEP', 'CALORIE', 'DISTANCE', 'HEART'];
  const MODES = ['two', 'fade_in', 'fade_out'];
  const num = (v, d) => { const n = Number(v); return Number.isFinite(n) ? n : d; };
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const clamp01 = (v) => clamp(v, 0, 1);

  const isVertical = (p) => !!(p && p.orientation === 'VERTICAL');
  const isSegmented = (p) => !!(p && (p.gradient_enabled || p.segments_enabled));
  const mode = (p) => (p && p.gradient_enabled && MODES.includes(p.gradient_mode)) ? p.gradient_mode : 'two';
  // Скруглены ли концы: у сегментной полосы — настройка сегментов, у сплошной — «Скруглённые концы».
  const isRounded = (p) => isSegmented(p) ? !!(p && p.segment_rounded) : !!(p && p.rounded_ends);

  /** Геометрия в целых пикселях. comp: { x, y, w, h, props }. */
  function geom(comp) {
    const p = comp.props || {};
    const vertical = isVertical(p);
    const x = Math.round(num(comp.x, 0)), y = Math.round(num(comp.y, 0));
    const w = Math.max(1, Math.round(num(comp.w, 1))), h = Math.max(1, Math.round(num(comp.h, 1)));
    const len = vertical ? h : w;
    const thick = Math.max(1, Math.round(num(p.line_width, 8)));
    const rs = clamp(num(p.range_start, 0), 0, 100), re = clamp(num(p.range_end, 100), 0, 100);
    const lo = Math.round(len * Math.min(rs, re) / 100), hi = Math.round(len * Math.max(rs, re) / 100);
    return {
      vertical, x, y, w, h, len, thick, lo, hi,
      cx: x + Math.round(w / 2), cy: y + Math.round(h / 2),   // середина рамки (поперёк оси)
    };
  }

  /**
   * Полоска [u0, u1] вдоль оси, толщиной t, расширенная на s с каждой стороны и сдвинутая на dx/dy.
   * Возвращает свойства FILL_RECT { x, y, w, h, radius } в координатах экрана.
   * Формулы дублируются в сгенерированном index.js (функция <имя>_rect) — менять только вместе.
   */
  function rect(g, u0, u1, t, s = 0, dx = 0, dy = 0, rounded = false) {
    const n = u1 - u0 + 2 * s, th = t + 2 * s;
    const radius = rounded ? Math.floor(Math.min(n, th) / 2) : 0;
    if (g.vertical) return { x: g.cx - Math.floor(t / 2) - s + dx, y: g.y + g.h - u1 - s + dy, w: th, h: n, radius };
    return { x: g.x + u0 - s + dx, y: g.cy - Math.floor(t / 2) - s + dy, w: n, h: th, radius };
  }

  // --- Значение --------------------------------------------------------------
  function timeRatio(src, d) {
    switch (src) {
      case 'SECOND': return d.getSeconds() / 60;
      case 'MINUTE': return (d.getMinutes() + d.getSeconds() / 60) / 60;
      case 'HOUR': return ((d.getHours() % 12) + d.getMinutes() / 60) / 12;
      case 'DAY': return d.getDate() / new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
      case 'WEEKDAY': return (((d.getDay() + 6) % 7) + 1) / 7;
      case 'MONTH': return (d.getMonth() + 1) / 12;
      default: return 1;
    }
  }
  /** Доля заполнения 0..1 для предпросмотра в редакторе. */
  function previewRatio(p, now) {
    const src = (p && p.data_source) || 'NONE';
    if (src === 'NONE') return 1;
    if (TIME_SOURCES.includes(src)) return clamp01(timeRatio(src, now || new Date()));
    return clamp01(num(p.preview_percent, 70) / 100);
  }

  /** Заполненная часть диапазона [lo, hi]: [u0, u1] — от «начала» или (reverse) от конца. */
  function fillRange(p, g, ratio) {
    const span = g.hi - g.lo;
    return (p && p.reverse_fill)
      ? [Math.round(g.hi - span * ratio), g.hi]
      : [g.lo, Math.round(g.lo + span * ratio)];
  }

  // --- Сегменты и градиент -----------------------------------------------------
  function rgb(h) {
    let c = String(h || '#000000').replace('#', '');
    if (c.length === 3) c = c.split('').map((x) => x + x).join('');
    const n = parseInt(c, 16) || 0;
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }
  function mix(c1, c2, t) {
    const a = rgb(c1), b = rgb(c2);
    return '#' + a.map((v, i) => Math.round(v + (b[i] - v) * t).toString(16).padStart(2, '0')).join('');
  }
  /** Цвет и непрозрачность (0..1) сегмента i из N. Для режимов с прозрачностью берётся середина сегмента. */
  function segStyle(p, i, N, track) {
    if (track) return { color: p.track_color || '#2a3042', alpha: 1 };
    const base = p.color || '#3366ff';
    if (!p.gradient_enabled) return { color: base, alpha: 1 };
    const m = mode(p);
    if (m === 'fade_in') return { color: base, alpha: (i + 0.5) / N };
    if (m === 'fade_out') return { color: base, alpha: 1 - (i + 0.5) / N };
    return { color: mix(base, p.color2 || '#ff3366', N > 1 ? i / (N - 1) : 0), alpha: 1 };
  }
  /**
   * Раскладка N сегментов по диапазону [lo, hi] в целых пикселях: { N, a[], b[], gap }.
   * Промежуток segment_gap — в пикселях; ограничивается так, чтобы каждому сегменту осталось ≥ 1 px.
   * 1 px перекрытия — только у сплошной непрозрачной полосы без скруглений и без промежутка (чтобы не было щелей).
   */
  function segLayout(p, g) {
    const N = clamp(Math.round(num(p.gradient_steps, 24)), 2, 48);
    const span = g.hi - g.lo;
    const gapReq = Math.max(0, num(p.segment_gap, 0));
    const gap = Math.max(0, Math.min(gapReq, (span - N) / (N - 1)));
    const sw = (span - gap * (N - 1)) / N;
    const ov = (gap === 0 && !p.segment_rounded && mode(p) === 'two') ? 1 : 0;
    const a = [], b = [];
    for (let i = 0; i < N; i++) {
      const af = g.lo + i * (sw + gap);
      const ai = Math.round(af), bi = Math.round(af + sw);
      a.push(ai);
      b.push((i < N - 1 && ov) ? Math.min(bi + 1, g.hi) : bi);
    }
    return { N, a, b, gap };
  }
  /** Заполненные части сегментов для доли ratio: [{ a, b, color, alpha }] (u-координаты). */
  function segs(p, g, ratio, track) {
    const L = segLayout(p, g);
    const rev = !!p.reverse_fill && !track;
    const span = g.hi - g.lo;
    const cur = rev ? g.hi - span * ratio : g.lo + span * ratio;
    const out = [];
    for (let i = 0; i < L.N; i++) {
      const a = L.a[i], b = L.b[i];
      const c = Math.round(clamp(cur, a, b));
      // Цвет градиента считается от начала ЗАПОЛНЕНИЯ: при reverse — с конца диапазона.
      const st = segStyle(p, rev ? L.N - 1 - i : i, L.N, track);
      if (rev) { if (c === b) continue; out.push({ a: c, b, color: st.color, alpha: st.alpha }); }
      else { if (c === a) break; out.push({ a, b: c, color: st.color, alpha: st.alpha }); }
    }
    return out;
  }

  // --- Контур и тень -------------------------------------------------------------
  // Слои под основной полосой (снизу вверх): тень (1…5 слоёв) и контур. Слой — полоска по заполненной части,
  // шире основной на s с каждой стороны, со сдвигом dx/dy. Те же слои пишет экспортёр (виджеты FILL_RECT).
  function decoLayers(p, bg) {
    const out = [];
    if (!p) return out;
    const pct = (v, d) => clamp(num(v, d), 0, 100) / 100;
    const ow = p.outline_enabled ? Math.max(1, Math.round(num(p.outline_width, 2))) : 0;
    if (p.shadow_enabled) {
      const blur = Math.max(0, Math.round(num(p.shadow_blur, 0)));
      const K = blur > 0 ? Math.min(5, Math.max(2, Math.ceil(blur / 2))) : 1;
      const total = pct(p.shadow_alpha, 60);
      const dx = Math.round(num(p.shadow_dx, 0)), dy = Math.round(num(p.shadow_dy, 3));
      for (let i = 0; i < K; i++) {
        // от самого широкого (бледного) слоя к самому узкому: плотность растёт к центру
        const s = ow + (K > 1 ? Math.round(blur * (1 - i / (K - 1))) : 0);
        out.push({ kind: 'shadow', s, dx, dy, color: p.shadow_color || '#000000', alpha: total / K });
      }
    }
    if (ow) out.push({ kind: 'outline', s: ow, dx: 0, dy: 0, color: p.outline_color || '#000000', alpha: pct(p.outline_alpha, 100) });
    // Контур на весь диапазон без подложки: «окно» внутри рамки закрашивается цветом фона.
    if (ow && p.outline_full && !p.track_enabled && bg) out.push({ kind: 'hole', s: 0, dx: 0, dy: 0, color: bg, alpha: 1 });
    return out;
  }
  const decoFull = (p) => !!(p && p.outline_enabled && p.outline_full);

  return {
    TIME_SOURCES, SENSOR_SOURCES,
    isVertical, isSegmented, isRounded, mode,
    geom, rect, previewRatio, timeRatio, fillRange,
    segStyle, segLayout, segs, decoLayers, decoFull, mix,
  };
})();

if (typeof window !== 'undefined') window.LineModel = LineModel;
