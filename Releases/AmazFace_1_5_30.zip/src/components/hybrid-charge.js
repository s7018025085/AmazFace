'use strict';
// ---------------------------------------------------------------------------
// HybridChargeModel — настройки компонентов «HybridCharge» и «BioCharge» (только число).
//
// Оба компонента — один нативный TEXT_FONT с data_type: значение обновляет прошивка.
// Ни дуги, ни подписи нет. Одна модель на предпросмотр (renderer.js) и экспорт
// (index-js-exporter.js).
//
// ИСТОЧНИК ДАННЫХ. В docs.zepp.com есть только hmUI.data_type.READINESS («Physical and mental
// readiness», [0, 100]). С мая 2026 Zepp заменил Readiness и BioCharge на HybridCharge, поэтому на
// новой прошивке READINESS может показывать 0. Отдельная константа HybridCharge/BioCharge в
// публичной документации не описана, так что источник выбирается в настройках; режим «Авто»
// на часах берёт первую константу, которая реально существует в прошивке (по порядку из CHAINS).
// Классический <script>; в Node подключается через vm / module.exports.
// ---------------------------------------------------------------------------
const HybridChargeModel = (() => {
  const SOURCES = ['AUTO', 'HYBRID_CHARGE', 'BIO_CHARGE', 'READINESS'];
  // Порядок поиска в режиме «Авто» для каждого компонента.
  const CHAINS = {
    HYBRID_CHARGE: ['HYBRID_CHARGE', 'HYBRIDCHARGE', 'BIO_CHARGE', 'BIOCHARGE', 'READINESS'],
    BIO_CHARGE: ['BIO_CHARGE', 'BIOCHARGE', 'HYBRID_CHARGE', 'HYBRIDCHARGE', 'READINESS'],
  };
  const DEFAULTS = {
    data_source: 'AUTO',
    number_size: 56, number_color: '#ffffff', number_dx: 0, number_dy: 0, number_unit: false,
    // только редактор
    preview_value: 82,
  };

  const num = (v, d) => { const n = Number(v); return Number.isFinite(n) ? n : d; };
  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

  /** Свойства компонента с подстановкой значений по умолчанию и приведением типов. */
  function props(comp) {
    const p = Object.assign({}, comp && comp.props);
    const o = {};
    for (const k of Object.keys(DEFAULTS)) {
      const d = DEFAULTS[k];
      if (typeof d === 'boolean') o[k] = p[k] === undefined ? d : !(p[k] === false || p[k] === 'false');
      else if (typeof d === 'number') o[k] = num(p[k], d);
      else o[k] = (p[k] === undefined || p[k] === null || p[k] === '') ? d : String(p[k]);
    }
    o.font = p.font || null;
    o.data_source = SOURCES.includes(o.data_source) ? o.data_source : 'AUTO';
    o.preview_value = clamp(Math.round(o.preview_value), 0, 100);
    return o;
  }

  /** Рамка числа: рамка компонента, сдвинутая на number_dx / number_dy. */
  function boxes(comp) {
    const q = props(comp);
    return {
      number: {
        x: Math.round(num(comp.x, 0) + q.number_dx), y: Math.round(num(comp.y, 0) + q.number_dy),
        w: Math.max(10, Math.round(num(comp.w, 0))), h: Math.max(8, Math.round(num(comp.h, 0))),
      },
    };
  }

  /**
   * JS-выражение для поля `type` на часах. kind — 'HYBRID_CHARGE' или 'BIO_CHARGE'.
   * Явный источник — data_type.X. «Авто» — цепочка из тернарников: берётся первая константа,
   * которая в этой прошивке не undefined (иначе TEXT_FONT получил бы type: undefined).
   */
  function typeExpr(comp, kind) {
    const q = props(comp);
    if (q.data_source !== 'AUTO') return `data_type.${q.data_source}`;
    const chain = CHAINS[kind] || CHAINS.HYBRID_CHARGE;
    let expr = `data_type.${chain[chain.length - 1]}`;
    for (let i = chain.length - 2; i >= 0; i--) expr = `(data_type.${chain[i]} !== undefined ? data_type.${chain[i]} : ${expr})`;
    return expr;
  }

  return { DEFAULTS, SOURCES, CHAINS, props, boxes, typeExpr };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = { HybridChargeModel };
