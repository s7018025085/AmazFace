// src/components/dial.js
// Модель компонента «Циферблат» (шкала): метки по кругу + цифры.
// ЕДИНАЯ геометрия для редактора (SVG), предпросмотра (canvas 2D) и экспорта (PNG),
// чтобы то, что видно в редакторе, совпадало с тем, что окажется на часах.
//
// На часах готового виджета «шкала» нет, поэтому при экспорте весь циферблат запекается
// в один прозрачный PNG и выводится обычным IMG (как «Треугольник»). Так работают любые
// свои шрифты и он одинаково показывается в Normal и в AOD.
//
// Углы: 0° — 12 часов, по часовой стрелке. Классический <script>; в Node — через vm.

const DialModel = (() => {
  const TICK_SHAPES = ['LINE', 'DOT', 'SQUARE', 'DIAMOND', 'TRIANGLE', 'TRIANGLE_IN'];
  const MAX_RINGS = 6;
  const NUM_STYLES = ['ARABIC', 'ROMAN', 'MIXED12', 'DOTS_ONLY', 'NONE'];
  const ROMAN = ['XII', 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI'];

  const num = (v, d) => (Number.isFinite(Number(v)) && v !== '' && v !== null && v !== undefined ? Number(v) : d);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const pick = (v, list, d) => (list.includes(v) ? v : d);
  const color = (v, d) => (typeof v === 'string' && /^#[0-9a-fA-F]{3,8}$/.test(v) ? v : d);

  /** Для сравнения подписей: «05» == «5», регистр не важен. */
  function normLabel(t) {
    t = String(t == null ? '' : t).trim().toUpperCase();
    return /^\d+$/.test(t) ? String(parseInt(t, 10)) : t;
  }

  /** Число с ведущими нулями: fmtNum(5, 2) → «05». Дробные значения округляются до 0,001. */
  function fmtNum(v, pad) {
    v = Math.round(v * 1000) / 1000;
    const body = String(Math.abs(v)).padStart(pad, '0');
    return (v < 0 ? '-' : '') + body;
  }

  /** «1, 2; XII» → Set('1','2','XII') — какие подписи не показывать (сравнение по тексту цифры). */
  function hiddenSet(v) {
    return new Set(String(v == null ? '' : v).split(/[\s,;]+/).map(normLabel).filter(Boolean));
  }

  /** Тень: { on, color, alpha(0..1), blur, dx, dy } — один набор настроек для меток и для цифр. */
  function shadowParams(p, prefix) {
    return {
      on: !!p[prefix + '_enabled'],
      color: color(p[prefix + '_color'], '#000000'),
      alpha: clamp(num(p[prefix + '_alpha'], 60), 0, 100) / 100,
      blur: clamp(num(p[prefix + '_blur'], 4), 0, 40),
      dx: clamp(num(p[prefix + '_dx'], 2), -40, 40),
      dy: clamp(num(p[prefix + '_dy'], 2), -40, 40),
    };
  }

  /** #rgb / #rrggbb → rgba(r,g,b,a) для тени canvas. */
  function rgba(hex, a) {
    let c = String(hex || '#000000').replace('#', '');
    if (/^[0-9a-f]{3}$/i.test(c)) c = c.split('').map((v) => v + v).join('');
    if (!/^[0-9a-f]{6}/i.test(c)) c = '000000';
    const r = parseInt(c.slice(0, 2), 16), g = parseInt(c.slice(2, 4), 16), b = parseInt(c.slice(4, 6), 16);
    return `rgba(${r},${g},${b},${Math.round(a * 1000) / 1000})`;
  }

  const GRADIENTS = ['NONE', 'OUTER_CLEAR', 'INNER_CLEAR', 'TWO_COLORS'];
  const MAX_TICK_OUTLINES = 3;

  /** Градиент вдоль метки: OUTER_CLEAR — внешний конец прозрачный, внутренний — цвет; INNER_CLEAR — наоборот;
   *  TWO_COLORS — от цвета метки (снаружи) к другому цвету (внутри). */
  const gradParam = (v) => (GRADIENTS.includes(v) ? v : 'NONE');
  /** Направление треугольника: OUT — остриём наружу, IN — остриём внутрь (к центру). */
  const triParam = (v) => (v === 'IN' ? 'IN' : 'OUT');

  /** Обводки вокруг метки (до 3): gap — зазор между фигурой и обводкой, width — толщина, color — цвет. */
  function tickOutlines(p, kind) {
    const n = Math.round(clamp(num(p[kind + '_outlines'], 0), 0, MAX_TICK_OUTLINES));
    const out = [];
    for (let j = 1; j <= n; j++) {
      const pre = `${kind}_ol${j}_`;
      out.push({
        j,
        gap: clamp(num(p[pre + 'gap'], 3 * j - 1), 0, 60),
        width: clamp(num(p[pre + 'width'], 1), 0.1, 30),
        color: color(p[pre + 'color'], '#ffffff'),
      });
    }
    return out;
  }

  /** Кольца (до MAX_RINGS): inset — отступ от края шкалы, width — толщина, fill — сплошной круг, dash/gap — пунктир. */
  function ringsParams(p, R) {
    const n = Math.round(clamp(num(p.rings_count, 0), 0, MAX_RINGS));
    const out = [];
    for (let k = 1; k <= n; k++) {
      const pre = 'ring' + k + '_';
      out.push({
        k,
        inset: clamp(num(p[pre + 'inset'], 0), 0, R),
        width: clamp(num(p[pre + 'width'], 2), 0.1, 120),
        color: color(p[pre + 'color'], '#ffffff'),
        alpha: clamp(num(p[pre + 'alpha'], 100), 0, 100) / 100,
        fill: !!p[pre + 'fill'],
        dash: clamp(num(p[pre + 'dash'], 0), 0, 200),
        gap: clamp(num(p[pre + 'gap'], 0), 0, 200),
        shadow: shadowParams(p, pre + 'shadow'),
      });
    }
    return out;
  }

  /** Нормализованные параметры (значения по умолчанию совпадают с registry.js). */
  function params(comp) {
    const p = (comp && comp.props) || {};
    const w = Math.max(2, Math.round(num(comp && comp.w, 400)));
    const h = Math.max(2, Math.round(num(comp && comp.h, 400)));
    const R = Math.min(w, h) / 2;
    const ticksPerHour = Math.round(clamp(num(p.minor_per_major, 5), 1, 30)); // сколько мелких делений в одной секции
    const sections = Math.round(clamp(num(p.sections, 12), 1, 60));           // число секций (основных меток)
    return {
      w, h, cx: w / 2, cy: h / 2, R,
      sections,
      minorPerSection: ticksPerHour,
      startAngle: num(p.start_angle, 0),

      minorEnabled: p.minor_enabled !== false,
      minorShape: pick(p.minor_shape, TICK_SHAPES, 'LINE'),
      minorLen: clamp(num(p.minor_length, 10), 0.1, R),
      minorWidth: clamp(num(p.minor_width, 2), 0.1, 60),
      minorRound: !!p.minor_round,
      minorOutline: clamp(num(p.minor_outline, 0), 0, 20),
      minorTri: triParam(p.minor_tri_dir), minorGrad: gradParam(p.minor_grad), minorGradColor: color(p.minor_grad_color2, '#ff9f1a'), minorOl: tickOutlines(p, 'minor'),
      minorColor: color(p.minor_color, '#888888'),
      minorInset: clamp(num(p.minor_inset, 0), 0, R),   // отступ от края

      majorEnabled: p.major_enabled !== false,
      majorShape: pick(p.major_shape, TICK_SHAPES, 'LINE'),
      majorLen: clamp(num(p.major_length, 22), 0.1, R),
      majorWidth: clamp(num(p.major_width, 4), 0.1, 80),
      majorRound: !!p.major_round,
      majorOutline: clamp(num(p.major_outline, 0), 0, 20),
      majorTri: triParam(p.major_tri_dir), majorGrad: gradParam(p.major_grad), majorGradColor: color(p.major_grad_color2, '#ff9f1a'), majorOl: tickOutlines(p, 'major'),
      majorColor: color(p.major_color, '#ffffff'),
      majorInset: clamp(num(p.major_inset, 0), 0, R),

      // Особые метки на 12·3·6·9 (если число делений делится на 4) — заменяют основные в этих местах.
      cardinalEnabled: !!p.cardinal_enabled,
      cardinalShape: pick(p.cardinal_shape, TICK_SHAPES, 'LINE'),
      cardinalLen: clamp(num(p.cardinal_length, 34), 0.1, R),
      cardinalWidth: clamp(num(p.cardinal_width, 6), 0.1, 100),
      cardinalColor: color(p.cardinal_color, '#ff9f1a'),
      cardinalInset: clamp(num(p.cardinal_inset, 0), 0, R),
      cardinalRound: !!p.cardinal_round,
      cardinalOutline: clamp(num(p.cardinal_outline, 0), 0, 20),
      cardinalTri: triParam(p.cardinal_tri_dir), cardinalGrad: gradParam(p.cardinal_grad), cardinalGradColor: color(p.cardinal_grad_color2, '#ff9f1a'), cardinalOl: tickOutlines(p, 'cardinal'),

      numStyle: pick(p.num_style, NUM_STYLES, 'ARABIC'),
      numCustom: String(p.num_custom == null ? '' : p.num_custom).split(/[,;]/).map((x) => x.trim()),
      numCustomOn: String(p.num_custom == null ? '' : p.num_custom).trim() !== '',
      numItalic: !!p.num_italic,
      numStroke: { on: !!p.num_stroke_enabled, color: color(p.num_stroke_color, '#000000'), width: clamp(num(p.num_stroke_width, 2), 0.1, 40) },
      numCount: Math.round(clamp(num(p.num_count, 12), 1, 60)),   // сколько цифр по кругу (обычно 12, 4, 6…)
      numRadius: clamp(num(p.num_radius, 0), 0, R * 2),           // 0 = авто (внутрь от меток)
      numSize: clamp(num(p.num_size, 36), 1, 400),
      numColor: color(p.num_color, '#ffffff'),
      numRotate: !!p.num_rotate,
      // Поворот цифр: NONE — прямо; UPRIGHT — по касательной, но читаемо (внизу не вверх ногами);
      // FULL — по касательной, верх цифры всегда смотрит наружу (как на «приборных» шкалах).
      numRotateMode: ['NONE', 'UPRIGHT', 'FULL'].includes(p.num_rotate_mode) ? p.num_rotate_mode : (p.num_rotate ? 'UPRIGHT' : 'NONE'),
      numStart: num(p.num_start, 1),                              // значение первой цифры (после верхней позиции)
      numStep: num(p.num_step, 1),                                // шаг: 1 → 1,2,3…; 5 → 5,10,15…
      numPad: Math.round(clamp(num(p.num_pad, 1), 1, 4)),         // ведущие нули: 2 → 05, 10
      numTopFirst: !!p.num_top_first,                             // верхняя позиция — нулевая (00), а не последняя (60)
      numWeight: String(p.num_weight || '400'),
      numFont: p.font || '',
      numOffset: clamp(num(p.num_offset, 0), -R, R),              // сдвиг от авто-радиуса

      rings: ringsParams(p, R),

      numHidden: hiddenSet(p.num_hidden),

      tickShadow: shadowParams(p, 'tick_shadow'),
      numShadow: shadowParams(p, 'num_shadow'),

      alpha: clamp(num(p.alpha, 100), 0, 100) / 100,
    };
  }

  /** Текст цифры для позиции i из n (i=0 — вверху, 12 часов). */
  function labelText(q, i) {
    if (q.numStyle === 'NONE' || q.numStyle === 'DOTS_ONLY') return '';
    const n = q.numCount;
    if (q.numCustomOn) return q.numCustom[i] || ''; // свой список подписей по кругу, начиная с верхней
    if (q.numStyle === 'ROMAN') return n === 12 ? ROMAN[i % 12] : toRoman(i === 0 ? n : i);
    // Номер позиции j: 1..n (вверху — n, как «12»), либо 0..n-1, если «вверху нулевая».
    const j = q.numTopFirst ? i : (i === 0 ? n : i);
    const text = fmtNum(q.numStart + q.numStep * (j - 1), q.numPad);
    if (q.numStyle === 'MIXED12') return n === 12 ? ([0, 3, 6, 9].includes(i) ? text : '') : text;
    return text;
  }
  function toRoman(v) {
    const map = [[1000, 'M'], [900, 'CM'], [500, 'D'], [400, 'CD'], [100, 'C'], [90, 'XC'], [50, 'L'], [40, 'XL'], [10, 'X'], [9, 'IX'], [5, 'V'], [4, 'IV'], [1, 'I']];
    let s = '';
    for (const [a, r] of map) while (v >= a) { s += r; v -= a; }
    return s;
  }

  const pol = (q, deg, r) => {
    const th = ((deg + q.startAngle) * Math.PI) / 180;
    return { x: q.cx + r * Math.sin(th), y: q.cy - r * Math.cos(th), th };
  };

  /** Все метки: [{ kind:'major'|'minor', angle, shape, len, width, color, x1,y1 (внешний конец), x2,y2 (внутренний) }]. */
  function ticks(comp) {
    const q = params(comp);
    const out = [];
    const total = q.sections * q.minorPerSection;
    for (let i = 0; i < total; i++) {
      const atSection = i % q.minorPerSection === 0;
      const cardinal = q.cardinalEnabled && total % 4 === 0 && (i * 4) % total === 0;
      // Приоритет: особая (12·3·6·9) → основная (граница секции) → мелкая.
      const major = !cardinal && atSection && q.majorEnabled;
      if (!cardinal && !major && !q.minorEnabled) continue;
      const kind = cardinal ? 'cardinal' : major ? 'major' : 'minor';
      const angle = (360 * i) / total;
      const shape = cardinal ? q.cardinalShape : major ? q.majorShape : q.minorShape;
      const len = cardinal ? q.cardinalLen : major ? q.majorLen : q.minorLen;
      const width = cardinal ? q.cardinalWidth : major ? q.majorWidth : q.minorWidth;
      const inset = cardinal ? q.cardinalInset : major ? q.majorInset : q.minorInset;
      const round = cardinal ? q.cardinalRound : major ? q.majorRound : q.minorRound;
      const outline = cardinal ? q.cardinalOutline : major ? q.majorOutline : q.minorOutline;
      const grad = cardinal ? q.cardinalGrad : major ? q.majorGrad : q.minorGrad;
      const gradColor = cardinal ? q.cardinalGradColor : major ? q.majorGradColor : q.minorGradColor;
      const outlines = cardinal ? q.cardinalOl : major ? q.majorOl : q.minorOl;
      let triDir = cardinal ? q.cardinalTri : major ? q.majorTri : q.minorTri;
      let shapeN = shape;
      if (shape === 'TRIANGLE_IN') { shapeN = 'TRIANGLE'; triDir = 'IN'; }   // старое значение: «треугольник остриём внутрь»
      const rOut = Math.max(0, q.R - inset);
      const rIn = Math.max(0, rOut - len);
      const a = pol(q, angle, rOut), b = pol(q, angle, rIn);
      out.push({
        kind, angle, shape: shapeN, len, width, round, outline, grad, gradColor, outlines, triDir,
        color: cardinal ? q.cardinalColor : major ? q.majorColor : q.minorColor,
        rOut, rIn, x1: a.x, y1: a.y, x2: b.x, y2: b.y, th: a.th,
        mx: (a.x + b.x) / 2, my: (a.y + b.y) / 2,
      });
    }
    return out;
  }

  /** Авто-радиус цифр: внутрь от самой длинной метки + половина размера цифры. */
  function autoNumRadius(q) {
    const innerMajor = q.majorEnabled ? q.majorInset + q.majorLen : 0;
    const innerMinor = q.minorEnabled ? q.minorInset + q.minorLen : 0;
    const innerCard = q.cardinalEnabled ? q.cardinalInset + q.cardinalLen : 0;
    const edge = Math.max(innerMajor, innerMinor, innerCard);
    return Math.max(0, q.R - edge - q.numSize * 0.75 - 4);
  }

  /** Подписи: [{ text, x, y, rot, size, color }] — по числу q.numCount вокруг круга. */
  function labels(comp) {
    const q = params(comp);
    if (q.numStyle === 'NONE') return [];
    const out = [];
    const r = (q.numRadius > 0 ? q.numRadius : autoNumRadius(q)) + q.numOffset;
    for (let i = 0; i < q.numCount; i++) {
      const text = labelText(q, i);
      if (!text) continue;
      if (q.numHidden.has(normLabel(text))) continue; // скрытые пользователем цифры
      const angle = (360 * i) / q.numCount;
      const pt = pol(q, angle, Math.max(0, r));
      let rot = 0;
      if (q.numRotateMode !== 'NONE') {
        rot = ((angle + q.startAngle) % 360 + 360) % 360;
        if (rot > 180) rot -= 360;
        if (q.numRotateMode === 'UPRIGHT') { if (rot > 90) rot -= 180; else if (rot < -90) rot += 180; } // не вверх ногами внизу
      }
      out.push({ text, x: pt.x, y: pt.y, rot, size: q.numSize, color: q.numColor, angle });
    }
    return out;
  }

  const fontFamily = (fontObj) => (fontObj ? `'${fontObj.cssFamily || fontObj.name}', sans-serif` : 'sans-serif');

  // Тень в canvas 2D: shadowBlur не масштабируется матрицей и смещение тоже в пикселях холста — поэтому умножаем на s сами.
  function applyShadow(ctx, sh, s) {
    if (!sh || !sh.on || sh.alpha <= 0) return;
    ctx.shadowColor = rgba(sh.color, sh.alpha);
    ctx.shadowBlur = sh.blur * s;
    ctx.shadowOffsetX = sh.dx * s;
    ctx.shadowOffsetY = sh.dy * s;
  }

  // ---- геометрия метки: выпуклое «ядро» + скругление r0 (сумма Минковского). Любая фигура меток
  //      (палочка, скруглённая палочка, кружок, квадрат, ромб, треугольник) — это ядро и радиус r0.
  //      Обводка со смещением — то же ядро с радиусом r0 + зазор + половина толщины. Локальные
  //      координаты: центр метки в (0,0), внешний конец — в сторону -y.
  function tickGeom(t) {
    const L = t.len, W = t.width;
    switch (t.shape) {
      case 'DOT': { const rr = Math.max(0.5, W / 2); return { core: [[0, -L / 2 + rr]], r0: rr, y0: -L / 2, y1: -L / 2 + 2 * rr }; }
      case 'SQUARE': { const h = Math.min(L, W); return { core: [[-W / 2, -L / 2], [W / 2, -L / 2], [W / 2, -L / 2 + h], [-W / 2, -L / 2 + h]], r0: 0, y0: -L / 2, y1: -L / 2 + h }; }
      case 'DIAMOND': { const h = Math.max(W, 1) / 2; return { core: [[0, -L / 2], [h, -L / 2 + h], [0, -L / 2 + 2 * h], [-h, -L / 2 + h]], r0: 0, y0: -L / 2, y1: -L / 2 + 2 * h }; }
      case 'TRIANGLE': return {
        core: t.triDir === 'IN' ? [[0, L / 2], [-W / 2, -L / 2], [W / 2, -L / 2]] : [[0, -L / 2], [W / 2, L / 2], [-W / 2, L / 2]],
        r0: 0, y0: -L / 2, y1: L / 2,
      };
      default: { // LINE
        if (t.round) {
          const r = Math.min(W, L) / 2, hx = W / 2 - r, hy = L / 2 - r;
          const core = hx > 1e-9 ? [[-hx, -hy], [hx, -hy], [hx, hy], [-hx, hy]] : (hy > 1e-9 ? [[0, -hy], [0, hy]] : [[0, 0]]);
          return { core, r0: r, y0: -L / 2, y1: L / 2 };
        }
        return { core: [[-W / 2, -L / 2], [W / 2, -L / 2], [W / 2, L / 2], [-W / 2, L / 2]], r0: 0, y0: -L / 2, y1: L / 2 };
      }
    }
  }

  /**
   * Контур «ядро ⊕ круг радиуса r» как список операций: ['C',cx,cy,r] (круг) или
   * ['M',x,y], ['L',x,y], ['A',cx,cy,r,a0,a1] (дуга по часовой от a0 к a1), ['Z'].
   * Углы дуг — как в canvas (atan2 при оси y вниз), поэтому одни и те же операции рисуют и canvas, и SVG.
   */
  function offsetOps(core, r) {
    r = Math.max(0, r);
    if (core.length === 1) return [['C', core[0][0], core[0][1], r]];
    let pts = core.map((q) => [q[0], q[1]]);
    if (pts.length > 2) {
      let area = 0;
      for (let i = 0; i < pts.length; i++) { const a = pts[i], b = pts[(i + 1) % pts.length]; area += a[0] * b[1] - b[0] * a[1]; }
      if (area < 0) pts.reverse();                 // на экране (y вниз) обход должен идти по часовой стрелке
    }
    const n = pts.length;
    const nrm = pts.map((a, i) => {
      const b = pts[(i + 1) % n];
      const dx = b[0] - a[0], dy = b[1] - a[1], d = Math.hypot(dx, dy) || 1;
      return [dy / d, -dx / d];                    // внешняя нормаль ребра
    });
    const ops = [];
    for (let i = 0; i < n; i++) {
      const a = pts[i], b = pts[(i + 1) % n], nm = nrm[i], nx = nrm[(i + 1) % n];
      if (i === 0) ops.push(['M', a[0] + nm[0] * r, a[1] + nm[1] * r]);
      ops.push(['L', b[0] + nm[0] * r, b[1] + nm[1] * r]);
      const a0 = Math.atan2(nm[1], nm[0]);
      let a1 = Math.atan2(nx[1], nx[0]);
      while (a1 < a0) a1 += Math.PI * 2;
      if (a1 - a0 > 1e-9 && r > 0) ops.push(['A', b[0], b[1], r, a0, a1]);
      else if (i < n - 1) ops.push(['L', b[0] + nx[0] * r, b[1] + nx[1] * r]);
    }
    ops.push(['Z']);
    return ops;
  }

  function emitOps(ctx, ops, s) {
    ctx.beginPath();
    for (const o of ops) {
      switch (o[0]) {
        case 'C': ctx.arc(o[1] * s, o[2] * s, o[3] * s, 0, Math.PI * 2); break;
        case 'M': ctx.moveTo(o[1] * s, o[2] * s); break;
        case 'L': ctx.lineTo(o[1] * s, o[2] * s); break;
        case 'A': ctx.arc(o[1] * s, o[2] * s, o[3] * s, o[4], o[5], false); break;
        default: ctx.closePath();
      }
    }
  }

  function opsToSvg(ops) {
    if (ops[0][0] === 'C') return { tag: 'circle', attrs: `cx="${f(ops[0][1])}" cy="${f(ops[0][2])}" r="${f(ops[0][3])}"` };
    const d = ops.map((o) => {
      switch (o[0]) {
        case 'M': return `M${f(o[1])} ${f(o[2])}`;
        case 'L': return `L${f(o[1])} ${f(o[2])}`;
        case 'A': return `A${f(o[3])} ${f(o[3])} 0 ${o[5] - o[4] > Math.PI ? 1 : 0} 1 ${f(o[1] + o[3] * Math.cos(o[5]))} ${f(o[2] + o[3] * Math.sin(o[5]))}`;
        default: return 'Z';
      }
    }).join('');
    return { tag: 'path', attrs: `d="${d}"` };
  }

  // ---- рисование метки в canvas 2D (s — масштаб предпросмотра, ox/oy — смещение) ----
  function paintTick(ctx, t, s, ox, oy) {
    ctx.save();
    ctx.translate(ox + t.mx * s, oy + t.my * s);
    ctx.rotate(t.th);
    const L = t.len * s, W = t.width * s;
    const hollow = t.outline > 0;                 // «только контур»: толщина контура в px, 0 — залитая
    const geom = tickGeom(t);
    let paintStyle = t.color;
    if (t.grad && t.grad !== 'NONE' && ctx.createLinearGradient) {
      // Градиент идёт вдоль метки: от внешнего конца (y0) к внутреннему (y1); «прозрачный» — тот же цвет с альфой 0.
      const gr = ctx.createLinearGradient(0, geom.y0 * s, 0, geom.y1 * s);
      if (t.grad === 'TWO_COLORS') {
        gr.addColorStop(0, t.color);              // снаружи — цвет метки
        gr.addColorStop(1, t.gradColor);          // внутри — второй цвет
      } else {
        const clear = rgba(t.color, 0);
        gr.addColorStop(0, t.grad === 'OUTER_CLEAR' ? clear : t.color);
        gr.addColorStop(1, t.grad === 'OUTER_CLEAR' ? t.color : clear);
      }
      paintStyle = gr;
    }
    ctx.fillStyle = paintStyle; ctx.strokeStyle = paintStyle; ctx.lineJoin = 'round';
    if (hollow) ctx.lineWidth = t.outline * s;
    const done = () => { if (hollow) ctx.stroke(); else ctx.fill(); };
    switch (t.shape) {
      case 'DOT': { const rr = Math.max(0.5 * s, W / 2); ctx.beginPath(); ctx.arc(0, -L / 2 + rr, rr, 0, Math.PI * 2); done(); break; }
      case 'SQUARE': { const h = Math.min(L, W); ctx.beginPath(); ctx.rect(-W / 2, -L / 2, W, h); done(); break; }
      case 'DIAMOND': { const h = Math.max(W, 1 * s) / 2; ctx.beginPath(); ctx.moveTo(0, -L / 2); ctx.lineTo(h, -L / 2 + h); ctx.lineTo(0, -L / 2 + 2 * h); ctx.lineTo(-h, -L / 2 + h); ctx.closePath(); done(); break; }
      case 'TRIANGLE':
        ctx.beginPath();
        if (t.triDir === 'IN') { ctx.moveTo(0, L / 2); ctx.lineTo(W / 2, -L / 2); ctx.lineTo(-W / 2, -L / 2); }
        else { ctx.moveTo(0, -L / 2); ctx.lineTo(W / 2, L / 2); ctx.lineTo(-W / 2, L / 2); }
        ctx.closePath(); done(); break;
      default: // LINE
        if (t.round) {
          const r = Math.min(W, L) / 2, x = -W / 2, y = -L / 2;
          ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + W, y, x + W, y + L, r); ctx.arcTo(x + W, y + L, x, y + L, r); ctx.arcTo(x, y + L, x, y, r); ctx.arcTo(x, y, x + W, y, r); ctx.closePath(); done();
        } else if (hollow) { ctx.beginPath(); ctx.rect(-W / 2, -L / 2, W, L); ctx.stroke(); }
        else ctx.fillRect(-W / 2, -L / 2, W, L);
    }
    // Обводки вокруг метки: линия толщиной o.width, отстоящая от края фигуры на o.gap.
    for (const o of (t.outlines || [])) {
      ctx.strokeStyle = o.color; ctx.lineWidth = o.width * s; ctx.lineJoin = 'round';
      emitOps(ctx, offsetOps(geom.core, geom.r0 + o.gap + o.width / 2), s);
      ctx.stroke();
    }
    ctx.restore();
  }

  /**
   * Рисует весь циферблат в ctx. fontObj — объект шрифта проекта (или null).
   * s — масштаб, (ox,oy) — левый верхний угол компонента в системе ctx.
   */
  function paint(ctx, comp, fontObj, s = 1, ox = 0, oy = 0) {
    const q = params(comp);
    ctx.save();
    ctx.globalAlpha *= q.alpha;
    for (const r of q.rings) {       // кольца рисуются под метками, по порядку 1…N
      ctx.save();
      ctx.globalAlpha *= r.alpha;
      applyShadow(ctx, r.shadow, s);
      ctx.beginPath();
      if (r.fill) {
        ctx.fillStyle = r.color;
        ctx.arc(ox + q.cx * s, oy + q.cy * s, Math.max(0, q.R - r.inset) * s, 0, Math.PI * 2);
        ctx.fill();
      } else {
        ctx.strokeStyle = r.color; ctx.lineWidth = r.width * s;
        if (r.dash > 0 && r.gap > 0 && ctx.setLineDash) ctx.setLineDash([r.dash * s, r.gap * s]);
        ctx.arc(ox + q.cx * s, oy + q.cy * s, Math.max(0, q.R - r.inset - r.width / 2) * s, 0, Math.PI * 2);
        ctx.stroke();
      }
      ctx.restore();
    }
    ctx.save();
    applyShadow(ctx, q.tickShadow, s);   // тень меток — отдельно от тени цифр
    for (const t of ticks(comp)) paintTick(ctx, t, s, ox, oy);
    ctx.restore();
    const fam = fontFamily(fontObj);
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    for (const l of labels(comp)) {
      ctx.save();
      ctx.translate(ox + l.x * s, oy + l.y * s);
      if (l.rot) ctx.rotate((l.rot * Math.PI) / 180);
      applyShadow(ctx, q.numShadow, s);
      ctx.font = `${q.numItalic ? 'italic ' : ''}${q.numWeight} ${l.size * s}px ${fam}`;
      if (q.numStroke.on) {
        // Контур цифр: рисуем под заливкой в 2× ширины (видна внешняя половина). Тень — только от контура.
        ctx.lineJoin = 'round'; ctx.strokeStyle = q.numStroke.color; ctx.lineWidth = q.numStroke.width * 2 * s;
        ctx.strokeText(l.text, 0, 0);
        ctx.shadowColor = 'rgba(0,0,0,0)';
      }
      ctx.fillStyle = l.color;
      ctx.fillText(l.text, 0, 0);
      ctx.restore();
    }
    ctx.restore();
  }

  const esc = (v) => String(v).replace(/[^#0-9a-zA-Z(),.% -]/g, '');
  const escText = (v) => String(v).replace(/&/g, '&amp;').replace(/</g, '&lt;');
  const f = (n) => Math.round(n * 100) / 100;

  /** SVG-разметка для холста редактора (viewBox = Ш×В компонента). */
  function toSvg(comp, fontObj) {
    const q = params(comp);
    const parts = [];
    const sid = String(comp && comp.id || 'd').replace(/[^a-zA-Z0-9_-]/g, '_');
    // feDropShadow: stdDeviation = blur/2 (так же, как shadowBlur в canvas).
    const filt = (id, sh) => `<filter id="${id}" filterUnits="userSpaceOnUse" x="${-q.w}" y="${-q.h}" width="${q.w * 3}" height="${q.h * 3}"><feDropShadow dx="${sh.dx}" dy="${sh.dy}" stdDeviation="${f(sh.blur / 2)}" flood-color="${esc(sh.color)}" flood-opacity="${sh.alpha}"/></filter>`;
    const defs = [];
    const tickFilter = q.tickShadow.on ? `dsh-${sid}-t` : '';
    const numFilter = q.numShadow.on ? `dsh-${sid}-n` : '';
    if (tickFilter) defs.push(filt(tickFilter, q.tickShadow));
    for (const r of q.rings) if (r.shadow.on) defs.push(filt(`dsh-${sid}-r${r.k}`, r.shadow));
    if (numFilter) defs.push(filt(numFilter, q.numShadow));
    for (const r of q.rings) {
      const flt = r.shadow.on ? ` filter="url(#dsh-${sid}-r${r.k})"` : '';
      const op = r.alpha < 1 ? ` opacity="${r.alpha}"` : '';
      if (r.fill) parts.push(`<circle cx="${f(q.cx)}" cy="${f(q.cy)}" r="${f(Math.max(0, q.R - r.inset))}" fill="${esc(r.color)}"${op}${flt}/>`);
      else parts.push(`<circle cx="${f(q.cx)}" cy="${f(q.cy)}" r="${f(Math.max(0, q.R - r.inset - r.width / 2))}" fill="none" stroke="${esc(r.color)}" stroke-width="${f(r.width)}"${r.dash > 0 && r.gap > 0 ? ` stroke-dasharray="${f(r.dash)} ${f(r.gap)}"` : ''}${op}${flt}/>`);
    }
    const tickParts = [];
    const gradDone = new Set();
    for (const t of ticks(comp)) {
      const deg = (t.th * 180) / Math.PI;
      const tr = `translate(${f(t.mx)} ${f(t.my)}) rotate(${f(deg)})`;
      const L = t.len, W = t.width, c = esc(t.color);
      const geom = tickGeom(t);
      let fillRef = c;
      if (t.grad && t.grad !== 'NONE') {
        const gid = `dg-${sid}-${t.kind}`;
        fillRef = `url(#${gid})`;
        if (!gradDone.has(gid)) {
          gradDone.add(gid);
          const two = t.grad === 'TWO_COLORS';
          const o0 = two ? 1 : (t.grad === 'OUTER_CLEAR' ? 0 : 1), o1 = two ? 1 : (t.grad === 'OUTER_CLEAR' ? 1 : 0);
          const c1 = two ? esc(t.gradColor) : c;
          defs.push(`<linearGradient id="${gid}" gradientUnits="userSpaceOnUse" x1="0" y1="${f(geom.y0)}" x2="0" y2="${f(geom.y1)}"><stop offset="0" stop-color="${c}" stop-opacity="${o0}"/><stop offset="1" stop-color="${c1}" stop-opacity="${o1}"/></linearGradient>`);
        }
      }
      const paintAttr = t.outline > 0 ? `fill="none" stroke="${fillRef}" stroke-width="${f(t.outline)}" stroke-linejoin="round"` : `fill="${fillRef}"`;
      let shape;
      switch (t.shape) {
        case 'DOT': { const rr = Math.max(0.5, W / 2); shape = `<circle cx="0" cy="${f(-L / 2 + rr)}" r="${f(rr)}" ${paintAttr}/>`; break; }
        case 'SQUARE': shape = `<rect x="${f(-W / 2)}" y="${f(-L / 2)}" width="${f(W)}" height="${f(Math.min(L, W))}" ${paintAttr}/>`; break;
        case 'DIAMOND': { const h = Math.max(W, 1) / 2; shape = `<polygon points="0,${f(-L / 2)} ${f(h)},${f(-L / 2 + h)} 0,${f(-L / 2 + 2 * h)} ${f(-h)},${f(-L / 2 + h)}" ${paintAttr}/>`; break; }
        case 'TRIANGLE': shape = t.triDir === 'IN'
          ? `<polygon points="0,${f(L / 2)} ${f(W / 2)},${f(-L / 2)} ${f(-W / 2)},${f(-L / 2)}" ${paintAttr}/>`
          : `<polygon points="0,${f(-L / 2)} ${f(W / 2)},${f(L / 2)} ${f(-W / 2)},${f(L / 2)}" ${paintAttr}/>`; break;
        default: shape = `<rect x="${f(-W / 2)}" y="${f(-L / 2)}" width="${f(W)}" height="${f(L)}"${t.round ? ` rx="${f(Math.min(W, L) / 2)}"` : ''} ${paintAttr}/>`;
      }
      for (const o of (t.outlines || [])) {
        const g = opsToSvg(offsetOps(geom.core, geom.r0 + o.gap + o.width / 2));
        shape += `<${g.tag} ${g.attrs} fill="none" stroke="${esc(o.color)}" stroke-width="${f(o.width)}" stroke-linejoin="round"/>`;
      }
      tickParts.push(`<g transform="${tr}">${shape}</g>`);
    }
    parts.push(tickFilter ? `<g filter="url(#${tickFilter})">${tickParts.join('')}</g>` : tickParts.join(''));
    const fam = fontFamily(fontObj).replace(/'/g, '&apos;');
    const labelParts = [];
    for (const l of labels(comp)) {
      const rot = l.rot ? ` rotate(${f(l.rot)})` : '';
      labelParts.push(`<text transform="translate(${f(l.x)} ${f(l.y)})${rot}" text-anchor="middle" dominant-baseline="central" font-family="${fam}" font-weight="${esc(q.numWeight)}"${q.numItalic ? ' font-style="italic"' : ''} font-size="${f(l.size)}" fill="${esc(l.color)}"${q.numStroke.on ? ` stroke="${esc(q.numStroke.color)}" stroke-width="${f(q.numStroke.width * 2)}" stroke-linejoin="round" paint-order="stroke"` : ''}>${escText(l.text)}</text>`);
    }
    parts.push(numFilter ? `<g filter="url(#${numFilter})">${labelParts.join('')}</g>` : labelParts.join(''));
    return `<svg data-dial="1" width="100%" height="100%" viewBox="0 0 ${q.w} ${q.h}" style="display:block;overflow:visible" opacity="${q.alpha}">${defs.length ? `<defs>${defs.join('')}</defs>` : ''}${parts.join('')}</svg>`;
  }

  return { TICK_SHAPES, NUM_STYLES, GRADIENTS, params, ticks, labels, labelText, autoNumRadius, tickGeom, offsetOps, paint, toSvg };
})();

// Для Node-тестов (в браузере module не определён).
if (typeof module !== 'undefined' && module.exports) module.exports = DialModel;
