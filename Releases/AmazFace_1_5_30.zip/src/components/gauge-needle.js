// src/components/gauge-needle.js
// Модель компонента «Стрелочный датчик»: PNG-стрелка, которая поворачивается вокруг оси
// пропорционально значению (пульс, шаги, батарея, время и т.д.).
// ЕДИНАЯ логика углов для редактора, предпросмотра (renderer.js) и экспорта (index-js-exporter.js).
//
// Углы: как у компонента «Дуга» — 0° это 12 часов, растут по часовой стрелке. PNG стрелки
// рисуется кончиком ВВЕРХ (поворот 0° = исходная картинка), как и у обычных стрелок часов.
// Стрелка стоит на start_angle при «пусто» и приходит на end_angle при «полно».
// Классический <script>; в Node — через vm.

const GaugeNeedleModel = (() => {
  const SENSOR_SOURCES = ['BATTERY', 'STEP', 'CALORIE', 'DISTANCE', 'HEART'];
  const TIME_SOURCES = ['SECOND', 'MINUTE', 'HOUR', 'DAY', 'WEEKDAY', 'MONTH'];
  const SOURCES = ['NONE', ...SENSOR_SOURCES, ...TIME_SOURCES];
  // Значение «полно» по умолчанию (как у дуги), если value_max = 0.
  const DEFAULT_MAX = { BATTERY: 100, STEP: 10000, CALORIE: 500, DISTANCE: 5, HEART: 200 };

  const num = (v, d) => (v !== '' && v !== null && v !== undefined && Number.isFinite(Number(v)) ? Number(v) : d);
  const clamp01 = (v) => Math.max(0, Math.min(1, v));

  /** Доля круга/диапазона для источников времени (те же формулы, что у дуги и в index.js). */
  function timeRatio(src, d) {
    switch (src) {
      case 'SECOND': return d.getSeconds() / 60;
      case 'MINUTE': return (d.getMinutes() + d.getSeconds() / 60) / 60;
      case 'HOUR': return ((d.getHours() % 12) + d.getMinutes() / 60) / 12;
      case 'DAY': return d.getDate() / new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
      case 'WEEKDAY': return (((d.getDay() + 6) % 7) + 1) / 7;
      case 'MONTH': return (d.getMonth() + 1) / 12;
      default: return 0;
    }
  }

  /** Нормализованные параметры (значения по умолчанию совпадают с registry.js). */
  function params(comp) {
    const p = (comp && comp.props) || {};
    const source = SOURCES.includes(p.data_source) ? p.data_source : 'NONE';
    const vMin = num(p.value_min, 0);
    const vMaxRaw = num(p.value_max, 0);
    // 0 — «авто»: значение по умолчанию для источника (батарея 100, шаги 10000, пульс 200…).
    const vMax = vMaxRaw !== 0 ? vMaxRaw : (DEFAULT_MAX[source] || 100);
    return {
      source,
      isSensor: SENSOR_SOURCES.includes(source),
      isTime: TIME_SOURCES.includes(source),
      start: num(p.start_angle, -120),
      end: num(p.end_angle, 120),
      vMin,
      vMax,
      span: (vMax - vMin) || 1,
      previewPercent: Math.max(0, Math.min(100, num(p.preview_percent, 50))),
      alpha: Math.max(0, Math.min(100, num(p.alpha, 100))),
    };
  }

  /** Угол стрелки (в градусах, как в редакторе) для доли 0..1 диапазона. */
  function angleAt(comp, ratio) {
    const q = params(comp);
    return q.start + (q.end - q.start) * clamp01(Number(ratio) || 0);
  }

  /** Доля диапазона для предпросмотра: время — по часам компьютера, датчик/статика — «значение в редакторе». */
  function previewRatio(comp, now) {
    const q = params(comp);
    if (q.isTime) return clamp01(timeRatio(q.source, now || new Date()));
    return clamp01(q.previewPercent / 100);
  }

  /** Угол стрелки в предпросмотре. */
  function previewAngle(comp, now) {
    return angleAt(comp, previewRatio(comp, now));
  }

  /** Центр вращения и положение PNG на экране: левый верхний угол картинки = центр − точка опоры. */
  function pivot(comp, imgW, imgH) {
    const p = (comp && comp.props) || {};
    const cx = num(p.center_x, 240), cy = num(p.center_y, 240);
    const px = num(p.pos_x, Math.round((imgW || (comp && comp.w) || 0) / 2));
    const py = num(p.pos_y, Math.round((imgH || (comp && comp.h) || 0) / 2));
    return { cx, cy, px, py, left: cx - px, top: cy - py };
  }

  return { SOURCES, SENSOR_SOURCES, TIME_SOURCES, DEFAULT_MAX, params, angleAt, previewRatio, previewAngle, timeRatio, pivot };
})();

// Для Node-тестов (в браузере module не определён).
if (typeof module !== 'undefined' && module.exports) module.exports = GaugeNeedleModel;
