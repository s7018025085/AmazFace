'use strict';
// bridge/fs-routes.js
//
// Файловая система проекта через мост (/fs/*). Браузер больше не использует
// File System Access API (Chrome его ограничивает): выбор папки, чтение, запись
// и удаление выполняет мост. Защита та же, что у /github/*: loopback Host, Origin
// null/localhost и код доступа X-AmazFace-Key.
//
// Доступ только к папкам, которые пользователь выбрал в системном диалоге
// (/fs/pick) или повторно открыл по пути (/fs/open, например «Продолжить последний»).
// Каждая выбранная папка получает id; все операции идут относительно её корня,
// выход за корень (.., абсолютные пути, диски) запрещён. Корень диска и системные
// папки выбрать нельзя.

const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { spawn } = require('child_process');
const { ORIGIN_RE, HOST_RE } = require('./github-routes');

const MAX_BODY = 260 * 1024 * 1024;
const SKIP_DIRS = new Set(['node_modules', '.git']);
const MAX_DEPTH = 8;

class FsErr extends Error {
  constructor(message, name, status) { super(message); this.fsName = name; this.status = status; }
}
const notFound = (p) => new FsErr(`Не найдено: ${p}`, 'NotFoundError', 404);

function createFsRoutes(opts) {
  const key = opts.key;
  const baseLog = opts.log || (() => {});
  const roots = new Map(); // id → абсолютный путь
  let lastPicked = '';     // родитель последней выбранной папки: с него стартует следующий диалог
  // Журнал /fs/*: пишется в bridge-debug.log (через opts.log) и в кольцевой буфер,
  // который редактор может прочитать через GET /fs/log и показать в окне импорта.
  const ring = [];
  const log = (msg) => {
    ring.push(`[${new Date().toISOString().slice(11, 23)}] ${msg}`);
    if (ring.length > 400) ring.shift();
    try { baseLog(msg); } catch (e) { /* журнал не должен ломать запрос */ }
  };
  const QUIET = new Set(['/fs/ping', '/fs/log', '/fs/stat', '/fs/read', '/fs/write', '/fs/mkdir', '/fs/list']); // успешные — только в счётчик
  const counters = {};

  function setCors(req, res) {
    const origin = req.headers.origin;
    res.removeHeader('Access-Control-Allow-Origin');
    if (origin) { res.setHeader('Access-Control-Allow-Origin', origin); res.setHeader('Vary', 'Origin'); }
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type,X-AmazFace-Key');
    res.setHeader('Access-Control-Allow-Private-Network', 'true');
  }
  function sendJson(req, res, code, obj) {
    setCors(req, res);
    res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(JSON.stringify(obj));
  }
  function sendBytes(req, res, buf) {
    setCors(req, res);
    res.writeHead(200, { 'Content-Type': 'application/octet-stream', 'Content-Length': buf.length, 'Cache-Control': 'no-store' });
    res.end(buf);
  }
  function readBody(req) {
    return new Promise((resolve, reject) => {
      const chunks = []; let size = 0;
      req.on('data', (c) => { size += c.length; if (size > MAX_BODY) { reject(new FsErr('Запрос слишком большой.', 'QuotaExceededError', 413)); req.destroy(); } else chunks.push(c); });
      req.on('end', () => resolve(Buffer.concat(chunks)));
      req.on('error', reject);
    });
  }
  const readJson = async (req) => { const b = await readBody(req); if (!b.length) return {}; try { return JSON.parse(b.toString('utf8')); } catch (e) { throw new FsErr('Некорректный JSON.', 'TypeError', 400); } };
  function keyOk(req) {
    const a = Buffer.from(String(req.headers['x-amazface-key'] || '')), b = Buffer.from(String(key()));
    return a.length === b.length && crypto.timingSafeEqual(a, b);
  }

  // ---- пути ----
  function cleanRel(rel) {
    if (rel == null || rel === '') return [];
    if (typeof rel !== 'string' || rel.length > 1000 || rel.includes('\\') || rel.startsWith('/') || /^[a-zA-Z]:/.test(rel) || /[\u0000-\u001f]/.test(rel)) {
      throw new FsErr(`Недопустимый путь: ${rel}`, 'TypeError', 400);
    }
    const parts = rel.split('/');
    if (parts.some((p) => !p || p === '.' || p === '..' || p.length > 255)) throw new FsErr(`Недопустимый путь: ${rel}`, 'TypeError', 400);
    return parts;
  }
  function rootPath(id) {
    const p = roots.get(String(id || ''));
    if (!p) throw new FsErr('Папка не выбрана или мост был перезапущен. Выберите папку заново.', 'NotAllowedError', 403);
    return p;
  }
  function resolve(id, rel, { allowRoot } = {}) {
    const base = rootPath(id);
    const parts = cleanRel(rel);
    if (!parts.length && !allowRoot) throw new FsErr('Нужен путь внутри папки проекта.', 'TypeError', 400);
    const abs = path.join(base, ...parts);
    const back = path.relative(base, abs);
    if (back.startsWith('..') || path.isAbsolute(back)) throw new FsErr('Путь выходит за пределы папки проекта.', 'TypeError', 400);
    return abs;
  }
  const kindOf = (st) => (st.isDirectory() ? 'directory' : 'file');
  function lstat(abs, shown) {
    try { return fs.lstatSync(abs); }
    catch (e) { if (e.code === 'ENOENT' || e.code === 'ENOTDIR') throw notFound(shown); throw e; }
  }

  function register(abs) {
    abs = path.resolve(abs);
    let st;
    try { st = fs.statSync(abs); } catch (e) { log(`register: статус ${abs} не получен: ${e.code || ''} ${e.message}`); throw new FsErr(`Папка не найдена: ${abs}`, 'NotFoundError', 404); }
    if (!st.isDirectory()) throw new FsErr('Это не папка.', 'TypeMismatchError', 409);
    if (path.parse(abs).root === abs) throw new FsErr('Корень диска выбрать нельзя. Выберите папку проекта.', 'NotAllowedError', 403);
    const win = process.env.SystemRoot || process.env.windir;
    if (win && (abs.toLowerCase() === win.toLowerCase() || abs.toLowerCase().startsWith(win.toLowerCase() + path.sep))) {
      throw new FsErr('Системную папку выбрать нельзя.', 'NotAllowedError', 403);
    }
    // Что мост реально видит в папке: читается ли она, сколько записей, можно ли писать.
    let entries = -1, writable = false;
    try { entries = fs.readdirSync(abs).length; } catch (e) { log(`register: папку не удаётся прочитать ${abs}: ${e.code || ''} ${e.message}`); }
    try { fs.accessSync(abs, fs.constants.W_OK); writable = true; } catch (e) { log(`register: нет права записи в ${abs}: ${e.code || ''}`); }
    for (const [id, p] of roots) if (p === abs) { log(`register: папка уже известна id=${id.slice(0, 6)} path=${abs} записей=${entries} запись=${writable}`); return { id, path: abs, name: path.basename(abs), entries, writable }; }
    const id = crypto.randomBytes(12).toString('hex');
    roots.set(id, abs);
    log(`register: новая папка id=${id.slice(0, 6)} path=${abs} записей=${entries} запись=${writable}`);
    return { id, path: abs, name: path.basename(abs), entries, writable };
  }

  // ---- системный диалог выбора папки ----
  // Windows: современный диалог Проводника (IFileOpenDialog + FOS_PICKFOLDERS) — тот же, что в
  // «Сохранить как…»: с адресной строкой, поиском, быстрым доступом и ПКМ-меню. Старый
  // FolderBrowserDialog (древовидное окно) открывался по нескольку секунд, потому что перед показом
  // раскрывал дерево «Этот компьютер»/сеть, а до этого PowerShell ещё грузил Forms/Drawing и строил
  // скрытую форму. Здесь ни Forms, ни Drawing не нужны; скомпилированный помощник кешируется в %TEMP%,
  // так что компиляция C# происходит только при самом первом запуске. Если современный диалог по
  // какой-то причине не поднялся — скрипт сам откатывается на старый FolderBrowserDialog.
  const WIN_PICKER_CS = `
using System;
using System.Runtime.InteropServices;
namespace AmazFace {
  [ComImport, Guid("DC1C5A9C-E88A-4DDE-A5A1-60F82A20AEF7")] class FileOpenDialogRCW {}
  [ComImport, Guid("43826D1E-E718-42EE-BC55-A1E261C37BFE"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  interface IShellItem {
    void BindToHandler(IntPtr pbc, ref Guid bhid, ref Guid riid, out IntPtr ppv);
    void GetParent(out IShellItem ppsi);
    void GetDisplayName(uint sigdn, [MarshalAs(UnmanagedType.LPWStr)] out string name);
    void GetAttributes(uint mask, out uint attr);
    void Compare(IShellItem psi, uint hint, out int order);
  }
  [ComImport, Guid("42F85136-DB7E-439C-85F1-E4075D135FC8"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  interface IFileDialog {
    [PreserveSig] int Show(IntPtr parent);
    void SetFileTypes(uint c, IntPtr p);
    void SetFileTypeIndex(uint i);
    void GetFileTypeIndex(out uint i);
    void Advise(IntPtr p, out uint c);
    void Unadvise(uint c);
    void SetOptions(uint o);
    void GetOptions(out uint o);
    void SetDefaultFolder(IShellItem s);
    void SetFolder(IShellItem s);
    void GetFolder(out IShellItem s);
    void GetCurrentSelection(out IShellItem s);
    void SetFileName([MarshalAs(UnmanagedType.LPWStr)] string n);
    void GetFileName([MarshalAs(UnmanagedType.LPWStr)] out string n);
    void SetTitle([MarshalAs(UnmanagedType.LPWStr)] string t);
    void SetOkButtonLabel([MarshalAs(UnmanagedType.LPWStr)] string t);
    void SetFileNameLabel([MarshalAs(UnmanagedType.LPWStr)] string t);
    void GetResult(out IShellItem s);
    void AddPlace(IShellItem s, int fdap);
    void SetDefaultExtension([MarshalAs(UnmanagedType.LPWStr)] string e);
    void Close(int hr);
    void SetClientGuid(ref Guid g);
    void ClearClientData();
    void SetFilter(IntPtr f);
  }
  public static class FolderPicker {
    [DllImport("shell32.dll", CharSet = CharSet.Unicode, PreserveSig = false)]
    static extern void SHCreateItemFromParsingName(string path, IntPtr pbc, ref Guid riid, out IShellItem item);
    [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
    public static string Show(string title, string start) {
      IFileDialog dlg = (IFileDialog)new FileOpenDialogRCW();
      uint o; dlg.GetOptions(out o);
      dlg.SetOptions(o | 0x20u | 0x40u | 0x800u); // PICKFOLDERS | FORCEFILESYSTEM | PATHMUSTEXIST
      if (!string.IsNullOrEmpty(title)) dlg.SetTitle(title);
      if (!string.IsNullOrEmpty(start) && System.IO.Directory.Exists(start)) {
        try {
          Guid iid = new Guid("43826D1E-E718-42EE-BC55-A1E261C37BFE"); IShellItem si;
          SHCreateItemFromParsingName(start, IntPtr.Zero, ref iid, out si);
          dlg.SetFolder(si);
        } catch { }
      }
      // Owner = current foreground window (the browser the button was clicked in), so the dialog opens on top.
      int hr = dlg.Show(GetForegroundWindow());
      if (hr == unchecked((int)0x800704C7)) return ""; // ERROR_CANCELLED
      if (hr != 0) Marshal.ThrowExceptionForHR(hr);
      IShellItem item; dlg.GetResult(out item);
      string path; item.GetDisplayName(0x80058000u, out path); // SIGDN_FILESYSPATH
      return path;
    }
  }
}`;
  const WIN_PICKER_PS = [
    "$ErrorActionPreference='Stop'",
    '[Console]::OutputEncoding=[System.Text.Encoding]::UTF8',
    "$src=@'",
    WIN_PICKER_CS,
    "'@",
    'function Pick-Modern {',
    "  $dll=Join-Path $env:TEMP 'amazface-folderpicker-1.dll'; $ok=$false",
    '  if(Test-Path $dll){ try{ Add-Type -Path $dll; $ok=$true }catch{ Remove-Item $dll -Force -ErrorAction SilentlyContinue } }',
    '  if(-not $ok){ try{ Add-Type -TypeDefinition $src -OutputAssembly $dll -OutputType Library; Add-Type -Path $dll }catch{ Add-Type -TypeDefinition $src } }',
    '  return [AmazFace.FolderPicker]::Show($env:AF_TITLE,$env:AF_START)',
    '}',
    'function Pick-Legacy {',
    '  Add-Type -AssemblyName System.Windows.Forms; Add-Type -AssemblyName System.Drawing',
    '  $o=New-Object System.Windows.Forms.Form',
    '  $o.TopMost=$true;$o.ShowInTaskbar=$false;$o.StartPosition="CenterScreen";$o.Opacity=0;$o.Size=New-Object System.Drawing.Size(1,1)',
    '  $o.Show();$o.Activate()',
    '  $d=New-Object System.Windows.Forms.FolderBrowserDialog',
    '  $d.Description=$env:AF_TITLE;$d.ShowNewFolderButton=$true',
    '  $r=""; if($d.ShowDialog($o) -eq "OK"){ $r=$d.SelectedPath }',
    '  $o.Close(); return $r',
    '}',
    '$res=""; $mode="modern"',
    'try { $res=Pick-Modern } catch { $mode="legacy"; [Console]::Error.WriteLine("modern dialog failed: "+$_.Exception.Message); $res=Pick-Legacy }',
    '[Console]::Out.Write("AFMODE:"+$mode+"`n"+"AFPATH:"+$res+"`n")',
  ].join('\r\n');

  function pickDialog(title, startDir) {
    return new Promise((resolve, reject) => {
      let cmd, args, env = Object.assign({}, process.env, { AF_TITLE: title, AF_START: startDir || '' });
      if (process.platform === 'win32') {
        cmd = 'powershell.exe';
        args = ['-NoProfile', '-NonInteractive', '-STA', '-WindowStyle', 'Hidden', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', Buffer.from(WIN_PICKER_PS, 'utf16le').toString('base64')];
      } else if (process.platform === 'darwin') {
        cmd = 'osascript';
        args = ['-e', 'POSIX path of (choose folder with prompt (system attribute "AF_TITLE"))'];
      } else {
        cmd = 'zenity';
        args = ['--file-selection', '--directory', '--title=' + title];
      }
      let out = '', err = '';
      const t0 = Date.now();
      log(`pick: запускаю диалог (${process.platform}): ${cmd} ${process.platform === 'win32' ? '[PowerShell, IFileOpenDialog]' : args.join(' ')}`);
      let p;
      try { p = spawn(cmd, args, { env, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] }); }
      catch (e) { log(`pick: spawn не удался: ${e.message}`); return reject(new FsErr('Не удалось открыть диалог выбора папки: ' + e.message, 'NotSupportedError', 500)); }
      log(`pick: процесс диалога pid=${p.pid}`);
      p.stdout.setEncoding('utf8'); p.stderr.setEncoding('utf8');
      p.stdout.on('data', (d) => { out += d; });
      p.stderr.on('data', (d) => { err += d; });
      p.on('error', (e) => { log(`pick: ошибка процесса: ${e.code || ''} ${e.message}`); reject(new FsErr('Не удалось открыть диалог выбора папки: ' + e.message, 'NotSupportedError', 500)); });
      // 'close', а не 'exit': 'exit' приходит раньше, чем дочитан stdout, и выбранный путь терялся
      // (диалог выглядел «отменённым»: папку выбрали, а дальше ничего не происходило).
      p.on('close', (code, signal) => {
        let clean = out.replace(/^\uFEFF/, '').trim();
        if (process.platform === 'win32') {
          // Путь приходит строкой AFPATH:… — любой посторонний вывод PowerShell в stdout игнорируется.
          const m = /^AFPATH:(.*)$/m.exec(out.replace(/\r/g, ''));
          clean = m ? m[1].trim() : '';
          const mode = /^AFMODE:(\w+)$/m.exec(out.replace(/\r/g, ''));
          if (mode && mode[1] === 'legacy') log('pick: современный диалог не поднялся, использован запасной FolderBrowserDialog');
        }
        const picked = clean.replace(/[\\/]+$/, (m) => (/^[a-zA-Z]:[\\/]$/.test(clean) ? m : ''));
        log(`pick: диалог закрыт за ${Date.now() - t0} мс, код=${code} сигнал=${signal || '-'} stdout=${JSON.stringify(out.slice(0, 300))} stderr=${JSON.stringify(err.trim().slice(0, 300))}`);
        if (picked) return resolve({ path: picked });
        if (code && code !== 0 && /execution|error|exception/i.test(err)) return reject(new FsErr('Диалог выбора папки завершился с ошибкой: ' + err.trim().slice(0, 300), 'NotSupportedError', 500));
        resolve({ path: '', reason: code ? `диалог закрылся с кодом ${code} без пути` : 'диалог закрыт без выбора папки (Отмена или окно закрыто)' }); // отмена
      });
    });
  }

  // ---- операции ----
  function list(id, rel) {
    const abs = resolve(id, rel, { allowRoot: true });
    const st = lstat(abs, rel || '/');
    if (!st.isDirectory()) throw new FsErr('Это не папка.', 'TypeMismatchError', 409);
    const entries = [];
    for (const d of fs.readdirSync(abs, { withFileTypes: true })) {
      if (d.isSymbolicLink()) continue;
      const isDir = d.isDirectory();
      entries.push({ name: d.name, kind: isDir ? 'directory' : 'file', size: isDir ? 0 : fs.statSync(path.join(abs, d.name)).size });
    }
    return { entries };
  }

  function bundle(id, maxBytes) {
    const base = rootPath(id);
    const parts = [];
    (function walk(dir, prefix, depth) {
      if (depth > MAX_DEPTH) return;
      for (const d of fs.readdirSync(dir, { withFileTypes: true })) {
        if (d.isSymbolicLink()) continue;
        const abs = path.join(dir, d.name), rel = prefix + d.name;
        if (d.isDirectory()) { if (!SKIP_DIRS.has(d.name)) walk(abs, rel + '/', depth + 1); continue; }
        const size = fs.statSync(abs).size;
        const big = size > maxBytes;
        const pb = Buffer.from(rel, 'utf8');
        const head = Buffer.alloc(4 + pb.length + 1 + 4);
        head.writeUInt32LE(pb.length, 0); pb.copy(head, 4);
        head.writeUInt8(big ? 1 : 0, 4 + pb.length);
        head.writeUInt32LE(size, 5 + pb.length);
        parts.push(head);
        if (!big) parts.push(fs.readFileSync(abs));
      }
    })(base, '', 0);
    return Buffer.concat(parts);
  }

  function remove(id, rel, recursive) {
    const abs = resolve(id, rel);
    const st = lstat(abs, rel);
    if (st.isDirectory()) {
      if (!recursive && fs.readdirSync(abs).length) throw new FsErr('Папка не пуста.', 'InvalidModificationError', 409);
      fs.rmSync(abs, { recursive: true, force: true });
    } else fs.unlinkSync(abs);
  }

  // Атомарная замена: tmp → name. Старая папка переименовывается в запасную и удаляется только после успеха.
  function swap(id, tmp, name, replace) {
    const from = resolve(id, tmp), to = resolve(id, name);
    if (!fs.existsSync(from)) throw notFound(tmp);
    const exists = fs.existsSync(to);
    if (exists && !replace) throw new FsErr(`Папка «${name}» уже существует.`, 'InvalidModificationError', 409);
    let backup = null;
    if (exists) { backup = to + '.old-' + Date.now().toString(36); fs.renameSync(to, backup); }
    try { fs.renameSync(from, to); }
    catch (e) { if (backup) { try { fs.renameSync(backup, to); } catch (e2) { /* оставляем backup */ } } throw e; }
    if (backup) { try { fs.rmSync(backup, { recursive: true, force: true }); } catch (e) { /* не критично */ } }
    return register(to);
  }

  const matches = (req) => String(req.url || '').split('?')[0].startsWith('/fs/');

  async function handle(req, res) {
    const url = new URL(req.url, 'http://127.0.0.1');
    const route = url.pathname;
    const q = (n) => url.searchParams.get(n);
    const t0 = Date.now();
    // Итог каждого запроса: успешные «тихие» маршруты только считаются, остальное и все ошибки — в журнал.
    res.on('finish', () => {
      const ms = Date.now() - t0, ok = res.statusCode < 400;
      counters[route] = (counters[route] || 0) + 1;
      if (ok && QUIET.has(route)) { if (ms > 1500) log(`${req.method} ${route} медленно: ${ms} мс`); return; }
      log(`${req.method} ${route}${url.search ? ' ' + decodeURIComponent(url.search).slice(0, 160) : ''} → ${res.statusCode} за ${ms} мс` +
        (req.headers.origin ? ` origin=${req.headers.origin}` : ' origin=нет'));
    });
    try {
      if (!HOST_RE.test(String(req.headers.host || ''))) return sendJson(req, res, 403, { error: 'Недопустимый Host.' });
      const origin = req.headers.origin;
      if (origin && !ORIGIN_RE.test(origin)) { res.removeHeader('Access-Control-Allow-Origin'); return sendJson({ headers: {} }, res, 403, { error: 'Источник запроса не разрешён.' }); }
      if (req.method === 'OPTIONS') { setCors(req, res); res.writeHead(204); return res.end(); }
      if (req.method === 'GET' && route === '/fs/ping') return sendJson(req, res, 200, { ok: true, keyValid: keyOk(req), platform: process.platform });
      if (!keyOk(req)) log(`${req.method} ${route}: неверный или пустой код доступа (длина заголовка ${String(req.headers['x-amazface-key'] || '').length})`);
      if (!keyOk(req)) return sendJson(req, res, 401, { error: 'Нужен код доступа к мосту. Он показан в окне моста (start-zeus-bridge.bat).', code: 'key' });

      if (req.method === 'GET' && route === '/fs/log') return sendJson(req, res, 200, { lines: ring.slice(-300), counters });
      if (req.method === 'POST' && route === '/fs/pick') {
        const b = await readJson(req);
        const r0 = await pickDialog(String(b.title || 'Выберите папку проекта').slice(0, 200), lastPicked);
        if (!r0.path) return sendJson(req, res, 200, { cancelled: true, reason: r0.reason });
        const r = register(r0.path);
        lastPicked = path.dirname(r.path); // следующий диалог откроется рядом с прошлым выбором
        log(`pick: выбрана папка ${r.path}`);
        return sendJson(req, res, 200, r);
      }
      if (req.method === 'POST' && route === '/fs/open') {
        const b = await readJson(req);
        if (typeof b.path !== 'string' || !b.path) throw new FsErr('Не указан путь.', 'TypeError', 400);
        log(`open: запрошена папка ${b.path}`);
        return sendJson(req, res, 200, register(b.path));
      }
      if (req.method === 'GET' && route === '/fs/list') return sendJson(req, res, 200, list(q('root'), q('path')));
      if (req.method === 'GET' && route === '/fs/stat') {
        const abs = resolve(q('root'), q('path'), { allowRoot: true });
        const st = lstat(abs, q('path') || '/');
        return sendJson(req, res, 200, { kind: kindOf(st), size: st.isDirectory() ? 0 : st.size });
      }
      if (req.method === 'GET' && route === '/fs/read') {
        const abs = resolve(q('root'), q('path'));
        const st = lstat(abs, q('path'));
        if (st.isDirectory()) throw new FsErr('Это папка.', 'TypeMismatchError', 409);
        return sendBytes(req, res, fs.readFileSync(abs));
      }
      if (req.method === 'GET' && route === '/fs/bundle') return sendBytes(req, res, bundle(q('root'), Number(q('maxBytes')) || 25 * 1024 * 1024));
      if (req.method === 'POST' && route === '/fs/write') {
        const abs = resolve(q('root'), q('path'));
        const data = await readBody(req);
        if (fs.existsSync(abs) && fs.lstatSync(abs).isDirectory()) throw new FsErr('На этом месте папка.', 'TypeMismatchError', 409);
        fs.mkdirSync(path.dirname(abs), { recursive: true });
        const tmp = abs + '.af-tmp-' + crypto.randomBytes(3).toString('hex');
        fs.writeFileSync(tmp, data);
        try { fs.renameSync(tmp, abs); } catch (e) { try { fs.unlinkSync(tmp); } catch (e2) { /* нет */ } throw e; }
        return sendJson(req, res, 200, { size: data.length });
      }
      if (req.method === 'POST' && route === '/fs/mkdir') {
        const abs = resolve(q('root'), q('path'));
        if (fs.existsSync(abs) && !fs.lstatSync(abs).isDirectory()) throw new FsErr('На этом месте файл.', 'TypeMismatchError', 409);
        fs.mkdirSync(abs, { recursive: true });
        return sendJson(req, res, 200, { ok: true });
      }
      if (req.method === 'POST' && route === '/fs/remove') { remove(q('root'), q('path'), q('recursive') === '1'); return sendJson(req, res, 200, { ok: true }); }
      if (req.method === 'POST' && route === '/fs/swap') {
        const b = await readJson(req);
        return sendJson(req, res, 200, swap(b.root, b.tmp, b.name, b.replace === true));
      }
      return sendJson(req, res, 404, { error: 'Not found', code: 'route' });
    } catch (e) {
      const status = e && e.status || (e && (e.code === 'EACCES' || e.code === 'EPERM') ? 403 : 500);
      const name = e && e.fsName || (e && (e.code === 'EACCES' || e.code === 'EPERM') ? 'NotAllowedError' : 'Error');
      log(`ОШИБКА ${req.method} ${route}: ${name} (${status}) ${String(e && e.message || e).slice(0, 300)}${e && e.code ? ' [' + e.code + ']' : ''}`);
      return sendJson(req, res, status, { error: String(e && e.message || e), code: name });
    }
  }

  log('fs-routes готовы (журнал /fs/* ведётся в bridge-debug.log и доступен по GET /fs/log)');
  return { matches, handle, _internals: { cleanRel, register, roots } };
}

module.exports = { createFsRoutes };
