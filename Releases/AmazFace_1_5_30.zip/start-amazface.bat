@echo off
setlocal
cd /d "%~dp0"
title AmazFace launcher

where node >nul 2>nul
if errorlevel 1 goto :no_node

call :check_port
if not errorlevel 1 goto :bridge_ready

echo Starting AmazFace bridge...
start "AmazFace Bridge" "%~dp0bridge\start-zeus-bridge.bat"

set /a tries=0
:wait_bridge
set /a tries+=1
call :check_port
if not errorlevel 1 goto :bridge_ready
if %tries% GEQ 30 goto :bridge_failed
timeout /t 1 /nobreak >nul
goto :wait_bridge

:bridge_ready
echo Bridge is up. Opening editor...
start "" "%~dp0index.html"
exit /b 0

:no_node
echo Node.js was not found in PATH.
echo Install it from https://nodejs.org and run this file again.
pause
exit /b 1

:bridge_failed
echo The bridge did not start within 30 seconds.
echo Look at the "AmazFace Bridge" window for the error.
pause
exit /b 1

:check_port
node -e "require('net').connect(17865,'127.0.0.1').on('connect',()=>process.exit(0)).on('error',()=>process.exit(1))" >nul 2>nul
exit /b %errorlevel%
