// src/project/archive-import.js
//
// «Открыть архив (ZPK / проект Саши)»: открывает циферблат, собранный в другом
// редакторе (Watch_Face_Editor SashaCX75 и подобных), из .zpk / .zab / .zip.
//
//  1. unpackArchive  — достаёт файлы проекта (app.json, watchface/index.js, assets/…),
//                      проходя вложенные архивы (.zab → .zpk → device.zip).
//  2. decodeSomh     — картинки «.png» этих редакторов на деле индексированный TGA
//                      с меткой SOMH (обратная операция к zepp-image-encoder.js).
//  3. parseWatchface — разбирает watchface/index.js как ТЕКСТ (код не выполняется):
//                      находит вызовы createWidget и читает их параметры.
//  4. buildScenes    — собирает слои AmazFace. Что пока не имеет аналога в AmazFace
//                      (цифры-картинки, IMG_LEVEL, кнопки…), не теряется молча:
//                      попадает в отчёт, а числовые поля — в заглушку-текст.
//
// Чистые функции (без DOM) доступны через module.exports — для тестов в Node.

(function (root) {
  'use strict';

  // ───────────────────────── 1. Распаковка ─────────────────────────

  const ARCHIVE_EXT = /\.(zip|zpk|zab)$/i;

  /**
   * Возвращает { files: Map<относительный путь, Uint8Array>, source: строка-путь }.
   * @param {Uint8Array} bytes
   * @param {(b: Uint8Array) => Promise<Map<string, Uint8Array>>} unzip
   */
  async function unpackArchive(bytes, unzip, depth = 0, trail = '') {
    const entries = await unzip(bytes);

    // Свой формат AmazFace: состояние редактора лежит в архиве целиком.
    for (const path of entries.keys()) {
      if (/(^|\/)amazface\.project\.json$/.test(path)) {
        return { files: rebase(entries, path.replace(/amazface\.project\.json$/, '')), source: trail || 'архив', amazface: true };
      }
    }
    // Обычный проект Zepp: app.json рядом с watchface/*.js.
    const roots = [];
    for (const path of entries.keys()) {
      if (/(^|\/)app\.json$/.test(path)) roots.push(path.replace(/app\.json$/, ''));
    }
    roots.sort((a, b) => a.length - b.length);
    for (const base of roots) {
      const hasFace = [...entries.keys()].some((p) => p.startsWith(base) && /(^|\/)watchface\/[^/]+\.js$/.test(p));
      if (hasFace) return { files: rebase(entries, base), source: trail || 'архив' };
    }
    // Вложенные архивы: device.zip внутри .zpk, .zpk внутри .zab.
    if (depth < 4) {
      const nested = [...entries.keys()].filter((p) => ARCHIVE_EXT.test(p));
      // device.zip — приоритетно: app-side.zip циферблата не содержит.
      nested.sort((a, b) => (/device/i.test(b) ? 1 : 0) - (/device/i.test(a) ? 1 : 0));
      for (const name of nested) {
        if (/app-side/i.test(name)) continue;
        try {
          return await unpackArchive(entries.get(name), unzip, depth + 1, (trail ? trail + ' → ' : '') + name);
        } catch (e) { /* пробуем следующий */ }
      }
    }
    throw new Error('В архиве не найден циферблат Zepp OS: нет ни app.json с папкой watchface/, ни вложенного device.zip.');
  }

  function rebase(entries, base) {
    const out = new Map();
    for (const [path, data] of entries) if (path.startsWith(base)) out.set(path.slice(base.length), data);
    return out;
  }

  // ───────────────────────── 2. Картинки SOMH ─────────────────────────

  const isPng = (b) => b.length > 8 && b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47;

  /**
   * Индексированный TGA циферблатов Zepp: 18 байт заголовка, поле id (46 байт:
   * «SOMH» + реальная ширина), палитра 256×RGBA (RGB умножен на A), индексы строк
   * с шириной, выровненной до 16. Возвращает { width, height, rgba } или null.
   */
  function decodeSomh(b) {
    if (b.length < 18 + 46 + 1024) return null;
    const idLen = b[0];
    if (b[1] !== 1 || b[2] !== 1 || idLen < 6) return null;
    if (String.fromCharCode(b[18], b[19], b[20], b[21]) !== 'SOMH') return null;
    const storedW = b[12] | (b[13] << 8);
    const height = b[14] | (b[15] << 8);
    const width = (b[22] | (b[23] << 8)) || storedW;
    const palStart = 18 + idLen;
    const pxStart = palStart + 1024;
    if (!storedW || !height || width > storedW || b.length < pxStart + storedW * height) return null;
    const topDown = (b[17] & 0x20) !== 0;

    const rgba = new Uint8ClampedArray(width * height * 4);
    for (let y = 0; y < height; y++) {
      const srcRow = topDown ? y : height - 1 - y;
      for (let x = 0; x < width; x++) {
        const pi = palStart + b[pxStart + srcRow * storedW + x] * 4;
        let r = b[pi], g = b[pi + 1], bl = b[pi + 2];
        const a = b[pi + 3];
        if (a > 0 && a < 255) { // вернуть цвет из премультиплированного вида
          r = Math.min(255, Math.round(r * 255 / a));
          g = Math.min(255, Math.round(g * 255 / a));
          bl = Math.min(255, Math.round(bl * 255 / a));
        }
        const o = (y * width + x) * 4;
        rgba[o] = r; rgba[o + 1] = g; rgba[o + 2] = bl; rgba[o + 3] = a;
      }
    }
    return { width, height, rgba };
  }

  // ───────────────────────── 3. Разбор watchface/index.js ─────────────────────────

  function stripComments(src) {
    let out = '', i = 0, q = null;
    const n = src.length;
    while (i < n) {
      const c = src[i], d = src[i + 1];
      if (q) {
        out += c;
        if (c === '\\') { out += src[i + 1] || ''; i += 2; continue; }
        if (c === q) q = null;
        i++; continue;
      }
      if (c === '"' || c === "'" || c === '`') { q = c; out += c; i++; continue; }
      if (c === '/' && d === '/') { while (i < n && src[i] !== '\n') i++; continue; }
      if (c === '/' && d === '*') { i += 2; while (i < n && !(src[i] === '*' && src[i + 1] === '/')) i++; i += 2; continue; }
      out += c; i++;
    }
    return out;
  }

  const CLOSERS = { '{': '}', '[': ']', '(': ')' };

  /** Индекс парной закрывающей скобки для s[start] или -1. */
  function matchBracket(s, start) {
    let depth = 0, q = null;
    for (let i = start; i < s.length; i++) {
      const c = s[i];
      if (q) { if (c === '\\') { i++; continue; } if (c === q) q = null; continue; }
      if (c === '"' || c === "'" || c === '`') { q = c; continue; }
      if (c === '{' || c === '[' || c === '(') depth++;
      else if (c === '}' || c === ']' || c === ')') { depth--; if (depth === 0) return i; }
    }
    return -1;
  }

  /** Делит содержимое списка/объекта по запятым верхнего уровня. */
  function splitTop(body) {
    const parts = [];
    let depth = 0, q = null, last = 0;
    for (let i = 0; i < body.length; i++) {
      const c = body[i];
      if (q) { if (c === '\\') { i++; continue; } if (c === q) q = null; continue; }
      if (c === '"' || c === "'" || c === '`') { q = c; continue; }
      if (c === '{' || c === '[' || c === '(') depth++;
      else if (c === '}' || c === ']' || c === ')') depth--;
      else if (c === ',' && depth === 0) { parts.push(body.slice(last, i)); last = i + 1; }
    }
    if (body.slice(last).trim()) parts.push(body.slice(last));
    return parts;
  }

  /** Значение JS-литерала. Всё, что не литерал, → { $expr } (не выполняем!). */
  function parseValue(raw) {
    const s = raw.trim();
    if (!s) return { $expr: '' };
    if (/^-?(0x[0-9a-f]+|\d+(\.\d+)?(e[+-]?\d+)?|\.\d+)$/i.test(s)) return Number(s);
    if (s === 'true') return true;
    if (s === 'false') return false;
    if (s === 'null' || s === 'undefined') return null;
    if ((s[0] === '"' || s[0] === "'") && matchString(s)) return s.slice(1, -1).replace(/\\(.)/g, '$1');
    if (s[0] === '[' && matchBracket(s, 0) === s.length - 1) return splitTop(s.slice(1, -1)).map(parseValue);
    if (s[0] === '{' && matchBracket(s, 0) === s.length - 1) return parseObjectBody(s.slice(1, -1));
    if (/^[A-Za-z_$][\w$]*(\.[A-Za-z_$][\w$]*)*$/.test(s)) return { $ref: s.replace(/^hmUI\./, '') };
    return { $expr: s };
  }

  function matchString(s) {
    const q = s[0];
    for (let i = 1; i < s.length; i++) {
      if (s[i] === '\\') { i++; continue; }
      if (s[i] === q) return i === s.length - 1;
    }
    return false;
  }

  function parseObjectBody(body) {
    const obj = {};
    for (const part of splitTop(body)) {
      const m = /^\s*(?:'([^']+)'|"([^"]+)"|([A-Za-z_$][\w$]*))\s*:/.exec(part);
      if (!m) continue;
      obj[m[1] || m[2] || m[3]] = parseValue(part.slice(m[0].length));
    }
    return obj;
  }

  const isRef = (v) => v && typeof v === 'object' && '$ref' in v;
  const isExpr = (v) => v && typeof v === 'object' && '$expr' in v;
  const refName = (v) => (isRef(v) ? v.$ref.split('.').pop() : null);

  /**
   * Находит все createWidget(...) вне комментариев.
   * @returns {{ widget: string, props: object, index: number, scene: 'normal'|'aod'|'both' }[]}
   */
  function parseWatchface(source) {
    const src = stripComments(source.replace(/^\uFEFF/, ''));
    const re = /(?:hmUI\.)?createWidget\(\s*(?:hmUI\.)?widget\.([A-Za-z_]+)\s*(\)|,\s*\{)/g;
    const list = [];
    let m;
    while ((m = re.exec(src))) {
      let props = {};
      if (m[2] !== ')') {
        const open = m.index + m[0].length - 1;
        const close = matchBracket(src, open);
        if (close < 0) continue;
        props = parseObjectBody(src.slice(open + 1, close));
        re.lastIndex = close;
      }
      // Виджет, созданный внутри цикла/функции с вычисляемыми аргументами, помечаем.
      const before = src.slice(Math.max(0, m.index - 160), m.index);
      const dynamic = /\bfor\s*\([^)]*\)\s*\{[^}]*$/.test(before);
      const level = refName(props.show_level);
      const scene = (level === 'ONLY_AOD' || level === 'ONAL_AOD') ? 'aod' : level === 'ONLY_NORMAL' ? 'normal' : 'both';
      list.push({ widget: m[1], props, index: list.length, scene, dynamic });
    }
    return list;
  }

  // ───────────────────────── 4. Сборка слоёв AmazFace ─────────────────────────

  // Источник данных Zepp → источник данных текстового слоя AmazFace.
  const DATA_MAP = {
    STEP: 'STEP', HEART: 'HEART', CAL: 'CALORIE', DISTANCE: 'DISTANCE', STAND: 'STAND',
    PAI_WEEKLY: 'PAI_WEEKLY', PAI_DAILY: 'PAI_DAILY', BATTERY: 'BATTERY', WEATHER_CURRENT: 'WEATHER_TEMP',
    SUN_CURRENT: 'SUN_CURRENT', SUN_RISE: 'SUN_RISE', SUN_SET: 'SUN_SET', ALARM_CLOCK: 'ALARM_CLOCK',
    COUNT_DOWN: 'COUNT_DOWN', STOP_WATCH: 'STOP_WATCH', UVI: 'UVI', WIND: 'WIND',
    STRESS: 'STRESS', SPO2: 'SPO2', STEP_TARGET: 'STEP_TARGET', CAL_TARGET: 'CAL_TARGET', FLOOR: 'FLOOR',
    SECOND: 'SECOND',
  };

  // Старые hmApp.startApp URL и IMG_CLICK типы, встреченные в архивных
  // циферблатах, сопоставляем с системными приложениями Zepp OS.
  const SYSTEM_URL_MAP = {
    activityAppScreen: 'STATUS', WeatherScreen: 'WEATHER', AlarmInfoScreen: 'ALARM',
    StopWatchScreen: 'STOPWATCH', ScheduleCalScreen: 'CALENDAR', BaroAltimeterScreen: 'ALTIMETER',
    Settings_batteryManagerScreen: 'BATTERY', BioChargeHomeScreen: 'BODY_COMPOSITION',
    TideScreen: 'TIDE', PowerSaveHintScreen: 'SETTING', SportListScreen: 'SPORT', PhoneHomeScreen: 'PHONE',
  };
  const CLICK_TYPE_MAP = {
    STEP: 'STATUS', STAND: 'STATUS', CAL: 'CALENDAR', HEART: 'HR', BATTERY: 'BATTERY',
    WEATHER_CURRENT: 'WEATHER', SUN_CURRENT: 'SUN_AND_MOON', ALARM_CLOCK: 'ALARM', STOP_WATCH: 'STOPWATCH',
    COUNT_DOWN: 'COUNTDOWN', PAI_WEEKLY: 'PAI', ALTIMETER: 'ALTIMETER', STRESS: 'PRESSURE', SPO2: 'SPO2',
  };

  function clickTarget(widget, props) {
    if (widget === 'IMG_CLICK') {
      const type = refName(props.type);
      return CLICK_TYPE_MAP[type] ? { tap_action: 'METRIC', tap_metric: CLICK_TYPE_MAP[type] } : null;
    }
    const expr = isExpr(props.click_func) ? props.click_func.$expr : '';
    const url = /\burl\s*:\s*['"]([^'"]+)['"]/.exec(expr);
    if (url && SYSTEM_URL_MAP[url[1]]) return { tap_action: 'METRIC', tap_metric: SYSTEM_URL_MAP[url[1]] };
    const appId = /\b(?:appId|appid)\s*:\s*(\d+)/i.exec(expr);
    if (appId && url) return { tap_action: 'APP', tap_app_id: Number(appId[1]), tap_app_url: url[1] };
    return null;
  }

  const num = (v, d = 0) => (typeof v === 'number' && isFinite(v) ? v : d);
  const str = (v) => (typeof v === 'string' ? v : null);
  const baseName = (p) => String(p).split('/').pop();

  /**
   * @param {object[]} widgets результат parseWatchface
   * @param {object} ctx {
   *   assetId(fileName) → id|null,  assetSize(fileName) → {width,height}|null,
   *   defaults(defId) → props по умолчанию, defaultSize(defId) → {w,h}, nameOf(defId) }
   * @returns {{ scenes, report }}
   */
  function buildScenes(widgets, ctx) {
    const scenes = {
      normal: { components: [], background: { color: '#000000', imageAssetId: null, alpha: 100 }, nextIndex: {} },
      aod: { components: [], background: { color: '#000000', imageAssetId: null, alpha: 100 }, nextIndex: {} },
    };
    const report = { imported: 0, skipped: [], approximated: [], notes: [] };
    const bgSet = { normal: false, aod: false };

    const make = (sceneKey, defId, patch) => {
      const sc = scenes[sceneKey];
      const idx = (sc.nextIndex[defId] || 0) + 1;
      sc.nextIndex[defId] = idx;
      const size = ctx.defaultSize(defId);
      const comp = {
        id: `${defId}_${String(idx).padStart(3, '0')}`, defId, name: ctx.nameOf(defId),
        x: 0, y: 0, w: size.w, h: size.h, visible: true, locked: false,
        props: Object.assign({}, ctx.defaults(defId)),
      };
      const { props, ...geom } = patch;
      Object.assign(comp, geom);
      Object.assign(comp.props, props || {});
      sc.components.push(comp);
      report.imported++;
      return comp;
    };
    const targets = (w) => (w.scene === 'both' ? ['normal', 'aod'] : [w.scene]);
    const skip = (w, reason) => report.skipped.push({
      widget: w.widget, scene: w.scene, reason,
      where: ('x' in w.props || 'y' in w.props) ? `x=${num(w.props.x)}, y=${num(w.props.y)}` : '',
      type: refName(w.props.type) || '',
    });
    const approx = (w, what) => report.approximated.push({ widget: w.widget, scene: w.scene, what, type: refName(w.props.type) || '' });

    for (const w of widgets) {
      const p = w.props;
      if (w.dynamic || Object.values(p).some((v) => isExpr(v) && /\[\s*i\s*\]|\bi\b/.test(v.$expr))) {
        skip(w, 'слой создаётся циклом с вычисляемыми параметрами (например, секунды на AOD через таймер)');
        continue;
      }
      switch (w.widget) {
        case 'IMG': {
          const file = str(p.src);
          const id = file && ctx.assetId(file);
          if (!id) { skip(w, `картинка «${file || '?'}» не найдена в архиве`); break; }
          const size = ctx.assetSize(file) || { width: 100, height: 100 };
          const wd = num(p.w, size.width), ht = num(p.h, size.height);
          for (const sk of targets(w)) {
            // Первая картинка на весь экран — это фон циферблата.
            if (!bgSet[sk] && scenes[sk].components.length === 0 && num(p.x) === 0 && num(p.y) === 0 && wd >= 450 && ht >= 450) {
              scenes[sk].background.imageAssetId = id; bgSet[sk] = true; report.imported++;
              continue;
            }
            make(sk, 'image', { x: num(p.x), y: num(p.y), w: wd, h: ht, name: `Изображение ${baseName(file)}`, props: { src: id } });
          }
          if (num(p.angle) !== 0 && p.angle !== undefined) approx(w, 'поворот картинки (angle) не перенесён');
          break;
        }
        case 'TIME_POINTER': {
          for (const hand of ['hour', 'minute', 'second']) {
            const file = str(p[`${hand}_path`]);
            if (!file) continue;
            const id = ctx.assetId(file);
            if (!id) { skip(w, `стрелка «${file}» не найдена`); continue; }
            const cover = str(p[`${hand}_cover_path`]);
            for (const sk of targets(w)) {
              make(sk, `time_pointer_${hand}`, {
                props: Object.assign({
                  center_x: num(p[`${hand}_centerX`], 240), center_y: num(p[`${hand}_centerY`], 240),
                  pos_x: num(p[`${hand}_posX`]), pos_y: num(p[`${hand}_posY`]), path: id,
                }, cover && ctx.assetId(cover) ? { cover_path: ctx.assetId(cover) } : {}),
              });
            }
          }
          break;
        }
        case 'FILL_RECT': {
          if (!('w' in p) || !('h' in p)) { skip(w, 'виджет создаётся без параметров (параметры задаются кодом позже)'); break; }
          const color = typeof p.color === 'number' ? '#' + (p.color & 0xFFFFFF).toString(16).padStart(6, '0') : '#ffffff';
          for (const sk of targets(w)) make(sk, 'fill_rect', { x: num(p.x), y: num(p.y), w: num(p.w), h: num(p.h), props: { color, radius: num(p.radius) } });
          break;
        }
        case 'TEXT_IMG': {
          const arr = Array.isArray(p.font_array) ? p.font_array.map(str).filter(Boolean) : [];
          const first = arr[0] && ctx.assetSize(arr[0]);
          const dw = first ? first.width : 16, dh = first ? first.height : 24;
          const type = refName(p.type);
          const src = DATA_MAP[type];
          const rotated = Math.abs(num(p.angle)) === 90;
          const w0 = num(p.w, dw * 5), h0 = num(p.h, dh);
          const align = refName(p.align_h);
          for (const sk of targets(w)) {
            make(sk, 'text', {
              x: num(p.x), y: num(p.y), w: rotated ? h0 : w0, h: rotated ? w0 : h0,
              name: `⚠ цифры-картинки ${type || ''}`.trim(),
              props: {
                data_source: src || 'NONE', text: src ? '' : '0', text_size: Math.max(8, Math.round(dh * 0.8)),
                color: '#ffffff', align_h: ['LEFT', 'CENTER_H', 'RIGHT'].includes(align) ? align : 'CENTER_H', align_v: 'CENTER_V',
              },
              imported: { widget: 'TEXT_IMG', raw: p },
            });
          }
          approx(w, 'цифры из картинок заменены текстом' + (rotated ? ' (поворот ±90° не перенесён)' : '') + (src ? '' : '; источник данных не распознан'));
          break;
        }
        case 'TEXT':
        case 'TEXT_FONT': {
          const type = refName(p.type);
          const source = w.widget === 'TEXT_FONT' ? DATA_MAP[type] : null;
          const alignH = refName(p.align_h), alignV = refName(p.align_v);
          const color = typeof p.color === 'number' ? '#' + (p.color & 0xFFFFFF).toString(16).padStart(6, '0') : '#ffffff';
          const size = Math.max(8, num(p.text_size, 32));
          const font = str(p.font) && ctx.fontId ? ctx.fontId(p.font) : null;
          for (const sk of targets(w)) {
            make(sk, 'text', {
              x: num(p.x), y: num(p.y), w: num(p.w, 120), h: num(p.h, 40),
              name: w.widget === 'TEXT_FONT' ? `Данные: ${type || 'неизвестно'}` : 'Текст из архива',
              props: {
                text: w.widget === 'TEXT' ? (str(p.text) || '') : (source ? '' : '0'),
                data_source: source || 'NONE', text_size: size, color,
                align_h: ['LEFT', 'CENTER_H', 'RIGHT'].includes(alignH) ? alignH : 'CENTER_H',
                align_v: ['TOP', 'CENTER_V', 'BOTTOM'].includes(alignV) ? alignV : 'CENTER_V',
                ...(font ? { font } : {}),
                ...(source && p.unit_type === 1 && ['BATTERY', 'HUMIDITY'].includes(source) ? { suffix: '%' } : {}),
              },
              imported: { widget: w.widget, raw: p },
            });
          }
          if (w.widget === 'TEXT_FONT' && !source) approx(w, `тип данных ${type || ''} не распознан — вместо него показан ноль`);
          if (str(p.font) && !font) approx(w, `шрифт «${p.font}» не найден в архиве — используется системный шрифт`);
          break;
        }
        case 'IMG_TIME': {
          const arr = (p.hour_array || p.minute_array || []).map?.(str) || [];
          const sz = arr[0] && ctx.assetSize(arr[0]);
          const dw = sz ? sz.width : 40, dh = sz ? sz.height : 60;
          const x = num(p.hour_startX, num(p.minute_startX)), y = num(p.hour_startY, num(p.minute_startY));
          const hasMin = 'minute_startX' in p;
          const right = hasMin ? num(p.minute_startX) + dw * 2 : x + dw * 2;
          for (const sk of targets(w)) {
            make(sk, 'time_hm', { x, y, w: Math.max(dw * 4, right - x), h: dh, name: '⚠ время (цифры-картинки)', props: { text_size: Math.max(8, Math.round(dh * 0.8)) }, imported: { widget: 'IMG_TIME', raw: p } });
          }
          approx(w, 'время из картинок заменено текстом ЧЧ:ММ (положение часов/минут приближённое)');
          break;
        }
        case 'IMG_DATE': {
          const kinds = [
            ['day', 'date_day', 'день'], ['month', 'date_month', 'месяц'], ['year', 'date_year', 'год'],
          ];
          let any = false;
          for (const [k, defId, label] of kinds) {
            if (!(`${k}_startX` in p)) continue;
            const arr = (p[`${k}_en_array`] || p[`${k}_sc_array`] || []).map?.(str) || [];
            const sz = arr[0] && ctx.assetSize(arr[0]);
            for (const sk of targets(w)) {
              make(sk, defId, { x: num(p[`${k}_startX`]), y: num(p[`${k}_startY`]), w: (sz ? sz.width : 30) * 2 + 4, h: sz ? sz.height : 30, name: `⚠ ${label} (картинки)`, imported: { widget: 'IMG_DATE', raw: p } });
            }
            any = true;
          }
          if (any) approx(w, 'дата из картинок заменена текстом');
          else skip(w, 'не удалось определить поля даты');
          break;
        }
        case 'IMG_WEEK': {
          const arr = (p.week_en || p.week_sc || p.week_tc || []).map?.(str) || [];
          const sz = arr[0] && ctx.assetSize(arr[0]);
          for (const sk of targets(w)) {
            make(sk, 'weekday', { x: num(p.x), y: num(p.y), w: sz ? sz.width : 80, h: sz ? sz.height : 30, name: '⚠ день недели (картинки)', props: { weekday_locale: 'RU' }, imported: { widget: 'IMG_WEEK', raw: p } });
          }
          approx(w, 'день недели из картинок заменён текстом');
          break;
        }
        case 'IMG_LEVEL': {
          const arr = Array.isArray(p.image_array) ? p.image_array.map(str) : [];
          if (refName(p.type) === 'WEATHER_CURRENT' && arr.length >= 2 && arr.every(Boolean) && ctx.weatherIconIds) {
            if (!report.weatherSlots) report.weatherSlots = arr.slice(0, ctx.weatherIconIds.length);
            const sz = ctx.assetSize(arr[0]) || { width: 64, height: 64 };
            for (const sk of targets(w)) make(sk, 'weather_icon', { x: num(p.x), y: num(p.y), w: sz.width, h: sz.height, name: 'Значок погоды', props: { src: ctx.weatherIconIds[0] } });
            report.notes.push(`Значок погоды: ${Math.min(arr.length, ctx.weatherIconIds.length)} картинок перенесены в набор «Иконки погоды».`);
          } else skip(w, 'ступенчатый индикатор из кадровых картинок пока нельзя точно восстановить как живой индикатор');
          break;
        }
        case 'IMG_STATUS': {
          const file = str(p.src);
          const id = file && ctx.assetId(file);
          const status = refName(p.type);
          if (!id) { skip(w, `значок статуса «${file || '?'}» не найден в архиве`); break; }
          if (!['DISCONNECT', 'CLOCK', 'DISTURB', 'LOCK'].includes(status)) { skip(w, `неизвестный системный статус «${status || '?'}»`); break; }
          const size = ctx.assetSize(file) || { width: 32, height: 32 };
          for (const sk of targets(w)) make(sk, 'system_status', {
            x: num(p.x), y: num(p.y), w: num(p.w, size.width), h: num(p.h, size.height),
            name: status === 'DISCONNECT' ? 'Нет Bluetooth' : status === 'CLOCK' ? 'Будильник' : status === 'DISTURB' ? 'Не беспокоить' : 'Экран заблокирован',
            props: { src: id, type: status },
          });
          break;
        }
        case 'IMG_CLICK':
        case 'BUTTON': {
          const action = clickTarget(w.widget, p);
          if (!action) { skip(w, w.widget === 'IMG_CLICK' ? 'тип данных этой зоны не сопоставлен со штатным экраном' : 'переход в click_func не распознан или ведёт в неподдерживаемый экран'); break; }
          const file = w.widget === 'BUTTON' ? str(p.normal_src) : null;
          const assetId = file && ctx.assetId(file);
          const width = num(p.w, 40), height = num(p.h, 40);
          for (const sk of targets(w)) {
            const component = make(sk, assetId ? 'image' : 'fill_rect', {
              x: num(p.x), y: num(p.y), w: width, h: height,
              name: w.widget === 'BUTTON' ? `Кнопка → ${action.tap_metric || action.tap_app_url}` : `Открыть экран → ${action.tap_metric}`,
              props: assetId ? { src: assetId } : { color: '#000000', alpha: 0 },
            });
            component.tapZones = [{
              id: `tap_${String(component.id).replace(/[^a-zA-Z0-9_-]/g, '_')}`,
              name: action.tap_metric ? `Открыть: ${action.tap_metric}` : 'Открыть приложение',
              x: 0, y: 0, w: width, h: height, visible: true, locked: false,
              props: Object.assign({ tap_action: 'NONE', tap_metric: 'STATUS', tap_app_id: 0, tap_app_url: 'pages/index' }, action),
            }];
          }
          break;
        }
        case 'Linear_Scale': skip(w, 'линейная шкала'); break;
        case 'Text_Rotate': skip(w, 'повёрнутый текст из картинок'); break;
        case 'WIDGET_DELEGATE': break; // служебный наблюдатель жизненного цикла
        default: skip(w, 'тип виджета пока не поддерживается');
      }
    }
    if (!widgets.some((w) => w.scene !== 'normal')) report.notes.push('В циферблате нет отдельной сцены AOD.');
    return { scenes, report };
  }

  // ───────────────────────── Браузерная часть ─────────────────────────

  const api = { unpackArchive, decodeSomh, parseWatchface, buildScenes, stripComments, parseValue, isPng };
  if (typeof module !== 'undefined' && module.exports) { module.exports = api; return; }
  root.ArchiveImport = api;

  if (typeof document === 'undefined') return;

  const $ = (id) => document.getElementById(id);
  const esc = (t) => String(t == null ? '' : t).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  async function rgbaToDataUrl(img) {
    const canvas = document.createElement('canvas');
    canvas.width = img.width; canvas.height = img.height;
    canvas.getContext('2d').putImageData(new ImageData(img.rgba, img.width, img.height), 0, 0);
    return canvas.toDataURL('image/png');
  }

  async function bytesToAsset(path, bytes) {
    const name = baseName(path).replace(/\.[^.]+$/, '');
    let dataUrl, width, height;
    const somh = isPng(bytes) ? null : decodeSomh(bytes);
    if (somh) {
      dataUrl = await rgbaToDataUrl(somh); width = somh.width; height = somh.height;
    } else {
      const mime = isPng(bytes) ? 'image/png' : /\.jpe?g$/i.test(path) ? 'image/jpeg' : null;
      if (!mime) return null;
      const blob = new Blob([bytes], { type: mime });
      const bmp = await createImageBitmap(blob);
      width = bmp.width; height = bmp.height;
      dataUrl = await new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = () => rej(r.error); r.readAsDataURL(blob); });
    }
    return { id: makeAssetId(), name, dataUrl, width, height, format: 'PNG', size: bytes.length };
  }

  async function bytesToFont(path, bytes) {
    let filename = baseName(path);
    const ext0 = (filename.match(/\.[^.]+$/) || ['.ttf'])[0].toLowerCase();
    if (!['.ttf', '.otf', '.woff', '.woff2'].includes(ext0) || typeof makeFontId !== 'function') return null;
    // Zepp OS читает только TTF — OTF/WOFF конвертируем при импорте.
    let data = bytes, converted = false, from = '';
    if (typeof FontConverter !== 'undefined') {
      try {
        const res = await FontConverter.toTtf(bytes);
        data = res.bytes; converted = res.converted; from = res.from;
      } catch (e) {
        console.warn('Шрифт ' + filename + ' не удалось привести к TTF:', e);
      }
    }
    const isTtf = converted || ext0 === '.ttf';
    if (converted) filename = FontConverter.toTtfName(filename);
    const mime = isTtf ? 'font/ttf' : ({ '.otf': 'font/otf', '.woff': 'font/woff', '.woff2': 'font/woff2' })[ext0];
    const blob = new Blob([data], { type: mime });
    const dataUrl = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(blob);
    });
    const id = makeFontId();
    const font = { id, name: baseName(path).replace(/\.[^.]+$/, ''), filename, ext: isTtf ? '.ttf' : ext0, dataUrl, size: data.length, cssFamily: `ProjectFont_${id.replace(/[^a-zA-Z0-9_]/g, '_')}` };
    if (converted) font.convertedFrom = from;
    return font;
  }

  /** Загружает архив в store. Возвращает отчёт. */
  async function importArchive(file, store, onStep) {
    const step = onStep || (() => {});
    step('Распаковываю архив…');
    const bytes = new Uint8Array(await file.arrayBuffer());
    const unpacked = await unpackArchive(bytes, (b) => readZipEntries(b));
    return importFiles(unpacked, store, step);
  }

  /** Распакованная папка проекта: FileList из <input webkitdirectory>. Находит app.json и отрезает префикс. */
  async function folderToUnpacked(fileList) {
    const entries = new Map();
    for (const f of fileList) {
      const rel = (f.webkitRelativePath || f.name).replace(/\\/g, '/');
      if (/(^|\/)(node_modules|\.git)\//.test(rel)) continue;
      entries.set(rel, new Uint8Array(await f.arrayBuffer()));
    }
    for (const path of entries.keys()) {
      if (/(^|\/)amazface\.project\.json$/.test(path)) {
        return { files: rebase(entries, path.replace(/amazface\.project\.json$/, '')), source: 'папка', amazface: true };
      }
    }
    const roots = [...entries.keys()].filter((p) => /(^|\/)app\.json$/.test(p)).map((p) => p.replace(/app\.json$/, ''));
    roots.sort((a, b) => a.length - b.length);
    for (const base of roots) {
      if ([...entries.keys()].some((p) => p.startsWith(base) && /(^|\/)watchface\/[^/]+\.js$/.test(p))) {
        return { files: rebase(entries, base), source: 'папка' };
      }
    }
    throw new Error('В папке не найден циферблат Zepp OS: нужны app.json и watchface/index.js.');
  }

  async function importFolder(fileList, store, onStep) {
    const step = onStep || (() => {});
    step('Читаю папку…');
    return importFiles(await folderToUnpacked(fileList), store, step);
  }

  async function importFiles({ files, source, amazface }, store, step) {

    if (amazface) { // наш собственный архив: состояние редактора уже внутри
      store.loadFromJSON(new TextDecoder().decode(files.get('amazface.project.json')));
      return { own: true, source, imported: 0, skipped: [], approximated: [], notes: ['Открыт проект AmazFace целиком.'], assets: store.state.assets.length };
    }

    const appJson = JSON.parse(new TextDecoder().decode(files.get('app.json')).replace(/^\uFEFF/, ''));
    const app = appJson.app || {};
    const facePath = ((appJson.module && appJson.module.watchface && appJson.module.watchface.path) || 'watchface/index') + '.js';
    const jsBytes = files.get(facePath) || files.get('watchface/index.js');
    if (!jsBytes) throw new Error(`В архиве нет файла ${facePath}.`);
    const jsText = new TextDecoder().decode(jsBytes);
    if (!/createWidget/.test(jsText)) {
      throw new Error('watchface/index.js не содержит вызовов createWidget: файл, видимо, зашифрован или собран иначе. Такой формат пока не поддерживается.');
    }

    step('Преобразую картинки…');
    const assets = [];
    const fonts = [];
    const byName = new Map();
    const byFont = new Map();
    let preview = null, failed = 0;
    for (const [path, data] of files) {
      if (/^assets\/fonts\/.+\.(ttf|otf|woff2?)$/i.test(path)) {
        const font = await bytesToFont(path, data).catch(() => null);
        if (font) { fonts.push(font); byFont.set(baseName(path).toLowerCase(), font.id); }
        else failed++;
        continue;
      }
      if (!/^assets\/.+\.(png|jpe?g)$/i.test(path)) continue;
      const a = await bytesToAsset(path, data).catch(() => null);
      if (!a) { failed++; continue; }
      if (/^preview(_en)?$/i.test(a.name)) { preview = a; continue; }
      assets.push(a);
      byName.set(baseName(path).toLowerCase(), a);
    }

    step('Разбираю слои…');
    const widgets = parseWatchface(jsText);
    const { scenes, report } = buildScenes(widgets, {
      assetId: (f) => (byName.get(baseName(f).toLowerCase()) || {}).id || null,
      assetSize: (f) => byName.get(baseName(f).toLowerCase()) || null,
      fontId: (f) => byFont.get(baseName(f).toLowerCase()) || null,
      weatherIconIds: typeof WEATHER_ICON_SET !== 'undefined' ? WEATHER_ICON_SET.map((c) => c.id) : null,
      defaults: (defId) => { const o = {}; for (const pr of REGISTRY[defId].properties) if (pr.default !== undefined) o[pr.key] = pr.default; return o; },
      defaultSize: (defId) => REGISTRY[defId].defaultSize,
      nameOf: (defId) => REGISTRY[defId].name,
    });

    // Слоты иконок погоды: картинка слота i → состояние WEATHER_ICON_SET[i].
    if (report.weatherSlots) {
      report.weatherSlots.forEach((f, i) => {
        const a = byName.get(baseName(f).toLowerCase());
        if (a && !a.weatherIcon) a.weatherIcon = WEATHER_ICON_SET[i].id;
      });
    }
    store.newProject();
    const st = store.state;
    st.meta.name = app.appName || 'Импортированный циферблат';
    if (Number(app.appId)) st.app.appId = Number(app.appId);
    if (app.vender) st.app.vendor = app.vender;
    if (app.version && app.version.name) st.app.versionName = app.version.name;
    if (app.version && Number(app.version.code)) st.app.versionCode = Number(app.version.code);
    st.assets = assets;
    st.fonts = fonts;
    if (preview) st.preview = Object.assign({}, st.preview, { dataUrl: preview.dataUrl });
    st.components = scenes.normal.components;
    st.background = scenes.normal.background;
    st.nextIndex = scenes.normal.nextIndex;
    st.scenes = st.scenes || {};
    st.scenes.aod = Object.assign({}, st.scenes.aod, {
      components: scenes.aod.components, background: scenes.aod.background, nextIndex: scenes.aod.nextIndex,
    });
    store.loadFromJSON(store.toJSON()); // сброс истории и перерисовка

    return Object.assign(report, {
      source, assets: assets.length, failedImages: failed,
      normal: scenes.normal.components.length, aod: scenes.aod.components.length,
      author: /Watch_Face_Editor tool v([\d.]+)/.exec(jsText)?.[1] || null,
    });
  }

  function showReport(report) {
    let dlg = $('archive-report-dialog');
    if (!dlg) {
      dlg = document.createElement('dialog');
      dlg.id = 'archive-report-dialog';
      dlg.className = 'zpk-modal';
      dlg.setAttribute('aria-label', 'Отчёт импорта');
      dlg.innerHTML = '<div class="zpk-modal-inner"><div class="zpk-head"><b>Отчёт импорта</b><button type="button" id="arc-close" aria-label="Закрыть">✕</button></div><div class="zpk-body" id="arc-body"></div></div>';
      document.body.appendChild(dlg);
      dlg.querySelector('#arc-close').onclick = () => dlg.close();
    }
    const group = (list) => {
      const m = new Map();
      for (const it of list) {
        const key = `${it.widget}|${it.reason || it.what}`;
        const e = m.get(key) || { ...it, n: 0, where: [], types: [] };
        e.n++; if (it.where) e.where.push(it.where);
        if (it.type && !e.types.includes(it.type)) e.types.push(it.type);
        m.set(key, e);
      }
      return [...m.values()];
    };
    const row = (e, text) => `<li><b>${esc(e.widget)}</b>${e.n > 1 ? ` ×${e.n}` : ''} — ${esc(text)}${e.where && e.where.length ? `<br><small>${esc(e.where.slice(0, 4).join(' · '))}${e.where.length > 4 ? '…' : ''}</small>` : ''}</li>`;
    let html = `<p><b>Источник:</b> ${esc(report.source)}${report.author ? ` · Watch_Face_Editor v${esc(report.author)}` : ''}</p>`;
    if (report.own) html += `<p>${esc(report.notes[0])}</p>`;
    else {
      html += `<p>Перенесено слоёв: <b>${report.imported}</b> (Normal — ${report.normal}, AOD — ${report.aod}), картинок: <b>${report.assets}</b>${report.failedImages ? `, не распознано файлов: ${report.failedImages}` : ''}.</p>`;
      const ap = group(report.approximated);
      if (ap.length) html += `<p><b>Приближённо (слой заменён заглушкой, смотрите значок ⚠ в названии):</b></p><ul>${ap.map((e) => row(e, e.what + (e.types.length ? ` [${e.types.join(', ')}]` : ''))).join('')}</ul>`;
      const sk = group(report.skipped);
      if (sk.length) html += `<p><b>Не перенесено:</b></p><ul>${sk.map((e) => row(e, e.reason + (e.types.length ? ` [${e.types.join(', ')}]` : ''))).join('')}</ul>`;
      html += '<p><small>Картинки цифр и значков загружены в «Ресурсы» целиком — их можно подставлять вручную.</small></p>';
    }
    dlg.querySelector('#arc-body').innerHTML = html;
    dlg.showModal();
  }

  function init() {
    const btn = $('welcome-archive');
    if (!btn || !window.AmazWelcome) return;
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.zpk,.zab,.zip';
    input.hidden = true;
    document.body.appendChild(input);
    let pendingFile = null;
    let destinationDialog = null;
    const startImport = async (file, destinationHandle) => {
      try {
        if (window.AmazWelcome.prepareForArchiveImport) await window.AmazWelcome.prepareForArchiveImport();
        const report = await withBusyOverlay('Открываю архив…', file.name, () => (file.folder ? importFolder(file.folder, store, (t) => { try { $('busy-text') && ($('busy-text').textContent = t); } catch (e) { /* не критично */ } }) : importArchive(file, store, (t) => { try { $('busy-text') && ($('busy-text').textContent = t); } catch (e) { /* не критично */ } })));
        await window.AmazWelcome.adoptImported(destinationHandle);
        showReport(report);
      } catch (err) {
        console.error(err);
        alert(err.message || String(err));
      }
    };
    const askDestination = (file) => {
      if (!destinationDialog) {
        destinationDialog = document.createElement('dialog');
        destinationDialog.className = 'zpk-modal';
        destinationDialog.setAttribute('aria-label', 'Папка для проекта из архива');
        destinationDialog.innerHTML = '<div class="zpk-modal-inner"><div class="zpk-head"><b>Куда сохранить проект?</b><button type="button" data-arc-cancel aria-label="Закрыть">✕</button></div><div class="zpk-body"><p data-arc-file></p><p>Выберите заранее созданную папку. Архив будет преобразован в проект AmazFace, сохранён туда и открыт для работы.</p><div class="ghi-row"><button type="button" data-arc-destination class="ghi-btn primary">Выбрать папку</button><button type="button" data-arc-cancel class="ghi-btn">Отмена</button></div></div></div>';
        document.body.appendChild(destinationDialog);
        destinationDialog.querySelectorAll('[data-arc-cancel]').forEach((b) => b.onclick = () => destinationDialog.close());
        destinationDialog.querySelector('[data-arc-destination]').onclick = async () => {
          try {
            const handle = await FsProject.pick();
            const fileToImport = pendingFile;
            pendingFile = null;
            destinationDialog.close();
            if (fileToImport) await startImport(fileToImport, handle);
          } catch (e) {
            if (!e || e.name !== 'AbortError') alert(e.message || String(e));
          }
        };
      }
      pendingFile = file;
      destinationDialog.querySelector('[data-arc-file]').textContent = `Выбран архив: ${file.name}`;
      if (!destinationDialog.open) destinationDialog.showModal();
    };
    btn.onclick = () => { input.value = ''; input.click(); };
    input.onchange = async () => {
      const file = input.files && input.files[0];
      if (!file) return;
      if (typeof FsProject !== 'undefined' && FsProject.supported()) askDestination(file);
      else startImport(file, null);
    };
    // Распакованная папка проекта Zepp (app.json + watchface/ + assets/).
    const dirBtn = $('welcome-zepp-folder');
    if (dirBtn) {
      const dirInput = document.createElement('input');
      dirInput.type = 'file';
      dirInput.setAttribute('webkitdirectory', '');
      dirInput.hidden = true;
      document.body.appendChild(dirInput);
      dirBtn.onclick = () => { dirInput.value = ''; dirInput.click(); };
      dirInput.onchange = () => {
        const list = Array.from(dirInput.files || []);
        if (!list.length) return;
        const name = ((list[0].webkitRelativePath || '').split('/')[0]) || 'папка';
        // Как архив: тот же диалог выбора папки назначения, но источник — файлы папки.
        const fake = { name, folder: list };
        if (typeof FsProject !== 'undefined' && FsProject.supported()) askDestination(fake);
        else startImport(fake, null);
      };
    }
  }
  init();
})(typeof window !== 'undefined' ? window : globalThis);
