// src/exporter/share-images.js
//
// Картинки для публикации и ручной отправки:
//   - qr        — отдельный QR-код для ручной отправки;
//   - watch     — мокап часов в полном качестве;
//   - night/aod — отдельные высококачественные мокапы этих сцен;
//   - watch200  — уменьшенный мокап высотой 200 px;
//   - combined  — мокап часов с циферблатом и QR-кодом.
//
// Часы рисует существующий WatchMockup (шаблон корпуса и ремешка не меняется),
// QR — матрица из qrEncodeToMatrix. Ничего не отправляется в сеть.
// Файл подключается после watch-mockup.js и qr-encoder.js.

(function () {
  'use strict';

  const FONT = '"Segoe UI", "Helvetica Neue", Arial, sans-serif';
  const QUIET = 4; // модулей тихой зоны — как в qrMatrixToPngDataUrl

  function makeCanvas(w, h) {
    const c = document.createElement('canvas');
    c.width = w; c.height = h;
    return c;
  }

  function toBlob(canvas) {
    return new Promise((resolve, reject) =>
      canvas.toBlob(b => b ? resolve(b) : reject(new Error('Не удалось получить PNG')), 'image/png'));
  }

  function roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  // Рисует QR (с тихой зоной) в левый верхний угол (x, y); размер — целое число пикселей на модуль.
  function drawQr(ctx, matrix, x, y, moduleSize) {
    const n = matrix.size;
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(x, y, (n + QUIET * 2) * moduleSize, (n + QUIET * 2) * moduleSize);
    ctx.fillStyle = '#000000';
    for (let r = 0; r < n; r++) {
      for (let c = 0; c < n; c++) {
        if (matrix.modules[r][c]) ctx.fillRect(x + (c + QUIET) * moduleSize, y + (r + QUIET) * moduleSize, moduleSize, moduleSize);
      }
    }
  }

  // Подбирает размер шрифта, чтобы строка влезла в maxWidth.
  function fitFont(ctx, text, weight, maxPx, minPx, maxWidth) {
    let size = maxPx;
    for (; size > minPx; size -= 2) {
      ctx.font = `${weight} ${size}px ${FONT}`;
      if (ctx.measureText(text).width <= maxWidth) break;
    }
    ctx.font = `${weight} ${size}px ${FONT}`;
    return size;
  }

  // «Amazfit Balance 2 (480×480)» → «Amazfit Balance 2»
  function deviceLabel(project) {
    const raw = String(project.device?.name || '').replace(/\s*\(.*?\)\s*/g, ' ').replace(/\s*[—–-]\s*target.*$/i, '').trim();
    return raw || 'Zepp OS';
  }

  function faceName(project) {
    return String(project.meta?.name || '').trim() || 'Watch Face';
  }

  // Build a renderer input from a saved scene while preserving the shared assets/fonts.
  // The active editor scene wins so unsaved canvas changes are reflected in exports.
  function projectForScene(project, sceneName) {
    const saved = project.scenes && project.scenes[sceneName];
    const scene = project.mode === sceneName ? project : saved;
    if (!scene) return null;
    const settings = sceneName === 'aod' ? (saved?.settings || project.scenes?.aod?.settings || {}) : {};
    const background = Object.assign({ color: '#000000', imageAssetId: null, alpha: 100 }, scene.background || {});
    if (sceneName === 'aod' && settings.background) background.color = settings.background;
    return {
      project: Object.assign({}, project, {
        mode: sceneName,
        components: Array.isArray(scene.components) ? scene.components : [],
        background,
        nextIndex: scene.nextIndex || {},
      }),
      brightness: sceneName === 'aod'
        ? Math.max(1, Math.min(100, Number(settings.brightness) || 100))
        : 100,
    };
  }

  // 1. Только QR
  async function buildQrCanvas(matrix) {
    const total = matrix.size + QUIET * 2;
    const m = Math.max(4, Math.round(800 / total));
    const cv = makeCanvas(total * m, total * m);
    drawQr(cv.getContext('2d'), matrix, 0, 0, m);
    return cv;
  }

  // 2. Только часы
  async function buildWatchCanvas(project, opts = {}) {
    return WatchMockup.buildWatchMockupCanvas(project, {
      transparent: !!opts.transparent,
      maxSize: opts.maxSize,
      brightness: opts.brightness,
    });
  }

  // Small scene badge above the watch keeps separately exported PNGs recognizable.
  function labelWatchCanvas(watch, label, accent) {
    const header = 64;
    const cv = makeCanvas(watch.width, watch.height + header);
    const ctx = cv.getContext('2d');
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(watch, 0, header);

    const x = 22, y = 12, h = 40, padX = 14, dotR = 4;
    const fontSize = Math.max(13, Math.min(17, Math.round(watch.width * 0.022)));
    ctx.font = `700 ${fontSize}px ${FONT}`;
    const pillW = Math.ceil(ctx.measureText(label).width + padX * 2 + dotR * 2 + 8);
    ctx.save();
    ctx.shadowColor = 'rgba(0,0,0,0.24)';
    ctx.shadowBlur = 8;
    ctx.shadowOffsetY = 2;
    roundRect(ctx, x, y, pillW, h, h / 2);
    ctx.fillStyle = 'rgba(17,24,39,0.96)';
    ctx.fill();
    ctx.restore();

    ctx.beginPath();
    ctx.arc(x + padX + dotR, y + h / 2, dotR, 0, Math.PI * 2);
    ctx.fillStyle = accent;
    ctx.fill();
    ctx.font = `700 ${fontSize}px ${FONT}`;
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = '#f8fafc';
    ctx.fillText(label, x + padX + dotR * 2 + 8, y + h / 2);
    return cv;
  }

  // 3. Презентационная карточка в стиле Almaty: фронтальные часы слева,
  // рабочий QR и аккуратная типографика справа. Исходный шаблон корпуса не меняется.
  async function buildCombinedCanvas(project, matrix) {
    const W = 1600, H = 1200;
    const watch = await buildWatchCanvas(project, { maxSize: 1100 });
    const cv = makeCanvas(W, H);
    const ctx = cv.getContext('2d');
    ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';

    // Глубокий сине-графитовый фон с мягким холодным свечением.
    const bg = ctx.createLinearGradient(0, 0, W, H);
    bg.addColorStop(0, '#0a101a');
    bg.addColorStop(0.52, '#101a2a');
    bg.addColorStop(1, '#151d2a');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, W, H);

    // Часы остаются строго фронтальными: рисуем готовый WatchMockup без поворотов,
    // перспективных трансформаций или перерисовки корпуса/ремешка.
    const watchW = 800;
    const watchH = watch.height * watchW / watch.width;
    const watchX = 18;
    const watchY = Math.round((H - watchH) / 2);
    const glow = ctx.createRadialGradient(watchX + watchW * 0.52, H * 0.48, 30,
      watchX + watchW * 0.52, H * 0.48, 620);
    glow.addColorStop(0, 'rgba(70,145,255,0.20)');
    glow.addColorStop(0.6, 'rgba(50,110,210,0.07)');
    glow.addColorStop(1, 'rgba(50,110,210,0)');
    ctx.fillStyle = glow;
    ctx.fillRect(0, 0, W, H);
    ctx.save();
    ctx.shadowColor = 'rgba(0,0,0,0.42)';
    ctx.shadowBlur = 30;
    ctx.shadowOffsetY = 10;
    ctx.drawImage(watch, watchX, watchY, watchW, watchH);
    ctx.restore();

    // QR сохраняет исходную матрицу и тихую зону, чтобы код оставался сканируемым.
    const total = matrix.size + QUIET * 2;
    const moduleSize = Math.max(4, Math.floor(480 / total));
    const qrPx = total * moduleSize;
    const pad = 22;
    const centerX = 1190;
    const qx = Math.round(centerX - qrPx / 2);
    const qy = 350;
    const cardX = qx - pad, cardY = qy - pad;
    const cardW = qrPx + pad * 2, cardH = qrPx + pad * 2;

    // Инструкция над QR — в стиле референса Almaty.
    ctx.save();
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = '#8fbaff';
    ctx.font = `700 25px ${FONT}`;
    const scanText = 'СКАНИРУЙТЕ В ZEPP APP';
    fitFont(ctx, scanText, '700', 25, 20, cardW + 70);
    ctx.fillText(scanText, centerX, cardY - 40);
    ctx.restore();

    // Белая карточка с закруглением и деликатной тенью.
    ctx.save();
    ctx.shadowColor = 'rgba(0,0,0,0.38)';
    ctx.shadowBlur = 30;
    ctx.shadowOffsetY = 12;
    ctx.fillStyle = '#ffffff';
    roundRect(ctx, cardX, cardY, cardW, cardH, 26);
    ctx.fill();
    ctx.restore();
    drawQr(ctx, matrix, qx, qy, moduleSize);

    // Подпись под QR: акцентная линия, название циферблата и модель устройства.
    const titleY = cardY + cardH + 62;
    ctx.save();
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    const lineW = 170;
    const lineGradient = ctx.createLinearGradient(centerX - lineW / 2, 0, centerX + lineW / 2, 0);
    lineGradient.addColorStop(0, 'rgba(70,145,255,0)');
    lineGradient.addColorStop(0.5, '#63a8ff');
    lineGradient.addColorStop(1, 'rgba(70,145,255,0)');
    ctx.fillStyle = lineGradient;
    ctx.fillRect(centerX - lineW / 2, titleY - 27, lineW, 3);

    ctx.fillStyle = '#f5f7fb';
    const title = faceName(project);
    fitFont(ctx, title, '700', 48, 25, 500);
    ctx.fillText(title, centerX, titleY + 17, 500);

    ctx.fillStyle = '#aebbd0';
    const device = deviceLabel(project);
    fitFont(ctx, device, '400', 34, 22, 500);
    ctx.fillText(device, centerX, titleY + 67, 500);

    // Небольшая подпись завершает композицию, не конкурируя с названием.
    ctx.fillStyle = '#7185a4';
    ctx.font = `600 15px ${FONT}`;
    ctx.fillText('WATCH FACE', centerX, titleY + 106);
    ctx.restore();

    return cv;
  }

  /**
   * Собирает изображения для публикации и при необходимости превью отдельных сцен.
   * @param {object} project  store.state
   * @param {object} matrix   матрица QR (qrEncodeToMatrix)
   * @param {{transparentWatch?: boolean, scenePreviews?: boolean}} [opts]
   * @returns {Promise<Array<{id:string,label:string,suffix:string,blob:Blob,width:number,height:number}>>}
   */
  // ───────── карта тап-зон: мокап + подсветка + нумерация + легенда ─────────
  const ZONE_COLORS = ['#ff5d73', '#ffb020', '#3ddc97', '#4da3ff', '#b57bff', '#ff8a3d', '#19d3da', '#e86bd6', '#a3e635', '#f5d90a'];

  function zoneActionLabel(p) {
    const action = p.tap_action || 'NONE';
    if (action === 'METRIC') {
      const list = (typeof SYSTEM_SCREENS !== 'undefined' && Array.isArray(SYSTEM_SCREENS)) ? SYSTEM_SCREENS : [];
      const scr = list.find((x) => x.value === p.tap_metric);
      return scr ? scr.label : String(p.tap_metric || 'Системный экран');
    }
    if (action === 'APP') {
      const id = Number(p.tap_app_id) || 0;
      return id ? `Приложение (App ID ${id})` : 'Другое приложение';
    }
    if (action === 'FLASHLIGHT') return 'Фонарик (вкл./выкл.)';
    if (action === 'SETTINGS') return 'Настройки циферблата';
    return '';
  }

  // Координаты считаются так же, как при экспорте в index.js: позиция компонента + смещение зоны.
  function collectTapZones(project) {
    const dw = Math.max(1, Number(project.device?.w) || 480);
    const dh = Math.max(1, Number(project.device?.h) || 480);
    const out = [];
    for (const comp of (project.components || [])) {
      if (comp.visible === false) continue;
      for (const zone of (Array.isArray(comp.tapZones) ? comp.tapZones : [])) {
        if (zone.visible === false) continue;
        const props = zone.props || {};
        const label = zoneActionLabel(props);
        if (!label) continue; // «Ничего» — зона ничего не открывает
        const x = Math.max(0, Math.min(dw - 1, Math.round((Number(comp.x) || 0) + (Number(zone.x) || 0))));
        const y = Math.max(0, Math.min(dh - 1, Math.round((Number(comp.y) || 0) + (Number(zone.y) || 0))));
        const w = Math.max(1, Math.min(dw - x, Math.round(Number(zone.w) || 1)));
        const h = Math.max(1, Math.min(dh - y, Math.round(Number(zone.h) || 1)));
        out.push({
          n: out.length + 1, x, y, w, h, label,
          sub: `${zone.name || zone.id} · ${comp.name || comp.id}`,
        });
      }
    }
    return { zones: out, dw, dh };
  }

  /** Часы на мокапе, тап-зоны подсвечены и пронумерованы, справа легенда «номер → что открывается». */
  async function buildTapZonesCanvas(project) {
    const { zones, dw, dh } = collectTapZones(project);
    if (!zones.length) return null;
    const tpl = await WatchMockup.loadTemplate();
    const MAXS = 1000;
    const scale = Math.min(1, MAXS / Math.max(tpl.width, tpl.height));
    const watch = await buildWatchCanvas(project, { maxSize: MAXS });
    const R = tpl.screen.r * scale, CX = tpl.screen.cx * scale, CY = tpl.screen.cy * scale;
    const sx = (2 * R) / dw, sy = (2 * R) / dh;

    const HEADER = 96, PAD = 40, LEG_W = 640;
    const rowH = zones.length > 12 ? 62 : 84;
    const legendH = zones.length * rowH;
    const W = PAD + watch.width + PAD + LEG_W + PAD;
    const H = Math.max(HEADER + watch.height + PAD, HEADER + legendH + PAD * 2);
    const cv = makeCanvas(W, H);
    const ctx = cv.getContext('2d');
    ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';

    const bg = ctx.createLinearGradient(0, 0, W, H);
    bg.addColorStop(0, '#0a101a'); bg.addColorStop(0.52, '#101a2a'); bg.addColorStop(1, '#151d2a');
    ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);

    // Заголовок
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillStyle = '#f8fafc';
    ctx.font = `700 34px ${FONT}`;
    ctx.fillText(`${faceName(project)} — зоны нажатия`, PAD, 48);
    ctx.fillStyle = '#94a3b8';
    ctx.font = `400 20px ${FONT}`;
    ctx.fillText(`${deviceLabel(project)} · зон: ${zones.length}`, PAD, 80);

    // Часы по центру левой части
    const wx = PAD, wy = HEADER + Math.max(0, Math.round((H - HEADER - PAD - watch.height) / 2));
    ctx.save();
    ctx.shadowColor = 'rgba(0,0,0,0.42)'; ctx.shadowBlur = 30; ctx.shadowOffsetY = 10;
    ctx.drawImage(watch, wx, wy);
    ctx.restore();

    // Подсветка зон — только внутри круглого окна экрана
    const rects = zones.map((z) => ({
      z, color: ZONE_COLORS[(z.n - 1) % ZONE_COLORS.length],
      x: wx + CX - R + z.x * sx, y: wy + CY - R + z.y * sy, w: z.w * sx, h: z.h * sy,
    }));
    ctx.save();
    ctx.beginPath(); ctx.arc(wx + CX, wy + CY, R, 0, Math.PI * 2); ctx.clip();
    for (const r of rects) {
      ctx.globalAlpha = 0.30; ctx.fillStyle = r.color; ctx.fillRect(r.x, r.y, r.w, r.h);
      ctx.globalAlpha = 1; ctx.lineWidth = 3; ctx.strokeStyle = r.color; ctx.strokeRect(r.x + 1.5, r.y + 1.5, r.w - 3, r.h - 3);
    }
    ctx.restore();

    // Номера на зонах; наложившиеся бейджи сдвигаются вниз
    const BR = 19, placed = [];
    for (const r of rects) {
      // Крупная зона: номер в левом верхнем углу, чтобы не закрывать содержимое; маленькая — по центру.
      const roomy = r.w > BR * 2 + 12 && r.h > BR * 2 + 12;
      let bx = roomy ? r.x + BR + 5 : r.x + r.w / 2, by = roomy ? r.y + BR + 5 : r.y + r.h / 2;
      for (let tries = 0; tries < 6 && placed.some((q) => Math.hypot(q.x - bx, q.y - by) < BR * 2 + 2); tries++) bx += BR * 2 + 4;
      bx = Math.max(r.x + BR, Math.min(bx, r.x + r.w - BR)); by = Math.min(by, r.y + r.h - BR);
      placed.push({ x: bx, y: by });
      ctx.save();
      ctx.shadowColor = 'rgba(0,0,0,0.5)'; ctx.shadowBlur = 6;
      ctx.beginPath(); ctx.arc(bx, by, BR, 0, Math.PI * 2);
      ctx.fillStyle = '#0b1220'; ctx.fill();
      ctx.restore();
      ctx.lineWidth = 3; ctx.strokeStyle = r.color; ctx.beginPath(); ctx.arc(bx, by, BR, 0, Math.PI * 2); ctx.stroke();
      ctx.fillStyle = '#ffffff'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.font = `700 ${r.z.n > 9 ? 17 : 20}px ${FONT}`;
      ctx.fillText(String(r.z.n), bx, by + 1);
    }

    // Легенда справа: номер → что откроется
    const lx = PAD + watch.width + PAD;
    let ly = HEADER + Math.max(0, Math.round((H - HEADER - PAD - legendH) / 2));
    for (const r of rects) {
      const z = r.z;
      ctx.save();
      roundRect(ctx, lx, ly + 4, LEG_W, rowH - 8, 14);
      ctx.fillStyle = 'rgba(255,255,255,0.05)'; ctx.fill();
      ctx.lineWidth = 1.5; ctx.strokeStyle = 'rgba(255,255,255,0.10)'; ctx.stroke();
      ctx.restore();
      const cy = ly + rowH / 2;
      ctx.beginPath(); ctx.arc(lx + 36, cy, 22, 0, Math.PI * 2);
      ctx.fillStyle = r.color; ctx.fill();
      ctx.fillStyle = '#0b1220'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.font = `800 ${z.n > 9 ? 20 : 24}px ${FONT}`;
      ctx.fillText(String(z.n), lx + 36, cy + 1);
      ctx.textAlign = 'left';
      const tx = lx + 76, tw = LEG_W - 96;
      ctx.fillStyle = '#f8fafc';
      fitFont(ctx, z.label, 700, rowH > 70 ? 28 : 24, 14, tw);
      ctx.fillText(z.label, tx, cy - (rowH > 70 ? 11 : 9));
      ctx.fillStyle = '#94a3b8';
      fitFont(ctx, z.sub, 400, 17, 11, tw);
      ctx.fillText(z.sub, tx, cy + (rowH > 70 ? 19 : 16));
      ly += rowH;
    }
    return cv;
  }

  async function buildAll(project, matrix, opts = {}) {
    const day = projectForScene(project, 'normal');
    const dayProject = day ? day.project : project;
    const defs = [
      { id: 'qr', label: 'QR-код', suffix: 'qr', canvas: await buildQrCanvas(matrix) },
      { id: 'watch', label: 'Основной дневной циферблат — высокое качество', suffix: 'watch', canvas: labelWatchCanvas(await buildWatchCanvas(dayProject, { transparent: opts.transparentWatch, maxSize: 1000 }), 'ДЕНЬ · ОСНОВНОЙ', '#f4c45e') },
      { id: 'watch200', label: 'Дневной мокап, высота 200 px', suffix: 'watch-200', canvas: await buildWatchCanvas(dayProject, { transparent: opts.transparentWatch, maxSize: 200 }) },
      { id: 'combined', label: 'Дневной циферблат с QR-кодом', suffix: 'watch-qr', canvas: await buildCombinedCanvas(dayProject, matrix) }
    ];
    if (opts.tapZones) {
      const tz = await buildTapZonesCanvas(dayProject);
      if (tz) defs.push({ id: 'zones', label: 'Зоны нажатия: что открывается по тапу', suffix: 'tap-zones', canvas: tz });
    }
    if (opts.scenePreviews) {
      const night = projectForScene(project, 'night');
      if (night) {
        defs.push({
          id: 'night', label: 'Ночной циферблат — высокое качество', suffix: 'night',
          canvas: labelWatchCanvas(await buildWatchCanvas(night.project, { transparent: opts.transparentWatch, maxSize: 1000, brightness: night.brightness }), 'НОЧНОЙ', '#9da9ff'),
        });
      }
      const aod = projectForScene(project, 'aod');
      if (aod) {
        defs.push({
          id: 'aod', label: 'AOD — высокое качество', suffix: 'aod',
          canvas: labelWatchCanvas(await buildWatchCanvas(aod.project, { transparent: opts.transparentWatch, maxSize: 1000, brightness: aod.brightness }), 'AOD', '#63d7be'),
        });
      }
    }
    const out = [];
    for (const d of defs) out.push({ id: d.id, label: d.label, suffix: d.suffix, blob: await toBlob(d.canvas), width: d.canvas.width, height: d.canvas.height });
    return out;
  }

  /** Картинка «часы с циферблатом + QR» для публикации на GitHub как watch-qr.png. */
  async function buildCombinedBlob(project, matrix) {
    return toBlob(await buildCombinedCanvas(project, matrix));
  }

  // ───────── сохранение ─────────
  const aborted = (e) => e && (e.name === 'AbortError' || e.code === 20);

  function downloadBlob(blob, filename) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 5000);
  }

  // Запоминаем последнюю выбранную папку в IndexedDB — только чтобы диалог
  // следующего сохранения открывался в ней.
  const DIR_DB = 'amazface-image-save';
  const DIR_STORE = 'settings';
  function openDirDb() {
    return new Promise((resolve, reject) => {
      if (!('indexedDB' in window)) return resolve(null);
      const req = indexedDB.open(DIR_DB, 1);
      req.onupgradeneeded = () => req.result.createObjectStore(DIR_STORE);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }
  async function rememberDir(dir) {
    try {
      const db = await openDirDb(); if (!db) return;
      await new Promise((resolve, reject) => {
        const tx = db.transaction(DIR_STORE, 'readwrite');
        tx.objectStore(DIR_STORE).put(dir, 'last-folder');
        tx.oncomplete = resolve; tx.onerror = () => reject(tx.error);
      });
      db.close();
    } catch (_) { /* сохранение всё равно работает без запоминания */ }
  }
  async function rememberedDir() {
    try {
      const db = await openDirDb(); if (!db) return null;
      const dir = await new Promise((resolve, reject) => {
        const tx = db.transaction(DIR_STORE, 'readonly');
        const req = tx.objectStore(DIR_STORE).get('last-folder');
        req.onsuccess = () => resolve(req.result || null); req.onerror = () => reject(req.error);
      });
      db.close(); return dir;
    } catch (_) { return null; }
  }
  async function writeFile(dir, filename, blob) {
    const fh = await dir.getFileHandle(filename, { create: true });
    const w = await fh.createWritable(); await w.write(blob); await w.close();
  }
  // Папка прошлого сохранения нужна только как место, где откроется диалог:
  // сохранять молча «в последний проект» больше нельзя — каждый раз спрашиваем.
  async function startInHint() {
    const dir = await rememberedDir();
    return dir || 'documents';
  }

  /** Диалог «Сохранить как…» (открывается в папке прошлого сохранения). */
  async function saveBlob(blob, filename) {
    if (typeof window.showSaveFilePicker === 'function') {
      try {
        const h = await window.showSaveFilePicker({
          id: 'amazface-images', startIn: await startInHint(), suggestedName: filename,
          types: /\.gif$/i.test(filename)
            ? [{ description: 'GIF', accept: { 'image/gif': ['.gif'] } }]
            : [{ description: 'PNG', accept: { 'image/png': ['.png'] } }]
        });
        const w = await h.createWritable(); await w.write(blob); await w.close();
        return 'picked';
      } catch (e) {
        if (aborted(e)) return 'cancelled';
      }
    }
    downloadBlob(blob, filename);
    return 'download';
  }

  /** Каждый раз спрашивает папку (диалог — в прошлой), затем пишет туда все картинки. */
  async function saveAll(files) {
    if (typeof window.showDirectoryPicker === 'function') {
      try {
        const dir = await window.showDirectoryPicker({ id: 'amazface-images', mode: 'readwrite', startIn: await startInHint() });
        await rememberDir(dir);
        for (const f of files) await writeFile(dir, f.name, f.blob);
        return 'folder';
      } catch (e) {
        if (aborted(e)) return 'cancelled';
      }
    }
    for (const f of files) { downloadBlob(f.blob, f.name); await new Promise(r => setTimeout(r, 250)); }
    return 'download';
  }

  // ───────── анимированное превью (GIF) ─────────

  // Кадры покадровой анимации фона из Normal-сцены (как их берёт экспорт); без анимации — [].
  function bgAnimFrameIds(project) {
    const sc = project && project.scenes && project.scenes.normal;
    const bg = (sc && sc.background) || (project && project.background) || {};
    const a = window.BgAnim ? window.BgAnim.normalize(bg.anim) : null;
    if (!a || !a.enabled) return { ids: [], fps: 12 };
    const known = new Set((project.assets || []).map(x => x.id));
    return { ids: a.frames.filter(id => known.has(id)), fps: a.fps };
  }

  /** Есть ли у циферблата анимация, из которой можно собрать GIF-превью. */
  function hasAnimation(project) { return bgAnimFrameIds(project).ids.length >= 2; }

  /**
   * GIF: часы в корпусе, на экране — кадры анимации фона по очереди. Бесконечный цикл.
   * Если файл получается больше maxBytes, размер уменьшается (300 → 240 → 180 px по длинной стороне).
   * @returns {Promise<null|{bytes:Uint8Array,width:number,height:number,frames:number,fps:number,maxSize:number}>}
   *          null — анимации нет (меньше двух кадров), GIF не нужен.
   */
  async function buildAnimatedGif(project, opts = {}) {
    if (!window.GifEncoder) throw new Error('Кодировщик GIF не загружен.');
    const { ids, fps } = bgAnimFrameIds(project);
    if (ids.length < 2) return null;
    const sizes = opts.sizes || [300, 240, 180];
    const maxBytes = opts.maxBytes || 8 * 1024 * 1024;
    const delayCs = Math.max(2, Math.round(100 / fps));
    let last = null;
    for (const maxSize of sizes) {
      const frames = []; let w = 0, h = 0;
      for (let i = 0; i < ids.length; i++) {
        const cv = await WatchMockup.buildWatchMockupCanvas(project, { maxSize, bgFrameId: ids[i] });
        w = cv.width; h = cv.height;
        frames.push(cv.getContext('2d').getImageData(0, 0, w, h).data);
        if (opts.onProgress) opts.onProgress(i + 1, ids.length, maxSize);
        if (i % 4 === 3) await new Promise(r => setTimeout(r, 0));   // дать интерфейсу вздохнуть
      }
      const bytes = window.GifEncoder.encode(frames, { width: w, height: h, delayCs, loop: 0 });
      last = { bytes, width: w, height: h, frames: ids.length, fps, maxSize };
      if (bytes.length <= maxBytes) break;
    }
    return last;
  }

  window.ShareImages = { buildTapZonesCanvas, collectTapZones, buildAnimatedGif, hasAnimation, buildAll, buildQrCanvas, buildWatchCanvas, buildCombinedCanvas, buildCombinedBlob, saveBlob, saveAll, deviceLabel, faceName };
})();
