// AssetFit — запекание размера компонентов «Изображение» при экспорте.
//
// Зачем: виджет Zepp OS IMG НЕ масштабирует картинку под w×h — он рисует пиксели
// как есть и обрезает всё, что не поместилось. Редактор же растягивает картинку на
// канвасе до w×h, поэтому в предпросмотре иконка 256×256 в блоке 40×40 выглядит
// правильно, а на часах виден только левый верхний угол 40×40 (часто прозрачный).
//
// Что делает: для каждого компонента defId === 'image', у которого размер ресурса
// не совпадает с w×h, создаёт копию ресурса, уже растянутую до w×h (так же, как её
// рисует редактор), и перенаправляет компонент на эту копию. Исходный ресурс
// остаётся в проекте, только если он ещё где-то используется. Исходный проект
// не изменяется (как и у AssetBg/AssetShadow.bakeProject).
const AssetFit = (() => {
  const VERSION = 1;

  const approxBytes = (dataUrl) => Math.max(0, Math.round((String(dataUrl).length - String(dataUrl).indexOf(',') - 1) * 3 / 4));

  function loadImage(dataUrl) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error('AssetFit: не удалось декодировать изображение'));
      img.src = dataUrl;
    });
  }

  /** Растягивает изображение до w×h. Сильное уменьшение делается ступенями ×½ — так края не «лесенкой». */
  function scaleToPng(img, w, h) {
    let cur = img;
    let cw = img.naturalWidth || img.width;
    let ch = img.naturalHeight || img.height;
    const step = (tw, th) => {
      const c = document.createElement('canvas');
      c.width = tw; c.height = th;
      const ctx = c.getContext('2d');
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'high';
      ctx.clearRect(0, 0, tw, th);
      ctx.drawImage(cur, 0, 0, tw, th);
      cur = c; cw = tw; ch = th;
    };
    while (cw / 2 >= w && ch / 2 >= h) step(Math.max(w, Math.floor(cw / 2)), Math.max(h, Math.floor(ch / 2)));
    if (cw !== w || ch !== h || cur === img) step(w, h);
    return cur.toDataURL('image/png');
  }

  const targetSize = (comp) => ({
    w: Math.max(1, Math.round(Number(comp.w) || 0)),
    h: Math.max(1, Math.round(Number(comp.h) || 0)),
  });

  /** Нужна ли подгонка: компонент-картинка, ресурс есть, размеры не совпадают. */
  function needsFit(comp, assetsById) {
    if (!comp || comp.defId !== 'image') return null;
    const a = assetsById.get(comp.props && comp.props.src);
    if (!a || !a.dataUrl || a.weatherIcon) return null;
    const t = targetSize(comp);
    if (!(Number(comp.w) > 0) || !(Number(comp.h) > 0)) return null;
    if (Number(a.width) === t.w && Number(a.height) === t.h) return null;
    return { asset: a, w: t.w, h: t.h };
  }

  /** Копия проекта для экспорта: картинки-компоненты ссылаются на ресурсы точного размера w×h. */
  async function bakeProject(project) {
    if (!project) return project;
    const assetsById = new Map((project.assets || []).map((a) => [a.id, a]));
    const lists = [project.components, project.scenes && project.scenes.normal && project.scenes.normal.components, project.scenes && project.scenes.night && project.scenes.night.components, project.scenes && project.scenes.aod && project.scenes.aod.components];
    const anyWork = lists.some((l) => Array.isArray(l) && l.some((c) => needsFit(c, assetsById)));
    if (!anyWork) return project;

    const clone = JSON.parse(JSON.stringify(Object.assign({}, project, { assets: [] })));
    clone.assets = [...(project.assets || [])];
    const cloneLists = [clone.components, clone.scenes && clone.scenes.normal && clone.scenes.normal.components, clone.scenes && clone.scenes.night && clone.scenes.night.components, clone.scenes && clone.scenes.aod && clone.scenes.aod.components];

    const made = new Map();   // "assetId|WxH" → новый ресурс
    const imgCache = new Map();
    for (const list of cloneLists) {
      if (!Array.isArray(list)) continue;
      for (const comp of list) {
        const need = needsFit(comp, assetsById);
        if (!need) continue;
        const key = `${need.asset.id}|${need.w}x${need.h}`;
        let fitted = made.get(key);
        if (!fitted) {
          let img = imgCache.get(need.asset.id);
          if (!img) { img = await loadImage(need.asset.dataUrl); imgCache.set(need.asset.id, img); }
          const dataUrl = scaleToPng(img, need.w, need.h);
          fitted = Object.assign({}, need.asset, {
            id: `${need.asset.id}__fit_${need.w}x${need.h}`,
            name: `${need.asset.name || need.asset.id}_${need.w}x${need.h}`,
            dataUrl, width: need.w, height: need.h, format: 'PNG', size: approxBytes(dataUrl),
          });
          delete fitted.bg;
          made.set(key, fitted);
          clone.assets.push(fitted);
        }
        comp.props.src = fitted.id;
      }
    }

    // Выбрасываем исходные ресурсы, на которые больше никто не ссылается (экономит размер пакета).
    const { assets: _drop, ...rest } = clone;
    const body = JSON.stringify(rest);
    const replaced = new Set([...made.keys()].map((k) => k.split('|')[0]));
    clone.assets = clone.assets.filter((a) => !replaced.has(a.id) || body.includes(JSON.stringify(a.id)));
    return clone;
  }

  return { VERSION, needsFit, scaleToPng, bakeProject };
})();

if (typeof window !== 'undefined') window.AssetFit = AssetFit;
