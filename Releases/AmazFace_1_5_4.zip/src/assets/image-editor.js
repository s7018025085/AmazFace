// Reusable raster asset editor.
// v27 Arrow Studio: templates for hour/minute/second hands + Photoshop-like
// background tools. Everything is processed locally in the browser.
class ImageAssetEditor {
  static open(asset, options = {}) {
    const opts = Object.assign({ mode: 'asset', title: 'Редактор изображения' }, options);
    // Режим переключается прямо в окне: изображение ↔ стрелка (общее рабочее
    // состояние — исходник, история, эффекты — при этом не сбрасывается).
    let isArrow = opts.mode === 'arrow';
    // Shape of the watch face, used only to draw the non-destructive
    // "циферблат" guide overlay in the crop tab — round by default since
    // that covers the vast majority of supported devices.
    const faceShape = (opts.device && opts.device.shape) || 'round';

    const modal = document.createElement('div');
    modal.className = 'image-editor-modal';
    modal.innerHTML = `
      <div class="image-editor-dialog image-editor-dialog-pro">
        <div class="image-editor-head">
          <div><b data-ie-title>${ImageAssetEditor.esc(opts.title)}</b><small>${ImageAssetEditor.esc(asset.name || '')}</small></div>
          <div class="ie-mode-switch" role="tablist">
            <button type="button" data-ie-mode="image" title="Обычное изображение: обрезка, фон, эффекты">🖼 Изображение</button>
            <button type="button" data-ie-mode="arrow" title="Стрелка: шаблон, точка вращения, TIME_POINTER">🧭 Стрелка</button>
          </div>
          <button type="button" data-ie-close>✕</button>
        </div>
        <div class="image-editor-body">
          <div class="image-editor-preview-wrap">
            <div class="image-editor-preview" data-ie-preview>
              <canvas data-ie-canvas></canvas>
              <div class="image-editor-hint" data-ie-hint></div>
              <div class="arrow-crosshair" data-arrow-crosshair></div>
            </div>
            <div class="arrow-preview-status" data-arrow-status></div>
          </div>
          <div class="image-editor-controls">
            <div class="ie-tabs" role="tablist">
              <button type="button" role="tab" data-tab="template" data-ie-arrow-only title="Шаблон стрелки: размер PNG, ось вращения, положение на циферблате">🎯 Шаблон</button>
              <button type="button" role="tab" data-tab="crop" title="Обрезка, масштаб, поворот">✂ Обрезка</button>
              <button type="button" role="tab" data-tab="remove" title="Удаление фона: пипетка, волшебная палочка, ластик">🪄 Без фона</button>
              <button type="button" role="tab" data-tab="effects" title="Эффекты: яркость, контраст, перекраска, прозрачность, тень">✨ Эффекты</button>
            </div>

            <div class="ie-tab-panel" data-panel="template" data-ie-arrow-only>
              <div class="ie-two">
                <label class="ie-stack"><span>Вид предпросмотра</span>
                  <select data-arrow-view>
                    <option value="face">На циферблате (1:1)</option>
                    <option value="template">Шаблон (крупно)</option>
                  </select>
                </label>
                <label class="ie-stack"><span>Тип стрелки</span>
                  <select data-arrow-template>
                    <option value="hour">Часовая</option>
                    <option value="minute">Минутная</option>
                    <option value="second">Секундная</option>
                  </select>
                </label>
              </div>
              <label class="ie-check" title="Выключено: PNG редактируется как есть, масштаб 100% = текущий размер. Включено: изображение вписывается в шаблон стрелки."><input type="checkbox" data-arrow-fitmode> Подогнать под шаблон</label>
              <div class="ie-note" data-arrow-size></div>
              <div class="ie-sec">Размер PNG · ось вращения внутри PNG</div>
              <div class="ie-grid-n n4">
                <label class="ie-stack"><span>Ширина</span><input type="number" data-arrow="w" min="1" max="1000"></label>
                <label class="ie-stack"><span>Высота</span><input type="number" data-arrow="h" min="1" max="1200"></label>
                <label class="ie-stack"><span>Ось X</span><input type="number" data-arrow="px" min="0" max="1000"></label>
                <label class="ie-stack"><span>Ось Y</span><input type="number" data-arrow="py" min="0" max="1200"></label>
              </div>
              <div class="ie-sec">Положение на циферблате</div>
              <div class="ie-grid-n n5">
                <label class="ie-stack" title="Где на экране находится ось вращения"><span>Центр X</span><input type="number" data-arrow="cx" min="0" max="2000"></label>
                <label class="ie-stack"><span>Центр Y</span><input type="number" data-arrow="cy" min="0" max="2000"></label>
                <label class="ie-stack" title="100% — размер PNG без изменений. При сохранении PNG физически станет больше или меньше."><span>Масштаб %</span><input type="number" data-arrow="scale" min="1" max="500"></label>
                <label class="ie-stack" title="Сдвиг картинки внутри PNG"><span>Сдвиг X</span><input type="number" data-arrow="ox" min="-1000" max="1000"></label>
                <label class="ie-stack"><span>Сдвиг Y</span><input type="number" data-arrow="oy" min="-1000" max="1000"></label>
              </div>
              <div class="ie-row nowrap">
                <button data-ie-action="arrow-autocrop" title="Найти непрозрачную область стрелки">🔎 Найти</button>
                <button data-ie-action="arrow-fit" title="Масштаб 100% (размер PNG без изменений), сдвиг 0">↺ Сброс</button>
                <button data-ie-action="arrow-center" title="Сбросить сдвиг">⊙ Центр</button>
              </div>
              <div class="ie-checks">
                <label class="ie-check" title="Показывать остальные стрелки проекта на 10:10"><input type="checkbox" data-arrow-others checked> Другие стрелки</label>
                <label class="ie-check"><input type="checkbox" data-arrow-preserve checked> Пропорции</label>
                <label class="ie-check"><input type="checkbox" data-arrow-transparent checked> Прозрачный фон</label>
              </div>
              <div class="ie-sec">Проверка вращения</div>
              <div class="ie-row nowrap">
                <button data-ie-action="test-0">12:00</button>
                <button data-ie-action="test-90">03:00</button>
                <button data-ie-action="test-180">06:00</button>
                <button data-ie-action="test-270">09:00</button>
                <button data-ie-action="test-1010" title="Угол этой стрелки при 10:10:00">10:10</button>
                <button data-ie-action="test-stop">Стоп</button>
              </div>
              <details class="ie-help">
                <summary>Подсказка</summary>
                <div class="ie-note"><b>На циферблате:</b> перетаскивайте стрелку мышью — меняется «Сдвиг X/Y» (картинка относительно оси). <b>Shift + перетаскивание</b> двигает саму ось («Центр X/Y»). Колесо — масштаб. <b>Масштаб</b> меняет реальный размер PNG: 100% — как сейчас, при сохранении картинка физически становится больше/меньше (размер показан над полями). «Подогнать под шаблон» — вписать новое изображение в стандартный размер стрелки. <b>Центр X/Y</b> — ось на экране, <b>Ось X/Y</b> — точка вращения внутри PNG; готовая стрелка сразу подходит TIME_POINTER.</div>
              </details>
            </div>

            <div class="ie-tab-panel" data-panel="crop">
              <div class="ie-row"><button data-ie-action="fit">Вписать</button><button data-ie-action="center">Центр</button><button data-ie-action="reset">Сброс</button><button data-ie-action="autocrop">Автокадр объекта</button></div>
              <label>Масштаб <input type="range" data-k="zoom" min="25" max="500" value="100"><output data-o="zoom">100%</output></label>
              <div class="ie-section">Сплющить / растянуть</div>
              <label>По горизонтали <input type="range" data-k="stretchX" min="20" max="300" value="100"><output data-o="stretchX">100%</output></label>
              <label>По вертикали <input type="range" data-k="stretchY" min="20" max="300" value="100"><output data-o="stretchY">100%</output></label>
              <div class="ie-row"><button data-ie-action="stretch-reset">↺ Сбросить растяжение</button></div>
              <label>Сдвиг X <input type="range" data-k="x" min="-1000" max="1000" value="0"><output data-o="x">0</output></label>
              <label>Сдвиг Y <input type="range" data-k="y" min="-1000" max="1000" value="0"><output data-o="y">0</output></label>
              <label>Поворот <input type="range" data-k="rot" min="-180" max="180" value="0"><output data-o="rot">0°</output></label>
              <div class="ie-section">Область результата</div>
              <div class="ie-grid4">
                <label>X <input type="number" data-crop="x" value="0"></label>
                <label>Y <input type="number" data-crop="y" value="0"></label>
                <label>Ш <input type="number" data-crop="w" value="0" min="1"></label>
                <label>В <input type="number" data-crop="h" value="0" min="1"></label>
              </div>
              <label class="ie-check"><input type="checkbox" data-crop-circle> Круглая обрезка</label>
              <label class="ie-check"><input type="checkbox" data-k="faceGuide"> Показать контур циферблата (только ориентир, не обрезает)</label>
              <div class="ie-note">Перетащите рамку мышью, либо задайте X/Y/Ш/В вручную. «Автокадр объекта» ищет непрозрачные пиксели. «Сплющить/растянуть» меняют ширину и высоту независимо друг от друга (100% — без искажений); при экспорте границы автоматически расширяются под масштаб и растяжение — удобно, если фон нужно чуть сжать или растянуть по одной оси под форму циферблата, не трогая пропорции остального. «Контур циферблата» рисует поверх рамки обрезки форму экрана устройства (круг или скруглённый прямоугольник) — это только визуальный ориентир, он не влияет на итоговый PNG.</div>
            </div>

            <div class="ie-tab-panel" data-panel="remove">
              <div class="ie-row">
                <button data-ie-action="pick">🎯 Пипетка</button>
                <button data-ie-action="wand">🪄 Волшебная палочка</button>
                <button data-ie-action="edge">🌊 От краёв</button>
              </div>
              <div class="ie-row">
                <button data-ie-action="erase">⌫ Ластик</button>
                <button data-ie-action="restore">↩ Восстановить</button>
                <button data-ie-action="undo-remove">↶ Отменить</button>
                <button data-ie-action="redo-remove">↷ Повторить</button>
              </div>
              <label>Допуск <input type="range" data-k="tolerance" min="0" max="160" value="35"><output data-o="tolerance">35</output></label>
              <label>Размер кисти <input type="range" data-k="brush" min="2" max="160" value="35"><output data-o="brush">35 px</output></label>
              <label>Мягкость края <input type="range" data-k="feather" min="0" max="40" value="0"><output data-o="feather">0 px</output></label>
              <label class="ie-check"><input type="checkbox" data-k="removeConnected" checked> Только связанная область</label>
              <label>Цвет фона <input type="color" data-remove-color value="#ffffff"></label>
              <div class="ie-row">
                <button data-ie-action="white">Удалить белый</button>
                <button data-ie-action="corner">Удалить фон по углу</button>
                <button data-ie-action="invert">Инвертировать маску</button>
              </div>
              <div class="ie-note">Пипетка берёт цвет из изображения. «Волшебная палочка» удаляет смежную область похожего цвета, как в Photoshop. Ластик удаляет кистью; Alt+ЛКМ восстанавливает исходный пиксель.</div>
            </div>

            <div class="ie-tab-panel" data-panel="effects">
              <label>Яркость <input type="range" data-k="brightness" min="40" max="180" value="100"><output data-o="brightness">100%</output></label>
              <label>Контраст <input type="range" data-k="contrast" min="40" max="180" value="100"><output data-o="contrast">100%</output></label>
              <label>Насыщенность <input type="range" data-k="saturation" min="0" max="200" value="100"><output data-o="saturation">100%</output></label>
              <label>Размытие <input type="range" data-k="blur" min="0" max="12" value="0"><output data-o="blur">0 px</output></label>
              <div class="ie-section">Прозрачность</div>
              <label>Непрозрачность <input type="range" data-k="alpha" min="0" max="100" value="100"><output data-o="alpha">100%</output></label>
              <div class="ie-section">🎨 Перекраска</div>
              <label>Новый цвет <input type="color" data-recolor-color value="#ffffff"></label>
              <div class="ie-row">
                <button data-ie-action="recolor">Перекрасить</button>
                <button data-ie-action="recolor-white">В белый</button>
                <button data-ie-action="recolor-black">В чёрный</button>
                <button data-ie-action="undo-recolor">↶ Отменить</button>
              </div>
              <div class="ie-note">Заливает всю иконку выбранным цветом, прозрачность и сглаженные края сохраняются. Подходит для одноцветных иконок (чёрная → белая). Цветная картинка станет однотонным силуэтом. Можно отменить кнопкой «↶».</div>
              <div class="ie-section">🌑 Тень</div>
              <label class="ie-check"><input type="checkbox" data-k="shadowEnabled"> Включить тень</label>
              <label>Направление <input type="range" data-k="shadowAngle" min="0" max="359" value="135"><output data-o="shadowAngle">135°</output></label>
              <label>Расстояние <input type="range" data-k="shadowDistance" min="0" max="40" value="6"><output data-o="shadowDistance">6 px</output></label>
              <label>Размытие тени <input type="range" data-k="shadowBlur" min="0" max="40" value="5"><output data-o="shadowBlur">5 px</output></label>
              <label>Растушёвка / spread <input type="range" data-k="shadowSpread" min="0" max="20" value="0"><output data-o="shadowSpread">0 px</output></label>
              <label>Непрозрачность тени <input type="range" data-k="shadowOpacity" min="0" max="100" value="45"><output data-o="shadowOpacity">45%</output></label>
              <label>Цвет тени <input type="color" data-shadow-color value="#000000"></label>
              <label class="ie-check"><input type="checkbox" data-k="shadowRotate" checked> Тень вращается вместе со стрелкой</label>
              <div class="ie-row"><button data-ie-action="shadow-reset">Сбросить тень</button><button data-ie-action="shadow-preset">Мягкая чёрная</button></div>
              <div class="ie-note">Тень хранится как настройка стрелки и не меняет саму картинку: её можно изменить или убрать в любой момент. В PNG для часов она запекается при сохранении проекта (экспорт, Zeus, Direct ZIP); для неё в картинке оставляются прозрачные поля, ось вращения не смещается и тень вращается вместе со стрелкой. Угол 0° — вправо, 90° — вниз, 180° — влево, 270° — вверх.</div>
            </div>

            <div class="ie-footer-note">Источник: ${asset.width || '?'}×${asset.height || '?'} px · PNG с прозрачностью сохраняется.</div>
            <div class="image-editor-buttons">
              <button type="button" data-ie-close>Отмена</button>
              ${typeof opts.onSave === 'function' ? '<button type="button" class="btn-primary" data-ie-save title="Заменить этот ресурс изменённой версией, не создавая новый">💾 Сохранить в этот ресурс</button>' : ''}
              <button type="button" ${typeof opts.onSave === 'function' ? '' : 'class="btn-primary"'} data-ie-apply></button>
            </div>
          </div>
        </div>
      </div>`;
    document.body.appendChild(modal);

    const canvas = modal.querySelector('[data-ie-canvas]');
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
    const img = new Image();
    const sourceCanvas = document.createElement('canvas');
    const originalCanvas = document.createElement('canvas');
    let sourceCtx, originalCtx;
    const history = [], future = [];
    const crop = { x: 0, y: 0, w: asset.width || 480, h: asset.height || 480 };

    const templates = {
      hour:   { w: 64, h: 220, px: 32, py: 170, cx: 240, cy: 240 },
      minute: { w: 52, h: 260, px: 26, py: 205, cx: 240, cy: 240 },
      second: { w: 28, h: 300, px: 14, py: 225, cx: 240, cy: 240 }
    };
    const state = {
      zoom: 100, x: 0, y: 0, rot: 0, stretchX: 100, stretchY: 100, tolerance: 35, removeConnected: true,
      brightness: 100, contrast: 100, saturation: 100, blur: 0, alpha: 100,
      removeColor: '#ffffff', circle: false, faceGuide: false, brush: 35, feather: 0,
      removeTool: 'wand', arrowTemplate: 'hour', arrowFit: true, arrowScale: 100, arrowOX: 0, arrowOY: 0,
      testAngle: 0,
      shadowEnabled: false, shadowAngle: 135, shadowDistance: 6, shadowBlur: 5,
      shadowSpread: 0, shadowOpacity: 45, shadowColor: '#000000', shadowRotate: true
    };
    const arrow = Object.assign({}, templates.hour);
    const view = { w: 720, h: 620, fitScale: 1 };
    canvas.width = view.w; canvas.height = view.h;

    const cloneImageData = (d) => new ImageData(new Uint8ClampedArray(d.data), d.width, d.height);
    const snapshot = () => sourceCtx ? cloneImageData(sourceCtx.getImageData(0,0,sourceCanvas.width,sourceCanvas.height)) : null;
    const restoreSnapshot = (d) => { if (!d) return; sourceCanvas.width=d.width; sourceCanvas.height=d.height; sourceCtx=sourceCanvas.getContext('2d',{willReadFrequently:true}); sourceCtx.putImageData(d,0,0); draw(); };
    const pushHistory = () => { const s=snapshot(); if(s){history.push(s); if(history.length>30)history.shift(); future.length=0;} };

    const updateOutputs = () => modal.querySelectorAll('[data-k]').forEach(el => {
      const o = modal.querySelector(`[data-o="${el.dataset.k}"]`); if (!o) return;
      const k=el.dataset.k,v=el.value;
      o.textContent = ['zoom','stretchX','stretchY','brightness','contrast','saturation','alpha','shadowOpacity'].includes(k) ? `${v}%` : k==='blur'||k==='brush'||k==='feather'||k==='shadowDistance'||k==='shadowBlur'||k==='shadowSpread' ? `${v} px` : k==='shadowAngle' ? `${v}°` : v;
    });

    const syncSliders = () => modal.querySelectorAll('[data-k]').forEach(el => { if(state[el.dataset.k]===undefined)return; if(el.type==='checkbox')el.checked=!!state[el.dataset.k]; else el.value=state[el.dataset.k]; });
    const fitScale = () => Math.min((view.w-40)/Math.max(1,sourceCanvas.width),(view.h-40)/Math.max(1,sourceCanvas.height));
    const drawChecker = () => {
      ctx.fillStyle='#161a22';ctx.fillRect(0,0,view.w,view.h);
      const s=16;
      for(let y=0;y<view.h;y+=s)for(let x=0;x<view.w;x+=s){ctx.fillStyle=((x/s+y/s)%2)?'#242a34':'#191e27';ctx.fillRect(x,y,s,s);}
    };
    const sourceToPreview = (sx,sy) => {
      const scale=view.fitScale*(state.zoom/100), scaleX=scale*(state.stretchX/100), scaleY=scale*(state.stretchY/100);
      return {x:view.w/2+state.x+(sx-sourceCanvas.width/2)*scaleX,y:view.h/2+state.y+(sy-sourceCanvas.height/2)*scaleY};
    };
    const previewToSource = (clientX,clientY) => {
      const r=canvas.getBoundingClientRect();
      const px=(clientX-r.left)*(view.w/r.width), py=(clientY-r.top)*(view.h/r.height);
      const scale=view.fitScale*(state.zoom/100), scaleX=scale*(state.stretchX/100), scaleY=scale*(state.stretchY/100);
      return {x:Math.max(0,Math.min(sourceCanvas.width-1,(px-(view.w/2+state.x))/scaleX+sourceCanvas.width/2)),y:Math.max(0,Math.min(sourceCanvas.height-1,(py-(view.h/2+state.y))/scaleY+sourceCanvas.height/2))};
    };

    const arrowParams = () => ({
      w: Math.max(1,Number(modal.querySelector('[data-arrow="w"]')?.value||arrow.w)),
      h: Math.max(1,Number(modal.querySelector('[data-arrow="h"]')?.value||arrow.h)),
      px: Math.max(0,Number(modal.querySelector('[data-arrow="px"]')?.value||arrow.px)),
      py: Math.max(0,Number(modal.querySelector('[data-arrow="py"]')?.value||arrow.py)),
      cx: Number(modal.querySelector('[data-arrow="cx"]')?.value||arrow.cx),
      cy: Number(modal.querySelector('[data-arrow="cy"]')?.value||arrow.cy),
      scale: Number(modal.querySelector('[data-arrow="scale"]')?.value||state.arrowScale),
      ox: Number(modal.querySelector('[data-arrow="ox"]')?.value||state.arrowOX),
      oy: Number(modal.querySelector('[data-arrow="oy"]')?.value||state.arrowOY)
    });

    // Раскладка стрелки внутри итогового PNG. Два режима:
    //  • «как есть» (arrowFit=false): PNG берётся в натуральном размере, масштаб 100% = без изменений,
    //    масштабирование идёт вокруг оси вращения;
    //  • «подгонка» (arrowFit=true): изображение вписывается в шаблон p.w×p.h.
    const arrowLayout = (p) => {
      const k=(Number(p.scale)||100)/100, ox=Number(p.ox)||0, oy=Number(p.oy)||0;
      if(!state.arrowFit){
        const W=sourceCanvas.width,H=sourceCanvas.height,dw=W*k,dh=H*k;
        const c0=alphaBounds();
        return {native:true,k,cb:c0,b:{x:0,y:0,w:W,h:H},baseW:Math.max(1,Math.ceil(dw-1e-6)),baseH:Math.max(1,Math.ceil(dh-1e-6)),px:Math.round(Number(p.px)*k),py:Math.round(Number(p.py)*k),dx:ox,dy:oy,dw,dh};
      }
      const baseW=Math.max(1,Number(p.w)),baseH=Math.max(1,Number(p.h)),b=alphaBounds();
      if(!b)return {native:false,b:null,baseW,baseH,px:Number(p.px),py:Number(p.py),dx:0,dy:0,dw:0,dh:0};
      const keep=modal.querySelector('[data-arrow-preserve]')?.checked!==false;
      // Прозрачные поля по бокам, чтобы силуэт и запечённая тень не обрезались краем PNG.
      const safeX=Math.min(Math.max(8,Math.ceil((state.shadowEnabled?state.shadowDistance+state.shadowBlur*2+state.shadowSpread:8)+3)),Math.floor(baseW*.28));
      const safeY=Math.min(8,Math.floor(baseH*.08));
      const sx=Math.max(1,baseW-2*safeX)/b.w,sy=Math.max(1,baseH-2*safeY)/b.h,fs=keep?Math.min(sx,sy):sx;
      const dw=b.w*fs*k,dh=b.h*fs*k;
      return {native:false,b,baseW,baseH,px:Number(p.px),py:Number(p.py),dx:(baseW-dw)/2+ox,dy:(baseH-dh)/2+oy,dw,dh};
    };
    // Границы итогового холста: шаблон + расширение под тень и выход за края.
    const arrowExtent = (L) => {
      let left=0,top=0,right=L.baseW,bottom=L.baseH;
      if(L.b){
        const shadowPad=state.shadowEnabled?state.shadowBlur*2+state.shadowDistance+state.shadowSpread:0;
        // «Как есть»: поля под тень считаются от видимой части стрелки, а не от края PNG —
        // поэтому уже имеющиеся прозрачные поля не накапливаются при каждом сохранении.
        const pad=Math.ceil(shadowPad+(L.native?0:2));
        const vis=L.native?(L.cb?{x0:L.dx+L.cb.x*L.k,y0:L.dy+L.cb.y*L.k,x1:L.dx+(L.cb.x+L.cb.w)*L.k,y1:L.dy+(L.cb.y+L.cb.h)*L.k}:null):{x0:L.dx,y0:L.dy,x1:L.dx+L.dw,y1:L.dy+L.dh};
        left=Math.min(0,Math.floor(L.dx+1e-6));top=Math.min(0,Math.floor(L.dy+1e-6));
        right=Math.max(L.baseW,Math.ceil(L.dx+L.dw-1e-6));bottom=Math.max(L.baseH,Math.ceil(L.dy+L.dh-1e-6));
        if(vis){
          left=Math.min(left,Math.floor(vis.x0-pad+1e-6));top=Math.min(top,Math.floor(vis.y0-pad+1e-6));
          right=Math.max(right,Math.ceil(vis.x1+pad-1e-6));bottom=Math.max(bottom,Math.ceil(vis.y1+pad-1e-6));
        }
      }
      return {left,top,ow:Math.max(1,right-left),oh:Math.max(1,bottom-top)};
    };
    const updateArrowSize = () => {
      const el=modal.querySelector('[data-arrow-size]');if(!el||!isArrow||!sourceCanvas.width)return;
      const p=arrowParams(),E=arrowExtent(arrowLayout(p)),W=sourceCanvas.width,H=sourceCanvas.height;
      el.textContent=state.arrowFit
        ? `Изображение вписывается в шаблон ${p.w}×${p.h}. Итоговый PNG: ${E.ow}×${E.oh} px.`
        : (E.ow===W&&E.oh===H?`Размер PNG: ${W}×${H} px — без изменений.`:`Размер PNG: ${W}×${H} px → ${E.ow}×${E.oh} px после сохранения.`);
    };
    const syncFitUI = () => {
      const cb=modal.querySelector('[data-arrow-fitmode]');if(cb)cb.checked=state.arrowFit;
      ['w','h'].forEach(k=>{const e=modal.querySelector(`[data-arrow="${k}"]`);if(e)e.disabled=!state.arrowFit;});
    };
    let openAxis=null; // ось существующей стрелки (в пикселях её PNG)
    const setFitMode = (on) => {
      if(state.arrowFit===on)return;
      const p=arrowParams(),t=templates[state.arrowTemplate];
      state.arrowFit=on;
      if(on)setArrowInputs(Object.assign({},t,{cx:p.cx,cy:p.cy}));
      else{
        const W=sourceCanvas.width,H=sourceCanvas.height;
        setArrowInputs({w:W,h:H,px:openAxis?openAxis.px:W*t.px/t.w,py:openAxis?openAxis.py:H*t.py/t.h,cx:p.cx,cy:p.cy});
      }
      syncFitUI();updateArrowSize();
    };

    const setArrowInputs = (t) => {
      Object.assign(arrow,t);
      const map={w:t.w,h:t.h,px:t.px,py:t.py,cx:t.cx,cy:t.cy};
      Object.entries(map).forEach(([k,v])=>{const el=modal.querySelector(`[data-arrow="${k}"]`);if(el)el.value=Math.round(v);});
      const s=modal.querySelector('[data-arrow="scale"]'),ox=modal.querySelector('[data-arrow="ox"]'),oy=modal.querySelector('[data-arrow="oy"]');
      if(s)s.value=state.arrowScale=100;if(ox)ox.value=state.arrowOX=0;if(oy)oy.value=state.arrowOY=0;
      updateArrowStatus();draw();
    };
    const syncArrowFromInputs = () => {
      const p=arrowParams(); Object.assign(arrow,{w:p.w,h:p.h,px:p.px,py:p.py,cx:p.cx,cy:p.cy}); state.arrowScale=p.scale;state.arrowOX=p.ox;state.arrowOY=p.oy; draw();updateArrowStatus();
    };

    const alphaBounds = () => {
      if(!sourceCanvas.width||!sourceCanvas.height)return null;
      const d=sourceCtx.getImageData(0,0,sourceCanvas.width,sourceCanvas.height).data;
      let x0=sourceCanvas.width,y0=sourceCanvas.height,x1=-1,y1=-1;
      for(let y=0;y<sourceCanvas.height;y++)for(let x=0;x<sourceCanvas.width;x++){if(d[(y*sourceCanvas.width+x)*4+3]>8){if(x<x0)x0=x;if(x>x1)x1=x;if(y<y0)y0=y;if(y>y1)y1=y;}}
      return x1<0?null:{x:x0,y:y0,w:x1-x0+1,h:y1-y0+1};
    };

    const autoCrop = () => {
      const b=alphaBounds(); if(!b)return;
      crop.x=b.x;crop.y=b.y;crop.w=b.w;crop.h=b.h;syncCropInputs();draw();
    };

    const syncCropInputs=()=>modal.querySelectorAll('[data-crop]').forEach(el=>el.value=Math.round(crop[el.dataset.crop]));
    const setCrop=(k,v)=>{
      const n=Number(v)||0;
      const max=k==='x'?sourceCanvas.width:k==='y'?sourceCanvas.height:k==='w'?sourceCanvas.width-crop.x:sourceCanvas.height-crop.y;
      crop[k]=Math.max(k==='w'||k==='h'?1:0,Math.min(max,n));
      if(k==='x')crop.w=Math.min(crop.w,sourceCanvas.width-crop.x);
      if(k==='y')crop.h=Math.min(crop.h,sourceCanvas.height-crop.y);
      syncCropInputs();draw();
    };

    const hexToRgba = (hex, alpha) => {
      const h=String(hex||'#000000').replace('#','');
      const n=parseInt(h.length===3?h.split('').map(c=>c+c).join(''):h,16);
      return `rgba(${(n>>16)&255},${(n>>8)&255},${n&255},${Math.max(0,Math.min(1,alpha))})`;
    };
    const shadowValues = () => ({
      enabled: !!state.shadowEnabled,
      angle: Number(state.shadowAngle)||0,
      distance: Number(state.shadowDistance)||0,
      blur: Number(state.shadowBlur)||0,
      spread: Number(state.shadowSpread)||0,
      opacity: Number(state.shadowOpacity)/100,
      color: state.shadowColor || '#000000',
      rotate: state.shadowRotate !== false
    });
    // Draw an image and a Photoshop-like drop shadow from its alpha channel.
    // The shadow is rendered first, then the original image is drawn on top.
    const drawWithShadow = (target, image, sx, sy, sw, sh, dx, dy, dw, dh, angleOffset=0) => {
      const sv=shadowValues();
      if(!sv.enabled || (sv.distance<=0 && sv.blur<=0 && sv.spread<=0)){
        target.drawImage(image,sx,sy,sw,sh,dx,dy,dw,dh); return;
      }
      const a=(sv.angle + (sv.rotate ? angleOffset : 0))*Math.PI/180;
      const ox=Math.cos(a)*sv.distance, oy=Math.sin(a)*sv.distance;
      target.save();
      target.shadowColor=hexToRgba(sv.color,sv.opacity);
      target.shadowBlur=sv.blur;
      target.shadowOffsetX=ox; target.shadowOffsetY=oy;
      // Spread is approximated by several nearby copies of the alpha mask.
      const spread=Math.max(0,sv.spread);
      const steps=spread>0?Math.min(16,Math.max(4,Math.ceil(spread/2))):1;
      for(let i=0;i<steps;i++){
        const t=steps===1?0:(i/steps)*Math.PI*2;
        const sxo=spread?Math.cos(t)*spread:0, syo=spread?Math.sin(t)*spread:0;
        target.drawImage(image,sx,sy,sw,sh,dx+sxo,dy+syo,dw,dh);
      }
      target.restore();
      target.drawImage(image,sx,sy,sw,sh,dx,dy,dw,dh);
    };

    // ---- Предпросмотр «На циферблате» ---------------------------------------
    // Показывает реальный экран устройства (фон и остальные компоненты проекта
    // рисует штатный WatchfacePreviewRenderer без стрелок) и поверх — итоговый
    // PNG стрелки в масштабе 1:1 относительно экрана, повёрнутый вокруг оси.
    const store=opts.store||null;
    let arrowView='face';
    const dev=(store&&store.state&&store.state.device)||opts.device||{w:480,h:480,shape:'round'};
    const devW=Number(dev.w)||480, devH=Number(dev.h)||480;
    const pointerDefIds=ImageAssetEditor.pointerDefs();
    const timeAngles={hour:305,minute:60,second:0};
    let faceBase=null,faceSc=1,faceDrag=null;
    const imgCache=new Map();
    const cachedImage=(dataUrl)=>{
      if(!dataUrl)return null;
      let e=imgCache.get(dataUrl);
      if(!e){const im=new Image();e={im,ok:false};im.onload=()=>{e.ok=true;draw();};im.src=dataUrl;imgCache.set(dataUrl,e);}
      return e.ok?e.im:null;
    };
    const renderFaceBase=()=>{
      if(!store||!window.WatchfacePreviewRenderer)return;
      const c=document.createElement('canvas');
      const proj=Object.assign({},store.state,{components:(store.state.components||[]).filter(k=>!pointerDefIds[k.defId])});
      window.WatchfacePreviewRenderer.draw(proj,c,{size:Math.max(devW,devH)}).then(()=>{faceBase=c;draw();}).catch(()=>{});
    };
    const withDeviceClip=(g,fn)=>{
      g.save();g.beginPath();
      if(dev.shape==='round')g.arc(devW/2,devH/2,Math.min(devW,devH)/2,0,Math.PI*2);else g.rect(0,0,devW,devH);
      g.clip();fn();g.restore();
    };
    const drawFaceView=()=>{
      const p=arrowParams();let faceInfo=null;
      const sc=Math.min((view.w-24)/devW,(view.h-24)/devH);
      faceSc=sc;
      const ox=(view.w-devW*sc)/2, oy=(view.h-devH*sc)/2;
      ctx.save();ctx.translate(ox,oy);ctx.scale(sc,sc);
      withDeviceClip(ctx,()=>{
        const bg=(store&&store.state.background)||{};
        ctx.fillStyle=bg.color||'#000';ctx.fillRect(0,0,devW,devH);
        if(faceBase){const k=Math.max(devW,devH)/faceBase.width;ctx.drawImage(faceBase,0,0,faceBase.width*k,faceBase.height*k);}
        else if(store){
          const a=(store.state.assets||[]).find(x=>x.id===(bg.imageAssetId));const im=a&&cachedImage(a.dataUrl);
          if(im)ctx.drawImage(im,0,0,devW,devH);
        }
        // Остальные стрелки проекта — на 10:10:00, как в экспортном превью.
        if(store&&modal.querySelector('[data-arrow-others]')?.checked!==false){
          for(const c of store.state.components||[]){
            const t=pointerDefIds[c.defId];if(!t||t===state.arrowTemplate||c.visible===false||!c.props)continue;
            const a=(store.state.assets||[]).find(x=>x.id===c.props.path);const im=a&&cachedImage(AssetShadow.url(a));if(!im)continue;
            ctx.save();ctx.translate(Number(c.props.center_x??devW/2),Number(c.props.center_y??devH/2));ctx.rotate(timeAngles[t]*Math.PI/180);
            ctx.drawImage(im,-Number(c.props.pos_x??im.naturalWidth/2),-Number(c.props.pos_y??im.naturalHeight/2));ctx.restore();
          }
        }
        // Редактируемая стрелка: ровно тот PNG, который уйдёт в ресурс.
        if(sourceCanvas.width&&alphaBounds()){
          const pp=arrowParams(), r=buildArrowCanvas(pp); // pp.px/py уже сдвинуты на расширение холста
          ctx.save();ctx.translate(p.cx,p.cy);ctx.rotate(state.testAngle*Math.PI/180);
          ctx.drawImage(r.out,-pp.px,-pp.py);ctx.restore();
          faceInfo={w:r.ow,h:r.oh,tip:null};
          if(modal.querySelector('[data-arrow-transparent]')?.checked){
            const d=r.out.getContext('2d').getImageData(0,0,r.ow,r.oh).data;
            top:for(let y=0;y<r.oh;y++)for(let x=0;x<r.ow;x++)if(d[(y*r.ow+x)*4+3]>10){faceInfo.tip=Math.round(pp.py-y);break top;}
          }
        }
      });
      // Центр оси и контур экрана (поверх, без обрезки)
      ctx.strokeStyle='rgba(255,190,50,.95)';ctx.lineWidth=1/sc;
      ctx.beginPath();ctx.moveTo(p.cx-8,p.cy);ctx.lineTo(p.cx+8,p.cy);ctx.moveTo(p.cx,p.cy-8);ctx.lineTo(p.cx,p.cy+8);ctx.stroke();
      ctx.setLineDash([6/sc,4/sc]);ctx.strokeStyle='rgba(90,160,255,.9)';ctx.lineWidth=2/sc;
      ctx.beginPath();if(dev.shape==='round')ctx.arc(devW/2,devH/2,Math.min(devW,devH)/2,0,Math.PI*2);else ctx.rect(0,0,devW,devH);ctx.stroke();
      ctx.restore();
      // Подпись: размеры в пикселях устройства (то, что реально будет на часах)
      const R=Math.round(Math.min(devW,devH)/2);
      const stEl=modal.querySelector('[data-arrow-status]');
      if(stEl)stEl.textContent=`Экран ${devW}×${devH} (${sc.toFixed(2)}×)`+(faceInfo?` · PNG ${faceInfo.w}×${faceInfo.h}`+(faceInfo.tip!=null?` · ось→кончик ${faceInfo.tip} из ${R} px (${Math.round(faceInfo.tip/R*100)}%)`:''):' · нет изображения стрелки');
    };

    const drawArrowTemplate = () => {
      if(!isArrow)return;
      const p=arrowParams(),L=arrowLayout(p);
      const scale=Math.min((view.w-80)/L.baseW,(view.h-60)/L.baseH,6.0);
      const fw=L.baseW*scale,fh=L.baseH*scale;
      const left=view.w/2-fw/2, top=view.h/2-fh/2;
      ctx.save();
      ctx.fillStyle='rgba(90,160,255,.08)';ctx.fillRect(left,top,fw,fh);ctx.setLineDash([7,5]);ctx.lineWidth=2;ctx.strokeStyle='rgba(90,160,255,.9)';ctx.strokeRect(left,top,fw,fh);
      ctx.setLineDash([]);ctx.strokeStyle='rgba(255,190,50,.95)';ctx.lineWidth=1;
      const px=left+L.px*scale,py=top+L.py*scale;
      ctx.beginPath();ctx.moveTo(px-14,py);ctx.lineTo(px+14,py);ctx.moveTo(px,py-14);ctx.lineTo(px,py+14);ctx.stroke();
      ctx.beginPath();ctx.arc(px,py,5,0,Math.PI*2);ctx.stroke();
      // Изображение стрелки внутри шаблона (в натуральном размере или вписанное).
      if(L.b){
        ctx.save();ctx.globalAlpha=state.alpha/100;
        ctx.filter=`brightness(${state.brightness}%) contrast(${state.contrast}%) saturate(${state.saturation}%) blur(${state.blur}px)`;
        drawWithShadow(ctx,sourceCanvas,L.b.x,L.b.y,L.b.w,L.b.h,left+L.dx*scale,top+L.dy*scale,L.dw*scale,L.dh*scale,state.testAngle);
        ctx.restore();
      }
      if(state.testAngle!==0){
        ctx.save();ctx.translate(px,py);ctx.rotate(state.testAngle*Math.PI/180);
        ctx.globalAlpha=.55;ctx.strokeStyle='rgba(255,90,90,.9)';ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(0,-Math.min(150,fh*.45));ctx.stroke();ctx.restore();
      }
      ctx.restore();
    };

    const updateArrowStatus=()=>{
      if(!isArrow)return;
      // В виде «На циферблате» строку статуса пишет drawFaceView (размеры в пикселях экрана).
      if(arrowView==='face'&&['template','effects'].some(n=>modal.querySelector(`[data-panel="${n}"]`)?.classList.contains('active')))return;
      const s=modal.querySelector('[data-arrow-status]');if(!s)return;
      const p=arrowParams();
      s.textContent=`${state.arrowFit?'Шаблон':'PNG'} ${p.w}×${p.h} · ось внутри PNG ${p.px},${p.py} · центр циферблата ${p.cx},${p.cy}`;
    };

    const draw = () => {
      drawChecker();
      if(!sourceCanvas.width){updateOutputs();return;}
      updateArrowSize();
      const panelOn=(n)=>modal.querySelector(`[data-panel="${n}"]`)?.classList.contains('active');
      if(isArrow && arrowView==='face' && (panelOn('template')||panelOn('effects'))){
        drawFaceView(); updateOutputs(); return;
      }
      if(isArrow && panelOn('template')){
        updateArrowStatus(); drawArrowTemplate(); updateOutputs(); return;
      }
      const scale=view.fitScale*(state.zoom/100), scaleX=scale*(state.stretchX/100), scaleY=scale*(state.stretchY/100);
      const dw=sourceCanvas.width*scaleX, dh=sourceCanvas.height*scaleY;
      const cx=view.w/2+state.x,cy=view.h/2+state.y;
      ctx.save();ctx.translate(cx,cy);ctx.rotate(state.rot*Math.PI/180);
      ctx.filter=`brightness(${state.brightness}%) contrast(${state.contrast}%) saturate(${state.saturation}%) blur(${state.blur}px)`;
      ctx.globalAlpha=state.alpha/100;drawWithShadow(ctx,sourceCanvas,0,0,sourceCanvas.width,sourceCanvas.height,-dw/2,-dh/2,dw,dh,state.rot);ctx.restore();
      const sx=view.w/2+state.x-dw/2,sy=view.h/2+state.y-dh/2;
      const rx=sx+crop.x*scaleX,ry=sy+crop.y*scaleY,rw=crop.w*scaleX,rh=crop.h*scaleY;
      ctx.save();ctx.setLineDash([8,6]);ctx.lineWidth=2;ctx.strokeStyle='#55aaff';ctx.strokeRect(rx,ry,rw,rh);
      if(state.circle){ctx.beginPath();ctx.arc(rx+rw/2,ry+rh/2,Math.min(rw,rh)/2,0,Math.PI*2);ctx.stroke();}
      ctx.restore();
      if(state.faceGuide){
        // Visual-only guide showing where the round (or square) watch face
        // sits over the current crop area. Never affects the exported PNG.
        ctx.save();ctx.setLineDash([5,4]);ctx.lineWidth=2;ctx.strokeStyle='#ff4fa3';
        if(faceShape==='round'){
          ctx.beginPath();ctx.arc(rx+rw/2,ry+rh/2,Math.min(rw,rh)/2,0,Math.PI*2);ctx.stroke();
        } else {
          const rr=Math.min(rw,rh)*0.12;
          ctx.beginPath();
          if(ctx.roundRect){ctx.roundRect(rx,ry,rw,rh,rr);} else {ctx.rect(rx,ry,rw,rh);}
          ctx.stroke();
        }
        ctx.restore();
      }
      if(modal.querySelector('[data-arrow-crosshair]')){const b=alphaBounds();if(b){const q=sourceToPreview(b.x+b.w/2,b.y+b.h);const cross=modal.querySelector('[data-arrow-crosshair]');cross.style.left=`${q.x}px`;cross.style.top=`${q.y}px`;}}
      updateOutputs();
    };

    const saveCurrent=()=>{pushHistory();};
    const removeByMask=(mask, feather=Number(state.feather)||0) => {
      if(!sourceCtx)return;saveCurrent();
      const w=sourceCanvas.width,h=sourceCanvas.height;
      const d=sourceCtx.getImageData(0,0,w,h),p=d.data;
      // A mask from the magic wand/edge tool used to ignore "Мягкость края".
      // Build a small distance-to-unmasked-boundary field so the requested
      // feather is applied only at the edge; the interior still becomes fully
      // transparent. This prevents a visible ring of background from remaining.
      const radius=Math.max(0,Math.round(feather));
      if(radius===0){
        for(let i=0;i<mask.length;i++) if(mask[i]) p[i*4+3]=0;
      } else {
        const dist=new Uint16Array(w*h);
        dist.fill(radius+1);
        const qx=new Int32Array(w*h), qy=new Int32Array(w*h);
        let head=0,tail=0;
        // Seed every unmasked pixel. A bounded BFS is enough because the
        // feather radius is at most 40 px in the UI.
        for(let y=0;y<h;y++) for(let x=0;x<w;x++){
          const idx=y*w+x;
          if(mask[idx]===0){ dist[idx]=0; qx[tail]=x; qy[tail++]=y; }
        }
        const push=(x,y,nd)=>{
          const idx=y*w+x;
          if(nd<dist[idx] && nd<=radius){dist[idx]=nd;qx[tail]=x;qy[tail++]=y;}
        };
        while(head<tail){
          const x=qx[head],y=qy[head++],nd=dist[y*w+x]+1;
          if(x>0)push(x-1,y,nd);
          if(x<w-1)push(x+1,y,nd);
          if(y>0)push(x,y-1,nd);
          if(y<h-1)push(x,y+1,nd);
        }
        for(let i=0;i<mask.length;i++) if(mask[i]){
          const dd=dist[i];
          // At the boundary keep a little of the original pixel, then remove
          // it completely once the feather distance has been crossed.
          const remove=Math.min(1,dd/Math.max(1,radius));
          p[i*4+3]=Math.round(p[i*4+3]*(1-remove));
        }
      }
      sourceCtx.putImageData(d,0,0);draw();
    };
    const colorDistance=(r,g,b,tr,tg,tb)=>Math.sqrt((r-tr)**2+(g-tg)**2+(b-tb)**2);
    const floodMask=(sx,sy)=>{
      const w=sourceCanvas.width,h=sourceCanvas.height,d=sourceCtx.getImageData(0,0,w,h).data;
      sx=Math.max(0,Math.min(w-1,Math.round(sx)));sy=Math.max(0,Math.min(h-1,Math.round(sy)));
      const si=(sy*w+sx)*4,target=[d[si],d[si+1],d[si+2]],tol=Number(state.tolerance);
      const mask=new Uint8Array(w*h),q=[sx,sy],seen=new Uint8Array(w*h);
      const match=i=>d[i*4+3]>0 && colorDistance(d[i*4],d[i*4+1],d[i*4+2],...target)<=tol;
      let head=0;
      while(head<q.length){const x=q[head++],y=q[head++],idx=y*w+x;if(seen[idx]||!match(idx))continue;seen[idx]=1;mask[idx]=255;
        if(x>0)q.push(x-1,y);if(x<w-1)q.push(x+1,y);if(y>0)q.push(x,y-1);if(y<h-1)q.push(x,y+1);}
      return mask;
    };
    const edgeMask=()=>{
      const w=sourceCanvas.width,h=sourceCanvas.height,d=sourceCtx.getImageData(0,0,w,h).data;
      const hex=state.removeColor.replace('#',''),target=[parseInt(hex.slice(0,2),16),parseInt(hex.slice(2,4),16),parseInt(hex.slice(4,6),16)],tol=Number(state.tolerance);
      const match=i=>colorDistance(d[i*4],d[i*4+1],d[i*4+2],...target)<=tol && d[i*4+3]>0;
      const mask=new Uint8Array(w*h),q=[];
      for(let x=0;x<w;x++){q.push(x,0);if(h>1)q.push(x,h-1);}for(let y=1;y<h-1;y++){q.push(0,y);if(w>1)q.push(w-1,y);}
      let head=0;while(head<q.length){const x=q[head++],y=q[head++],idx=y*w+x;if(mask[idx]||!match(idx))continue;mask[idx]=255;
        if(x>0)q.push(x-1,y);if(x<w-1)q.push(x+1,y);if(y>0)q.push(x,y-1);if(y<h-1)q.push(x,y+1);}
      return mask;
    };
    const applyBrush=(clientX,clientY,restore)=>{
      const p=previewToSource(clientX,clientY),r=Math.max(1,Number(state.brush)/2),fe=Number(state.feather);
      saveCurrent();const d=sourceCtx.getImageData(0,0,sourceCanvas.width,sourceCanvas.height),od=originalCtx.getImageData(0,0,originalCanvas.width,originalCanvas.height);
      const x0=Math.max(0,Math.floor(p.x-r-fe)),x1=Math.min(sourceCanvas.width-1,Math.ceil(p.x+r+fe)),y0=Math.max(0,Math.floor(p.y-r-fe)),y1=Math.min(sourceCanvas.height-1,Math.ceil(p.y+r+fe));
      for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++){const dist=Math.hypot(x-p.x,y-p.y);if(dist>r+fe)continue;const k=(y*sourceCanvas.width+x)*4;let a=dist<=r?1:1-(dist-r)/Math.max(1,fe);if(restore){for(let c=0;c<4;c++)d[k+c]=od.data[k+c];}else d[k+3]=Math.round(d[k+3]*(1-a));}
      sourceCtx.putImageData(d,0,0);draw();
    };

    // Mouse interaction
    let dragging=false, selecting=false, cropStart=null, lastBrush=null;
    // Предпросмотр «На циферблате» активен на вкладках «Шаблон» и «Эффекты» в режиме стрелки.
    const faceActive=()=>isArrow&&arrowView==='face'&&['template','effects'].some(n=>modal.querySelector(`[data-panel="${n}"]`)?.classList.contains('active'));
    const setArrowInput=(k,v)=>{const el=modal.querySelector(`[data-arrow="${k}"]`);if(el)el.value=v;};
    canvas.addEventListener('mousedown',e=>{
      if(faceActive()&&e.button===0){
        const pp=arrowParams();
        faceDrag={x:e.clientX,y:e.clientY,ox:Number(state.arrowOX)||0,oy:Number(state.arrowOY)||0,cx:pp.cx,cy:pp.cy,axis:e.shiftKey};
        e.preventDefault();return;
      }
      const tab=modal.querySelector('.ie-tabs button.active')?.dataset.tab;
      if(tab==='remove' && (state.removeTool==='erase'||state.removeTool==='restore')){
        lastBrush={x:e.clientX,y:e.clientY};applyBrush(e.clientX,e.clientY,state.removeTool==='restore'||e.altKey);e.preventDefault();return;
      }
      if(tab==='crop' && !e.altKey && e.button===0){selecting=true;cropStart=previewToSource(e.clientX,e.clientY);crop.x=cropStart.x;crop.y=cropStart.y;crop.w=1;crop.h=1;syncCropInputs();draw();e.preventDefault();return;}
      dragging=true;draggingStart={x:e.clientX,y:e.clientY,sx:state.x,sy:state.y};e.preventDefault();
    });
    let draggingStart=null;
    window.addEventListener('mousemove',e=>{
      if(faceDrag){
        // Смещение мыши -> пиксели устройства (масштаб предпросмотра учтён).
        const r=canvas.getBoundingClientRect(), k=(view.w/r.width)/(faceSc||1);
        const dx=(e.clientX-faceDrag.x)*k, dy=(e.clientY-faceDrag.y)*k;
        if(faceDrag.axis){
          setArrowInput('cx',Math.round(faceDrag.cx+dx));setArrowInput('cy',Math.round(faceDrag.cy+dy));
        } else {
          // «Сдвиг X/Y» задан в системе координат PNG (стрелка не повёрнута), поэтому
          // экранное смещение переводим обратным поворотом на текущий тестовый угол.
          const a=state.testAngle*Math.PI/180, c=Math.cos(a), sn=Math.sin(a);
          setArrowInput('ox',Math.round(faceDrag.ox+dx*c+dy*sn));setArrowInput('oy',Math.round(faceDrag.oy-dx*sn+dy*c));
        }
        syncArrowFromInputs();return;
      }
      if(selecting){const p=previewToSource(e.clientX,e.clientY);crop.x=Math.min(cropStart.x,p.x);crop.y=Math.min(cropStart.y,p.y);crop.w=Math.abs(p.x-cropStart.x);crop.h=Math.abs(p.y-cropStart.y);syncCropInputs();draw();return;}
      if(state.removeTool==='erase'||state.removeTool==='restore'){
        const tab=modal.querySelector('.ie-tabs button.active')?.dataset.tab;if(tab==='remove'&&lastBrush){applyBrush(e.clientX,e.clientY,state.removeTool==='restore'||e.altKey);return;}
      }
      if(!dragging)return;state.x=draggingStart.sx+(e.clientX-draggingStart.x);state.y=draggingStart.sy+(e.clientY-draggingStart.y);syncSliders();draw();
    });
    window.addEventListener('mouseup',()=>{selecting=false;dragging=false;lastBrush=null;faceDrag=null;});
    canvas.addEventListener('wheel',e=>{e.preventDefault();if(faceActive()||(isArrow&&modal.querySelector('[data-panel="template"]')?.classList.contains('active'))){state.arrowScale=Math.max(1,Math.min(500,state.arrowScale+(e.deltaY<0?2:-2)));const el=modal.querySelector('[data-arrow="scale"]');if(el)el.value=state.arrowScale;draw();return;}state.zoom=Math.max(25,Math.min(500,state.zoom+(e.deltaY<0?5:-5)));syncSliders();draw();},{passive:false});

    // Tabs
    modal.querySelectorAll('[data-tab]').forEach(btn=>btn.onclick=()=>{modal.__ieTabChosen=true;modal.querySelectorAll('[data-tab]').forEach(b=>b.classList.toggle('active',b===btn));modal.querySelectorAll('[data-panel]').forEach(p=>p.classList.toggle('active',p.dataset.panel===btn.dataset.tab));draw();});

    // Sliders
    modal.querySelectorAll('[data-k]').forEach(el=>el.addEventListener('input',()=>{state[el.dataset.k]=el.type==='checkbox'?el.checked:Number(el.value);updateOutputs();draw();}));
    modal.querySelector('[data-crop-circle]')?.addEventListener('change',e=>{state.circle=e.target.checked;draw();});
    modal.querySelector('[data-shadow-color]')?.addEventListener('input',e=>{state.shadowColor=e.target.value;draw();});
    modal.querySelector('[data-ie-action="shadow-reset"]')?.addEventListener('click',()=>{Object.assign(state,{shadowEnabled:false,shadowAngle:135,shadowDistance:6,shadowBlur:5,shadowSpread:0,shadowOpacity:45,shadowColor:'#000000',shadowRotate:true});const sc=modal.querySelector('[data-shadow-color]');if(sc)sc.value=state.shadowColor;syncSliders();draw();});
    modal.querySelector('[data-ie-action="shadow-preset"]')?.addEventListener('click',()=>{Object.assign(state,{shadowEnabled:true,shadowAngle:135,shadowDistance:5,shadowBlur:7,shadowSpread:1,shadowOpacity:38,shadowColor:'#000000',shadowRotate:true});const sc=modal.querySelector('[data-shadow-color]');if(sc)sc.value=state.shadowColor;syncSliders();draw();});
    modal.querySelectorAll('[data-crop]').forEach(el=>el.addEventListener('input',()=>setCrop(el.dataset.crop,el.value)));

    // Crop actions
    modal.querySelector('[data-ie-action="fit"]')?.addEventListener('click',()=>{state.zoom=100;state.x=0;state.y=0;syncSliders();draw();});
    modal.querySelector('[data-ie-action="center"]')?.addEventListener('click',()=>{state.x=0;state.y=0;syncSliders();draw();});
    modal.querySelector('[data-ie-action="stretch-reset"]')?.addEventListener('click',()=>{state.stretchX=100;state.stretchY=100;syncSliders();draw();});
    modal.querySelector('[data-ie-action="reset"]')?.addEventListener('click',()=>{Object.assign(state,{zoom:100,x:0,y:0,rot:0,stretchX:100,stretchY:100,brightness:100,contrast:100,saturation:100,blur:0,alpha:100,shadowEnabled:false,shadowAngle:135,shadowDistance:6,shadowBlur:5,shadowSpread:0,shadowOpacity:45,shadowColor:'#000000',shadowRotate:true});const sc=modal.querySelector('[data-shadow-color]');if(sc)sc.value=state.shadowColor;crop.x=0;crop.y=0;crop.w=sourceCanvas.width;crop.h=sourceCanvas.height;syncCropInputs();syncSliders();draw();});
    modal.querySelector('[data-ie-action="autocrop"]')?.addEventListener('click',autoCrop);

    // Remove background actions
    const pickColorAt=(clientX,clientY)=>{const p=previewToSource(clientX,clientY),d=sourceCtx.getImageData(Math.round(p.x),Math.round(p.y),1,1).data;state.removeColor='#'+[d[0],d[1],d[2]].map(v=>v.toString(16).padStart(2,'0')).join('');const c=modal.querySelector('[data-remove-color]');if(c)c.value=state.removeColor;};
    modal.querySelector('[data-ie-action="pick"]')?.addEventListener('click',()=>{state.removeTool='pick';});
    modal.querySelector('[data-ie-action="wand"]')?.addEventListener('click',()=>{state.removeTool='wand';});
    modal.querySelector('[data-ie-action="erase"]')?.addEventListener('click',()=>{state.removeTool='erase';});
    modal.querySelector('[data-ie-action="restore"]')?.addEventListener('click',()=>{state.removeTool='restore';});
    modal.querySelector('[data-ie-action="undo-remove"]')?.addEventListener('click',()=>{const s=history.pop();if(s){future.push(snapshot());restoreSnapshot(s);}});
    // Перекраска: заменяет RGB всех непрозрачных пикселей, альфа-канал (края, прозрачность) не трогаем.
    const recolorSource=(hex)=>{
      if(!sourceCtx||!sourceCanvas.width)return;
      const m=/^#?([0-9a-f]{6})$/i.exec(String(hex||'').trim()); if(!m)return;
      const r=parseInt(m[1].slice(0,2),16),g=parseInt(m[1].slice(2,4),16),b=parseInt(m[1].slice(4,6),16);
      pushHistory();
      const id=sourceCtx.getImageData(0,0,sourceCanvas.width,sourceCanvas.height),d=id.data;
      for(let i=0;i<d.length;i+=4){ if(d[i+3]){ d[i]=r;d[i+1]=g;d[i+2]=b; } }
      sourceCtx.putImageData(id,0,0); draw();
    };
    const recolorInput=()=>modal.querySelector('[data-recolor-color]');
    modal.querySelector('[data-ie-action="recolor"]')?.addEventListener('click',()=>recolorSource(recolorInput()?.value));
    modal.querySelector('[data-ie-action="recolor-white"]')?.addEventListener('click',()=>{const c=recolorInput();if(c)c.value='#ffffff';recolorSource('#ffffff');});
    modal.querySelector('[data-ie-action="recolor-black"]')?.addEventListener('click',()=>{const c=recolorInput();if(c)c.value='#000000';recolorSource('#000000');});
    modal.querySelector('[data-ie-action="undo-recolor"]')?.addEventListener('click',()=>{const h=history.pop();if(h){future.push(snapshot());restoreSnapshot(h);}});
    modal.querySelector('[data-ie-action="redo-remove"]')?.addEventListener('click',()=>{const s=future.pop();if(s){history.push(snapshot());restoreSnapshot(s);}});
    modal.querySelector('[data-ie-action="edge"]')?.addEventListener('click',()=>{state.removeTool='wand';removeByMask(edgeMask(), Number(state.feather)||0);});
    modal.querySelector('[data-ie-action="white"]')?.addEventListener('click',()=>{state.removeColor='#ffffff';const c=modal.querySelector('[data-remove-color]');if(c)c.value='#ffffff';removeByMask(state.removeConnected?edgeMask():floodMask(0,0), Number(state.feather)||0);});
    modal.querySelector('[data-ie-action="corner"]')?.addEventListener('click',()=>{const d=sourceCtx.getImageData(0,0,1,1).data;state.removeColor='#'+[d[0],d[1],d[2]].map(v=>v.toString(16).padStart(2,'0')).join('');const c=modal.querySelector('[data-remove-color]');if(c)c.value=state.removeColor;removeByMask(edgeMask(), Number(state.feather)||0);});
    modal.querySelector('[data-ie-action="invert"]')?.addEventListener('click',()=>{saveCurrent();const d=sourceCtx.getImageData(0,0,sourceCanvas.width,sourceCanvas.height),p=d.data;for(let i=0;i<p.length;i+=4)p[i+3]=255-p[i+3];sourceCtx.putImageData(d,0,0);draw();});
    modal.querySelector('[data-remove-color]')?.addEventListener('input',e=>state.removeColor=e.target.value);

    // Clicking the image in remove mode behaves like Photoshop's eyedropper/wand.
    canvas.addEventListener('click',e=>{
      const tab=modal.querySelector('.ie-tabs button.active')?.dataset.tab;if(tab!=='remove')return;
      if(state.removeTool==='pick'){pickColorAt(e.clientX,e.clientY);state.removeTool='wand';return;}
      if(state.removeTool==='wand'){const p=previewToSource(e.clientX,e.clientY);removeByMask(floodMask(p.x,p.y));}
    });

    // Arrow studio
    {
      const select=modal.querySelector('[data-arrow-template]');
      const loadTemplate=k=>{state.arrowTemplate=k;select.value=k;if(state.arrowFit)setArrowInputs(templates[k]);else{updateArrowStatus();draw();}};
      modal.querySelector('[data-arrow-fitmode]')?.addEventListener('change',e=>setFitMode(e.target.checked));
      select.onchange=()=>loadTemplate(select.value);
      modal.querySelectorAll('[data-arrow-preset]').forEach(b=>b.onclick=()=>loadTemplate(b.dataset.arrowPreset));
      modal.querySelectorAll('[data-arrow]').forEach(el=>el.addEventListener('input',syncArrowFromInputs));
      modal.querySelector('[data-ie-action="arrow-autocrop"]')?.addEventListener('click',()=>{autoCrop();});
      modal.querySelector('[data-ie-action="arrow-fit"]')?.addEventListener('click',()=>{state.arrowScale=100;state.arrowOX=0;state.arrowOY=0;modal.querySelector('[data-arrow="scale"]').value=100;modal.querySelector('[data-arrow="ox"]').value=0;modal.querySelector('[data-arrow="oy"]').value=0;draw();});
      modal.querySelector('[data-ie-action="arrow-center"]')?.addEventListener('click',()=>{state.arrowOX=0;state.arrowOY=0;modal.querySelector('[data-arrow="ox"]').value=0;modal.querySelector('[data-arrow="oy"]').value=0;draw();});
      modal.querySelector('[data-ie-action="test-0"]')?.addEventListener('click',()=>{state.testAngle=0;draw();});
      modal.querySelector('[data-ie-action="test-90"]')?.addEventListener('click',()=>{state.testAngle=90;draw();});
      modal.querySelector('[data-ie-action="test-180"]')?.addEventListener('click',()=>{state.testAngle=180;draw();});
      modal.querySelector('[data-ie-action="test-270"]')?.addEventListener('click',()=>{state.testAngle=270;draw();});
      modal.querySelector('[data-ie-action="test-1010"]')?.addEventListener('click',()=>{state.testAngle=timeAngles[state.arrowTemplate]||0;draw();});
      modal.querySelector('[data-arrow-view]')?.addEventListener('change',e=>{arrowView=e.target.value;draw();});
      modal.querySelector('[data-arrow-others]')?.addEventListener('change',()=>draw());
      modal.querySelector('[data-ie-action="test-stop"]')?.addEventListener('click',()=>{state.testAngle=0;draw();});
    }

    // --- Переключение режимов -------------------------------------------
    const applyMode=(mode)=>{
      isArrow = mode==='arrow';
      modal.classList.toggle('ie-mode-arrow',isArrow);
      modal.querySelectorAll('[data-ie-mode]').forEach(b=>b.classList.toggle('active',b.dataset.ieMode===mode));
      modal.querySelector('[data-ie-preview]').classList.toggle('arrow-studio-preview',isArrow);
      modal.querySelector('[data-ie-hint]').textContent=isArrow?'Перетаскивание — сдвиг стрелки · Shift — переместить ось · колесо — масштаб':'Перетаскивайте изображение · Колесо — масштаб · Alt+перетаскивание — перемещение';
      modal.querySelector('[data-arrow-status]').style.display=isArrow?'':'none';
      modal.querySelectorAll('[data-ie-arrow-only]').forEach(el=>{el.hidden=!isArrow;});
      const ttl=modal.querySelector('[data-ie-title]');
      if(ttl)ttl.textContent=isArrow?(opts.arrowTitle||'Мастер стрелок — шаблон + удаление фона'):opts.title;
      const apply=modal.querySelector('[data-ie-apply]');
      apply.textContent=(isArrow?'Создать готовую стрелку':'Создать PNG')+(typeof opts.onSave==='function'?' (новый)':'');
      const wanted=isArrow?'template':'crop';
      const cur=modal.querySelector('.ie-tabs button.active')?.dataset.tab;
      const useTab=(!cur||(!isArrow&&cur==='template'))?wanted:(isArrow&&!modal.__ieTabChosen?wanted:cur);
      modal.querySelectorAll('[data-tab]').forEach(b=>b.classList.toggle('active',b.dataset.tab===useTab));
      modal.querySelectorAll('[data-panel]').forEach(p=>p.classList.toggle('active',p.dataset.panel===useTab));
      updateArrowStatus();draw();
    };
    modal.querySelectorAll('[data-ie-mode]').forEach(b=>b.onclick=()=>{if((b.dataset.ieMode==='arrow')!==isArrow)applyMode(b.dataset.ieMode);});

    const previewHost=modal.querySelector('[data-ie-preview]');
    const fitCanvasToPreview=()=>{
      const w=Math.floor(previewHost.clientWidth),h=Math.floor(previewHost.clientHeight);
      if(w<120||h<120||(w===view.w&&h===view.h))return;
      view.w=w;view.h=h;canvas.width=w;canvas.height=h;
      ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';
      if(sourceCtx){view.fitScale=fitScale();draw();}
    };
    const resizeObs=window.ResizeObserver?new ResizeObserver(fitCanvasToPreview):null;
    if(resizeObs)resizeObs.observe(previewHost);
    const close=()=>{if(resizeObs)resizeObs.disconnect();modal.remove();};
    // Отпечаток правок: параметры, обрезка, число шагов истории и режим.
    // Сравнивается с исходным, снятым после загрузки картинки.
    const editSignature=()=>JSON.stringify([state,crop,history.length,isArrow,isArrow?arrowParams():null]);
    let initialSignature=null;
    const isDirty=()=>initialSignature!==null&&editSignature()!==initialSignature;
    const requestClose=()=>{if(isDirty()&&!confirm('Есть несохранённые правки. Закрыть редактор без сохранения?'))return;close();};
    modal.querySelectorAll('[data-ie-close]').forEach(b=>b.onclick=requestClose);
    modal.addEventListener('keydown',(e)=>{if(e.key==='Escape'&&!/^(INPUT|SELECT|TEXTAREA)$/.test(e.target.tagName)){e.stopPropagation();requestClose();}});

    // Строит итоговый PNG стрелки (канвас) по текущим параметрам. Ось p.px/p.py
    // сдвигается на величину расширения холста. Используется и при сохранении,
    // и в предпросмотре «На циферблате», чтобы они совпадали пиксель в пиксель.
    // withShadow=true — как будет на часах (предпросмотр); false — чистая картинка для ресурса
    // (поля под тень в ней уже есть, сама тень рисуется при сборке проекта).
    const buildArrowCanvas=(p,withShadow=true)=>{
      const L=arrowLayout(p),E=arrowExtent(L),ow=E.ow,oh=E.oh;
      const out=document.createElement('canvas');out.width=ow;out.height=oh;
      const ox=out.getContext('2d');
      if(!modal.querySelector('[data-arrow-transparent]')?.checked){ox.fillStyle='#000';ox.fillRect(0,0,ow,oh);}
      if(L.b){ox.filter=`brightness(${state.brightness}%) contrast(${state.contrast}%) saturate(${state.saturation}%) blur(${state.blur}px)`;ox.globalAlpha=state.alpha/100;if(withShadow)drawWithShadow(ox,sourceCanvas,L.b.x,L.b.y,L.b.w,L.b.h,L.dx-E.left,L.dy-E.top,L.dw,L.dh,0);else ox.drawImage(sourceCanvas,L.b.x,L.b.y,L.b.w,L.b.h,L.dx-E.left,L.dy-E.top,L.dw,L.dh);}
      // Ось сдвигается на ту же величину, что и расширенный холст.
      p.px=L.px-E.left;p.py=L.py-E.top;
      return {out,ow,oh};
    };

    // Build exact output PNG. For arrow mode, source object is fitted into a
    // deterministic template and the returned metadata can be applied directly
    // to TIME_POINTER.
    const buildResult=(replace)=>{
      const p=isArrow?arrowParams():null;
      let out,ow,oh;
      if(isArrow){
        const r=buildArrowCanvas(p,false);out=r.out;ow=r.ow;oh=r.oh;
      } else {
        // Build an expanded working canvas from the transformed image bounds. This
        // prevents zoom/stretch from being clipped by the original source dimensions.
        const zx=state.zoom/100*(state.stretchX/100),zy=state.zoom/100*(state.stretchY/100);
        const rad=state.rot*Math.PI/180, rw=Math.abs(sourceCanvas.width*zx*Math.cos(rad))+Math.abs(sourceCanvas.height*zy*Math.sin(rad));
        const rh=Math.abs(sourceCanvas.width*zx*Math.sin(rad))+Math.abs(sourceCanvas.height*zy*Math.cos(rad));
        const work=document.createElement('canvas');const snapPx=(v)=>Math.ceil(Math.round(v*1000)/1000);work.width=Math.max(1,snapPx(rw+Math.abs(state.x)*2));work.height=Math.max(1,snapPx(rh+Math.abs(state.y)*2));const wx=work.getContext('2d');
        wx.save();wx.translate(work.width/2+state.x,work.height/2+state.y);wx.rotate(rad);wx.scale(zx,zy);wx.filter=`brightness(${state.brightness}%) contrast(${state.contrast}%) saturate(${state.saturation}%) blur(${state.blur}px)`;wx.globalAlpha=state.alpha/100;wx.drawImage(sourceCanvas,-sourceCanvas.width/2,-sourceCanvas.height/2);wx.restore();
        const fx=work.width/sourceCanvas.width,fy=work.height/sourceCanvas.height;
        const cx=Math.max(0,Math.round(crop.x*fx)),cy=Math.max(0,Math.round(crop.y*fy));
        ow=Math.max(1,Math.min(work.width-cx,Math.round(crop.w*fx)));oh=Math.max(1,Math.min(work.height-cy,Math.round(crop.h*fy)));
        out=document.createElement('canvas');out.width=ow;out.height=oh;const ox=out.getContext('2d');
        if(state.circle){ox.save();ox.beginPath();ox.arc(ow/2,oh/2,Math.min(ow,oh)/2,0,Math.PI*2);ox.clip();}
        ox.drawImage(work,cx,cy,ow,oh,0,0,ow,oh);if(state.circle)ox.restore();
      }
      out.toBlob(blob=>{const r=new FileReader();r.onload=()=>{
        const name=replace?asset.name:(asset.name||'image').replace(/-edited(?:-\d+)?$/,'')+(isArrow?`-${state.arrowTemplate}-hand`:'-edited');
        const result={id:replace?asset.id:makeAssetId(),name,dataUrl:r.result,width:ow,height:oh,format:'PNG',size:blob.size};
        if(isArrow){
          result.arrow={type:state.arrowTemplate,center_x:p.cx,center_y:p.cy,pos_x:p.px,pos_y:p.py,motion:state.arrowTemplate==='second'?'TICK':undefined};
          // Тень не вшивается в картинку: хранятся параметры, PNG с тенью строится при сборке проекта.
          result.shadow=state.shadowEnabled?{enabled:true,angle:state.shadowAngle,distance:state.shadowDistance,blur:state.shadowBlur,spread:state.shadowSpread,opacity:state.shadowOpacity,color:state.shadowColor,rotate:state.shadowRotate!==false}:null;
        }
        if(replace){ if(typeof opts.onSave==='function'&&opts.onSave(result)===false)return; }
        else if(typeof opts.onApply==='function')opts.onApply(result);
        close();
      };r.readAsDataURL(blob);},'image/png');
    };
    modal.querySelector('[data-ie-apply]').onclick=()=>buildResult(false);
    const saveBtn=modal.querySelector('[data-ie-save]'); if(saveBtn)saveBtn.onclick=()=>buildResult(true);

    img.onload=()=>{
      sourceCanvas.width=img.naturalWidth;sourceCanvas.height=img.naturalHeight;sourceCtx=sourceCanvas.getContext('2d',{willReadFrequently:true});sourceCtx.imageSmoothingEnabled=true;sourceCtx.imageSmoothingQuality='high';sourceCtx.clearRect(0,0,sourceCanvas.width,sourceCanvas.height);sourceCtx.drawImage(img,0,0);
      originalCanvas.width=img.naturalWidth;originalCanvas.height=img.naturalHeight;originalCtx=originalCanvas.getContext('2d',{willReadFrequently:true});originalCtx.drawImage(img,0,0);
      view.fitScale=fitScale();crop.w=sourceCanvas.width;crop.h=sourceCanvas.height;syncCropInputs();
      loadArrowInitial();
      if(opts.shadow&&opts.shadow.enabled){const sh=opts.shadow;Object.assign(state,{shadowEnabled:true,shadowAngle:sh.angle,shadowDistance:sh.distance,shadowBlur:sh.blur,shadowSpread:sh.spread,shadowOpacity:sh.opacity,shadowColor:sh.color||'#000000',shadowRotate:sh.rotate!==false});const scol=modal.querySelector('[data-shadow-color]');if(scol)scol.value=state.shadowColor;}
      applyMode(isArrow?'arrow':'image');
      syncSliders();updateOutputs();draw();
      renderFaceBase();
      // Поля масштаба/сдвига стрелки раньше оставались пустыми до первого нажатия кнопок.
      [['scale',state.arrowScale],['ox',state.arrowOX],['oy',state.arrowOY]].forEach(([k,v])=>{const el=modal.querySelector(`[data-arrow="${k}"]`);if(el&&el.value==='')el.value=v;});
      initialSignature=editSignature();
    };
    const loadArrowInitial=()=>{const select=modal.querySelector('[data-arrow-template]');if(select){const ai=opts.arrowInit;const t=ai&&templates[ai.type]?Object.assign({},templates[ai.type],ai):templates.hour;const k=ai&&templates[ai.type]?ai.type:'hour';state.arrowTemplate=k;select.value=k;Object.assign(arrow,t);
        // Существующая стрелка открывается «как есть» (100% = текущий размер PNG); новое изображение — с подгонкой под шаблон.
        state.arrowFit=!(ai&&templates[ai.type]);
        openAxis=state.arrowFit?null:{px:Number(t.px),py:Number(t.py)};
['w','h','px','py','cx','cy'].forEach(k=>{const e=modal.querySelector(`[data-arrow="${k}"]`);if(e)e.value=arrow[k];});syncFitUI();}};
    img.src=asset.dataUrl;
  }

  // ---- Единая точка входа для всех мест приложения ---------------------
  // Открывает один и тот же редактор для PNG и для стрелок. Режим выбирается
  // автоматически: ресурс, на который ссылается TIME_POINTER (часовая/минутная/
  // секундная стрелка), открывается в режиме стрелки, остальные — в режиме
  // изображения. `mode` ('image' | 'arrow') принудительно задаёт режим.
  static pointerDefs() {
    return { time_pointer_hour: 'hour', time_pointer_minute: 'minute', time_pointer_second: 'second' };
  }

  static linkedPointers(store, asset) {
    const defs = ImageAssetEditor.pointerDefs();
    return (store.state.components || []).filter((c) => defs[c.defId] && c.props && c.props.path === asset.id);
  }

  static openForAsset(store, asset, options = {}) {
    // Фон циферблата с сохранёнными настройками правится только в редакторе фона:
    // в общем редакторе исходник перезаписался бы, а настройки остались бы прежними.
    if (typeof AssetBg !== 'undefined' && AssetBg.isBg(asset) && options.mode !== 'arrow' && typeof window.openBackgroundEditorForAsset === 'function') {
      return window.openBackgroundEditorForAsset(asset);
    }
    const defs = ImageAssetEditor.pointerDefs();
    const typeToDef = { hour: 'time_pointer_hour', minute: 'time_pointer_minute', second: 'time_pointer_second' };
    const linked = ImageAssetEditor.linkedPointers(store, asset);
    const mode = options.mode || (linked.length ? 'arrow' : 'image');
    const first = linked[0];
    const arrowInit = first ? {
      type: defs[first.defId], w: asset.width, h: asset.height,
      px: Number(first.props.pos_x), py: Number(first.props.pos_y),
      cx: Number(first.props.center_x), cy: Number(first.props.center_y)
    } : null;
    if (arrowInit) Object.keys(arrowInit).forEach((k) => { if (typeof arrowInit[k] === 'number' && !isFinite(arrowInit[k])) delete arrowInit[k]; });

    const patchOf = (out) => ({ dataUrl: out.dataUrl, width: out.width, height: out.height, format: out.format, size: out.size, ...(out.arrow ? { shadow: out.shadow || null } : {}) });
    return ImageAssetEditor.open(asset, {
      mode,
      title: options.title || 'Редактор ресурса',
      arrowTitle: 'Мастер стрелок — шаблон + удаление фона',
      device: store.state.device,
      store,
      arrowInit,
      shadow: asset.shadow || null,
      // «Сохранить в этот ресурс»: тот же id/имя; метаданные стрелки хранятся в
      // компонентах TIME_POINTER и обновляются только при сохранении в режиме стрелки.
      onSave: (out) => {
        if (!out.arrow) {
          // Режим изображения. Если ресурс используется как стрелка и размер PNG
          // изменился, точка вращения (pos_x/pos_y) может перестать совпадать с картинкой.
          if (linked.length && (out.width !== asset.width || out.height !== asset.height) &&
              !confirm('Этот ресурс используется как стрелка (TIME_POINTER), а размер PNG изменился.\n' +
                       'Точка вращения останется прежней и может не совпасть с картинкой.\n\n' +
                       'Сохранить в режиме изображения? (Для стрелки лучше переключиться в режим «Стрелка».)')) return false;
          store.replaceAsset(asset.id, patchOf(out));
          return true;
        }
        store.replaceAsset(asset.id, patchOf(out));
        for (const c of store.state.components) {
          if (c.props && c.props.path === asset.id && c.defId === typeToDef[out.arrow.type]) {
            store.updateComponent(c.id, { x: out.arrow.center_x - out.arrow.pos_x, y: out.arrow.center_y - out.arrow.pos_y, w: out.width, h: out.height });
            ['center_x', 'center_y', 'pos_x', 'pos_y'].forEach((k) => store.updateComponentProp(c.id, k, out.arrow[k]));
          }
        }
        return true;
      },
      // «Создать (новый)»: новый ресурс, исходный не изменяется.
      onApply: (out) => {
        store.addAsset(out);
        if (!out.arrow) return;
        const defId = typeToDef[out.arrow.type];
        const selectedId = [...store.selection][0];
        const selected = store.state.components.find((c) => c.id === selectedId);
        const target = selected && selected.defId === defId ? selected : store.addComponent(defId, 0, 0);
        if (!target) return;
        store.updateComponent(target.id, {
          x: out.arrow.center_x - out.arrow.pos_x, y: out.arrow.center_y - out.arrow.pos_y, w: out.width, h: out.height,
          name: `${out.arrow.type === 'hour' ? 'Часовая' : out.arrow.type === 'minute' ? 'Минутная' : 'Секундная'} стрелка · ${out.name}`
        });
        store.updateComponentProp(target.id, 'path', out.id);
        store.updateComponentProp(target.id, 'center_x', out.arrow.center_x);
        store.updateComponentProp(target.id, 'center_y', out.arrow.center_y);
        store.updateComponentProp(target.id, 'pos_x', out.arrow.pos_x);
        store.updateComponentProp(target.id, 'pos_y', out.arrow.pos_y);
        if (defId === 'time_pointer_second' && out.arrow.motion) store.updateComponentProp(target.id, 'motion', out.arrow.motion);
      }
    });
  }

  static esc(s){return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
}
