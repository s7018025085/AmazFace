// Перетаскивание анимации фона мышью по холсту (меняет anim.fit.x / anim.fit.y).
// Работает только когда включён режим «✥ Двигать GIF мышью» и мышь нажата на самом фоне (не на компоненте).
// Во время движения пересчитывается только показанный кадр; после отпускания — все кадры (inspector._refitBgAnim).
(function (root) {
  'use strict';

  class BgAnimDrag {
    constructor(deps) {
      this.editor = deps.editor;          // CanvasEditor
      this.store = deps.store;
      this.preview = deps.preview;        // BgAnim.createPreview(...)
      this.onCommit = deps.onCommit;      // (fit) => Promise — пересчёт всех кадров + commit
      this.active = false;
      this.drag = null;
      this.busy = false;
      this.pending = null;
      this.editor.viewport.addEventListener('mousedown', (e) => this._down(e), true);
      window.addEventListener('mousemove', (e) => this._move(e));
      window.addEventListener('mouseup', () => this._up());
    }

    setActive(on) {
      this.active = !!on;
      this.editor.viewport.classList.toggle('bg-drag-mode', this.active);
    }

    _anim() { return BgAnim.normalize(this.store.state.background && this.store.state.background.anim); }

    _down(e) {
      if (!this.active || e.button !== 0 || e.altKey || this.store.state.mode === 'aod') return;
      if (!e.target.classList || !e.target.classList.contains('shared-preview-canvas')) return;
      const a = this._anim();
      if (!a.frames.length) return;
      e.preventDefault(); e.stopPropagation();
      this.preview.stop(false);
      const idx = Math.max(0, Math.min(a.frames.length - 1, this.preview.currentIndex()));
      this.preview.seek(idx);             // на холсте — нужный кадр, а не статичный фон
      const rect = e.target.getBoundingClientRect();
      const ratio = (rect.width / (this.store.state.device.w || 480)) || 1;
      this.drag = { x: e.clientX, y: e.clientY, ratio, fit: a.fit, frameId: a.frames[idx], cur: a.fit, moved: false };
    }

    _move(e) {
      const d = this.drag;
      if (!d) return;
      let dx = Math.round((e.clientX - d.x) / d.ratio), dy = Math.round((e.clientY - d.y) / d.ratio);
      if (e.shiftKey) { if (Math.abs(dx) >= Math.abs(dy)) dy = 0; else dx = 0; }     // Shift — только по одной оси
      const fit = BgAnim.normFit(Object.assign({}, d.fit, { x: d.fit.x + dx, y: d.fit.y + dy }));
      if (fit.x === d.cur.x && fit.y === d.cur.y) return;
      d.cur = fit; d.moved = true;
      this._livePreview();
    }

    async _livePreview() {
      if (this.busy) { this.pending = true; return; }
      this.busy = true;
      try {
        do {
          this.pending = false;
          const d = this.drag;
          if (!d) break;
          const asset = (this.store.state.assets || []).find((x) => x.id === d.frameId);
          if (!asset) break;
          const dev = this.store.state.device || { w: 480, h: 480 };
          await BgAnim.rebakeFrames([asset], dev.w, dev.h, d.cur);
          this.editor.redrawPreview();
        } while (this.pending);
      } catch (err) { console.warn(err); }
      this.busy = false;
    }

    async _up() {
      const d = this.drag;
      if (!d) return;
      this.drag = null;
      if (!d.moved) return;
      while (this.busy) await new Promise((r) => setTimeout(r, 10));
      await this.onCommit(d.cur);
    }
  }

  root.BgAnimDrag = BgAnimDrag;
})(typeof window !== 'undefined' ? window : globalThis);
