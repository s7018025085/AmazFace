// Timeline for scrubbing and previewing the background animation frames.
(function (root) {
  'use strict';

  class BgAnimTimeline {
    constructor(el, deps) {
      this.el = el;
      this.getState = deps.getState;
      this.store = deps.store;
      this.preview = deps.preview;
      this.trash = new Map();          // удалённые кадры: нужны, чтобы Ctrl+Z мог вернуть кадр вместе с картинкой
      this.dragFrom = null;
      this.range = null;               // выбранный кусок { from, to } (индексы кадров, null — край не задан); только интерфейс
      this.index = 0;
      this.zoom = Math.max(44, Math.min(112, Number(localStorage.getItem('amazface.bgTimeline.zoom')) || 64));
      this.height = Math.max(90, Math.min(320, Number(localStorage.getItem('amazface.bgTimeline.height')) || 142));
      this.collapsed = localStorage.getItem('amazface.bgTimeline.collapsed') === '1';
      this.dragStart = null;
      this.el.addEventListener('input', (e) => this._input(e));
      this.el.addEventListener('click', (e) => this._click(e));
      this.el.addEventListener('pointerdown', (e) => this._pointerDown(e));
      this.el.addEventListener('keydown', (e) => this._keyDown(e));
      this.el.addEventListener('dragstart', (e) => this._dragStart(e));
      this.el.addEventListener('dragover', (e) => this._dragOver(e));
      this.el.addEventListener('dragleave', (e) => this._clearDropMarks(e));
      this.el.addEventListener('drop', (e) => this._drop(e));
      this.el.addEventListener('dragend', () => { this.dragFrom = null; this._clearDropMarks(); });
      this._onMove = (e) => this._pointerMove(e);
      this._onUp = () => this._pointerUp();
      window.addEventListener('pointermove', this._onMove);
      window.addEventListener('pointerup', this._onUp);
      window.addEventListener('pointercancel', this._onUp);
      this.preview.setOnChange((playing, index) => {
        if (Number.isInteger(index)) this.index = index;
        this._syncPlayButton(playing);
        this._syncPosition(true);
      });
      this.render();
    }

    _rangeBounds(n) {
      const r = this.range;
      if (!r || (r.from === null && r.to === null) || n < 1) return null;
      let from = r.from === null ? 0 : Math.max(0, Math.min(n - 1, r.from));
      let to = r.to === null ? n - 1 : Math.max(0, Math.min(n - 1, r.to));
      if (to < from) to = from;
      return { from, to };
    }

    _anim() {
      return BgAnim.normalize(this.getState()?.background?.anim);
    }

    _escAttr(value) {
      return String(value).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    }

    render() {
      const state = this.getState();
      this._heal(state);
      const anim = this._anim();
      const frames = anim.frames;
      const assets = state?.assets || [];
      const rb = this._rangeBounds(frames.length);
      if (state?.mode === 'aod' || frames.length < 1) {
        this.el.hidden = true;
        return;
      }
      this.el.hidden = false;
      this.index = Math.max(0, Math.min(this.index, frames.length - 1));
      this.el.classList.toggle('is-collapsed', this.collapsed);
      this.el.style.setProperty('--bg-timeline-height', this.height + 'px');
      this.el.style.setProperty('--bg-timeline-frame-width', this.zoom + 'px');
      this.el.innerHTML = `
        <div class="bg-timeline-grip" data-ba-timeline-grip title="Потяните, чтобы изменить высоту таймлайна"><span></span></div>
        <div class="bg-timeline-head">
          <div class="bg-timeline-title"><b>Таймлайн фона</b><span data-ba-time>Кадр ${this.index + 1} / ${frames.length}</span>${rb ? `<span>кусок ${rb.from + 1}–${rb.to + 1}</span>` : ''}</div>
          <div class="bg-timeline-actions">
            <button type="button" data-ba-timeline-act="play" title="Воспроизвести">▶</button>
            <button type="button" data-ba-timeline-act="move-left" title="Сдвинуть выбранный кадр влево (Shift+←)" ${this.index > 0 ? '' : 'disabled'}>←</button>
            <button type="button" data-ba-timeline-act="move-right" title="Сдвинуть выбранный кадр вправо (Shift+→)" ${this.index < frames.length - 1 ? '' : 'disabled'}>→</button>
            <button type="button" data-ba-timeline-act="delete" title="Удалить выбранный кадр (Delete)">🗑</button>
            <button type="button" data-ba-timeline-act="mark-in" title="Начало нужного куска — текущий кадр ( [ )">[</button>
            <button type="button" data-ba-timeline-act="mark-out" title="Конец нужного куска — текущий кадр ( ] )">]</button>
            <button type="button" data-ba-timeline-act="trim" title="Оставить только отмеченный кусок, остальное удалить" ${rb && (rb.from > 0 || rb.to < frames.length - 1) ? '' : 'disabled'}>✂</button>
            ${rb ? '<button type="button" data-ba-timeline-act="clear-range" title="Снять отметки куска">✕</button>' : ''}
            <button type="button" data-ba-timeline-act="zoom-out" title="Уменьшить кадры">−</button>
            <button type="button" data-ba-timeline-act="zoom-in" title="Увеличить кадры">+</button>
            <button type="button" data-ba-timeline-act="collapse" title="Свернуть таймлайн">${this.collapsed ? '▴' : '▾'}</button>
          </div>
        </div>
        <div class="bg-timeline-body">
          <div class="bg-timeline-rail" data-ba-rail>
            ${frames.map((id, i) => {
              const asset = assets.find((a) => a.id === id);
              return `<div role="button" tabindex="0" draggable="true" class="bg-timeline-frame${i === this.index ? ' active' : ''}${rb ? (i < rb.from || i > rb.to ? ' out-range' : '') + (i === rb.from ? ' range-start' : '') + (i === rb.to ? ' range-end' : '') : ''}" data-ba-frame="${i}" title="Кадр ${i + 1} — перетащите, чтобы переставить"><img alt="" draggable="false" src="${this._escAttr(asset?.dataUrl || '')}"><span>${i + 1}</span></div>`;
            }).join('')}
          </div>
          <div class="bg-timeline-scrubber">
            <input type="range" data-ba-scrub min="0" max="${frames.length - 1}" value="${this.index}" aria-label="Положение на таймлайне">
            <span data-ba-position>${this.index + 1} / ${frames.length}</span>
          </div>
        </div>`;
      this._syncPlayButton(this.preview.isPlaying());
      this._syncPosition(false);
    }

    _input(e) {
      if (e.target.matches('[data-ba-scrub]')) this._seek(Number(e.target.value));
    }

    _click(e) {
      const frame = e.target.closest('[data-ba-frame]');
      if (frame) { this._seek(Number(frame.dataset.baFrame)); return; }
      const action = e.target.closest('[data-ba-timeline-act]')?.dataset.baTimelineAct;
      if (!action) return;
      if (action === 'mark-in' || action === 'mark-out' || action === 'trim' || action === 'clear-range') { this._rangeAction(action); return; }
      if (action === 'delete') { this._deleteFrame(this.index); return; }
      if (action === 'move-left') { this._moveFrame(this.index, this.index - 1); return; }
      if (action === 'move-right') { this._moveFrame(this.index, this.index + 1); return; }
      if (action === 'play') {
        if (this.preview.isPlaying()) this.preview.stop(false);
        else this.preview.play();
      } else if (action === 'zoom-in' || action === 'zoom-out') {
        this.zoom = Math.max(44, Math.min(112, this.zoom + (action === 'zoom-in' ? 12 : -12)));
        localStorage.setItem('amazface.bgTimeline.zoom', String(this.zoom));
        this.render();
      } else if (action === 'collapse') {
        this.collapsed = !this.collapsed;
        localStorage.setItem('amazface.bgTimeline.collapsed', this.collapsed ? '1' : '0');
        this.render();
      }
    }

    // ---- Правка кадров: удалить / переставить ----
    _rangeAction(action) {
      const n = this._anim().frames.length;
      if (action === 'clear-range') this.range = null;
      else if (action === 'mark-in') this.range = { from: this.index, to: this.range ? this.range.to : null };
      else if (action === 'mark-out') this.range = { from: this.range ? this.range.from : null, to: this.index };
      else if (action === 'trim') {
        const b = this._rangeBounds(n);
        if (!b || (b.from === 0 && b.to === n - 1)) return;
        const frames = this._frameAssetIds();
        this._commitFrames(frames.slice(b.from, b.to + 1), frames.slice(0, b.from).concat(frames.slice(b.to + 1)), 0);   // обрезка отменяется Ctrl+Z
        return;
      }
      this.render();
      this._focusFrame();
    }

    _frameAssetIds() { return this._anim().frames.slice(); }

    // Записывает новый порядок кадров. removedIds — ресурсы-кадры, которые больше не нужны (уходят в корзину, не в пакет).
    _commitFrames(frames, removedIds, newIndex) {
      if (!this.store) return;
      this.range = null;
      const st = this.store.state;
      const bg = st.background || { color: '#000000', imageAssetId: null, alpha: 100 };
      const anim = Object.assign({}, this._anim(), { frames, enabled: this._anim().enabled && frames.length >= 2 });
      if (removedIds.length) {
        const gone = new Set(removedIds);
        for (const a of st.assets || []) if (gone.has(a.id) && a.bgFrame) this._toTrash(a);
        st.assets = (st.assets || []).filter((a) => !(gone.has(a.id) && a.bgFrame));
      }
      const imageAssetId = removedIds.includes(bg.imageAssetId) ? null : bg.imageAssetId;
      st.background = Object.assign({}, bg, { imageAssetId, anim });
      this.index = frames.length ? Math.max(0, Math.min(frames.length - 1, newIndex)) : 0;
      if (this.preview.isPlaying()) this.preview.stop(false);
      if (!frames.length) this.preview.stop(true);
      this.store.commit();
      if (frames.length) this.preview.seek(this.index);
      this._focusFrame();
    }

    _deleteFrame(i) {
      const frames = this._frameAssetIds();
      if (!frames.length || i < 0 || i >= frames.length) return;
      const [removed] = frames.splice(i, 1);
      this._commitFrames(frames, [removed], Math.min(i, frames.length - 1));
    }

    _moveFrame(from, to) {
      const frames = this._frameAssetIds();
      if (from === to || from < 0 || to < 0 || from >= frames.length || to >= frames.length) return;
      const [item] = frames.splice(from, 1);
      frames.splice(to, 0, item);
      this._commitFrames(frames, [], to);
    }

    _focusFrame() {
      const el = this.el.querySelector(`[data-ba-frame="${this.index}"]`);
      if (el) el.focus({ preventScroll: true });
    }

    _keyDown(e) {
      if (!e.target.closest('[data-ba-rail]')) return;
      const key = e.key;
      const frames = this._anim().frames;
      if (key === 'Delete' || key === 'Backspace') {
        e.preventDefault(); e.stopPropagation();      // иначе то же нажатие удалило бы выделенный слой на холсте
        this._deleteFrame(this.index);
      } else if (key === '[' || key === ']') {
        e.preventDefault(); e.stopPropagation();
        this._rangeAction(key === '[' ? 'mark-in' : 'mark-out');
      } else if (key === 'ArrowLeft' || key === 'ArrowRight') {
        e.preventDefault(); e.stopPropagation();
        const d = key === 'ArrowLeft' ? -1 : 1;
        if (e.shiftKey || e.altKey) this._moveFrame(this.index, this.index + d);
        else { this._seek(Math.max(0, Math.min(frames.length - 1, this.index + d))); this._focusFrame(); }
      }
    }

    _dragStart(e) {
      const f = e.target.closest('[data-ba-frame]');
      if (!f) return;
      this.dragFrom = Number(f.dataset.baFrame);
      if (e.dataTransfer) { e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', String(this.dragFrom)); }
    }

    _dropTarget(e) {
      const f = e.target.closest('[data-ba-frame]');
      if (!f) return null;
      const r = f.getBoundingClientRect();
      const i = Number(f.dataset.baFrame);
      return { el: f, index: i, after: e.clientX > r.left + r.width / 2 };
    }

    _dragOver(e) {
      if (this.dragFrom === null) return;
      const t = this._dropTarget(e);
      if (!t) return;
      e.preventDefault();
      if (e.dataTransfer) e.dataTransfer.dropEffect = 'move';
      this._clearDropMarks();
      t.el.classList.add(t.after ? 'drop-after' : 'drop-before');
    }

    _clearDropMarks(e) {
      if (e && e.relatedTarget && this.el.contains(e.relatedTarget)) return;
      this.el.querySelectorAll('.drop-before, .drop-after').forEach((x) => x.classList.remove('drop-before', 'drop-after'));
    }

    _drop(e) {
      if (this.dragFrom === null) return;
      const t = this._dropTarget(e);
      const from = this.dragFrom;
      this.dragFrom = null;
      this._clearDropMarks();
      if (!t) return;
      e.preventDefault();
      let to = t.index + (t.after ? 1 : 0);
      if (from < to) to--;                                   // после изъятия кадра индексы справа сдвигаются
      this._moveFrame(from, Math.max(0, to));
    }

    // Согласованность ресурсов-кадров с историей «Отменить/Повторить» (ресурсы лежат вне истории):
    // кадр, вернувшийся через Ctrl+Z, возвращается с картинкой из корзины; кадр, ушедший через Ctrl+Y/Z и нигде не
    // используемый, убирается из ресурсов, чтобы не раздувать пакет.
    _toTrash(asset) {
      this.trash.set(asset.id, asset);
      while (this.trash.size > 150) this.trash.delete(this.trash.keys().next().value);
    }

    _heal(state) {
      if (!state || !Array.isArray(state.assets)) return;
      const anim = state.background && state.background.anim;
      const used = new Set(anim && Array.isArray(anim.frames) ? anim.frames : []);
      for (const sc of Object.values(state.scenes || {})) {
        const fr = sc && sc.background && sc.background.anim && sc.background.anim.frames;
        if (Array.isArray(fr)) fr.forEach((id) => used.add(id));
      }
      const known = new Set(state.assets.map((a) => a.id));
      for (const id of used) {
        if (!known.has(id) && this.trash.has(id)) { state.assets.push(this.trash.get(id)); this.trash.delete(id); known.add(id); }
      }
      if (anim && Array.isArray(anim.frames) && anim.frames.some((id) => !known.has(id))) {
        state.background.anim = Object.assign({}, anim, { frames: anim.frames.filter((id) => known.has(id)) });
      }
      const orphans = state.assets.filter((a) => a.bgFrame && !used.has(a.id));
      if (orphans.length) {
        orphans.forEach((a) => this._toTrash(a));
        state.assets = state.assets.filter((a) => !(a.bgFrame && !used.has(a.id)));
      }
    }

    _seek(index) {
      const frames = this._anim().frames;
      if (!frames.length) return;
      this.preview.seek(Math.max(0, Math.min(frames.length - 1, Math.round(index))));
    }

    _syncPosition(scrollIntoView) {
      if (this.el.hidden) return;
      const frames = this._anim().frames;
      const range = this.el.querySelector('[data-ba-scrub]');
      if (!range) return;
      this.index = Math.max(0, Math.min(this.index, frames.length - 1));
      range.value = String(this.index);
      const position = this.el.querySelector('[data-ba-position]');
      const time = this.el.querySelector('[data-ba-time]');
      if (position) position.textContent = `${this.index + 1} / ${frames.length}`;
      if (time) time.textContent = `Кадр ${this.index + 1} / ${frames.length}`;
      this.el.querySelectorAll('[data-ba-frame]').forEach((el, i) => el.classList.toggle('active', i === this.index));
      if (scrollIntoView) this.el.querySelector(`[data-ba-frame="${this.index}"]`)?.scrollIntoView({ block: 'nearest', inline: 'nearest' });
    }

    _syncPlayButton(playing) {
      const button = this.el.querySelector('[data-ba-timeline-act="play"]');
      if (button) {
        button.textContent = playing ? '⏸' : '▶';
        button.title = playing ? 'Остановить' : 'Воспроизвести';
      }
    }

    _pointerDown(e) {
      if (!e.target.closest('[data-ba-timeline-grip]') || this.collapsed || e.button !== 0) return;
      e.preventDefault();
      this.dragStart = { y: e.clientY, height: this.height };
      this.el.classList.add('is-resizing');
    }

    _pointerMove(e) {
      if (!this.dragStart) return;
      this.height = Math.max(90, Math.min(320, this.dragStart.height + this.dragStart.y - e.clientY));
      this.el.style.setProperty('--bg-timeline-height', this.height + 'px');
    }

    _pointerUp() {
      if (!this.dragStart) return;
      this.dragStart = null;
      this.el.classList.remove('is-resizing');
      localStorage.setItem('amazface.bgTimeline.height', String(this.height));
    }
  }

  root.BgAnimTimeline = BgAnimTimeline;
})(typeof window !== 'undefined' ? window : globalThis);
