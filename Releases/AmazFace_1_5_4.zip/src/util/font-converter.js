// ---------------------------------------------------------------------------
// font-converter.js
//
// Zepp OS читает в TEXT.font только TrueType (.ttf). Шрифты OpenType с
// CFF-контурами (.otf) и WOFF браузер показывает без проблем, поэтому в
// редакторе всё выглядит правильно, а на часах текст пропадает.
//
// Этот модуль приводит любой загруженный шрифт к TTF:
//   TTF (glyf)        -> без изменений
//   OTF (CFF, Type 2) -> контуры Безье 3-й степени переводятся в квадратичные
//                        (TrueType glyf), собирается новый sfnt
//   WOFF              -> распаковывается, затем как выше
//   WOFF2, CFF2 (variable), TTC -> понятная ошибка (не поддерживается)
//
// API (глобально и через module.exports):
//   FontConverter.toTtf(bytes) -> Promise<{ bytes, converted, from, note }>
//   FontConverter.bytesToDataUrl(bytes, mime)
//   FontConverter.toTtfName(filename)
//   FontConverter.convertFontRecord(font) -> Promise<font> (для старых проектов)
// ---------------------------------------------------------------------------
(function (root) {
  'use strict';

  const TT_VERSION = 0x00010000;
  const KEEP_TABLES = ['cmap', 'head', 'hhea', 'hmtx', 'name', 'OS/2'];

  // ---------- утилиты байтов ----------
  function u32(dv, o) { return dv.getUint32(o, false); }
  function tagAt(dv, o) {
    return String.fromCharCode(dv.getUint8(o), dv.getUint8(o + 1), dv.getUint8(o + 2), dv.getUint8(o + 3));
  }
  function pad4(n) { return (n + 3) & ~3; }
  function checksum(bytes) {
    let sum = 0;
    const len = bytes.length;
    const dv = new DataView(bytes.buffer, bytes.byteOffset, len);
    const full = len & ~3;
    for (let i = 0; i < full; i += 4) sum = (sum + dv.getUint32(i, false)) >>> 0;
    if (len > full) {
      let last = 0;
      for (let i = 0; i < 4; i++) last = (last << 8) | (full + i < len ? bytes[full + i] : 0);
      sum = (sum + (last >>> 0)) >>> 0;
    }
    return sum >>> 0;
  }

  // ---------- чтение sfnt ----------
  function readSfnt(bytes) {
    if (bytes.length < 12) throw new Error('Файл слишком короткий для шрифта.');
    const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.length);
    const version = u32(dv, 0);
    if (version === 0x74746366) throw new Error('Коллекции шрифтов (TTC) не поддерживаются: выберите один шрифт из коллекции.');
    const ok = version === TT_VERSION || version === 0x4f54544f || version === 0x74727565;
    if (!ok) throw new Error('Неизвестный формат шрифта.');
    const n = dv.getUint16(4, false);
    const tables = {};
    for (let i = 0; i < n; i++) {
      const o = 12 + i * 16;
      const tag = tagAt(dv, o);
      const off = u32(dv, o + 8);
      const len = u32(dv, o + 12);
      if (off + len > bytes.length) throw new Error('Повреждённый шрифт: таблица ' + tag + ' выходит за пределы файла.');
      tables[tag] = bytes.subarray(off, off + len);
    }
    return { version, tables };
  }

  function buildSfnt(version, tables) {
    const tags = Object.keys(tables).sort();
    const n = tags.length;
    let es = 0; while ((1 << (es + 1)) <= n) es++;
    const searchRange = (1 << es) * 16;
    let offset = 12 + n * 16;
    const offsets = {};
    for (const t of tags) { offsets[t] = offset; offset += pad4(tables[t].length); }
    const out = new Uint8Array(offset);
    const dv = new DataView(out.buffer);
    dv.setUint32(0, version, false);
    dv.setUint16(4, n, false);
    dv.setUint16(6, searchRange, false);
    dv.setUint16(8, es, false);
    dv.setUint16(10, n * 16 - searchRange, false);
    tags.forEach((t, i) => {
      const o = 12 + i * 16;
      for (let k = 0; k < 4; k++) out[o + k] = t.charCodeAt(k);
      dv.setUint32(o + 4, checksum(tables[t]), false);
      dv.setUint32(o + 8, offsets[t], false);
      dv.setUint32(o + 12, tables[t].length, false);
      out.set(tables[t], offsets[t]);
    });
    // head.checkSumAdjustment
    if (tables.head) {
      const ho = offsets.head;
      dv.setUint32(ho + 8, 0, false);
      const adj = (0xB1B0AFBA - checksum(out)) >>> 0;
      dv.setUint32(ho + 8, adj, false);
    }
    return out;
  }

  // ---------- WOFF ----------
  async function inflate(bytes) {
    if (typeof DecompressionStream === 'undefined') {
      throw new Error('Браузер не умеет распаковывать WOFF. Загрузите шрифт в формате TTF или OTF.');
    }
    const ds = new DecompressionStream('deflate');
    const stream = new Blob([bytes]).stream().pipeThrough(ds);
    return new Uint8Array(await new Response(stream).arrayBuffer());
  }

  async function woffToSfnt(bytes) {
    const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.length);
    const flavor = u32(dv, 4);
    const n = dv.getUint16(12, false);
    const tables = {};
    for (let i = 0; i < n; i++) {
      const o = 44 + i * 20;
      const tag = tagAt(dv, o);
      const off = u32(dv, o + 4);
      const comp = u32(dv, o + 8);
      const orig = u32(dv, o + 12);
      let data = bytes.subarray(off, off + comp);
      if (comp < orig) data = await inflate(data);
      tables[tag] = data;
    }
    return { version: flavor, tables };
  }

  // ---------- CFF ----------
  function readIndex(dv, bytes, pos) {
    const count = dv.getUint16(pos, false);
    if (count === 0) return { items: [], end: pos + 2 };
    const offSize = dv.getUint8(pos + 2);
    const offs = [];
    let p = pos + 3;
    for (let i = 0; i <= count; i++) {
      let v = 0;
      for (let k = 0; k < offSize; k++) v = v * 256 + dv.getUint8(p++);
      offs.push(v);
    }
    const base = p - 1;
    const items = [];
    for (let i = 0; i < count; i++) items.push(bytes.subarray(base + offs[i], base + offs[i + 1]));
    return { items, end: base + offs[count] };
  }

  function parseDict(data) {
    const d = {};
    let ops = [];
    let i = 0;
    while (i < data.length) {
      const b = data[i];
      if (b <= 21) {
        let key = b;
        i++;
        if (b === 12) { key = 1200 + data[i]; i++; }
        d[key] = ops;
        ops = [];
      } else if (b === 28) { ops.push(((data[i + 1] << 8) | data[i + 2]) << 16 >> 16); i += 3; }
      else if (b === 29) { ops.push((data[i + 1] << 24) | (data[i + 2] << 16) | (data[i + 3] << 8) | data[i + 4]); i += 5; }
      else if (b === 30) {
        let s = ''; i++;
        let done = false;
        while (!done && i < data.length) {
          const byte = data[i++];
          for (const nib of [byte >> 4, byte & 15]) {
            if (nib === 15) { done = true; break; }
            s += nib < 10 ? String(nib) : nib === 10 ? '.' : nib === 11 ? 'E' : nib === 12 ? 'E-' : nib === 14 ? '-' : '';
          }
        }
        ops.push(parseFloat(s) || 0);
      }
      else if (b >= 32 && b <= 246) { ops.push(b - 139); i++; }
      else if (b >= 247 && b <= 250) { ops.push((b - 247) * 256 + data[i + 1] + 108); i += 2; }
      else if (b >= 251 && b <= 254) { ops.push(-(b - 251) * 256 - data[i + 1] - 108); i += 2; }
      else i++;
    }
    return d;
  }

  function subrBias(n) { return n < 1240 ? 107 : n < 33900 ? 1131 : 32768; }

  function parsePrivate(dv, bytes, pdict) {
    const info = { defaultWidthX: 0, nominalWidthX: 0, subrs: [] };
    if (!pdict) return info;
    const size = pdict[0], off = pdict[1];
    const priv = parseDict(bytes.subarray(off, off + size));
    if (priv[20]) info.defaultWidthX = priv[20][0];
    if (priv[21]) info.nominalWidthX = priv[21][0];
    if (priv[19]) info.subrs = readIndex(dv, bytes, off + priv[19][0]).items;
    return info;
  }

  function parseCff(bytes) {
    const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.length);
    if (bytes[0] !== 1) throw new Error('Неподдерживаемая версия CFF (variable-шрифты CFF2 не поддерживаются).');
    const hdrSize = bytes[2];
    const nameIdx = readIndex(dv, bytes, hdrSize);
    const topIdx = readIndex(dv, bytes, nameIdx.end);
    const strIdx = readIndex(dv, bytes, topIdx.end);
    const gsubrIdx = readIndex(dv, bytes, strIdx.end);
    const top = parseDict(topIdx.items[0]);
    if (top[1206] && top[1206][0] !== 2) throw new Error('Неподдерживаемый тип чарстрингов CFF.');
    const csOff = top[17] && top[17][0];
    if (!csOff) throw new Error('В CFF нет CharStrings.');
    const charStrings = readIndex(dv, bytes, csOff).items;
    const isCid = !!top[1230];
    let fds = [];
    let fdSelect = null;
    if (isCid) {
      const fdArr = readIndex(dv, bytes, top[1236][0]).items;
      fds = fdArr.map((d) => parsePrivate(dv, bytes, parseDict(d)[18]));
      const p = top[1237][0];
      const fmt = bytes[p];
      fdSelect = new Uint8Array(charStrings.length);
      if (fmt === 0) {
        for (let i = 0; i < charStrings.length; i++) fdSelect[i] = bytes[p + 1 + i];
      } else if (fmt === 3) {
        const nr = dv.getUint16(p + 1, false);
        let q = p + 3;
        for (let r = 0; r < nr; r++) {
          const first = dv.getUint16(q, false), fd = bytes[q + 2];
          const next = dv.getUint16(q + 3, false);
          for (let g = first; g < next; g++) fdSelect[g] = fd;
          q += 3;
        }
      } else throw new Error('Неподдерживаемый FDSelect.');
    } else {
      fds = [parsePrivate(dv, bytes, top[18])];
    }
    return { charStrings, gsubrs: gsubrIdx.items, fds, fdSelect };
  }

  // ---------- интерпретатор Type 2 ----------
  // Возвращает массив контуров; контур — массив сегментов
  // {t:'l'|'c', x, y, x1, y1, x2, y2}, плюс start {x,y}.
  function runCharString(cff, gid) {
    const fd = cff.fds[cff.fdSelect ? cff.fdSelect[gid] : 0] || cff.fds[0];
    const gsubrs = cff.gsubrs, lsubrs = fd.subrs;
    const gb = subrBias(gsubrs.length), lb = subrBias(lsubrs.length);
    const stack = [];
    const contours = [];
    let cur = null;
    let x = 0, y = 0;
    let stems = 0;
    let widthSeen = false;
    let done = false;

    function closeContour() { if (cur && cur.segs.length) contours.push(cur); cur = null; }
    function moveTo(dx, dy) {
      closeContour();
      x += dx; y += dy;
      cur = { start: { x, y }, segs: [] };
    }
    function lineTo(dx, dy) {
      if (!cur) cur = { start: { x, y }, segs: [] };
      x += dx; y += dy;
      cur.segs.push({ t: 'l', x, y });
    }
    function curveTo(dx1, dy1, dx2, dy2, dx3, dy3) {
      if (!cur) cur = { start: { x, y }, segs: [] };
      const x1 = x + dx1, y1 = y + dy1;
      const x2 = x1 + dx2, y2 = y1 + dy2;
      x = x2 + dx3; y = y2 + dy3;
      cur.segs.push({ t: 'c', x1, y1, x2, y2, x, y });
    }
    function takeWidth(expectedEven, nargs) {
      // Первый операторы, очищающий стек, может содержать лишний аргумент — ширину.
      if (widthSeen) return;
      widthSeen = true;
      if (nargs !== undefined) { if (stack.length > nargs) stack.shift(); }
      else if (expectedEven && (stack.length & 1)) stack.shift();
    }

    function exec(code, depth) {
      if (depth > 10) throw new Error('Слишком глубокая вложенность subr.');
      let i = 0;
      while (i < code.length && !done) {
        const b = code[i++];
        if (b >= 32 || b === 28) {
          if (b === 28) { stack.push(((code[i] << 8) | code[i + 1]) << 16 >> 16); i += 2; }
          else if (b <= 246) stack.push(b - 139);
          else if (b <= 250) { stack.push((b - 247) * 256 + code[i++] + 108); }
          else if (b <= 254) { stack.push(-(b - 251) * 256 - code[i++] - 108); }
          else {
            const v = (code[i] << 24) | (code[i + 1] << 16) | (code[i + 2] << 8) | code[i + 3];
            stack.push(v / 65536); i += 4;
          }
          continue;
        }
        switch (b) {
          case 1: case 3: case 18: case 23: // hstem vstem hstemhm vstemhm
            takeWidth(true); stems += stack.length >> 1; stack.length = 0; break;
          case 19: case 20: // hintmask cntrmask
            takeWidth(true); stems += stack.length >> 1; stack.length = 0;
            i += (stems + 7) >> 3; break;
          case 21: // rmoveto
            takeWidth(false, 2); moveTo(stack[0] || 0, stack[1] || 0); stack.length = 0; break;
          case 22: // hmoveto
            takeWidth(false, 1); moveTo(stack[0] || 0, 0); stack.length = 0; break;
          case 4: // vmoveto
            takeWidth(false, 1); moveTo(0, stack[0] || 0); stack.length = 0; break;
          case 5: // rlineto
            for (let k = 0; k + 1 < stack.length; k += 2) lineTo(stack[k], stack[k + 1]);
            stack.length = 0; break;
          case 6: case 7: { // hlineto vlineto
            let horiz = b === 6;
            for (let k = 0; k < stack.length; k++) { if (horiz) lineTo(stack[k], 0); else lineTo(0, stack[k]); horiz = !horiz; }
            stack.length = 0; break;
          }
          case 8: // rrcurveto
            for (let k = 0; k + 5 < stack.length; k += 6) curveTo(stack[k], stack[k + 1], stack[k + 2], stack[k + 3], stack[k + 4], stack[k + 5]);
            stack.length = 0; break;
          case 24: { // rcurveline
            let k = 0;
            for (; k + 7 < stack.length; k += 6) curveTo(stack[k], stack[k + 1], stack[k + 2], stack[k + 3], stack[k + 4], stack[k + 5]);
            lineTo(stack[k], stack[k + 1]); stack.length = 0; break;
          }
          case 25: { // rlinecurve
            let k = 0;
            for (; k + 7 < stack.length; k += 2) lineTo(stack[k], stack[k + 1]);
            curveTo(stack[k], stack[k + 1], stack[k + 2], stack[k + 3], stack[k + 4], stack[k + 5]);
            stack.length = 0; break;
          }
          case 26: { // vvcurveto
            let k = 0, dx1 = 0;
            if (stack.length & 1) dx1 = stack[k++];
            for (; k + 3 < stack.length; k += 4) { curveTo(dx1, stack[k], stack[k + 1], stack[k + 2], 0, stack[k + 3]); dx1 = 0; }
            stack.length = 0; break;
          }
          case 27: { // hhcurveto
            let k = 0, dy1 = 0;
            if (stack.length & 1) dy1 = stack[k++];
            for (; k + 3 < stack.length; k += 4) { curveTo(stack[k], dy1, stack[k + 1], stack[k + 2], stack[k + 3], 0); dy1 = 0; }
            stack.length = 0; break;
          }
          case 30: case 31: { // vhcurveto hvcurveto
            let horiz = b === 31;
            let k = 0;
            while (k + 3 < stack.length) {
              const last = (stack.length - k) === 5 ? stack[k + 4] : 0;
              if (horiz) curveTo(stack[k], 0, stack[k + 1], stack[k + 2], last, stack[k + 3]);
              else curveTo(0, stack[k], stack[k + 1], stack[k + 2], stack[k + 3], last);
              horiz = !horiz; k += 4;
            }
            stack.length = 0; break;
          }
          case 10: { // callsubr
            const idx = stack.pop() + lb;
            if (!lsubrs[idx]) throw new Error('Нет subr ' + idx);
            exec(lsubrs[idx], depth + 1); break;
          }
          case 29: { // callgsubr
            const idx = stack.pop() + gb;
            if (!gsubrs[idx]) throw new Error('Нет gsubr ' + idx);
            exec(gsubrs[idx], depth + 1); break;
          }
          case 11: return; // return
          case 14: // endchar (seac с 4 аргументами не поддерживаем — глиф остаётся пустым)
            closeContour(); done = true; stack.length = 0; return;
          case 12: {
            const b2 = code[i++];
            switch (b2) {
              case 35: { // flex
                curveTo(stack[0], stack[1], stack[2], stack[3], stack[4], stack[5]);
                curveTo(stack[6], stack[7], stack[8], stack[9], stack[10], stack[11]);
                stack.length = 0; break;
              }
              case 34: { // hflex
                const [dx1, dx2, dy2, dx3, dx4, dx5, dx6] = stack;
                curveTo(dx1, 0, dx2, dy2, dx3, 0);
                curveTo(dx4, 0, dx5, -dy2, dx6, 0);
                stack.length = 0; break;
              }
              case 36: { // hflex1
                const [dx1, dy1, dx2, dy2, dx3, dx4, dx5, dy5, dx6] = stack;
                curveTo(dx1, dy1, dx2, dy2, dx3, 0);
                curveTo(dx4, 0, dx5, dy5, dx6, -(dy1 + dy2 + dy5));
                stack.length = 0; break;
              }
              case 37: { // flex1
                const [dx1, dy1, dx2, dy2, dx3, dy3, dx4, dy4, dx5, dy5, d6] = stack;
                const sx = dx1 + dx2 + dx3 + dx4 + dx5, sy = dy1 + dy2 + dy3 + dy4 + dy5;
                curveTo(dx1, dy1, dx2, dy2, dx3, dy3);
                if (Math.abs(sx) > Math.abs(sy)) curveTo(dx4, dy4, dx5, dy5, d6, -sy);
                else curveTo(dx4, dy4, dx5, dy5, -sx, d6);
                stack.length = 0; break;
              }
              default: stack.length = 0; // арифметика и пр. в шрифтах не встречается
            }
            break;
          }
          default: stack.length = 0;
        }
      }
    }

    exec(cff.charStrings[gid], 0);
    closeContour();
    return contours;
  }

  // ---------- кубика -> квадратика ----------
  function cubicPoint(p0, p1, p2, p3, t) {
    const u = 1 - t;
    const a = u * u * u, b = 3 * u * u * t, c = 3 * u * t * t, d = t * t * t;
    return [a * p0[0] + b * p1[0] + c * p2[0] + d * p3[0], a * p0[1] + b * p1[1] + c * p2[1] + d * p3[1]];
  }
  function quadPoint(p0, q, p3, t) {
    const u = 1 - t;
    return [u * u * p0[0] + 2 * u * t * q[0] + t * t * p3[0], u * u * p0[1] + 2 * u * t * q[1] + t * t * p3[1]];
  }

  // Добавляет в out пары [контрольная, конечная] квадратичных сегментов.
  function cubicToQuads(p0, p1, p2, p3, tol, depth, out) {
    const q1 = [p0[0] + 1.5 * (p1[0] - p0[0]), p0[1] + 1.5 * (p1[1] - p0[1])];
    const q2 = [p3[0] + 1.5 * (p2[0] - p3[0]), p3[1] + 1.5 * (p2[1] - p3[1])];
    const q = [(q1[0] + q2[0]) / 2, (q1[1] + q2[1]) / 2];
    let ok = true;
    for (let k = 1; k < 8 && ok; k++) {
      const t = k / 8;
      const a = cubicPoint(p0, p1, p2, p3, t), b = quadPoint(p0, q, p3, t);
      if (Math.hypot(a[0] - b[0], a[1] - b[1]) > tol) ok = false;
    }
    if (ok || depth >= 8) { out.push([q, p3]); return; }
    // де Кастельжо на t = 0.5
    const m = (a, b) => [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
    const p01 = m(p0, p1), p12 = m(p1, p2), p23 = m(p2, p3);
    const p012 = m(p01, p12), p123 = m(p12, p23);
    const mid = m(p012, p123);
    cubicToQuads(p0, p01, p012, mid, tol, depth + 1, out);
    cubicToQuads(mid, p123, p23, p3, tol, depth + 1, out);
  }

  // Контур -> массив точек [{x,y,on}], направление развёрнуто (CFF -> TrueType).
  function contourToPoints(c, tol) {
    const pts = [{ x: c.start.x, y: c.start.y, on: true }];
    let cx = c.start.x, cy = c.start.y;
    for (const s of c.segs) {
      if (s.t === 'l') { pts.push({ x: s.x, y: s.y, on: true }); }
      else {
        const out = [];
        cubicToQuads([cx, cy], [s.x1, s.y1], [s.x2, s.y2], [s.x, s.y], tol, 0, out);
        for (const [q, e] of out) {
          pts.push({ x: q[0], y: q[1], on: false });
          pts.push({ x: e[0], y: e[1], on: true });
        }
      }
      cx = s.x; cy = s.y;
    }
    // Контур замкнут: если последняя точка совпала со стартовой — убираем дубль.
    const first = pts[0], last = pts[pts.length - 1];
    if (pts.length > 1 && last.on && Math.abs(last.x - first.x) < 0.5 && Math.abs(last.y - first.y) < 0.5) pts.pop();
    for (const p of pts) { p.x = Math.round(p.x); p.y = Math.round(p.y); }
    pts.reverse();
    return pts;
  }

  // ---------- запись glyf ----------
  function encodeGlyph(contours) {
    const kept = contours.filter((c) => c.length >= 3);
    if (!kept.length) return { data: new Uint8Array(0), points: 0, contours: 0 };
    const all = [].concat(...kept);
    let xMin = Infinity, yMin = Infinity, xMax = -Infinity, yMax = -Infinity;
    for (const p of all) {
      if (p.x < xMin) xMin = p.x; if (p.x > xMax) xMax = p.x;
      if (p.y < yMin) yMin = p.y; if (p.y > yMax) yMax = p.y;
    }
    const size = 10 + kept.length * 2 + 2 + all.length * 5;
    const buf = new Uint8Array(size);
    const dv = new DataView(buf.buffer);
    let o = 0;
    dv.setInt16(o, kept.length, false); o += 2;
    dv.setInt16(o, xMin, false); dv.setInt16(o + 2, yMin, false);
    dv.setInt16(o + 4, xMax, false); dv.setInt16(o + 6, yMax, false); o += 8;
    let end = -1;
    for (const c of kept) { end += c.length; dv.setUint16(o, end, false); o += 2; }
    dv.setUint16(o, 0, false); o += 2; // instructionLength
    for (const p of all) buf[o++] = p.on ? 1 : 0; // координаты — int16-дельты
    let px = 0;
    for (const p of all) { dv.setInt16(o, p.x - px, false); px = p.x; o += 2; }
    let py = 0;
    for (const p of all) { dv.setInt16(o, p.y - py, false); py = p.y; o += 2; }
    return { data: buf.subarray(0, o), points: all.length, contours: kept.length };
  }

  function cffToTrueType(sfnt) {
    const t = sfnt.tables;
    if (t.CFF2 && !t['CFF ']) throw new Error('Variable-шрифты (CFF2) не поддерживаются. Загрузите статический TTF.');
    const cff = parseCff(t['CFF ']);
    const numGlyphs = new DataView(t.maxp.buffer, t.maxp.byteOffset, t.maxp.length).getUint16(4, false);
    const upm = new DataView(t.head.buffer, t.head.byteOffset, t.head.length).getUint16(18, false) || 1000;
    const tol = Math.max(0.5, upm / 1000 * 0.6);

    const glyphs = [];
    let maxPoints = 0, maxContours = 0;
    for (let g = 0; g < numGlyphs; g++) {
      let enc;
      try {
        const contours = runCharString(cff, g).map((c) => contourToPoints(c, tol));
        enc = encodeGlyph(contours);
      } catch (e) {
        enc = { data: new Uint8Array(0), points: 0, contours: 0 };
      }
      glyphs.push(enc.data);
      if (enc.points > maxPoints) maxPoints = enc.points;
      if (enc.contours > maxContours) maxContours = enc.contours;
    }

    // glyf + loca (длинный формат)
    let total = 0;
    for (const d of glyphs) total += pad4(d.length);
    const glyf = new Uint8Array(total);
    const loca = new Uint8Array((numGlyphs + 1) * 4);
    const ldv = new DataView(loca.buffer);
    let off = 0;
    glyphs.forEach((d, i) => { ldv.setUint32(i * 4, off, false); glyf.set(d, off); off += pad4(d.length); });
    ldv.setUint32(numGlyphs * 4, off, false);

    // maxp 1.0
    const maxp = new Uint8Array(32);
    const mdv = new DataView(maxp.buffer);
    mdv.setUint32(0, 0x00010000, false);
    mdv.setUint16(4, numGlyphs, false);
    mdv.setUint16(6, maxPoints, false);
    mdv.setUint16(8, maxContours, false);
    mdv.setUint16(14, 1, false); // maxZones

    // post 3.0 (без имён глифов)
    const post = new Uint8Array(32);
    if (t.post && t.post.length >= 32) post.set(t.post.subarray(0, 32));
    new DataView(post.buffer).setUint32(0, 0x00030000, false);

    // head: indexToLocFormat = 1, glyphDataFormat = 0
    const head = new Uint8Array(t.head);
    const hdv = new DataView(head.buffer);
    hdv.setInt16(50, 1, false);
    hdv.setInt16(52, 0, false);

    const out = { head, maxp, post, glyf, loca };
    for (const tag of KEEP_TABLES) if (t[tag] && tag !== 'head') out[tag] = t[tag];
    for (const need of ['cmap', 'hhea', 'hmtx']) {
      if (!out[need]) throw new Error('В шрифте нет обязательной таблицы ' + need + '.');
    }
    return buildSfnt(TT_VERSION, out);
  }

  // ---------- публичный API ----------
  function isWoff2(bytes) { return bytes[0] === 0x77 && bytes[1] === 0x4f && bytes[2] === 0x46 && bytes[3] === 0x32; }
  function isWoff(bytes) { return bytes[0] === 0x77 && bytes[1] === 0x4f && bytes[2] === 0x46 && bytes[3] === 0x46; }

  /**
   * Приводит шрифт к TTF.
   * @param {Uint8Array} input
   * @returns {Promise<{bytes:Uint8Array, converted:boolean, from:string, note:string}>}
   */
  async function toTtf(input) {
    const bytes = input instanceof Uint8Array ? input : new Uint8Array(input);
    if (isWoff2(bytes)) {
      throw new Error('WOFF2 не поддерживается конвертером. Загрузите шрифт в формате TTF, OTF или WOFF.');
    }
    let sfnt;
    let from = 'ttf';
    if (isWoff(bytes)) { sfnt = await woffToSfnt(bytes); from = 'woff'; }
    else sfnt = readSfnt(bytes);

    if (sfnt.tables.glyf && sfnt.tables.loca) {
      if (from === 'ttf') return { bytes, converted: false, from, note: '' };
      return { bytes: buildSfnt(TT_VERSION, sfnt.tables), converted: true, from, note: 'WOFF распакован в TTF.' };
    }
    if (sfnt.tables['CFF '] || sfnt.tables.CFF2) {
      const ttf = cffToTrueType(sfnt);
      return { bytes: ttf, converted: true, from: from === 'woff' ? 'woff(cff)' : 'otf', note: 'OTF (CFF) переведён в TTF: Zepp OS читает только TrueType.' };
    }
    throw new Error('Не удалось определить тип контуров шрифта.');
  }

  function bytesToDataUrl(bytes, mime) {
    let bin = '';
    const CH = 0x8000;
    for (let i = 0; i < bytes.length; i += CH) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + CH));
    return 'data:' + (mime || 'font/ttf') + ';base64,' + btoa(bin);
  }

  function dataUrlToBytes(url) {
    const b64 = String(url).split(',')[1] || '';
    const bin = atob(b64);
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }

  function toTtfName(filename) {
    const base = String(filename || 'font').replace(/\.[^.]+$/, '');
    return base + '.ttf';
  }

  /**
   * Миграция записи шрифта из проекта: если шрифт не TTF — конвертирует на месте.
   * Возвращает true, если запись изменена.
   */
  async function convertFontRecord(font) {
    if (!font || !font.dataUrl) return false;
    const res = await toTtf(dataUrlToBytes(font.dataUrl));
    const wantName = toTtfName(font.filename || font.name);
    const needsRename = String(font.ext || '').toLowerCase() !== '.ttf' || font.filename !== wantName;
    if (!res.converted && !needsRename) return false;
    if (res.converted) {
      font.dataUrl = bytesToDataUrl(res.bytes, 'font/ttf');
      font.size = res.bytes.length;
      font.convertedFrom = res.from;
    }
    font.ext = '.ttf';
    font.filename = wantName;
    return true;
  }

  const api = { toTtf, bytesToDataUrl, dataUrlToBytes, toTtfName, convertFontRecord };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.FontConverter = api;
})(typeof window !== 'undefined' ? window : globalThis);
