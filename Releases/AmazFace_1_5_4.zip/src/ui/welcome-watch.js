// src/ui/welcome-watch.js
//
// Большой мокап часов на главной странице: тот же корпус, что и в превью
// (WatchMockup), а в окно экрана рисуется «живой» демо-циферблат (время, дата,
// кольцо секунд). Проект и store не затрагиваются; при ошибке просто ничего не рисуется.

(function () {
  'use strict';
  const canvas = document.getElementById('welcome-watch');
  const screen = document.getElementById('welcome-screen');
  if (!canvas || !window.WatchMockup) return;

  const DAYS = ['ВС', 'ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ'];
  const MONTHS = ['янв', 'фев', 'мар', 'апр', 'мая', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
  const pad = (n) => String(n).padStart(2, '0');

  /** Рисует циферблат в квадрате size×size (0,0). */
  function drawFace(ctx, size, now) {
    const c = size / 2, R = size / 2;
    ctx.save();
    const bg = ctx.createRadialGradient(c, c * 0.8, R * 0.1, c, c, R);
    bg.addColorStop(0, '#1d2347'); bg.addColorStop(1, '#07080f');
    ctx.fillStyle = bg; ctx.fillRect(0, 0, size, size);

    // минутные деления
    for (let i = 0; i < 60; i++) {
      const a = (i / 60) * Math.PI * 2 - Math.PI / 2, big = i % 5 === 0;
      const r1 = R * 0.93, r2 = R * (big ? 0.85 : 0.89);
      ctx.strokeStyle = big ? '#e7e9ef' : 'rgba(154,160,176,.55)';
      ctx.lineWidth = size * (big ? 0.008 : 0.004);
      ctx.beginPath();
      ctx.moveTo(c + Math.cos(a) * r1, c + Math.sin(a) * r1);
      ctx.lineTo(c + Math.cos(a) * r2, c + Math.sin(a) * r2);
      ctx.stroke();
    }

    // кольцо секунд
    const sec = now.getSeconds() + now.getMilliseconds() / 1000;
    const ringR = R * 0.74, start = -Math.PI / 2;
    ctx.lineCap = 'round'; ctx.lineWidth = size * 0.02;
    ctx.strokeStyle = 'rgba(108,141,255,.18)';
    ctx.beginPath(); ctx.arc(c, c, ringR, 0, Math.PI * 2); ctx.stroke();
    ctx.strokeStyle = '#6c8dff';
    ctx.beginPath(); ctx.arc(c, c, ringR, start, start + (sec / 60) * Math.PI * 2); ctx.stroke();

    // время
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillStyle = '#ffffff';
    ctx.font = `700 ${size * 0.25}px -apple-system, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif`;
    ctx.fillText(`${pad(now.getHours())}:${pad(now.getMinutes())}`, c, c - size * 0.02);

    // дата
    ctx.fillStyle = '#4bd6a0';
    ctx.font = `600 ${size * 0.058}px -apple-system, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif`;
    ctx.fillText(`${DAYS[now.getDay()]}  ${now.getDate()} ${MONTHS[now.getMonth()]}`, c, c + size * 0.15);

    // нижняя строка: пульс / шаги (демо-значения)
    ctx.fillStyle = '#9aa0b0';
    ctx.font = `500 ${size * 0.045}px -apple-system, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif`;
    ctx.fillText('♥ 72     👣 8 214', c, c + size * 0.27);
    ctx.restore();
  }

  let tpl = null, face = null, timer = null;

  function render() {
    if (!tpl) return;
    const rect = canvas.getBoundingClientRect();
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const w = Math.max(1, Math.round((rect.width || 400) * dpr));
    const h = Math.max(1, Math.round(w * tpl.height / tpl.width));
    if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; }
    const k = w / tpl.width, { cx, cy, r } = tpl.screen;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, w, h);

    const d = Math.max(1, Math.ceil(r * 2 * k));
    if (!face) face = document.createElement('canvas');
    face.width = d; face.height = d;
    drawFace(face.getContext('2d'), d, new Date());

    ctx.save();
    ctx.beginPath(); ctx.arc(cx * k, cy * k, r * k, 0, Math.PI * 2); ctx.clip();
    ctx.drawImage(face, (cx - r) * k, (cy - r) * k, d, d);
    ctx.restore();
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(tpl.image, 0, 0, w, h);   // корпус поверх экрана
  }

  function tick() {
    if (!screen.hidden && !document.hidden) render();
    timer = setTimeout(tick, 1000 - (Date.now() % 1000) + 5);
  }

  WatchMockup.loadTemplate().then((t) => { tpl = t; render(); tick(); })
    .catch((e) => console.warn('Welcome watch:', e));
  window.addEventListener('resize', () => render());
})();
