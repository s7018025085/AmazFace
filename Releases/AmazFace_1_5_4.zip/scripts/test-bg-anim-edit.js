// Проверка правки кадров анимации фона: удаление, перестановка, Undo-согласованность, подгонка под циферблат.
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const store0 = new Map();
global.window = global; global.addEventListener = () => {}; global.localStorage = { getItem: (k) => store0.get(k) || null, setItem: (k, v) => store0.set(k, v) };
global.BgAnim = require(path.join(root, 'src/anim/bg-anim.js'));
require(path.join(root, 'src/anim/bg-anim-timeline.js'));

let failed = 0;
const check = (n, c, x) => { if (!c) { failed++; console.error('FAIL:', n, x || ''); } else console.log('ok:', n); };

const el = { addEventListener() {}, querySelector() { return null; }, querySelectorAll() { return []; }, classList: { toggle() {}, add() {}, remove() {} }, style: { setProperty() {} }, contains() { return false; }, hidden: false, innerHTML: '' };
function mk(n) {
  const assets = Array.from({ length: n }, (_, i) => ({ id: 'f' + i, name: 'bgf_' + i, dataUrl: 'd' + i, bgFrame: true }));
  assets.push({ id: 'bg0', name: 'bg', dataUrl: 'bg' });
  const st = { mode: 'normal', assets, background: { imageAssetId: 'bg0', anim: { enabled: true, frames: assets.filter((a) => a.bgFrame).map((a) => a.id), fps: 12 } } };
  st.scenes = { normal: { background: st.background } };
  const store = { state: st, commits: 0, commit() { this.commits++; st.scenes.normal = { background: JSON.parse(JSON.stringify(st.background)) }; } };
  let seeked = null;
  const preview = { setOnChange() {}, isPlaying: () => false, stop() {}, seek(i) { seeked = i; return true; } };
  const tl = new BgAnimTimeline(el, { getState: () => st, store, preview });
  return { st, store, tl, seeked: () => seeked };
}
const fr = (m) => m.st.background.anim.frames.join(',');

// перестановка
let m = mk(4);
m.tl._moveFrame(0, 2);
check('перестановка 0→2', fr(m) === 'f1,f2,f0,f3', fr(m));
check('выбранный кадр следует за перенесённым', m.tl.index === 2 && m.seeked() === 2);
check('перестановка не удаляет ресурсы', m.st.assets.filter((a) => a.bgFrame).length === 4);
m.tl._moveFrame(2, 9);
check('выход за границы игнорируется', fr(m) === 'f1,f2,f0,f3');

// удаление
m = mk(4);
m.tl.index = 1; m.tl._deleteFrame(1);
check('удаление кадра 1', fr(m) === 'f0,f2,f3', fr(m));
check('ресурс удалённого кадра убран из проекта', !m.st.assets.some((a) => a.id === 'f1'));
check('статичный фон не тронут', m.st.assets.some((a) => a.id === 'bg0'));
check('после удаления выбран следующий кадр', m.tl.index === 1);
m.tl.index = 2; m.tl._deleteFrame(2);
check('удаление последнего кадра сдвигает выбор назад', m.tl.index === 1 && fr(m) === 'f0,f2');
m.tl._deleteFrame(0);
check('остался 1 кадр → анимация выключается', m.st.background.anim.enabled === false && fr(m) === 'f2');
m.tl._deleteFrame(0);
check('удалён последний кадр → список пуст', fr(m) === '');

// ссылка фона на удаляемый кадр сбрасывается
m = mk(3); m.st.background.imageAssetId = 'f1'; m.tl._deleteFrame(1);
check('imageAssetId на удалённый кадр сброшен', m.st.background.imageAssetId === null);

// Undo: id вернулся в список, ресурс — из корзины
m = mk(3);
const before = JSON.parse(JSON.stringify(m.st.background));
m.tl._deleteFrame(1);
m.st.background = before;                    // как делает store.undo()
m.tl.render();
check('Undo возвращает кадр вместе с картинкой', fr(m) === 'f0,f1,f2' && m.st.assets.some((a) => a.id === 'f1'));
// Redo: id ушёл, ресурс остался → чистится
const after = JSON.parse(JSON.stringify(m.st.background)); after.anim.frames = ['f0', 'f2'];
m.st.background = after; m.st.scenes.normal = { background: after };
m.tl.render();
check('Redo не оставляет кадр-сироту в пакете', !m.st.assets.some((a) => a.id === 'f1'));
// потерянный ресурс без корзины: id выкидывается из списка
m = mk(3); m.st.assets = m.st.assets.filter((a) => a.id !== 'f1'); m.tl.render();
check('кадр без ресурса убирается из списка', fr(m) === 'f0,f2');
// кадры другой сцены не считаются сиротами
m = mk(2); m.st.scenes.night = { background: { anim: { enabled: true, frames: ['n0', 'n1'] } } };
m.st.assets.push({ id: 'n0', bgFrame: true, name: 'n0', dataUrl: 'x' }, { id: 'n1', bgFrame: true, name: 'n1', dataUrl: 'y' });
m.tl.render();
check('кадры другой сцены сохраняются', m.st.assets.some((a) => a.id === 'n0') && m.st.assets.some((a) => a.id === 'n1'));

// подгонка
const R = BgAnim.fitRect;
let r = R(240, 120, 480, 480, { mode: 'cover' });
check('cover: заполняет циферблат', r.dh === 480 && r.dw === 960 && r.dx === -240);
r = R(240, 120, 480, 480, { mode: 'contain' });
check('contain: вписывает целиком по центру', r.dw === 480 && r.dh === 240 && r.dy === 120);
r = R(240, 120, 480, 480, { mode: 'stretch' });
check('stretch: на весь циферблат', r.dw === 480 && r.dh === 480 && r.dx === 0);
r = R(100, 100, 480, 480, { mode: 'contain', scale: 50 });
check('масштаб 50% уменьшает вдвое вокруг центра', r.dw === 240 && r.dx === 120);
r = R(100, 100, 480, 480, { mode: 'contain', scale: 200, x: 10, y: -10 });
check('масштаб 200% и сдвиг', r.dw === 960 && r.dx === -240 + 10 && r.dy === -240 - 10);
const nf = BgAnim.normFit({ mode: 'bad', scale: 9999, x: 'q' });
check('normFit ограничивает значения', nf.mode === 'cover' && nf.scale === 400 && nf.x === 0);
check('normalize хранит fit', BgAnim.normalize({ fit: { scale: 120 } }).fit.scale === 120 && BgAnim.normalize({}).fit.scale === 100);

// выбор куска и обрезка
m = mk(6);
m.tl.index = 1; m.tl._rangeAction('mark-in');
m.tl.index = 3; m.tl._rangeAction('mark-out');
let rb = m.tl._rangeBounds(6);
check('кусок отмечен 1..3', rb && rb.from === 1 && rb.to === 3);
m.tl._rangeAction('trim');
check('обрезка оставляет кадры куска', fr(m) === 'f1,f2,f3', fr(m));
check('ресурсы вне куска убраны', ['f0', 'f4', 'f5'].every((id) => !m.st.assets.some((a) => a.id === id)));
check('после обрезки отметки сброшены', m.tl.range === null && m.tl.index === 0);
m = mk(5); m.tl.index = 2; m.tl._rangeAction('mark-out');
check('только конец: кусок с начала', JSON.stringify(m.tl._rangeBounds(5)) === '{"from":0,"to":2}');
m.tl._rangeAction('trim');
check('обрезка по концу', fr(m) === 'f0,f1,f2');
m = mk(4); m.tl.index = 3; m.tl._rangeAction('mark-in'); m.tl.index = 1; m.tl._rangeAction('mark-out');
check('конец раньше начала → кусок из одного кадра', JSON.stringify(m.tl._rangeBounds(4)) === '{"from":3,"to":3}');
m = mk(4); m.tl._rangeAction('mark-in'); m.tl._rangeAction('trim');
check('выбран весь ролик → обрезать нечего', fr(m) === 'f0,f1,f2,f3');
m.tl._rangeAction('clear-range');
check('✕ снимает отметки', m.tl.range === null);

// GIF целиком: частота подбирается под лимит, длительность цикла сохраняется
let pl = BgAnim.wholeGifPlan(Array(50).fill(100), 12, 60);        // 5 с
check('GIF 5 с при 12 к/с → 60 кадров укладываются', pl.fps === 12 && Math.abs(pl.duration - 5) < 1e-9);
pl = BgAnim.wholeGifPlan(Array(100).fill(100), 12, 60);           // 10 с
check('GIF 10 с → частота снижена до 6 к/с (60 кадров)', pl.fps === 6, pl.fps);
pl = BgAnim.wholeGifPlan(Array(300).fill(100), 12, 60);           // 30 с
check('GIF 30 с → 2 к/с', pl.fps === 2, pl.fps);
pl = BgAnim.wholeGifPlan(Array(10).fill(100), 30, 60);            // 1 с
check('короткий GIF: частота не выше заданной', pl.fps === 30);
const idx = BgAnim.sampleIndices(Array(100).fill(100), 6, 0, 0, 60);
check('whole: выборка покрывает весь ролик без повторов', idx.length === 60 && idx[0] === 0 && idx[59] === 98, idx.length + ' ' + idx[59]);

if (failed) { console.error(`\nbg-anim-edit: ${failed} FAILED`); process.exit(1); }
console.log('\nbg-anim-edit: all checks passed');
