// «Плавающий текст» в AOD: реестр, экспорт, поведение в симуляции рантайма, обратная совместимость.
// Запуск: node scripts/test-aod-float.js
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const fx = require('./export-fixtures.js');

const root = path.resolve(__dirname, '..');
const ex = fx.loadExporter(root);
const { REGISTRY, exportIndexJsDual } = ex;

let passed = 0, failed = 0;
const check = (n, c, x) => { if (c) { passed++; console.log('ok: ' + n); } else { failed++; console.log('FAIL: ' + n + (x ? ' — ' + x : '')); } };

const floatProps = (extra) => Object.assign({ data_source: 'TIME', time_format: 'HH:MM', text_size: 40, color: '#ffffff', float_enabled: true, float_interval: '5', float_step: 10, float_margin: 12 }, extra || {});
const aodText = (props, geo) => fx.mk('aod_t', 'text', floatProps(props), Object.assign({ x: 140, y: 200, w: 200, h: 70 }, geo || {}));
const normalText = fx.mk('n_t', 'text', { data_source: 'TIME', time_format: 'HH:MM', text_size: 40, color: '#ffffff' });

// Мини-рантайм: выполняет index.js, фиксирует виджеты и таймеры, позволяет «прокручивать» время.
function run(code) {
  const widgets = [];
  const timers = [];
  const proxy = new Proxy({}, { get: (_, k) => String(k) });
  const mk = (type, params) => {
    const w = { type, params, pos: { x: params.x, y: params.y }, calls: 0 };
    w.setAlpha = () => {};
    w.setProperty = (k, v) => { if (k === 'MORE' && v && ('x' in v || 'y' in v)) { if ('x' in v) w.pos.x = v.x; if ('y' in v) w.pos.y = v.y; w.calls++; } };
    w.getProperty = () => undefined;
    widgets.push(w);
    return w;
  };
  let built = null;
  const body = code.replace(/^import .*$/gm, '');
  const sandbox = {
    console, Math, Date, JSON,
    createWidget: mk, widget: proxy, align: proxy, text_style: proxy, prop: proxy, show_level: proxy, data_type: proxy,
    system_status: proxy, anim_status: proxy, launchApp: () => {},
    setInterval: (fn, ms) => { timers.push({ fn, ms, id: timers.length + 1 }); return timers.length; },
    clearInterval: (id) => { const t = timers.find((x) => x.id === id); if (t) t.cleared = true; },
    setTimeout: () => 1, clearTimeout: () => {},
    Time: function () { this.getTime = () => 0; this.getHours = () => 10; this.getMinutes = () => 10; this.getSeconds = () => 0; },
    Battery: function () {}, Step: function () {}, Screen: function () { this.getStatus = () => 1; this.onChange = () => {}; this.offChange = () => {}; },
    hmUI: {},
    WatchFace: (o) => { built = o; },
  };
  vm.createContext(sandbox);
  vm.runInContext(body, sandbox, { filename: 'index.js' });
  const self = {};
  built.build.call(self);
  return { widgets, timers, self, built };
}

// 1. Реестр: свойства есть у всех TEXT-компонентов и только у них
{
  const textDefs = Object.values(REGISTRY).filter((d) => d.widgetId === 'TEXT');
  check('реестр: есть TEXT-компоненты', textDefs.length > 5);
  check('реестр: float_* у каждого TEXT-компонента', textDefs.every((d) => ['float_enabled', 'float_interval', 'float_step', 'float_margin'].every((k) => d.properties.some((p) => p.key === k))));
  check('реестр: float_* нет у нетекстовых', Object.values(REGISTRY).filter((d) => d.widgetId !== 'TEXT').every((d) => !d.properties.some((p) => p.key === 'float_enabled')));
  const iv = REGISTRY.text.properties.find((p) => p.key === 'float_interval');
  check('реестр: частоты 1/5/10/30/60 с', JSON.stringify(iv.options.map((o) => o.value)) === JSON.stringify(['1', '5', '10', '30', '60']));
  check('реестр: по умолчанию выключено', REGISTRY.text.properties.find((p) => p.key === 'float_enabled').default === false);
}

// 2. Экспорт: AOD-текст получает дрейф, обычная сцена — нет
let g1, r1;
{
  g1 = exportIndexJsDual(fx.project([normalText], [aodText()]), {}, {});
  check('экспорт: нет ошибок валидации', g1.validation.errors.length === 0, g1.validation.errors.join('; '));
  check('экспорт: код синтаксически корректен', (() => { try { new vm.Script(g1.code.replace(/^import .*$/gm, '')); return true; } catch (e) { return false; } })());
  check('экспорт: setInterval на 5000 мс', /_floatTimers[^;]*setInterval\(aod_w_\d+_aod_t_fl_step, 5000\)/.test(g1.code), (g1.code.match(/_floatTimers.*/) || [''])[0]);
  check('экспорт: таймер импортируется из @zos/timer', /import \{[^}]*\bsetInterval\b[^}]*\bclearInterval\b[^}]*\} from '@zos\/timer'/.test(g1.code));
  check('экспорт: очистка таймеров в onDestroy', /for \(let i = 0; i < this\._floatTimers\.length/.test(g1.code));
  check('экспорт: у обычного текста нет дрейфа', (g1.code.match(/_floatTimers = self/g) || []).length === 1);
  check('экспорт: в коде комментарий с пометкой unverified', /Плавающий текст AOD: шаг 10px, обновление раз в 5 с \(⚠ unverified/.test(g1.code));
  r1 = run(g1.code);
  check('рантайм: создан один таймер', r1.timers.length >= 1 && r1.timers.filter((t) => t.ms === 5000).length === 1);
}

// 3. Поведение: отскок, границы круга, движение
function simulate(props, geo, steps) {
  const g = exportIndexJsDual(fx.project([normalText], [aodText(props, geo)]), {}, {});
  const r = run(g.code);
  const tm = r.timers.find((t) => t.ms === Number(((props && props.float_interval) || '5')) * 1000);
  const w = r.widgets.find((x) => x.params && x.params.x === (geo && geo.x !== undefined ? geo.x : 140) && x.params.y === (geo && geo.y !== undefined ? geo.y : 200) && x.params.w === (geo && geo.w || 200));
  const track = [];
  for (let i = 0; i < steps; i++) { tm.fn(); track.push({ x: w.pos.x, y: w.pos.y }); }
  return { track, w, g };
}
{
  const R = 240 - 12, W = 200, H = 70;
  const { track, w } = simulate({}, {}, 400);
  const inCircle = (p) => [[p.x, p.y], [p.x + W, p.y], [p.x, p.y + H], [p.x + W, p.y + H]].every(([x, y]) => (x - 240) ** 2 + (y - 240) ** 2 <= R * R + 1e-6);
  check('поведение: 400 шагов — рамка всегда внутри круга с отступом', track.every(inCircle), JSON.stringify(track.find((p) => !inCircle(p))));
  check('поведение: текст реально движется', new Set(track.map((p) => p.x + ',' + p.y)).size > 20);
  const xs = track.map((p) => p.x), ys = track.map((p) => p.y);
  check('поведение: есть отскок по X (движение туда и обратно)', xs.some((v, i) => i > 1 && Math.sign(v - xs[i - 1]) !== Math.sign(xs[i - 1] - xs[i - 2]) && v !== xs[i - 1] && xs[i - 1] !== xs[i - 2]));
  check('поведение: есть отскок по Y', ys.some((v, i) => i > 1 && Math.sign(v - ys[i - 1]) !== Math.sign(ys[i - 1] - ys[i - 2]) && v !== ys[i - 1] && ys[i - 1] !== ys[i - 2]));
  check('поведение: позиция целочисленная', track.every((p) => Number.isInteger(p.x) && Number.isInteger(p.y)));
}
{
  // Раз в секунду и раз в минуту дают разные интервалы
  const a = simulate({ float_interval: '1' }, {}, 3), b = simulate({ float_interval: '60' }, {}, 3);
  check('частота: 1 с = 1000 мс', /setInterval\([^)]*, 1000\)/.test(a.g.code));
  check('частота: 60 с = 60000 мс', /setInterval\([^)]*, 60000\)/.test(b.g.code));
  check('частота: 1 с даёт предупреждение о батарее', a.g.validation.warnings.some((w) => /батаре/.test(w)));
  check('частота: 60 с без предупреждения о батарее', !b.g.validation.warnings.some((w) => /батаре/.test(w)));
}
{
  // Старт вне допустимой области: текст возвращается к центру, а не застревает
  const { track } = simulate({}, { x: 0, y: 0, w: 200, h: 70 }, 60);
  const first = track[0], last = track[track.length - 1];
  check('старт вне области: сдвигается к центру', Math.hypot(last.x - 140, last.y - 205) < Math.hypot(first.x - 140, first.y - 205) || last.x > first.x);
  const g = exportIndexJsDual(fx.project([normalText], [aodText({}, { x: 0, y: 0, w: 200, h: 70 })]), {}, {});
  check('старт вне области: предупреждение', g.validation.warnings.some((w) => /стартовая рамка/.test(w)));
}

// 4. Выключено / вне AOD / обратная совместимость
{
  const off = exportIndexJsDual(fx.project([normalText], [aodText({ float_enabled: false })]), {}, {});
  check('выключено: в коде нет дрейфа', !/_floatTimers|_fl_step/.test(off.code));
  const none = exportIndexJsDual(fx.project([normalText], [fx.mk('aod_t', 'text', { data_source: 'TIME', time_format: 'HH:MM', text_size: 40, color: '#fff' })]), {}, {});
  check('без свойства: в коде нет дрейфа', !/_floatTimers|_fl_step/.test(none.code));
  const inNormal = exportIndexJsDual(fx.project([fx.mk('n_t', 'text', floatProps())], []), {}, {});
  check('в обычной сцене: дрейф не создаётся', !/_floatTimers|_fl_step/.test(inNormal.code));
  check('в обычной сцене: предупреждение', inNormal.validation.warnings.some((w) => /вне AOD/.test(w)));
  check('в обычной сцене: нет ошибок', inNormal.validation.errors.length === 0, inNormal.validation.errors.join('; '));
}

// 5. Другие источники данных и квадратный экран
{
  for (const ds of ['NONE', 'DATE', 'STEP', 'BATTERY', 'HUMIDITY']) {
    const g = exportIndexJsDual(fx.project([normalText], [fx.mk('aod_t', 'text', floatProps({ data_source: ds, text: 'Hi' }), { x: 140, y: 200, w: 200, h: 70 })]), {}, {});
    check(`источник ${ds}: есть дрейф и нет ошибок`, /_fl_step/.test(g.code) && g.validation.errors.length === 0, g.validation.errors.join('; '));
    try { run(g.code); check(`источник ${ds}: код исполняется`, true); } catch (e) { check(`источник ${ds}: код исполняется`, false, e.message); }
  }
  const sq = fx.project([normalText], [aodText()]);
  sq.device = { w: 400, h: 300, shape: 'rect' };
  const g = exportIndexJsDual(sq, {}, {});
  check('прямоугольный экран: проверка по границам экрана', /px \+ 200 <= 388 && py \+ 70 <= 288/.test(g.code) || /px >= 12 && py >= 12 && px \+ 200 <= 388/.test(g.code));
}

// 5b. С ночной сценой дрейф в AOD тоже работает
{
  const proj = fx.project([normalText], [aodText()]);
  proj.scenes.night = { components: [fx.mk('nn', 'text', { data_source: 'TIME', time_format: 'HH:MM', text_size: 40, color: '#8899ff' })], background: { color: '#000011' } };
  const g = exportIndexJsDual(proj, {}, {});
  check('с ночной сценой: нет ошибок', g.validation.errors.length === 0, g.validation.errors.join('; '));
  let r = null; try { r = run(g.code); } catch (e) { check('с ночной сценой: код исполняется', false, e.message); }
  if (r) {
    check('с ночной сценой: код исполняется', true);
    check('с ночной сценой: таймер дрейфа создан', r.timers.some((t) => t.ms === 5000));
  }
}

// 6. UI: инспектор показывает группу свойств
{
  const insp = fs.readFileSync(path.join(root, 'src/inspector/inspector.js'), 'utf8');
  check('инспектор: поддерживает group/showIf (общий механизм)', /showIf/.test(insp) && /group/.test(insp));
}

console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed ? 1 : 0);
