// Фикстуры экспорта и загрузчик экспортёра в vm (общие для тестов и генератора эталонов).
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const crypto = require('node:crypto');

function loadExporter(root, extra = []) {
  const ctx = { console, Math, Date, JSON, window: {} };
  vm.createContext(ctx);
  const files = ['src/util/slug.js', 'src/components/registry.js', ...extra.filter((f) => fs.existsSync(path.join(root, f))), 'src/exporter/index-js-exporter.js'];
  for (const rel of files) {
    const src = fs.readFileSync(path.join(root, rel), 'utf8');
    vm.runInContext(src + '\n;globalThis.__ex = Object.assign(globalThis.__ex || {}, {' +
      ['REGISTRY', 'exportIndexJs', 'exportIndexJsDual', 'hourlyServiceSource', 'projectUsesHourlyVibration'].filter((n) => src.includes(`const ${n}`) || src.includes(`function ${n}`)).join(',') + '});', ctx, { filename: rel });
  }
  return ctx.__ex;
}

const mk = (id, defId, props, geo) => Object.assign({ id, name: id, defId, x: 40, y: 60, w: 300, h: 80, props }, geo || {});
function project(comps, aod) {
  return { device: { w: 480, h: 480 }, components: comps, assets: [], fonts: [], background: { color: '#101010' }, app: { appId: 1234567 },
    scenes: { normal: { components: comps, background: { color: '#101010' } }, aod: { components: aod || [], background: { color: '#000000' } } } };
}
// Набор проектов БЕЗ анимации текста: их экспорт не должен меняться ни на байт.
const FIXTURES = {
  arc_static: () => project([mk('a1', 'arc', { start_angle: 0, end_angle: 270 }, { w: 200, h: 200 })]),
  arc_anim: () => project([mk('a1', 'arc', { data_source: 'BATTERY', anim_enabled: true, anim_type: 'FADE_FILL', anim_duration: 900, anim_replay: true, anim_replay_raise: true, track_enabled: true }, { w: 200, h: 200 })]),
  arc_grad: () => project([mk('a1', 'arc', { data_source: 'STEP', gradient_enabled: true, color2: '#ff3366', anim_enabled: true }, { w: 200, h: 200 })]),
  text_static: () => project([mk('t1', 'text', { data_source: 'NONE', text: 'Привет', text_size: 40, color: '#ffffff', align_h: 'CENTER_H', align_v: 'CENTER_V' })]),
  text_time: () => project([mk('t1', 'text', { data_source: 'TIME', time_format: 'HH:MM', text_size: 60, color: '#ffd35a', align_h: 'CENTER_H', align_v: 'CENTER_V' })]),
  text_steps: () => project([mk('t1', 'text', { data_source: 'STEP', suffix: ' шагов', text_size: 30, color: '#ffffff', align_h: 'LEFT', align_v: 'CENTER_V' })]),
  text_native: () => project([mk('t1', 'text', { data_source: 'HUMIDITY', text_size: 30, color: '#ffffff' })]),
  presets: () => project([mk('b1', 'battery', { text_size: 28, color: '#fff' }), mk('s1', 'steps', { text_size: 28, color: '#fff' }), mk('h1', 'time_hm', { text_size: 70, color: '#fff' }), mk('f1', 'fill_rect', { color: '#334455' }), mk('c1', 'circle', { color: '#aa3300' }, { w: 100, h: 100 })]),
  mixed_aod: () => project([mk('t1', 'text', { data_source: 'TIME', time_format: 'HH:MM', text_size: 60, color: '#fff' }), mk('a1', 'arc', { data_source: 'BATTERY', anim_enabled: true }, { w: 200, h: 200 })], [mk('t2', 'text', { data_source: 'TIME', time_format: 'HH:MM', text_size: 60, color: '#888' })]),
};
const sha = (s) => crypto.createHash('sha256').update(s).digest('hex').slice(0, 16);
function hashAll(ex) {
  const out = {};
  for (const [name, fn] of Object.entries(FIXTURES)) {
    const p = fn();
    out[name + ':single'] = sha(ex.exportIndexJs(p, {}, {}, {}).code);
    out[name + ':dual'] = sha(ex.exportIndexJsDual(p, {}, {}, {}).code);
  }
  return out;
}
module.exports = { loadExporter, FIXTURES, mk, project, hashAll, sha };
