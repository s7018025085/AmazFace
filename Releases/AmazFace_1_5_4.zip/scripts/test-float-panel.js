// Панель настроек на часах: пункт «Плавающий AOD» (вкл./выкл., частота, шаг, отступ), сохранение в hmFS.
// Запуск: node scripts/test-float-panel.js
const vm = require('node:vm');
const fx = require('./export-fixtures.js');

const ex = fx.loadExporter(process.cwd());
const { exportIndexJsDual } = ex;

let passed = 0, failed = 0;
const check = (n, c, x) => { if (c) { passed++; console.log('ok: ' + n); } else { failed++; console.log('FAIL: ' + n + (x ? ' — ' + x : '')); } };

function makeProject({ night = false, panel = true, floatOn = true } = {}) {
  const dial = fx.mk('dial', 'fill_rect', { color: '#334455' });
  if (panel) dial.tapZones = [{ id: 'z1', name: 'Настройки', x: 0, y: 0, w: 100, h: 60, visible: true, props: { tap_action: 'SETTINGS' } }];
  const aodTxt = fx.mk('aod_time', 'text', { data_source: 'TIME', time_format: 'HH:MM', text_size: 40, color: '#888888', float_enabled: floatOn, float_interval: '5', float_step: 6, float_margin: 12 }, { x: 140, y: 200, w: 200, h: 70 });
  const p = fx.project([dial], [aodTxt]);
  p.app.appId = 1234567;
  p.meta = { name: 'Float panel test', createdAt: 123456789 };
  if (night) p.scenes.night = { components: [fx.mk('nn', 'text', { data_source: 'TIME', time_format: 'HH:MM', text_size: 40, color: '#8899ff' })], background: { color: '#000011' } };
  return p;
}

function runtime(code, files) {
  const widgets = [];
  const timers = [];
  const proxy = new Proxy({}, { get: (_, k) => String(k) });
  const fsState = { failWrite: false };
  // @zos/fs: readFileSync возвращает строку или undefined, writeFileSync пишет строку в /data.
  const readFileSync = ({ path }) => files.has(path) ? files.get(path) : undefined;
  const writeFileSync = ({ path, data }) => { if (fsState.failWrite) throw new Error('write failed'); files.set(path, String(data)); };
  const sandbox = {
    console, Math, Date, JSON, Uint8Array, ArrayBuffer, readFileSync, writeFileSync,
    createWidget: (type, params) => {
      const w = { type, params: Object.assign({}, params), visible: true, alpha: null };
      w.setAlpha = (a) => { w.alpha = a; };
      w.setProperty = (k, v) => { if (k === 'VISIBLE') w.visible = !!v; else if (k === 'MORE') Object.assign(w.params, v); };
      w.getProperty = () => undefined;
      widgets.push(w);
      return w;
    },
    widget: proxy, align: proxy, text_style: proxy, prop: proxy, show_level: proxy, data_type: proxy, system_status: proxy, anim_status: proxy,
    launchApp: () => {},
    setInterval: (fn, delay) => { const t = { fn, delay, cleared: false }; timers.push(t); return timers.length; },
    clearInterval: (id) => { if (timers[id - 1]) timers[id - 1].cleared = true; },
    setTimeout: () => 1, clearTimeout: () => {},
    Time: function () { this.getTime = () => 0; this.getHours = () => 10; this.getMinutes = () => 10; this.getSeconds = () => 0; },
    Battery: function () {}, Step: function () {}, Screen: function () { this.getStatus = () => 1; this.onChange = () => {}; this.offChange = () => {}; },
    WatchFace: (d) => { sandbox.__wf = d; },
  };
  vm.createContext(sandbox);
  vm.runInContext(code.replace(/^import .*$/gm, ''), sandbox, { filename: 'index.js' });
  const self = {};
  sandbox.__wf.build.call(self);
  const R = { widgets, timers, self, files, sandbox, fsState };
  R.active = () => timers.filter((t) => !t.cleared);
  // Таймеры именно дрейфа (а не обновления времени): их хэндлы лежат в self._floatTimers.
  R.floatActive = () => (self._floatTimers || []).map((id) => timers[id - 1]).filter((t) => t && !t.cleared);
  R.visible = (text) => widgets.find((w) => w.visible && w.params.text === text);
  R.visibleText = () => widgets.filter((w) => w.visible && typeof w.params.text === 'string' && w.params.text).map((w) => w.params.text);
  R.click = (text) => { const w = R.visible(text); if (!w) throw new Error('кнопка не найдена или не видна: ' + text + ' | видны: ' + R.visibleText().join(' / ')); w.params.click_func(); };
  R.plus = (n) => widgets.filter((w) => w.visible && w.params.text === '+').sort((a, b) => a.params.y - b.params.y)[n];
  R.minus = (n) => widgets.filter((w) => w.visible && w.params.text === '−').sort((a, b) => a.params.y - b.params.y)[n];
  R.openSettings = () => widgets.find((w) => w.alpha === 0 && w.params.w === 100 && typeof w.params.click_func === 'function').params.click_func();
  R.floatWidget = () => widgets.find((w) => w.params.x === 140 && w.params.y !== undefined && w.params.w === 200 && w.params.h === 70 && w.type);
  return R;
}
const readFile = (files, path) => JSON.parse(files.get(path));

for (const night of [false, true]) {
  const tag = night ? 'с ночной сценой' : 'без ночной сцены';
  const gen = exportIndexJsDual(makeProject({ night }), {}, {});
  check(`${tag}: нет ошибок экспорта`, gen.validation.errors.length === 0, gen.validation.errors.join('; '));
  check(`${tag}: в коде есть страница настроек и файл`, /__afFlRefresh/.test(gen.code) && /amazface_float_1234567_123456789\.json/.test(gen.code));
  check(`${tag}: виджет регистрируется в общем таймере`, /__afFloatRegister\(aod_w_\d+_aod_time_fl_step/.test(gen.code) && !/_floatTimers\.push\(setInterval\(aod_/.test(gen.code));
  check(`${tag}: очистка таймеров при выходе`, /this\._floatTimers\.length/.test(gen.code));

  const files = new Map();
  const rt = runtime(gen.code, files);
  check(`${tag}: старт — включено, частота 5 с (из свойств компонента)`, rt.floatActive().length === 1 && rt.floatActive()[0].delay === 5000);

  rt.openSettings();
  check(`${tag}: в меню настроек есть пункт «Плавающий AOD»`, !!rt.visible('Плавающий AOD  ›'), rt.visibleText().join(' / '));
  rt.click('Плавающий AOD  ›');
  check(`${tag}: страница показывает ВКЛ`, !!rt.visible('Плавающий AOD: ВКЛ'), rt.visibleText().join(' / '));
  check(`${tag}: страница показывает частоту, шаг, отступ`, !!rt.visible('Частота 5 с') && !!rt.visible('Шаг 6 px') && !!rt.visible('Отступ 12 px'), rt.visibleText().join(' / '));
  check(`${tag}: в меню пункт скрыт, когда открыта страница`, !rt.visible('Плавающий AOD  ›'));

  // Частота
  rt.plus(0).params.click_func();
  check(`${tag}: «+» частоты → 10 с, таймер перезапущен`, !!rt.visible('Частота 10 с') && rt.floatActive().length === 1 && rt.floatActive()[0].delay === 10000);
  rt.plus(0).params.click_func(); rt.plus(0).params.click_func(); rt.plus(0).params.click_func();
  check(`${tag}: максимум частоты — 1 мин`, !!rt.visible('Частота 1 мин') && rt.floatActive().some((t) => t.delay === 60000));
  rt.plus(0).params.click_func();
  check(`${tag}: дальше максимума не растёт`, !!rt.visible('Частота 1 мин'));
  for (let i = 0; i < 6; i++) rt.minus(0).params.click_func();
  check(`${tag}: минимум частоты — 1 с`, !!rt.visible('Частота 1 с') && rt.floatActive().some((t) => t.delay === 1000));

  // Шаг и отступ
  rt.plus(1).params.click_func();
  check(`${tag}: «+» шага: 6 → 8 px`, !!rt.visible('Шаг 8 px'), rt.visibleText().join(' / '));
  rt.minus(2).params.click_func();
  check(`${tag}: «−» отступа: 12 → 6 px`, !!rt.visible('Отступ 6 px'), rt.visibleText().join(' / '));

  // Движение использует новые значения
  const fw = rt.floatWidget();
  const before = { x: fw.params.x, y: fw.params.y };
  rt.floatActive()[0].fn();
  check(`${tag}: тик двигает текст на новый шаг (8 px по X)`, fw.params.x - before.x === 8 && fw.params.y - before.y === 5, JSON.stringify({ before, now: { x: fw.params.x, y: fw.params.y } }));

  // Файл
  const path = [...files.keys()].find((k) => /amazface_float_/.test(k));
  const saved = path ? readFile(files, path) : null;
  check(`${tag}: настройки записаны в файл`, !!saved && saved.on === true && saved.iv === 1 && saved.st === 8 && saved.mg === 6, JSON.stringify(saved));

  // Выключение
  rt.click('Плавающий AOD: ВКЛ');
  check(`${tag}: выключение: надпись ВЫКЛ`, !!rt.visible('Плавающий AOD: ВЫКЛ'));
  check(`${tag}: выключение: таймеров дрейфа нет`, rt.floatActive().length === 0, JSON.stringify(rt.floatActive().map((t) => t.delay)));
  check(`${tag}: выключение: текст вернулся на место`, fw.params.x === 140 && fw.params.y === 200, JSON.stringify({ x: fw.params.x, y: fw.params.y }));
  check(`${tag}: выключение записано в файл`, readFile(files, path).on === false);

  // Назад
  rt.click('‹ Назад');
  check(`${tag}: «Назад» возвращает в меню`, !!rt.visible('Плавающий AOD  ›') && !rt.visible('Плавающий AOD: ВЫКЛ'));

  // Перезапуск циферблата: настройки подхватываются из файла
  const rt2 = runtime(gen.code, files);
  check(`${tag}: после перезапуска дрейф выключен (из файла)`, rt2.floatActive().length === 0);
  rt2.openSettings(); rt2.click('Плавающий AOD  ›');
  check(`${tag}: после перезапуска значения восстановлены`, !!rt2.visible('Плавающий AOD: ВЫКЛ') && !!rt2.visible('Частота 1 с') && !!rt2.visible('Шаг 8 px') && !!rt2.visible('Отступ 6 px'), rt2.visibleText().join(' / '));
  rt2.click('Плавающий AOD: ВЫКЛ');
  check(`${tag}: включение после перезапуска запускает таймер 1 с`, rt2.floatActive().some((t) => t.delay === 1000));

  // Повреждённый файл не ломает запуск
  const bad = new Map([[path, '{oops']]);
  const rt3 = runtime(gen.code, bad);
  check(`${tag}: битый файл настроек → значения по умолчанию`, rt3.floatActive().some((t) => t.delay === 5000));
}

// Два отдельных запуска кода (как на часах): «живой» AOD и панель настроек, общий файл.
{
  const gen = exportIndexJsDual(makeProject({}), {}, {});
  const files = new Map();
  const aod = runtime(gen.code, files);          // AOD-запуск уже работает
  const panel = runtime(gen.code, files);        // запуск, в котором пользователь открывает настройки
  const fw = aod.floatWidget();
  check('два запуска: AOD стартует со значениями по умолчанию (5 с)', aod.floatActive().length === 1 && aod.floatActive()[0].delay === 5000);

  panel.openSettings(); panel.click('Плавающий AOD  ›');
  panel.plus(1).params.click_func(); panel.plus(1).params.click_func();   // шаг 6 → 8 → 10
  check('два запуска: панель показывает шаг 10', !!panel.visible('Шаг 10 px'));
  const x0 = fw.params.x;
  aod.floatActive()[0].fn();
  check('два запуска: AOD-запуск подхватил шаг 10 из файла (сдвиг 10 px, а не 6)', fw.params.x - x0 === 10, 'сдвиг ' + (fw.params.x - x0));

  panel.plus(0).params.click_func();    // частота 5 → 10 с
  aod.floatActive()[0].fn();
  check('два запуска: AOD-запуск перезапустил таймер на 10 с', aod.floatActive().length === 1 && aod.floatActive()[0].delay === 10000, JSON.stringify(aod.floatActive().map((t) => t.delay)));

  fw.params.x = 200; fw.params.y = 230;
  panel.click('Плавающий AOD: ВКЛ');
  aod.floatActive()[0] && aod.floatActive()[0].fn();
  check('два запуска: «ВЫКЛ» в панели останавливает AOD-запуск', aod.floatActive().length === 0, JSON.stringify(aod.floatActive().map((t) => t.delay)));
  check('два запуска: «ВЫКЛ» возвращает текст на место', fw.params.x === 140 && fw.params.y === 200, JSON.stringify({ x: fw.params.x, y: fw.params.y }));

  panel.click('Плавающий AOD: ВЫКЛ');
  check('два запуска: «ВКЛ» снова запускает таймер у панели', panel.floatActive().length === 1);
  const aod2 = runtime(gen.code, files);   // AOD-запуск создаётся позже, чем изменили настройки
  check('два запуска: новый AOD-запуск читает настройки (10 с)', aod2.floatActive().length === 1 && aod2.floatActive()[0].delay === 10000);
  const fw2 = aod2.floatWidget();
  aod2.floatActive()[0].fn();
  check('два запуска: новый AOD-запуск двигает на шаг 10', Math.abs(fw2.params.x - 140) === 10, 'x=' + fw2.params.x);
}

// Ошибка записи файла видна в панели
{
  const gen = exportIndexJsDual(makeProject({}), {}, {});
  const rt = runtime(gen.code, new Map());
  rt.fsState.failWrite = true;
  rt.openSettings(); rt.click('Плавающий AOD  ›');
  rt.plus(1).params.click_func();
  check('ошибка записи: в панели видно «ошибка записи»', !!rt.visible('‹ Назад · ошибка записи'), rt.visibleText().join(' / '));
  check('ошибка записи: значение всё равно применено в этом запуске', !!rt.visible('Шаг 8 px'));
  rt.fsState.failWrite = false;
  rt.plus(1).params.click_func();
  check('после исправления: ошибка исчезает', !!rt.visible('‹ Назад'));
}

// Шапка панели: крупная кнопка «Закрыть», отделённая от шестерёнки, внутри круглого экрана
for (const [W, H] of [[480, 480], [454, 454], [466, 466]]) {
  const p = makeProject({ night: true });
  p.device = { w: W, h: H, shape: 'round' };
  const gen = exportIndexJsDual(p, {}, {});
  const rt = runtime(gen.code, new Map());
  rt.openSettings();
  const close = rt.widgets.find((w) => w.visible && /Закрыть/.test(w.params.text || ''));
  const gear = rt.widgets.find((w) => w.visible && w.params.text === '⚙');
  const tag = `${W}x${H}`;
  check(`шапка ${tag}: кнопка «Закрыть» и шестерёнка есть`, !!close && !!gear);
  if (close && gear) {
    const sc = Math.min(W, H) / 480;
    check(`шапка ${tag}: кнопка закрытия крупная`, close.params.w >= 100 * sc && close.params.h >= 36 * sc, JSON.stringify({ w: close.params.w, h: close.params.h }));
    check(`шапка ${tag}: между шестерёнкой и закрытием зазор`, close.params.x - (gear.params.x + gear.params.w) >= 8 * sc, String(close.params.x - (gear.params.x + gear.params.w)));
    const inside = (b) => [[b.x, b.y], [b.x + b.w, b.y], [b.x, b.y + b.h], [b.x + b.w, b.y + b.h]].every(([x, y]) => (x - W / 2) ** 2 + (y - H / 2) ** 2 <= (Math.min(W, H) / 2) ** 2);
    check(`шапка ${tag}: обе кнопки целиком внутри круга`, inside(close.params) && inside(gear.params));
    close.params.click_func();
    check(`шапка ${tag}: «Закрыть» закрывает панель`, !rt.widgets.some((w) => w.visible && /Закрыть/.test(w.params.text || '')));
  }
  rt.openSettings(); rt.click('Плавающий AOD  ›');
  const off = rt.widgets.filter((w) => w.visible && w.params.w > 1 && typeof w.params.text === 'string' && w.params.text && !((w.params.x >= 0) && (w.params.y >= 0) && (w.params.x + w.params.w <= W) && (w.params.y + w.params.h <= H)));
  check(`страница «Плавающий AOD» ${tag}: все кнопки в пределах экрана`, off.length === 0, JSON.stringify(off.map((w) => w.params.text)));
}

// Без панели настроек и без плавающих текстов — прежнее поведение
{
  const noPanel = exportIndexJsDual(makeProject({ panel: false }), {}, {});
  check('без панели: настройки не добавляются, дрейф зашит в код', !/__afFlRefresh|__afFloatCur/.test(noPanel.code) && /\.push\(setInterval\(aod_w_/.test(noPanel.code));
  const noFloat = exportIndexJsDual(makeProject({ floatOn: false }), {}, {});
  check('панель без плавающих текстов: пункта нет', !/__afFlRefresh|__afFloatCur/.test(noFloat.code));
  let ran = true; try { runtime(noFloat.code, new Map()); } catch (e) { ran = false; }
  check('панель без плавающих текстов: код исполняется', ran);
  let ran2 = true; try { runtime(noPanel.code, new Map()); } catch (e) { ran2 = false; }
  check('без панели: код исполняется', ran2);
}

console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed ? 1 : 0);
