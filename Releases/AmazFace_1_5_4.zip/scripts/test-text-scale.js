// Ширина / высота шрифта: поля в инспекторе и поведение при экспорте.
// Запуск: node scripts/test-text-scale.js
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert');

const root = path.resolve(__dirname, '..');
const ctx = { console, Math, Date, JSON, window: {}, document: {}, WatchfacePreviewRenderer: { arcIsActive: () => false } };
vm.createContext(ctx);
for (const rel of ['src/util/slug.js', 'src/components/registry.js', 'src/exporter/index-js-exporter.js', 'src/exporter/project-exporter.js']) {
  vm.runInContext(fs.readFileSync(path.join(root, rel), 'utf8'), ctx, { filename: rel });
}
vm.runInContext(';globalThis.__t = { REGISTRY, premiumTextNeedsRaster, premiumTextPad, textHasScale, textScaleIsBakeable };', ctx);
const t = ctx.__t;
const text = (props, extra) => Object.assign({ id: 'c1', defId: 'text', x: 0, y: 0, w: 200, h: 50, props }, extra || {});

// поля есть у обычного текста, хранятся коэффициентом
const props = t.REGISTRY.text.properties;
const sx = props.find((p) => p.key === 'scale_x'), sy = props.find((p) => p.key === 'scale_y');
assert.ok(sx && sy && sx.percent && sy.percent, 'у текста есть scale_x/scale_y в процентах');
assert.strictEqual(sx.default, 1);
assert.ok(sx.label.includes('Ширина') && sy.label.includes('Высота'));

// 100% — нативный TEXT, ничего не запекается
assert.strictEqual(t.premiumTextNeedsRaster(text({ data_source: 'NONE', scale_x: 1, scale_y: 1 })), false);
assert.strictEqual(t.premiumTextNeedsRaster(text({ data_source: 'NONE' })), false);
// статичный текст с масштабом — запекается в PNG
assert.strictEqual(t.premiumTextNeedsRaster(text({ data_source: 'NONE', scale_x: 1.5 })), true);
assert.strictEqual(t.premiumTextNeedsRaster(text({ data_source: 'NONE', scale_y: 0.6 })), true);
// живой текст запекать нельзя (PNG заморозит время)
assert.strictEqual(t.premiumTextNeedsRaster(text({ data_source: 'TIME', scale_x: 1.5 })), false);
assert.strictEqual(t.textHasScale(text({ data_source: 'TIME', scale_x: 1.5 })), true);
// запас холста растёт с масштабом, иначе растянутый текст обрежется
const base = t.premiumTextPad(text({ scale_x: 1 }));
assert.ok(t.premiumTextPad(text({ scale_x: 2 })) >= 18 + 200, 'запас под растяжение по ширине (w=200)');
assert.ok(t.premiumTextPad(text({ scale_y: 3 })) >= 18 + 100, 'запас под растяжение по высоте (h=50)');
assert.strictEqual(t.premiumTextPad(text({ scale_x: 0.5 })), base, 'сжатие запаса не требует');

console.log('Text scale tests passed.');
