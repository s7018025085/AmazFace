// Проверки общих форматтеров редакторского предпросмотра.
// Запуск: node scripts/test-preview-formats.js
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.resolve(__dirname, '..');
const ctx = {
  console, Map, Promise, Math, Number, String, Object, Array, JSON, Set,
  Image: function () {},
  document: { createElement: () => ({ getContext: () => null }) },
};
ctx.window = ctx;
ctx.globalThis = ctx;
vm.createContext(ctx);
for (const file of [
  'src/components/registry.js',
  'src/editor/canvas.js',
  'src/preview/renderer.js',
]) {
  vm.runInContext(fs.readFileSync(path.join(root, file), 'utf8'), ctx, { filename: file });
}

const registry = vm.runInContext('REGISTRY', ctx);
const previewText = vm.runInContext('componentPreviewText', ctx);
const textFor = ctx.WatchfacePreviewRenderer.textFor;
const handAngle = ctx.WatchfacePreviewRenderer.timePointerAngle;
const fitWeatherIcon = ctx.WatchfacePreviewRenderer.fitWeatherIconRect;
const at = new Date(2026, 8, 18, 22, 9, 36);
const text = (dataSource, props = {}) => ({
  id: 'text', defId: 'text', props: { data_source: dataSource, ...props },
});

assert.equal(previewText(text('AMPM'), registry.text, at), 'PM');
assert.equal(previewText(text('AMPM', { ampm_case: 'am/pm' }), registry.text, at), 'pm');
assert.equal(textFor(text('AMPM', { ampm_case: 'am/pm' }), registry.text, true, false), 'am');
assert.equal(previewText(text('TIME', { time_format: 'hh:MM:SS' }), registry.text, at), '10:09:36');
assert.equal(previewText(text('TIME', { time_format: 'HH:MM:SS' }), registry.text, at), '22:09:36');
assert.equal(previewText(text('DATE', { date_format: 'DD MMMM', date_locale: 'RU' }), registry.text, at), '18 сентября');
assert.equal(previewText(text('WEEKDAY', { weekday_format: 'EEEE', weekday_locale: 'RU' }), registry.text, at), 'ПЯТНИЦА');

const exportNow = new Date(2025, 0, 2, 15, 30, 20, 500);
assert.equal(textFor(text('DATE', { date_format: 'DD.MM.YYYY' }), registry.text, true, false), '18.09.2026', 'regular preview keeps its fixed date');
assert.equal(textFor(text('DATE', { date_format: 'DD.MM.YYYY' }), registry.text, true, false, exportNow), '02.01.2025', 'export preview can use the current date');
assert.equal(textFor(text('WEEKDAY', { weekday_format: 'EEEE', weekday_locale: 'EN' }), registry.text, true, false, exportNow), 'THURSDAY', 'weekday follows the export date');
assert.equal(textFor(text('TIME', { time_format: 'HH:MM' }), registry.text, true, false, exportNow), '10:09', 'export date override leaves the preview clock fixed');
assert.equal(textFor(text('DAY', { day_leading_zero: true }), registry.date_day, true, false, exportNow), '02', 'day component uses the export date');
assert.equal(textFor(text('MONTH', { month_format: 'MMMM', month_locale: 'EN' }), registry.date_month, true, false, exportNow), 'January', 'month component uses the export date');
assert.equal(textFor(text('YEAR', { year_format: 'YY' }), registry.date_year, true, false, exportNow), '25', 'year component uses the export date');
assert.equal(textFor({ id: 'date', defId: 'digital_display', props: { data_source: 'DATE', format: 'YYYY-MM-DD' } }, registry.digital_display, true, false, exportNow), '2025-01-02', 'date digital display uses the export date');
assert.ok(Math.abs(handAngle('time_pointer_hour', exportNow) - 105.1666667) < 0.001, 'hour hand includes minutes and seconds');
assert.equal(handAngle('time_pointer_minute', exportNow), 182, 'minute hand follows current seconds');
assert.equal(handAngle('time_pointer_second', exportNow), 120, 'step second hand follows current seconds');
assert.equal(handAngle('time_pointer_second', exportNow, 'SMOOTH'), 123, 'smooth second hand includes milliseconds');
assert.equal(handAngle('time_pointer_second', exportNow, 'SMOOTH', 15), 120, 'smooth second hand respects its configured step');
assert.deepEqual({ ...fitWeatherIcon({ x: 100, y: 40, w: 80, h: 80 }, { width: 24, height: 32 }) }, { x: 128, y: 64, w: 24, h: 32 }, 'small weather icon stays native-size and centered');
assert.deepEqual({ ...fitWeatherIcon({ x: 100, y: 40, w: 64, h: 64 }, { width: 128, height: 64 }) }, { x: 100, y: 56, w: 64, h: 32 }, 'large weather icon scales down proportionally');

const month = { id: 'date_month', defId: 'date_month', props: { month_format: 'M' } };
assert.equal(previewText(month, registry.date_month, at), '9');
const year = { id: 'date_year', defId: 'date_year', props: { year_format: 'YY' } };
assert.equal(previewText(year, registry.date_year, at), '26');

const digitalHour = (format) => ({
  id: 'digital_hour', defId: 'digital_display',
  props: { data_source: 'HOUR', format },
});
assert.ok(registry.digital_display.properties.find((p) => p.key === 'format').options.includes('hh'));
assert.equal(previewText(digitalHour('HH'), registry.digital_display, at), '22');
assert.equal(previewText(digitalHour('hh'), registry.digital_display, at), '10');

const fx = require('./export-fixtures.js');
const exporter = fx.loadExporter(root);
const exported = exporter.exportIndexJs(
  fx.project([fx.mk('digital_hour', 'digital_display', { data_source: 'HOUR', format: 'hh' })]),
  {}, {}, {},
).code;
assert.match(exported, /formatHour\(now, "hh", true\)/);

console.log('Preview format tests passed.');
