// Тесты конвертера шрифтов (src/util/font-converter.js).
// Запуск: node scripts/test-font-converter.js
const fs = require('node:fs');
const path = require('node:path');
const FC = require('../src/util/font-converter.js');

let failed = 0;
function ok(name, cond, extra) { if (cond) console.log('ok: ' + name); else { failed++; console.log('FAIL: ' + name + (extra ? ' — ' + extra : '')); } }
const fx = (n) => new Uint8Array(fs.readFileSync(path.join(__dirname, 'fixtures', n)));

function tables(bytes) {
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.length);
  const n = dv.getUint16(4);
  const t = {};
  for (let i = 0; i < n; i++) {
    const o = 12 + i * 16;
    const tag = String.fromCharCode(bytes[o], bytes[o + 1], bytes[o + 2], bytes[o + 3]);
    t[tag] = { off: dv.getUint32(o + 8), len: dv.getUint32(o + 12), sum: dv.getUint32(o + 4) };
  }
  return { dv, t };
}
function wholeSum(bytes) {
  let s = 0;
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.length);
  for (let i = 0; i + 3 < bytes.length; i += 4) s = (s + dv.getUint32(i)) >>> 0;
  return s;
}

(async () => {
  const otf = fx('Project_Space.otf');
  const res = await FC.toTtf(otf);
  const { dv, t } = tables(res.bytes);
  ok('OTF(CFF) конвертируется', res.converted === true && res.from === 'otf');
  ok('результат — TrueType (sfnt 0x00010000)', dv.getUint32(0) === 0x00010000);
  ok('есть glyf/loca, нет CFF', !!t.glyf && !!t.loca && !t['CFF ']);
  ok('есть cmap/hmtx/head/hhea/maxp/name/OS/2/post', ['cmap', 'hmtx', 'head', 'hhea', 'maxp', 'name', 'OS/2', 'post'].every((k) => t[k]));
  ok('контрольная сумма файла сходится (0xB1B0AFBA)', wholeSum(res.bytes) === 0xB1B0AFBA);
  const numGlyphsOtf = new DataView(otf.buffer, otf.byteOffset).getUint16(0) && tables(otf).dv.getUint16(tables(otf).t.maxp.off + 4);
  ok('число глифов сохранено', dv.getUint16(t.maxp.off + 4) === numGlyphsOtf, String(numGlyphsOtf));
  ok('loca в длинном формате и конечный индекс = размер glyf', dv.getInt16(t.head.off + 50) === 1 && dv.getUint32(t.loca.off + numGlyphsOtf * 4) === t.glyf.len);
  // у цифр должны быть контуры
  const cmapOff = t.cmap.off;
  ok('в glyf есть непустые контуры', t.glyf.len > 1000);

  const ttf = fx('DacikPush.ttf');
  const same = await FC.toTtf(ttf);
  ok('TTF проходит без изменений', same.converted === false && same.bytes === ttf);

  let err = null;
  try { await FC.toTtf(new Uint8Array([0x77, 0x4f, 0x46, 0x32, 0, 0, 0, 0, 0, 0, 0, 0, 0])); } catch (e) { err = e; }
  ok('WOFF2 — понятная ошибка', err && /WOFF2/.test(err.message));
  err = null;
  try { await FC.toTtf(new Uint8Array(40)); } catch (e) { err = e; }
  ok('мусор — ошибка, а не падение', !!err);

  // миграция записи из проекта
  const font = { id: 'font_x', name: 'Project_Space', filename: 'Project_Space.otf', ext: '.otf', dataUrl: FC.bytesToDataUrl(otf, 'application/octet-stream'), size: otf.length, cssFamily: 'F' };
  const changed = await FC.convertFontRecord(font);
  ok('convertFontRecord меняет запись', changed === true && font.ext === '.ttf' && font.filename === 'Project_Space.ttf' && /^data:font\/ttf;base64,/.test(font.dataUrl));
  ok('id шрифта не меняется (ссылки в компонентах живы)', font.id === 'font_x');
  ok('повторная миграция ничего не делает', (await FC.convertFontRecord(font)) === false);

  ok('toTtfName', FC.toTtfName('My Font.otf') === 'My Font.ttf');
  if (failed) { console.log(failed + ' failed'); process.exit(1); }
  console.log('Font converter tests passed.');
})().catch((e) => { console.error(e); process.exit(1); });
