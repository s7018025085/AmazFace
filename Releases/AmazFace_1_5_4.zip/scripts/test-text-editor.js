// Редактор текста на часах: регистрация виджетов, страница панели, сохранение и применение правок.
// Запуск: node scripts/test-text-editor.js
const assert = require('node:assert/strict');
const vm = require('node:vm');
const fx = require('./export-fixtures.js');

const exporter = fx.loadExporter(process.cwd());

function makeProject(withPanel) {
  const dial = fx.mk('dial', 'fill_rect', { color: '#334455' });
  if (withPanel) {
    dial.tapZones = [{ id: 'sz', name: 'Настройки', x: 0, y: 0, w: 100, h: 60, visible: true, props: { tap_action: 'SETTINGS' } }];
  }
  const project = fx.project([
    dial,
    fx.mk('label', 'text', { text: 'Привет', text_size: 30, color: '#ffffff', align_h: 'LEFT' }, { x: 100, y: 200, w: 200, h: 40 }),
    fx.mk('clock', 'time_hm', { text_size: 60, color: '#ff0000', format: 'HH:MM' }, { x: 80, y: 100, w: 300, h: 80 }),
    fx.mk('steps', 'text', { data_source: 'STEP', text_size: 24, color: '#00ff00' }, { x: 150, y: 300, w: 150, h: 30 }),
  ], [fx.mk('aod_time', 'time_hm', { text_size: 40, color: '#888888', format: 'HH:MM' }, { x: 80, y: 80, w: 220, h: 60 })]);
  project.app.appId = 1234567;
  project.meta = { name: 'Text editor test', createdAt: 123456789 };
  project.watchSettings = { hourlyVibration: false };
  return project;
}

// 1. Без панели настроек экспорт не меняется: нет реестра и редактора.
const plain = exporter.exportIndexJsDual(makeProject(false), {}, {});
assert.equal(plain.validation.errors.length, 0, plain.validation.errors.join('\n'));
assert.doesNotMatch(plain.code, /__afEd/, 'без панели настроек редактор не добавляется');

// 2. С панелью: реестр, сохранённые ручки, страница редактора.
const generated = exporter.exportIndexJsDual(makeProject(true), {}, {});
assert.equal(generated.validation.errors.length, 0, generated.validation.errors.join('\n'));
assert.match(generated.code, /const __afEd = \[\];/, 'реестр объявлен до сцен');
assert.equal((generated.code.match(/__afEd\.push\(/g) || []).length, 3, 'зарегистрированы все три текста Normal-сцены, AOD не затронут');
assert.match(generated.code, /amazface_edits_1234567_123456789\.json/, 'правки лежат в отдельном файле');
assert.match(generated.code, /Редактор текста  ›/, 'в меню есть вход в редактор');

const files = new Map();
function TestDate() {}
['getMinutes', 'getSeconds', 'getHours'].forEach((m) => { TestDate.prototype[m] = () => 10; });
TestDate.prototype.getFullYear = () => 2026; TestDate.prototype.getMonth = () => 9; TestDate.prototype.getDate = () => 31;
TestDate.prototype.getDay = () => 6;

function buildRuntime() {
  const widgets = [];
  const handles = new Map();
  let next = 1;
  const enumProxy = new Proxy({}, { get: (_, key) => String(key) });
  const hmFS = {
    O_RDONLY: 1, O_RDWR: 2, O_CREAT: 4, O_TRUNC: 8,
    stat: (path) => files.has(path) ? [{ size: files.get(path).length }, 0] : [null, -1],
    open: (path, flags) => {
      if (!files.has(path) && (flags & 4)) files.set(path, new Uint8Array());
      if (!files.has(path)) return -1;
      const fd = next++; handles.set(fd, path);
      if (flags & 8) files.set(path, new Uint8Array());
      return fd;
    },
    read: (fd, buffer, position, length) => { new Uint8Array(buffer).set((files.get(handles.get(fd)) || new Uint8Array()).slice(0, length), position); return 0; },
    write: (fd, buffer, position, length) => { files.set(handles.get(fd), new Uint8Array(buffer).slice(position, position + length)); return 0; },
    close: (fd) => { handles.delete(fd); return 0; },
  };
  const sandbox = {
    console, Math, Date: TestDate, JSON, Uint8Array, ArrayBuffer,
    createWidget: (type, params) => {
      const w = { type, params, visible: true };
      w.setAlpha = () => {};
      w.setProperty = (key, value) => {
        if (key === 'VISIBLE') w.visible = !!value;
        else if (key === 'MORE') Object.assign(w.params, value);
      };
      widgets.push(w);
      return w;
    },
    widget: enumProxy, align: enumProxy, text_style: enumProxy, prop: enumProxy, show_level: enumProxy, data_type: enumProxy,
    hmFS,
    hmSetting: { screen_type: { WATCHFACE: 1, AOD: 2 }, getScreenType: () => 1 },
    hmSensor: { id: {}, createSensor: () => ({ start() {}, stop() {} }) },
    setInterval: () => 1, clearInterval: () => {}, setTimeout: () => 1, clearTimeout: () => {},
    WatchFace: (definition) => { sandbox.watchFace = definition; },
  };
  vm.createContext(sandbox);
  vm.runInContext(generated.code.replace(/^import .*$/gm, ''), sandbox, { filename: 'text-editor-test.js' });
  sandbox.watchFace.build.call({});
  return widgets;
}

const vis = (widgets, text) => widgets.find((w) => w.visible && w.params.text === text);
const labelWidget = (widgets) => widgets.find((w) => w.type === 'TEXT' && w.params.text === 'Привет');

let widgets = buildRuntime();
const label = labelWidget(widgets);
assert.ok(label, 'текст «Привет» создан как обычный виджет');
const openPanel = (ws) => ws.find((w) => w.params.w === 100 && typeof w.params.click_func === 'function').params.click_func();
openPanel(widgets);
const entry = vis(widgets, 'Редактор текста  ›');
assert.ok(entry, 'меню настроек показывает вход в редактор');
entry.params.click_func();

// Уровень 1: список текстов с понятными подписями.
assert.ok(vis(widgets, 'Выберите текст 1/1'), 'заголовок списка');
assert.ok(vis(widgets, '1. label - Привет'), 'у статичного текста в подписи его содержимое');
assert.ok(vis(widgets, '2. clock - TIME') || vis(widgets, '2. clock - ' + 'HM') || widgets.find((w) => w.visible && /^2\. clock/.test(String(w.params.text))), 'у времени подпись с именем и источником');
assert.ok(vis(widgets, '3. steps - STEP'), 'у датчика в подписи источник данных');
assert.ok(!vis(widgets, 'Размер 30'), 'на уровне списка настроек размера нет');
assert.ok(widgets.find((w) => w.type === 'STROKE_RECT' && !w.visible), 'рамка на списке скрыта');

// Уровень 2: тап по строке открывает экран этого текста.
vis(widgets, '1. label - Привет').params.click_func();
const title = widgets.find((w) => w.type === 'TEXT' && w.visible && w.params.text === 'label - Привет');
assert.ok(title, 'заголовок экрана редактирования называет редактируемый текст');
assert.ok(!vis(widgets, '1. label - Привет'), 'список скрыт');
const frame = widgets.find((w) => w.type === 'STROKE_RECT');

assert.ok(!frame.visible, 'рамка не показывается поверх кнопок на экране редактирования');
assert.ok(vis(widgets, 'Размер 30   X 100   Y 200'), 'под заголовком показаны текущие размер, X и Y');
const bigBtn = (text) => {
  const w = widgets.find((b) => b.visible && b.params.text === text);
  assert.ok(w, 'кнопка «' + text + '» есть');
  return w;
};
for (const t of ['−  Размер', '+  Размер', '−  X', '+  X', '−  Y', '+  Y']) {
  assert.ok(bigBtn(t).params.w >= 100 && bigBtn(t).params.h >= 36, 'кнопка «' + t + '» крупная (половина ширины)');
}
assert.ok(bigBtn('−  Размер').params.x < bigBtn('+  Размер').params.x, 'минус слева, плюс справа (две колонки)');
assert.equal(bigBtn('−  Размер').params.x, bigBtn('−  X').params.x, 'колонка минусов выровнена');
assert.equal(bigBtn('+  Размер').params.x, bigBtn('+  Y').params.x, 'колонка плюсов выровнена');
assert.ok(widgets.find((b) => b.visible && b.params.normal_color === 0x000000), 'в палитре есть чёрный цвет');

bigBtn('+  Размер').params.click_func();
assert.ok(vis(widgets, 'Размер 32   X 100   Y 200'), 'размер увеличен на шаг 2');
assert.equal(label.params.text_size, 32, 'размер применён к виджету на лету');
assert.equal(label.params.x, 100, 'левое выравнивание: левый край остаётся');

vis(widgets, 'Шаг: 2 px').params.click_func();
bigBtn('+  X').params.click_func();
assert.equal(label.params.x, 105, 'положение сдвинуто на 5');

const swatch = widgets.find((w) => w.visible && w.params.normal_color === 0xff3b30);
assert.ok(swatch, 'в палитре есть образцы цвета');
swatch.params.click_func();
assert.equal(label.params.color, 0xff3b30, 'цвет применён');
widgets.find((w) => w.visible && w.params.normal_color === 0x000000).params.click_func();
assert.equal(label.params.color, 0x000000, 'чёрный цвет применяется');
swatch.params.click_func();

const editsKey = [...files.keys()].find((k) => k.includes('edits'));
assert.ok(editsKey, 'файл правок создан');
assert.deepEqual(JSON.parse(String.fromCharCode.apply(null, files.get(editsKey))).label, [5, 0, 2, 0xff3b30], 'сохранены смещения и цвет');

// Режим просмотра.
vis(widgets, 'Показать на циферблате').params.click_func();
assert.ok(vis(widgets, '‹ К правкам'), 'в режиме просмотра есть кнопка возврата');
assert.ok(!vis(widgets, 'Размер 32'), 'элементы управления скрыты');
assert.ok(frame.visible, 'в режиме просмотра рамка видна');
assert.equal(frame.params.x, 103); assert.equal(frame.params.y, 198 - 1, 'рамка следует за размером и положением');
vis(widgets, '‹ К правкам').params.click_func();

// Возврат в список: изменённый текст помечен звёздочкой.
vis(widgets, '‹ К списку').params.click_func();
assert.ok(vis(widgets, '* 1. label - Привет'), 'изменённый текст помечен в списке');
assert.ok(vis(widgets, '2. clock - TIME') || widgets.find((w) => w.visible && /^2\. clock/.test(String(w.params.text))), 'неизменённый без метки');
assert.ok(!frame.visible, 'на списке рамка снова скрыта');

// Перезапуск: правки применяются при старте.
widgets = buildRuntime();
const label2 = labelWidget(widgets);
assert.equal(label2.params.text_size, 32, 'размер восстановлен после перезапуска');
assert.equal(label2.params.color, 0xff3b30, 'цвет восстановлен после перезапуска');

// Сброс одного текста.
openPanel(widgets);
vis(widgets, 'Редактор текста  ›').params.click_func();
vis(widgets, '* 1. label - Привет').params.click_func();
vis(widgets, 'Сбросить').params.click_func();
assert.equal(label2.params.text_size, 30); assert.equal(label2.params.x, 100); assert.equal(label2.params.color, 0xffffff);
assert.equal(String.fromCharCode.apply(null, files.get(editsKey)), '{}', 'после сброса файл пуст');

// Сброс всех из списка.
vis(widgets, '‹ К списку').params.click_func();
widgets.find((w) => w.visible && /^2\. clock/.test(String(w.params.text))).params.click_func();
widgets.find((w) => w.visible && w.params.text === '+  Размер').params.click_func();
vis(widgets, '‹ К списку').params.click_func();
vis(widgets, 'Сбросить все правки').params.click_func();
assert.equal(String.fromCharCode.apply(null, files.get(editsKey)), '{}', 'сброс всех очищает файл');

console.log('Text editor test passed (list -> detail screens, size/position/color, persistence, preview, resets).');
