// Панель настроек на часах: переходы, хранение параметров и тихие интервалы.
// Запуск: node scripts/test-watch-settings-panel.js
const assert = require('node:assert/strict');
const vm = require('node:vm');
const fx = require('./export-fixtures.js');

const exporter = fx.loadExporter(process.cwd());
const component = fx.mk('dial', 'fill_rect', { color: '#334455' });
component.tapZones = [{
  id: 'settings-zone', name: 'Настройки', x: 0, y: 0, w: 100, h: 60, visible: true,
  props: { tap_action: 'SETTINGS' },
}];
const project = fx.project([component], [
  fx.mk('aod_time', 'time_hm', { text_size: 40, color: '#888888', format: 'HH:MM' }, { x: 80, y: 80, w: 220, h: 60 }),
  fx.mk('aod_date', 'date_full', { text_size: 20, color: '#888888', format: 'DD.MM' }, { x: 100, y: 145, w: 180, h: 32 }),
  fx.mk('aod_arc', 'arc', { data_source: 'BATTERY', segments_enabled: true, gradient_steps: 8, segment_gap: 4, segment_rounded: true, track_enabled: true }, { x: 20, y: 20, w: 100, h: 100 }),
  fx.mk('aod_circle', 'circle', { color: '#ff0000' }, { x: 20, y: 20, w: 40, h: 40 }),
]);
project.app.appId = 1234567;
project.meta = { name: 'Settings panel test', createdAt: 123456789 };
project.watchSettings = { hourlyVibration: false };
const generated = exporter.exportIndexJsDual(project, {}, {});
assert.equal(generated.validation.errors.length, 0, generated.validation.errors.join('\n'));
assert.match(generated.code, /__afOpenSettings\(\)/, 'tap-zone action opens the settings panel');
assert.match(generated.code, /show_level: show_level\.ONLY_NORMAL/, 'interactive panel is restricted to the normal face');
assert.match(generated.code, /hmFS\.write\(/, 'watch preferences are saved to hmFS');
assert.match(generated.code, /amazface_settings_1234567_123456789\.json/, 'preferences use a file in this watchface data directory');
assert.match(generated.code, /inQuietWindow\(__afHourlyPrefs\.nightQuiet/, 'night silence is checked by the shared hourly controller');
assert.match(generated.code, /inQuietWindow\(__afHourlyPrefs\.napQuiet/, 'nap silence is checked by the shared hourly controller');
assert.match(generated.code, /\[23, 24, 25\]\[level\]/, 'strength selects a supported Zepp vibration scene');
assert.match(generated.code, /import \{[^}]*\bVibrator\b[^}]*\} from '@zos\/sensor'/, 'API 3.0 Vibrator is imported for the hourly signal and the test button');
assert.match(generated.code, /function __afVibrate\(/, 'hourly signal and test button share one vibration function');
assert.doesNotMatch(generated.code, /__afTrackAodWidget|__afSetAodWidgetVisible|aodDisplay|Настройки AOD/, 'the AOD settings page and its widget tracking are removed');

const files = new Map();
const current = { hour: 10, minute: 15, second: 0 };
const vibrations = [];
let nextHandle = 1;
let screenType = 1;
function TestDate() {}
TestDate.prototype.getMinutes = () => current.minute;
TestDate.prototype.getSeconds = () => current.second;
TestDate.prototype.getHours = () => current.hour;
TestDate.prototype.getFullYear = () => 2026;
TestDate.prototype.getMonth = () => 9;
TestDate.prototype.getDate = () => 31;

function buildRuntime(overrides = {}) {
  const widgets = [];
  const intervals = [];
  const handles = new Map();
  const enumProxy = new Proxy({}, { get: (_, key) => String(key) });
  const hmFS = {
    O_RDONLY: 1, O_RDWR: 2, O_CREAT: 4, O_TRUNC: 8,
    stat: (path) => files.has(path) ? [{ size: files.get(path).length }, 0] : [null, -1],
    open: (path, flags) => {
      if (!files.has(path) && (flags & 4)) files.set(path, new Uint8Array());
      if (!files.has(path)) return -1;
      const fd = nextHandle++;
      handles.set(fd, path);
      if (flags & 8) files.set(path, new Uint8Array());
      return fd;
    },
    read: (fd, buffer, position, length) => {
      const bytes = files.get(handles.get(fd)) || new Uint8Array();
      new Uint8Array(buffer).set(bytes.slice(0, length), position);
      return 0;
    },
    write: (fd, buffer, position, length) => {
      files.set(handles.get(fd), new Uint8Array(buffer).slice(position, position + length));
      return 0;
    },
    close: (fd) => { handles.delete(fd); return 0; },
  };
  const sandbox = {
    console, Math, Date: TestDate, JSON, Uint8Array, ArrayBuffer,
    createWidget: (type, params) => {
      const w = { type, params, visible: true, props: {}, alpha: null };
      w.setAlpha = (alpha) => { w.alpha = alpha; };
      w.setProperty = (key, value) => {
        if (key === 'VISIBLE') w.visible = !!value;
        else if (key === 'MORE') Object.assign(w.params, value);
        else w.props[key] = value;
      };
      widgets.push(w);
      return w;
    },
    widget: enumProxy, align: enumProxy, text_style: enumProxy, prop: enumProxy, show_level: enumProxy, data_type: enumProxy,
    hmFS,
    hmSetting: { screen_type: { WATCHFACE: 1, AOD: 2 }, getScreenType: () => screenType },
    hmSensor: {
      id: { VIBRATE: 99 },
      createSensor: () => ({
        scene: 0,
        start() { vibrations.push({ scene: this.scene, hour: current.hour, screenType }); },
        stop() {},
      }),
    },
    setInterval: (fn, delay) => { intervals.push({ fn, delay }); return intervals.length; },
    clearInterval: () => {}, setTimeout: () => 1, clearTimeout: () => {},
    WatchFace: (definition) => { sandbox.watchFace = definition; },
  };
  for (const [key, value] of Object.entries(overrides)) {
    if (value === null) delete sandbox[key]; else sandbox[key] = value;
  }
  vm.createContext(sandbox);
  vm.runInContext(generated.code.replace(/^import .*$/gm, ''), sandbox, { filename: 'watchface-settings-test.js' });
  const self = {};
  sandbox.watchFace.build.call(self);
  return { widgets, intervals, self, sandbox };
}

function visibleText(runtime, text) {
  return runtime.widgets.find((w) => w.visible && w.params.text === text);
}

function assertInsideRoundedScreen(widget, message) {
  const { x, y, w, h } = widget.params;
  const insetAt = (vertical) => {
    const normalized = Math.max(-1, Math.min(1, (vertical - 240) / 240));
    return 240 * (1 - Math.sqrt(Math.max(0, 1 - normalized * normalized)));
  };
  const safeInset = Math.max(insetAt(y), insetAt(y + h)) + 12;
  assert.ok(x >= safeInset - 1, `${message}: left edge stays inside the rounded screen`);
  assert.ok(x + w <= 480 - safeInset + 1, `${message}: right edge stays inside the rounded screen`);
}

let runtime = buildRuntime();
const zoneButton = runtime.widgets.find((w) => w.alpha === 0 && w.params.w === 100 && typeof w.params.click_func === 'function');
assert.ok(zoneButton, 'the SETTINGS tap zone is created');
zoneButton.params.click_func();
const menuEntry = visibleText(runtime, 'Почасовая вибрация  ›');
assert.ok(menuEntry, 'tap opens the settings menu with a vibration entry');
assert.ok(menuEntry.params.h >= 36, 'menu rows provide a larger touch target');
assertInsideRoundedScreen(menuEntry, 'main menu item');
assertInsideRoundedScreen(visibleText(runtime, '⚙'), 'panel title');
assertInsideRoundedScreen(visibleText(runtime, '×'), 'close button');
menuEntry.params.click_func();
let hourlyToggle = visibleText(runtime, 'Почасовая вибрация: ВЫКЛ');
assert.ok(hourlyToggle, 'the vibration subpage opens with the project default');
assert.ok(hourlyToggle.params.h >= 36, 'settings rows provide a larger touch target');
assertInsideRoundedScreen(hourlyToggle, 'hourly toggle');
hourlyToggle.params.click_func();
assert.ok(visibleText(runtime, 'Почасовая вибрация: ВКЛ'), 'hourly vibration can be enabled from the watch');

const nightStartLabel = visibleText(runtime, 'Ночь с 22:00');
assert.ok(nightStartLabel, 'night quiet start defaults to 22:00');
const minusForNightStart = runtime.widgets.find((w) => w.visible && w.params.text === '−' && w.params.y === nightStartLabel.params.y);
const plusForNightStart = runtime.widgets.find((w) => w.visible && w.params.text === '+' && w.params.y === nightStartLabel.params.y);
assert.ok(minusForNightStart.params.h >= 36 && plusForNightStart.params.h >= 36, 'time controls have larger touch targets');
assertInsideRoundedScreen(minusForNightStart, 'time minus control');
assertInsideRoundedScreen(plusForNightStart, 'time plus control');
plusForNightStart.params.click_func();
assert.ok(visibleText(runtime, 'Ночь с 23:00'), 'quiet start can be moved with the plus button');
const nightToggle = visibleText(runtime, 'Ночная тишина: ВКЛ');
assert.ok(nightToggle, 'night silence can be configured independently');
const napToggle = visibleText(runtime, 'Дневной сон: ВЫКЛ');
assert.ok(napToggle, 'daytime sleep silence is independently disabled by default');
napToggle.params.click_func();
assert.ok(visibleText(runtime, 'Дневной сон: ВКЛ'), 'daytime sleep silence can be enabled');
const strength = visibleText(runtime, 'Сила вибрации: средняя');
strength.params.click_func();
assert.ok(visibleText(runtime, 'Сила вибрации: высокая'), 'vibration strength can be changed');

// Кнопка проверки: срабатывает тем же путём, но игнорирует «тишину».
current.hour = 23;
const vibTest = visibleText(runtime, 'Проверить вибрацию');
assert.ok(vibTest, 'the vibration page has a test button');
assert.ok(vibTest.params.h >= 36, 'test button provides a larger touch target');
assertInsideRoundedScreen(vibTest, 'vibration test button');
vibTest.params.click_func();
assert.deepEqual(vibrations.map((v) => v.scene), [25], 'test button vibrates with the selected strength even inside quiet hours');
assert.ok(visibleText(runtime, 'Проверка: отправлено'), 'test button reports that the signal was sent');
vibrations.length = 0;
current.hour = 10;
const back = visibleText(runtime, '‹ Назад');
assertInsideRoundedScreen(back, 'back button below the test button');
back.params.click_func();
assert.ok(visibleText(runtime, 'Почасовая вибрация  ›'), 'back returns to the settings menu');
assert.ok(!visibleText(runtime, 'Настройки AOD  ›'), 'the AOD settings entry is gone from the menu');
visibleText(runtime, 'Почасовая вибрация  ›').params.click_func();
assert.ok(visibleText(runtime, 'Проверить вибрацию'), 'test result is cleared after leaving the page');
visibleText(runtime, '×').params.click_func();
assert.ok(!runtime.widgets.some((w) => w.visible && w.type === 'FILL_RECT' && w.params.color === 0x111923), 'close hides the panel');
zoneButton.params.click_func();
visibleText(runtime, 'Почасовая вибрация  ›').params.click_func();

const tick = runtime.intervals.find((entry) => entry.fn.name === '__afHourlyCheck');
assert.ok(tick, 'the shared hourly controller checks both watchface modes');
current.minute = 0;
current.hour = 23;
tick.fn();
assert.strictEqual(vibrations.length, 0, 'night quiet range suppresses the hourly vibration');
current.hour = 13;
tick.fn();
assert.strictEqual(vibrations.length, 0, 'daytime nap range suppresses the hourly vibration');
current.hour = 14;
tick.fn();
assert.deepEqual(vibrations.map((v) => v.scene), [25], 'outside quiet hours, the selected high intensity fires');
assert.strictEqual(screenType, 1);

const persisted = [...files.values()][0];
assert.ok(persisted && persisted.length > 0, 'watch settings were written to the local data file');
const persistedText = String.fromCharCode(...persisted);
assert.match(persistedText, /"hourlyEnabled":true/);
assert.match(persistedText, /"nightStart":23/);
assert.match(persistedText, /"napQuiet":true/);
assert.match(persistedText, /"strength":2/);

runtime = buildRuntime();
runtime.widgets.find((w) => w.alpha === 0 && w.params.w === 100).params.click_func();
visibleText(runtime, 'Почасовая вибрация  ›').params.click_func();
assert.ok(visibleText(runtime, 'Почасовая вибрация: ВКЛ'), 'hourly vibration survives face reinitialization');
assert.ok(visibleText(runtime, 'Ночь с 23:00'), 'quiet times survive face reinitialization');
assert.ok(visibleText(runtime, 'Дневной сон: ВКЛ'), 'nap silence survives face reinitialization');
assert.ok(visibleText(runtime, 'Сила вибрации: высокая'), 'strength survives face reinitialization');
visibleText(runtime, '×').params.click_func();

function openVibrationPage(rt) {
  rt.widgets.find((w) => w.alpha === 0 && w.params.w === 100).params.click_func();
  visibleText(rt, 'Почасовая вибрация  ›').params.click_func();
}

// Новый API 3.0: Vibrator из '@zos/sensor', старый hmSensor отсутствует.
class MockVibrator {
  setMode(mode) { this.mode = mode; }
  start() { vibrations.push({ mode: this.mode, via: 'Vibrator' }); }
  stop() {}
}
vibrations.length = 0;
current.hour = 10; current.minute = 15; current.second = 0; // не начало часа: сигнал при сборке не нужен
runtime = buildRuntime({
  hmSensor: null, Vibrator: MockVibrator,
  VIBRATOR_SCENE_SHORT_LIGHT: 101, VIBRATOR_SCENE_SHORT_MIDDLE: 102, VIBRATOR_SCENE_SHORT_STRONG: 103,
});
openVibrationPage(runtime);
visibleText(runtime, 'Проверить вибрацию').params.click_func();
assert.deepEqual(vibrations.map((v) => [v.via, v.mode]), [['Vibrator', 103]], 'test button uses the API 3.0 Vibrator with the saved strength');
assert.ok(visibleText(runtime, 'Проверка: отправлено'));

// Нет ни одного API вибрации: ошибка видна на кнопке, а не глотается молча.
vibrations.length = 0;
runtime = buildRuntime({ hmSensor: null });
openVibrationPage(runtime);
visibleText(runtime, 'Проверить вибрацию').params.click_func();
assert.strictEqual(vibrations.length, 0);
assert.ok(visibleText(runtime, 'Проверка: ошибка нет API вибрации'), 'a missing vibration API is reported on the button');

// Если hmSetting.getScreenType недоступен, почасовой сигнал не блокируется молча.
vibrations.length = 0;
current.hour = 15; current.minute = 15; current.second = 0;
runtime = buildRuntime({ hmSetting: null });
let failOpenTick = runtime.intervals.find((entry) => entry.fn.name === '__afHourlyCheck');
current.minute = 0;
failOpenTick.fn();
assert.deepEqual(vibrations.map((v) => v.scene), [25], 'hourly signal still fires without the screen-type API');

// Окно срабатывания — первые две минуты часа (AOD и выход из сна могут запаздывать), один раз на час.
vibrations.length = 0;
current.hour = 16; current.minute = 15; current.second = 0;
runtime = buildRuntime();
const windowTick = runtime.intervals.find((entry) => entry.fn.name === '__afHourlyCheck');
current.minute = 1; current.second = 40;
windowTick.fn();
assert.strictEqual(vibrations.length, 1, 'a late tick inside the first two minutes still vibrates');
windowTick.fn();
assert.strictEqual(vibrations.length, 1, 'the same hour never vibrates twice');
current.hour = 17; current.minute = 2; current.second = 0;
windowTick.fn();
assert.strictEqual(vibrations.length, 1, 'ticks after the two-minute window do not vibrate');

// Тест «каждую минуту»: работает при выключенной почасовой вибрации, игнорирует тишину,
// не сохраняется в файл и полностью останавливается при выключении.
files.clear();
vibrations.length = 0;
current.hour = 23; current.minute = 15; current.second = 5; // ночь (тишина по умолчанию) и не начало часа
const cleared = [];
runtime = buildRuntime({ clearInterval: (id) => { cleared.push(id); } });
assert.strictEqual(vibrations.length, 0, 'nothing vibrates while both hourly and minute modes are off');
assert.ok(!runtime.intervals.find((entry) => entry.fn.name === '__afHourlyCheck'), 'no timer runs while both modes are off');
runtime.widgets.find((w) => w.alpha === 0 && w.params.w === 100).params.click_func();
const minuteToggle = visibleText(runtime, 'Тест каждую минуту: ВЫКЛ');
assert.ok(minuteToggle, 'main menu has the every-minute test switch');
assert.ok(minuteToggle.params.h >= 36, 'test switch provides a larger touch target');
assertInsideRoundedScreen(minuteToggle, 'every-minute test switch');
minuteToggle.params.click_func();
assert.ok(visibleText(runtime, 'Тест каждую минуту: ВКЛ'), 'test mode can be switched on');
assert.strictEqual(vibrations.length, 1, 'switching the test on vibrates right away');
const minuteTick = runtime.intervals.find((entry) => entry.fn.name === '__afHourlyCheck');
assert.ok(minuteTick, 'test mode starts the controller timer even with hourly vibration off');
minuteTick.fn();
assert.strictEqual(vibrations.length, 1, 'no second signal within the same minute');
current.minute = 16; current.second = 0;
minuteTick.fn();
assert.strictEqual(vibrations.length, 2, 'a new minute gives a new signal, even at night');
current.second = 45;
minuteTick.fn();
assert.strictEqual(vibrations.length, 2, 'late ticks inside the same minute do not repeat');
current.minute = 17; current.second = 30;
minuteTick.fn();
assert.strictEqual(vibrations.length, 3, 'a late tick still signals the new minute');
assert.ok(!String.fromCharCode(...([...files.values()][0] || [])).includes('inute'), 'test mode is not persisted to the watch file');
visibleText(runtime, 'Тест каждую минуту: ВКЛ').params.click_func();
assert.ok(visibleText(runtime, 'Тест каждую минуту: ВЫКЛ'), 'test mode can be switched off');
assert.ok(cleared.length >= 1, 'switching the test off stops the timer when hourly vibration is off');
current.minute = 18; current.second = 0;
minuteTick.fn();
assert.strictEqual(vibrations.length, 3, 'nothing vibrates after the test is switched off');
runtime = buildRuntime();
runtime.widgets.find((w) => w.alpha === 0 && w.params.w === 100).params.click_func();
assert.ok(visibleText(runtime, 'Тест каждую минуту: ВЫКЛ'), 'test mode is off again after the face restarts');

// AOD: setInterval заморожен, но системное событие смены минуты (Time.onPerMinute) всё равно вызывает проверку.
files.clear();
vibrations.length = 0;
current.hour = 12; current.minute = 15; current.second = 5;
const minuteCallbacks = [];
const removedCallbacks = [];
class MockTime {
  getTime() { return 0; }
  onPerMinute(cb) { minuteCallbacks.push(cb); }
  offPerMinute(cb) { removedCallbacks.push(cb); }
}
runtime = buildRuntime({ Time: MockTime });
assert.strictEqual(minuteCallbacks.length, 0, 'no minute subscription while all vibration modes are off');
runtime.widgets.find((w) => w.alpha === 0 && w.params.w === 100).params.click_func();
visibleText(runtime, 'Тест каждую минуту: ВЫКЛ').params.click_func();
assert.strictEqual(minuteCallbacks.length, 1, 'the system minute event is subscribed once when a vibration mode turns on');
assert.strictEqual(vibrations.length, 1);
current.minute = 16; current.second = 0;
minuteCallbacks[0](); // интервал «спит» (AOD), вызывается только системное событие
assert.strictEqual(vibrations.length, 2, 'the system minute event vibrates even when the interval timer is frozen');
visibleText(runtime, 'Тест каждую минуту: ВКЛ').params.click_func();
assert.deepEqual(removedCallbacks, [minuteCallbacks[0]], 'the minute subscription is removed when the modes turn off');
assert.match(generated.code, /offPerMinute\(this\._hourlyMinuteSensor|offPerMinute\(this\._hourlyMinuteCb/, 'onDestroy releases the minute subscription');

console.log('Watch settings panel test passed (single vibration menu, test button, every-minute test mode, AOD minute event, API 3.0 Vibrator + legacy fallback, rounded-screen-safe controls, persistence, quiet windows, intensity).');
