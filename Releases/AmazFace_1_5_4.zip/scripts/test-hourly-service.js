// Почасовая вибрация через системный будильник + app-service (работает и в AOD).
// Запуск: node scripts/test-hourly-service.js
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const fx = require('./export-fixtures.js');

const exporter = fx.loadExporter(process.cwd());
assert.equal(typeof exporter.hourlyServiceSource, 'function', 'hourlyServiceSource exported');
assert.equal(typeof exporter.projectUsesHourlyVibration, 'function', 'projectUsesHourlyVibration exported');

// ── проект с настройками на часах (тап-зона SETTINGS) и почасовой вибрацией ──
const comp = fx.mk('dial', 'fill_rect', { color: '#334455' });
comp.tapZones = [{ id: 'z', name: 'z', x: 0, y: 0, w: 100, h: 60, visible: true, props: { tap_action: 'SETTINGS' } }];
const project = fx.project([comp], []);
project.watchSettings = { hourlyVibration: true };
project.app.appId = 1234567;
project.meta = { name: 'Hourly service test', createdAt: 5551234 };
assert.equal(exporter.projectUsesHourlyVibration(project), true);
assert.equal(exporter.projectUsesHourlyVibration(fx.project([fx.mk('a', 'fill_rect', {})], [])), false, 'no hourly runtime -> no service');

const generated = exporter.exportIndexJsDual(project, {}, {});
assert.equal(generated.validation.errors.length, 0, generated.validation.errors.join('\n'));
assert.match(generated.code, /import \{[^}]*set as __afAlarmSet[^}]*\} from '@zos\/alarm'/, 'alarm API imported with aliases');
assert.match(generated.code, /url: 'app-service\/hourly'/, 'alarm wakes the hourly service');

// ── управляемые часы ──
let nowMs = 0;
const setClock = (h, m, s) => { nowMs = new Date(2026, 9, 31, h, m, s).getTime(); };
class FakeDate extends Date {
  constructor(...a) { if (a.length) super(...a); else super(nowMs); }
  static now() { return nowMs; }
}

function runWatchface(alarmMode) {
  const alarms = { set: [], cancel: [] };
  const vibrations = [];
  const intervals = [];
  const noop = () => {};
  const widgetProxy = () => new Proxy({}, { get: (_, k) => (k === 'then' ? undefined : noop) });
  const enumProxy = new Proxy({}, { get: (_, key) => String(key) });
  const sandbox = {
    console, Math, Date: FakeDate, JSON, Uint8Array, ArrayBuffer, Number, String, Array,
    createWidget: widgetProxy, widget: enumProxy, align: enumProxy, text_style: enumProxy, prop: enumProxy, show_level: enumProxy, data_type: enumProxy,
    hmFS: { O_RDONLY: 1, O_RDWR: 2, O_CREAT: 4, O_TRUNC: 8, stat: () => [null, -1], open: () => -1, read: noop, write: noop, close: noop },
    hmSensor: { id: { VIBRATE: 99 }, createSensor: () => ({ scene: 0, start() { vibrations.push(this.scene); }, stop() {} }) },
    setInterval: (fn, delay) => { intervals.push({ fn, delay }); return intervals.length; },
    clearInterval: noop, setTimeout: () => 1, clearTimeout: noop,
    WatchFace: (d) => { sandbox.watchFace = d; },
  };
  if (alarmMode !== 'absent') {
    sandbox.__afAlarmSet = (opt) => { alarms.set.push(opt); return alarmMode === 'fail' ? 0 : 42; };
    sandbox.__afAlarmCancel = (id) => { alarms.cancel.push(id); };
    sandbox.__afAlarmAll = () => [7];
  }
  vm.createContext(sandbox);
  vm.runInContext(generated.code.replace(/^import .*$/gm, ''), sandbox, { filename: 'hourly-wf.js' });
  sandbox.watchFace.build.call({});
  return { alarms, vibrations, intervals };
}

// 1) будильник доступен: взведён на ближайший час, внутри циферблата час не дублируется
setClock(10, 15, 0);
let rt = runWatchface('ok');
assert.equal(rt.alarms.set.length >= 1, true, 'alarm armed on start');
const last = rt.alarms.set[rt.alarms.set.length - 1];
assert.equal(last.url, 'app-service/hourly');
assert.equal(last.store, true, 'alarm survives reboot');
assert.equal(last.time, Math.floor(new Date(2026, 9, 31, 11, 0, 0).getTime() / 1000), 'armed for the next full hour');
assert.match(last.param, /(^|&)s=1(&|$)/); assert.match(last.param, /nq=1/); assert.match(last.param, /ns=22/); assert.match(last.param, /ne=7/);
assert.ok(rt.alarms.cancel.includes(7), 'stale alarms are cancelled before re-arming');
setClock(11, 0, 5);
rt.intervals.forEach((i) => { try { i.fn(); } catch (e) {} });
assert.equal(rt.vibrations.length, 0, 'in-face timer does not double the hourly signal when the service is armed');

// 2) будильник недоступен или не взвёлся: запасной путь внутри циферблата
for (const mode of ['absent', 'fail']) {
  setClock(10, 15, 0);
  rt = runWatchface(mode);
  setClock(11, 0, 5);
  rt.intervals.forEach((i) => { try { i.fn(); } catch (e) {} });
  assert.equal(rt.vibrations.length, 1, `fallback in-face signal works when alarm is ${mode}`);
}

// 3) сервис
function runService(h, m, s, param) {
  setClock(h, m, s);
  const vib = []; const alarms = [];
  let cfg = null;
  class Vibrator { stop() {} setMode(x) { this.mode = x; } start() { vib.push(this.mode); } }
  const code = exporter.hourlyServiceSource().replace(/^import .*$/gm, '');
  const sandbox = {
    Date: FakeDate, Math, Number, String, console, Vibrator,
    VIBRATOR_SCENE_SHORT_LIGHT: 'L', VIBRATOR_SCENE_SHORT_MIDDLE: 'M', VIBRATOR_SCENE_SHORT_STRONG: 'S',
    set: (o) => { alarms.push(o); return 1; },
    AppService: (c) => { cfg = c; },
  };
  vm.createContext(sandbox);
  vm.runInContext(code, sandbox, { filename: 'hourly-service.js' });
  assert.ok(cfg && typeof cfg.onInit === 'function', 'AppService registered');
  cfg.onInit(param);
  return { vib, alarms };
}
const P = 'v=1&s=1&nq=1&ns=22&ne=7&pq=1&ps=13&pe=14';
let r = runService(11, 0, 1, P);
assert.deepEqual(r.vib, ['M'], 'service vibrates with the configured strength');
assert.equal(r.alarms.length, 1);
assert.equal(r.alarms[0].url, 'app-service/hourly');
assert.equal(r.alarms[0].time, Math.floor(new Date(2026, 9, 31, 12, 0, 0).getTime() / 1000), 'next alarm is the next hour');
assert.equal(r.alarms[0].param, P, 'settings are passed on to the next alarm');
assert.equal(r.alarms[0].store, true);
r = runService(10, 59, 59, P);   // будильник сработал чуть раньше: сигнал относится к 11:00
assert.deepEqual(r.vib, ['M']);
assert.equal(r.alarms[0].time, Math.floor(new Date(2026, 9, 31, 12, 0, 0).getTime() / 1000), 'early fire does not re-arm the same hour');
r = runService(23, 0, 2, P);
assert.deepEqual(r.vib, [], 'night quiet suppresses the signal');
assert.equal(r.alarms.length, 1, 'but the chain continues');
assert.equal(r.alarms[0].time, Math.floor(new Date(2026, 9, 31, 24, 0, 0).getTime() / 1000));
r = runService(13, 0, 3, P);
assert.deepEqual(r.vib, [], 'nap quiet suppresses the signal');
r = runService(14, 0, 3, P);
assert.deepEqual(r.vib, ['M'], 'nap range ends at 14:00');
r = runService(8, 0, 1, 'v=1&s=2&nq=0&ns=22&ne=7&pq=0&ps=13&pe=14');
assert.deepEqual(r.vib, ['S']);
r = runService(8, 0, 1, '');
assert.deepEqual(r.vib, ['M'], 'garbage param falls back to defaults and still vibrates');

// 3b) сервис: отметка запуска (fn=) и тестовый режим (t=1)
{
  const files = {}; const notes = []; const timers = [];
  setClock(23, 0, 2);
  let cfg2 = null; const vib2 = []; const al2 = [];
  class V2 { stop() {} setMode(x) { this.mode = x; } start() { vib2.push(this.mode); } }
  const sb = {
    Date: FakeDate, Math, Number, String, JSON, console, Vibrator: V2,
    VIBRATOR_SCENE_SHORT_LIGHT: 'L', VIBRATOR_SCENE_SHORT_MIDDLE: 'M', VIBRATOR_SCENE_SHORT_STRONG: 'S',
    set: (o) => { al2.push(o); return 5; },
    notif: { notify: (o) => { notes.push(o); } },
    sysTimer: { createSysTimer: (per, ms, cb) => { timers.push({ per, ms, cb }); return 9; } },
    VIBRATOR_SCENE_DURATION: 'D',
    writeFileSync: (o) => { files[o.path] = o.data; return true; },
    AppService: (c) => { cfg2 = c; },
  };
  vm.createContext(sb);
  vm.runInContext(exporter.hourlyServiceSource().replace(/^import .*$/gm, ''), sb);
  cfg2.onInit(P + '&fn=amazface_svc_1_2.json');
  let rec = JSON.parse(files['amazface_svc_1_2.json']);
  assert.equal(rec.st, 'quiet', 'quiet hour is reported in the service mark');
  assert.equal(rec.nid, 5, 'next alarm id recorded');
  assert.equal(al2.length, 1);
  assert.match(al2[0].param, /fn=amazface_svc_1_2\.json/, 'mark file name is passed on to the next alarm');
  cfg2.onInit(P + '&fn=amazface_svc_1_2.json&t=1');   // тест игнорирует «тишину», цепочку не продолжает
  rec = JSON.parse(files['amazface_svc_1_2.json']);
  assert.equal(rec.st, 'ok'); assert.equal(rec.test, 1);
  assert.deepEqual(vib2, ['M'], 'test run vibrates even in quiet hours');
  assert.equal(al2.length, 1, 'test run does not create a next alarm');
  assert.equal(rec.ntf, 'ok', 'test run posts a notification'); assert.equal(notes.length, 1);
  assert.equal(rec.tm, 'set'); assert.equal(timers.length, 1); assert.equal(timers[0].per, false);
  timers[0].cb();
  rec = JSON.parse(files['amazface_svc_1_2.json']);
  assert.equal(rec.tm, 'fired', 'system timer callback is recorded'); assert.deepEqual(vib2, ['M', 'D'], 'timer fires a long vibration');
  cfg2.onInit(P + '&fn=amazface_svc_1_2.json');
  assert.equal(notes.length, 1, 'regular (non-test) runs do not post notifications');
}

// 3c) экран «Диагностика будильника» в панели настроек
{
  const widgets = [];
  const alarmSet = []; let alarmFail = false;
  const svcFile = { data: null };
  const noop = () => {};
  const enumProxy = new Proxy({}, { get: (_, key) => String(key) });
  const mkWidget = (type, opts) => {
    const w = { type, opts, text: opts && opts.text, visible: true, setAlpha: noop };
    w.setProperty = (k, v) => { if (k === 'MORE' && v && v.text !== undefined) w.text = v.text; if (k === 'VISIBLE') w.visible = !!v; };
    widgets.push(w); return w;
  };
  const intervals = [];
  const sandbox = {
    console, Math, Date: FakeDate, JSON, Uint8Array, ArrayBuffer, Number, String, Array,
    createWidget: mkWidget, widget: enumProxy, align: enumProxy, text_style: enumProxy, prop: enumProxy, show_level: enumProxy, data_type: enumProxy,
    hmFS: {
      O_RDONLY: 1, O_RDWR: 2, O_CREAT: 4, O_TRUNC: 8,
      stat: (path) => (/svc/.test(path) && svcFile.data ? [{ size: svcFile.data.length }, 0] : [null, -1]),
      open: (path) => (/svc/.test(path) && svcFile.data ? 3 : -1),
      read: (fd, buf) => { const b = new Uint8Array(buf); for (let i = 0; i < svcFile.data.length; i++) b[i] = svcFile.data.charCodeAt(i); },
      write: noop, close: noop,
    },
    hmSensor: { id: { VIBRATE: 99 }, createSensor: () => ({ start() {}, stop() {} }) },
    setInterval: (fn) => { intervals.push(fn); return intervals.length; }, clearInterval: noop, setTimeout: () => 1, clearTimeout: noop,
    WatchFace: (d) => { sandbox.watchFace = d; },
    __afAlarmSet: (o) => { alarmSet.push(o); return alarmFail ? 0 : 42; },
    __afAlarmCancel: noop, __afAlarmAll: () => [42],
  };
  vm.createContext(sandbox);
  setClock(10, 15, 0);
  vm.runInContext(generated.code.replace(/^import .*$/gm, ''), sandbox, { filename: 'diag-wf.js' });
  sandbox.watchFace.build.call({});
  const open = widgets.find((w) => w.opts && typeof w.opts.click_func === 'function' && /__afOpenSettings/.test(String(w.opts.click_func)));
  assert.ok(open, 'settings tap zone found');
  open.opts.click_func();
  const menu = widgets.find((w) => /Диагностика будильника/.test(String(w.text || '')) && w.type === 'BUTTON' && w.opts.click_func && w.visible);
  assert.ok(menu, 'diagnostics entry is shown on the settings page');
  menu.opts.click_func();
  const rows = widgets.filter((w) => w.visible && w.type === 'BUTTON' && /API будильника|Взведён|В системе|До сигнала|Сервис:|Итог:|Журнал|\d+\/\d+ |Перевзвести|Тест/.test(String(w.text || '')));
  const texts = rows.map((w) => w.text);
  const has = (re) => assert.ok(texts.some((t) => re.test(t)), 'diagnostics row ' + re + ' in: ' + texts.join(' | '));
  has(/API будильника: есть/); has(/Взведён: да, №42/); has(/В системе: есть \(всего 1\)/);
  has(/До сигнала 44:00|До сигнала 0?:?45:00|До сигнала \d+:\d\d/); has(/Сервис: нет отметок/); has(/^1\/\d+ /);
  has(/Тест сервиса через 1 мин/);
  // тест-кнопка взводит тестовый будильник с t=1
  const testBtn = widgets.find((w) => w.visible && /Тест сервиса через 1 мин/.test(String(w.text || '')));
  const before = alarmSet.length;
  testBtn.opts.click_func();
  assert.equal(alarmSet.length, before + 1, 'test alarm armed');
  assert.match(alarmSet[alarmSet.length - 1].param, /&t=1$/);
  assert.equal(alarmSet[alarmSet.length - 1].time, Math.floor(nowMs / 1000) + 60, 'test alarm is one minute ahead');
  assert.ok(widgets.some((w) => w.visible && /Тест: сигнал через 1:00/.test(String(w.text || ''))), 'test countdown shown');
  // отметка сервиса видна в диагностике после следующего тика
  svcFile.data = JSON.stringify({ t: nowMs, st: 'ok', test: 1, nid: 0, e: '' });
  intervals.forEach((fn) => { try { fn(); } catch (e) {} });
  assert.ok(widgets.some((w) => w.visible && /Итог: вибро отправлена/.test(String(w.text || ''))), 'service result shown');
  assert.ok(widgets.some((w) => w.visible && /Сервис: был 10:15:00/.test(String(w.text || ''))), 'service run time shown');
}

// 4) app.json: разрешение и модуль сервиса
const src = fs.readFileSync('src/exporter/project-exporter.js', 'utf8');
const m = src.match(/function buildAppJson\(project\) \{[\s\S]*?\n\}\n/);
assert.ok(m, 'buildAppJson found');
const ctx = { JSON, Number, computePermissions: () => ['data:user.hd.step'], projectUsesHourlyVibration: exporter.projectUsesHourlyVibration };
vm.createContext(ctx);
vm.runInContext(m[0] + '\nglobalThis.out = buildAppJson;', ctx);
const mkProj = (p) => Object.assign({}, p, { apiLevel: 3, meta: { name: 'T' }, app: {}, device: { targetKey: 'x', deviceSources: [1], w: 480, designWidth: 480 } });
let app = JSON.parse(ctx.out(mkProj(project)));
assert.ok(app.permissions.includes('device:os.alarm'), 'alarm permission requested');
assert.ok(app.permissions.includes('device:os.notification'), 'notification permission requested for the service test');
assert.ok(app.permissions.includes('data:user.hd.step'), 'existing permissions kept');
assert.deepEqual(app.targets.x.module['app-service'].services, ['app-service/hourly']);
assert.ok(app.targets.x.module.watchface, 'watchface module kept');
app = JSON.parse(ctx.out(mkProj(fx.project([fx.mk('a', 'fill_rect', {})], []))));
assert.ok(!app.permissions.includes('device:os.alarm'), 'no alarm permission without hourly vibration');
assert.equal(app.targets.x.module['app-service'], undefined, 'no service module without hourly vibration');

// 5) сервис кладётся в проект
assert.match(src, /zip\.addFile\('app-service\/hourly\.js', hourlyServiceSource\(\)\)/, 'service file is packed into the project zip');

console.log('Hourly service test passed (alarm arming, no double signal, fallback, service quiet hours/strength/re-arm, app.json permission + module).');
