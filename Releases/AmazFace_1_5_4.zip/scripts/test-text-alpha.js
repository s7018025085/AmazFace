// Прозрачность текста: setAlpha() + запасной способ «затухание цветом».
// Запуск: node scripts/test-text-alpha.js
const vm = require('node:vm');
const fx = require('./export-fixtures.js');

const ex = fx.loadExporter(process.cwd());
const { REGISTRY, exportIndexJs, exportIndexJsDual } = ex;

let passed = 0, failed = 0;
const check = (n, c, x) => { if (c) { passed++; console.log('ok: ' + n); } else { failed++; console.log('FAIL: ' + n + (x ? ' — ' + x : '')); } };

function run(code) {
  const widgets = [];
  const proxy = new Proxy({}, { get: (_, k) => String(k) });
  const sb = {
    console, Math, Date, JSON,
    createWidget: (type, params) => {
      const w = { type, params: Object.assign({}, params), alpha: null };
      w.setAlpha = (a) => { w.alpha = a; };
      w.setProperty = (k, v) => { if (k === 'MORE') Object.assign(w.params, v); };
      w.getProperty = () => undefined;
      widgets.push(w); return w;
    },
    widget: proxy, align: proxy, text_style: proxy, prop: proxy, show_level: proxy, data_type: proxy, system_status: proxy,
    setInterval: () => 1, clearInterval() {}, setTimeout: () => 1, clearTimeout() {},
    Time: function () { this.getTime = () => new Date(2026, 10, 6, 13, 5, 30).getTime(); },
    Battery: function () {}, Step: function () {}, Screen: function () { this.getStatus = () => 1; this.onChange = () => {}; this.offChange = () => {}; },
    WatchFace: (d) => { sb.__wf = d; },
  };
  vm.createContext(sb);
  vm.runInContext(code.replace(/^import .*$/gm, ''), sb, { filename: 'index.js' });
  sb.__wf.build.call({});
  return widgets;
}
const textWidgets = (ws) => ws.filter((w) => /^(TEXT|TEXT_FONT)$/.test(w.type));
const exp = (comp) => { const g = exportIndexJs(fx.project([comp]), {}, {}); if (g.validation.errors.length) throw new Error(g.validation.errors.join('; ')); return g; };
const hex = (n) => '0x' + Number(n).toString(16).padStart(6, '0');
const mkText = (props, defId) => fx.mk('t', defId || 'text', Object.assign({ data_source: 'NONE', text: 'Привет', text_size: 40, color: '#ffffff' }, props));

// Реестр
{
  const defs = Object.values(REGISTRY).filter((d) => d.widgetId === 'TEXT');
  check('реестр: у каждого текстового компонента есть прозрачность и затухание', defs.every((d) => ['text_alpha', 'text_blend', 'text_blend_color'].every((k) => d.properties.some((p) => p.key === k))));
  const pa = REGISTRY.text.properties.find((p) => p.key === 'text_alpha');
  check('реестр: прозрачность 0–100, по умолчанию 100', pa.default === 100 && pa.min === 0 && pa.max === 100);
  check('реестр: нетекстовые компоненты не затронуты', Object.values(REGISTRY).filter((d) => d.widgetId !== 'TEXT').every((d) => !d.properties.some((p) => p.key === 'text_alpha')));
  check('реестр: ключи без повторов у «Текста»', new Set(REGISTRY.text.properties.map((p) => p.key)).size === REGISTRY.text.properties.length);
}

// Прозрачность через setAlpha
for (const [pct, a255] of [[100, null], [75, 191], [50, 128], [40, 102], [10, 26], [0, 0]]) {
  const g = exp(mkText({ text_alpha: pct }));
  const w = textWidgets(run(g.code))[0];
  if (pct === 100) check('прозрачность 100 → у текста setAlpha не вызывается', w.alpha === null);
  else check(`прозрачность ${pct}% → setAlpha(${a255})`, w.alpha === a255, String(w.alpha));
}

// Разные источники данных: время (JS-путь), нативный TEXT_FONT, температура
for (const [label, props, defId] of [
  ['время', { data_source: 'TIME', time_format: 'HH:MM' }],
  ['часы (заготовка)', {}, 'time_hour'],
  ['влажность (TEXT_FONT)', { data_source: 'HUMIDITY' }],
  ['температура (TEXT_FONT)', { data_source: 'WEATHER_TEMP' }],
  ['шаги', { data_source: 'STEP' }],
]) {
  const g = exp(mkText(Object.assign({ text_alpha: 30 }, props), defId));
  let ws; try { ws = textWidgets(run(g.code)); } catch (e) { ws = []; check(`${label}: код исполняется`, false, e.message); }
  check(`${label}: setAlpha(77) применён`, ws.length >= 1 && ws[0].alpha === 77, ws[0] && String(ws[0].alpha));
}

// Затухание цветом
{
  const col = (props) => hex(textWidgets(run(exp(mkText(props)).code))[0].params.color);
  check('затухание 0% — цвет без изменений', col({ color: '#ffffff', text_blend: 0 }) === '0xffffff');
  check('затухание 50% к чёрному: белый → 808080', col({ color: '#ffffff', text_blend: 50, text_blend_color: '#000000' }) === '0x808080', col({ color: '#ffffff', text_blend: 50, text_blend_color: '#000000' }));
  check('затухание 100% = цвет фона', col({ color: '#ffffff', text_blend: 100, text_blend_color: '#112233' }) === '0x112233');
  check('затухание 25% к синему', col({ color: '#ff0000', text_blend: 25, text_blend_color: '#0000ff' }) === '0xbf0040', col({ color: '#ff0000', text_blend: 25, text_blend_color: '#0000ff' }));
  check('короткий #rgb поддерживается', col({ color: '#fff', text_blend: 50, text_blend_color: '#000' }) === '0x808080');
  check('мусорный цвет фона не ломает экспорт', /^0x[0-9a-f]{6}$/.test(col({ color: '#ffffff', text_blend: 50, text_blend_color: 'zzz' })));
  const g = exp(mkText({ color: '#ffffff', text_blend: 50, text_blend_color: '#000000' }));
  check('затухание не требует setAlpha у текста', textWidgets(run(g.code))[0].alpha === null);
  // затухание и у нативного TEXT_FONT
  const nat = textWidgets(run(exp(mkText({ data_source: 'HUMIDITY', color: '#ffffff', text_blend: 50, text_blend_color: '#000000' })).code))[0];
  check('затухание: TEXT_FONT тоже получает смешанный цвет', hex(nat.params.color) === '0x808080');
  // оба способа вместе
  const both = textWidgets(run(exp(mkText({ color: '#ffffff', text_blend: 50, text_alpha: 50 })).code))[0];
  check('оба способа вместе: цвет 808080 и setAlpha(128)', hex(both.params.color) === '0x808080' && both.alpha === 128);
}

// Без свойств код не меняется
{
  const withDefaults = exp(mkText({ text_alpha: 100, text_blend: 0, text_blend_color: '#000000' })).code;
  const without = exp(mkText({})).code;
  check('значения по умолчанию = код как без свойств', withDefaults === without);
}

// Мусорные значения
for (const bad of ['abc', null, undefined, NaN, -50, 500]) {
  let ok = true, a;
  try { a = textWidgets(run(exp(mkText({ text_alpha: bad })).code))[0].alpha; } catch (e) { ok = false; }
  check(`мусорная прозрачность ${JSON.stringify(bad)} → экспорт не ломается`, ok && (a === null || (a >= 0 && a <= 255)), String(a));
}

// Сцены: день/ночь/AOD
{
  const day = mkText({ text_alpha: 50 });
  const night = fx.mk('nt', 'text', { data_source: 'NONE', text: 'Ночь', text_size: 40, color: '#8899ff', text_alpha: 25 });
  const aod = fx.mk('at', 'text', { data_source: 'NONE', text: 'AOD', text_size: 40, color: '#888888', text_alpha: 60 });
  const p = fx.project([day], [aod]);
  p.scenes.night = { components: [night], background: { color: '#000011' } };
  const g = exportIndexJsDual(p, {}, {});
  check('сцены: нет ошибок экспорта', g.validation.errors.length === 0, g.validation.errors.join('; '));
  let ws; try { ws = textWidgets(run(g.code)); } catch (e) { ws = []; check('сцены: код исполняется', false, e.message); }
  const by = (t) => ws.find((w) => w.params.text === t);
  check('сцены: день — setAlpha(128)', by('Привет') && by('Привет').alpha === 128, by('Привет') && String(by('Привет').alpha));
  check('сцены: ночь — setAlpha(64)', by('Ночь') && by('Ночь').alpha === 64, by('Ночь') && String(by('Ночь').alpha));
  check('сцены: AOD — setAlpha(153)', by('AOD') && by('AOD').alpha === 153, by('AOD') && String(by('AOD').alpha));
}

// Совместимость с плавающим текстом и смещением времени
{
  const aod = fx.mk('a', 'time_minute', { time_offset: -1, text_size: 40, color: '#ffffff', text_alpha: 50, float_enabled: true, float_interval: '5' }, { x: 140, y: 200, w: 200, h: 70 });
  const g = exportIndexJsDual(fx.project([fx.mk('n', 'text', { data_source: 'NONE', text: 'n' })], [aod]), {}, {});
  check('вместе со смещением и плаванием: нет ошибок', g.validation.errors.length === 0, g.validation.errors.join('; '));
  let w; try { w = textWidgets(run(g.code)).find((x) => x.params.w === 200 && x.params.h === 70); } catch (e) { check('вместе со смещением и плаванием: код исполняется', false, e.message); }
  check('вместе со смещением и плаванием: setAlpha(128) и минуты со смещением', w && w.alpha === 128 && w.params.text === '04', w && JSON.stringify({ a: w.alpha, t: w.params.text }));
}

console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed ? 1 : 0);
