// Проверка перетаскивания анимации фона мышью (логика, без браузера).
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const handlers = {};
global.window = global; global.addEventListener = (t, f) => { handlers[t] = f; };
global.document = { createElement: () => ({ getContext: () => ({}), toDataURL: () => 'data:' }) };
global.BgAnim = require(path.join(root, 'src/anim/bg-anim.js'));
let rebaked = [];
BgAnim.rebakeFrames = async (assets, w, h, fit) => { rebaked.push({ ids: assets.map((a) => a.id), fit }); };
require(path.join(root, 'src/anim/bg-anim-drag.js'));

let failed = 0;
const check = (n, c, x) => { if (!c) { failed++; console.error('FAIL:', n, x || ''); } else console.log('ok:', n); };

const state = { mode: 'normal', device: { w: 480, h: 480 }, assets: [{ id: 'f0' }, { id: 'f1' }], background: { anim: { enabled: true, frames: ['f0', 'f1'], fit: { mode: 'cover', scale: 100, x: 10, y: 0 } } } };
let committed = null, redraws = 0, seeks = [];
let vH = {};
const canvasEl = { classList: { contains: (c) => c === 'shared-preview-canvas' }, getBoundingClientRect: () => ({ width: 960 }) };   // зум 2×
const editor = { viewport: { addEventListener: (t, f) => { vH[t] = f; }, classList: { toggle() {} } }, redrawPreview() { redraws++; } };
const preview = { stop() {}, currentIndex: () => 1, seek: (i) => seeks.push(i) };
const d = new BgAnimDrag({ editor, store: { state }, preview, onCommit: async (fit) => { committed = fit; } });
const ev = (o) => Object.assign({ button: 0, altKey: false, shiftKey: false, target: canvasEl, preventDefault() {}, stopPropagation() {} }, o);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  vH.mousedown(ev({ clientX: 100, clientY: 100 }));
  check('без включённого режима мышь игнорируется', d.drag === null);
  d.setActive(true);
  vH.mousedown(ev({ clientX: 100, clientY: 100, target: { classList: { contains: () => false } } }));
  check('нажатие не на фоне (компонент) игнорируется', d.drag === null);
  vH.mousedown(ev({ clientX: 100, clientY: 100 }));
  check('нажатие на фоне начинает перетаскивание текущего кадра', d.drag && d.drag.frameId === 'f1' && seeks[0] === 1);
  handlers.mousemove(ev({ clientX: 140, clientY: 120 }));
  await sleep(20);
  check('при зуме 2× сдвиг 40/20 px экрана = 20/10 px циферблата', d.drag.cur.x === 30 && d.drag.cur.y === 10, JSON.stringify(d.drag.cur));
  check('вживую пересчитывается только показанный кадр', rebaked.length >= 1 && rebaked[0].ids.join() === 'f1' && redraws >= 1);
  handlers.mousemove(ev({ clientX: 140, clientY: 100, shiftKey: true }));
  await sleep(20);
  check('Shift фиксирует ось', d.drag.cur.y === 0 && d.drag.cur.x === 30, JSON.stringify(d.drag.cur));
  await handlers.mouseup();
  check('после отпускания применяется итоговая подгонка', committed && committed.x === 30 && committed.y === 0 && d.drag === null);
  committed = null;
  vH.mousedown(ev({ clientX: 5, clientY: 5 })); await handlers.mouseup();
  check('простой клик без движения ничего не меняет', committed === null);
  state.mode = 'aod';
  vH.mousedown(ev({ clientX: 5, clientY: 5 }));
  check('в AOD перетаскивание отключено', d.drag === null);
  if (failed) { console.error(`\nbg-anim-drag: ${failed} FAILED`); process.exit(1); }
  console.log('\nbg-anim-drag: all checks passed');
})();
