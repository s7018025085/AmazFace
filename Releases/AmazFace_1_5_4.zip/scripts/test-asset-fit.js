// AssetFit: картинки-компоненты запекаются до w×h (IMG на часах не масштабирует ресурс).
// Запуск: node scripts/test-asset-fit.js
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const fx = require('./export-fixtures.js');

const canvases = [];
const mkCanvas = () => {
  const c = { width: 0, height: 0, getContext: () => new Proxy({}, { get: (t, k) => (k in t ? t[k] : () => {}), set: (t, k, v) => { t[k] = v; return true; } }),
    toDataURL() { return 'data:image/png;base64,' + Buffer.from(`${this.width}x${this.height}`).toString('base64'); } };
  canvases.push(c); return c;
};
class FakeImage { set src(v) { this.naturalWidth = 256; this.naturalHeight = 256; setTimeout(() => this.onload && this.onload()); } }
const sandbox = { window: {}, document: { createElement: mkCanvas }, Image: FakeImage, console, setTimeout, JSON, Math, Object, Promise, Number, String, Map, Set, Array };
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'src/assets/asset-fit.js'), 'utf8') + '\nthis.AssetFit = AssetFit;', sandbox);
const { AssetFit } = sandbox;

let failed = 0;
const check = (n, c, x) => { if (c) console.log('ok: ' + n); else { failed++; console.log('FAIL: ' + n + (x ? ' — ' + x : '')); } };
const decode = (u) => Buffer.from(u.split(',')[1], 'base64').toString();

const icon = { id: 'asset_1', name: 'flash', dataUrl: 'data:image/png;base64,QQ==', width: 256, height: 256, format: 'PNG', size: 1 };
const same = { id: 'asset_2', name: 'ok', dataUrl: 'data:image/png;base64,QQ==', width: 40, height: 40, format: 'PNG', size: 1 };
const comp = (id, src, w, h) => ({ id, defId: 'image', x: 0, y: 0, w, h, visible: true, props: { src, alpha: 100 } });

(async () => {
  // 1. Размер не совпал → копия w×h, ссылка подменена, исходник выброшен
  let p = { assets: [icon], components: [comp('i1', 'asset_1', 40, 40)], scenes: { normal: { components: [] }, aod: { components: [] } } };
  let out = await AssetFit.bakeProject(p);
  check('копия проекта, оригинал не тронут', out !== p && p.components[0].props.src === 'asset_1' && p.assets.length === 1);
  const fitted = out.assets.find((a) => a.id === out.components[0].props.src);
  check('компонент ссылается на запечённый ресурс', fitted && fitted.id !== 'asset_1');
  check('ресурс 40×40', fitted && fitted.width === 40 && fitted.height === 40 && decode(fitted.dataUrl) === '40x40', fitted && decode(fitted.dataUrl));
  check('исходник выброшен (больше не используется)', !out.assets.some((a) => a.id === 'asset_1'));

  // 2. Размер совпал → проект не меняется
  p = { assets: [same], components: [comp('i1', 'asset_2', 40, 40)] };
  check('совпадающий размер: проект возвращается как есть', (await AssetFit.bakeProject(p)) === p);

  // 3. Один ресурс в двух размерах + сцена AOD; исходник нужен другому компоненту (не image)
  p = { assets: [icon], components: [comp('i1', 'asset_1', 40, 40), comp('i2', 'asset_1', 40, 40), comp('i3', 'asset_1', 100, 60), { id: 'h', defId: 'time_pointer', props: { path: 'asset_1' } }],
    scenes: { normal: { components: [] }, aod: { components: [comp('a1', 'asset_1', 24, 24)] } } };
  out = await AssetFit.bakeProject(p);
  const srcs = out.components.filter((c) => c.defId === 'image').map((c) => c.props.src);
  check('одинаковые размеры делят один ресурс', srcs[0] === srcs[1] && srcs[0] !== srcs[2]);
  check('AOD-сцена тоже обработана', out.scenes.aod.components[0].props.src !== 'asset_1' && decode(out.assets.find((a) => a.id === out.scenes.aod.components[0].props.src).dataUrl) === '24x24');
  check('исходник сохранён, раз его использует стрелка', out.assets.some((a) => a.id === 'asset_1') && out.components[3].props.path === 'asset_1');
  check('ресурсы: исходный + 3 размера', out.assets.length === 4, String(out.assets.length));

  // 4. Реальный экспортёр: файл и размер в index.js согласованы
  const ex = fx.loadExporter(path.resolve(__dirname, '..'));
  const proj = fx.project([comp('i1', 'asset_1', 40, 40)]);
  proj.assets = [icon];
  const baked = await AssetFit.bakeProject(proj);
  const r = ex.exportIndexJs(baked, ex.computeAssetFilenames ? ex.computeAssetFilenames(baked) : undefined, undefined, {});
  const m = /widget\.IMG[^;]*?w: 40, h: 40, src: "([^"]+)"/s.exec(r.code);
  check('index.js: IMG 40×40 ссылается на запечённый файл', !!m && /_40x40\.png$/.test(m[1]), m ? m[1] : r.validation.errors.join('; '));

  console.log(failed ? `\n${failed} FAILED` : '\nAssetFit tests passed.');
  process.exit(failed ? 1 : 0);
})();
