// Смещение часов/минут/секунд у текстовых компонентов (ряд «соседних» часов и минут).
// Запуск: node scripts/test-time-offset.js
const vm = require('node:vm');
const fx = require('./export-fixtures.js');

const ex = fx.loadExporter(process.cwd());
const { REGISTRY } = ex;
// DATA_SOURCES не экспортируется загрузчиком фикстур — читаем его из registry.js напрямую.
const DATA_SOURCES = (() => {
  const fs = require('node:fs'), path = require('node:path');
  const ctx = { console, Math, Date, JSON, window: {} };
  vm.createContext(ctx);
  const read = (rel) => fs.readFileSync(path.join(process.cwd(), rel), 'utf8');
  vm.runInContext(read('src/util/slug.js'), ctx);
  vm.runInContext(read('src/components/registry.js') + '\n;globalThis.__ds = DATA_SOURCES;', ctx);
  return ctx.__ds;
})();

let passed = 0, failed = 0;
const check = (n, c, x) => { if (c) { passed++; console.log('ok: ' + n); } else { failed++; console.log('FAIL: ' + n + (x ? ' — ' + x : '')); } };

// Выполняет экспортированный циферблат при заданном «текущем» времени и возвращает тексты виджетов по порядку.
function texts(comps, h, m, s) {
  const g = ex.exportIndexJs(fx.project(comps), {}, {});
  if (g.validation.errors.length) throw new Error('ошибки экспорта: ' + g.validation.errors.join('; '));
  const ms = new Date(2026, 10, 6, h, m, s).getTime();
  const widgets = [];
  const proxy = new Proxy({}, { get: (_, k) => String(k) });
  const sb = {
    console, Math, Date, JSON,
    createWidget: (type, params) => {
      const w = { params: Object.assign({}, params), setAlpha() {}, getProperty() {} };
      w.setProperty = (k, v) => { if (k === 'MORE') Object.assign(w.params, v); };
      widgets.push(w); return w;
    },
    widget: proxy, align: proxy, text_style: proxy, prop: proxy, show_level: proxy, data_type: proxy,
    setInterval: () => 1, clearInterval() {}, setTimeout: () => 1, clearTimeout() {},
    Time: function () { this.getTime = () => ms; },
    WatchFace: (d) => { sb.__wf = d; },
  };
  vm.createContext(sb);
  vm.runInContext(g.code.replace(/^import .*$/gm, ''), sb, { filename: 'index.js' });
  sb.__wf.build.call({});
  return { out: widgets.filter((w) => typeof w.params.text === 'string' && w.params.text !== '').map((w) => w.params.text), code: g.code };
}
const hour = (off, extra) => fx.mk('h', 'time_hour', Object.assign({ time_offset: off, text_size: 40, color: '#fff' }, extra || {}));
const minute = (off, extra) => fx.mk('m', 'time_minute', Object.assign({ time_offset: off, text_size: 40, color: '#fff' }, extra || {}));
const second = (off) => fx.mk('s', 'time_second', { time_offset: off, text_size: 40, color: '#fff' });
const one = (comp, h, m, s) => texts([comp], h, m, s).out[0];

// Реестр: свойство есть везде, где выбираются часы/минуты/секунды
for (const id of ['time_hour', 'time_minute', 'time_second']) {
  const p = REGISTRY[id].properties.find((x) => x.key === 'time_offset');
  check(`реестр: ${id} имеет «Смещение»`, !!p && p.default === 0 && p.min < 0 && p.max > 0, JSON.stringify(p && { d: p.default, min: p.min, max: p.max }));
}
for (const src of ['HOUR', 'MINUTE', 'SECOND']) {
  const f = (DATA_SOURCES[src].fields || []).find((x) => x.key === 'time_offset');
  check(`реестр: источник ${src} в «Тексте» имеет «Смещение»`, !!f && f.default === 0);
}

// Часы 24 ч, время 13:05:30
check('часы +0 → 13', one(hour(0), 13, 5, 30) === '13');
check('часы −1 → 12', one(hour(-1), 13, 5, 30) === '12');
check('часы −3 → 10', one(hour(-3), 13, 5, 30) === '10');
check('часы +2 → 15', one(hour(2), 13, 5, 30) === '15');
check('часы +3 → 16', one(hour(3), 13, 5, 30) === '16');
check('часы +10 → 23', one(hour(10), 13, 5, 30) === '23');
check('часы +11 переходят через полночь → 00', one(hour(11), 13, 5, 30) === '00');
check('часы −13 → 00', one(hour(-13), 13, 5, 30) === '00');
check('часы −14 → 23 (по кругу)', one(hour(-14), 13, 5, 30) === '23');
check('00:30, −1 → 23', one(hour(-1), 0, 30, 0) === '23');
check('23:30, +1 → 00', one(hour(1), 23, 30, 0) === '00');
check('минуты не влияют на час (13:59, +1 → 14)', one(hour(1), 13, 59, 59) === '14');
// 12-часовой формат
check('12 ч: 13:05 +0 → 01', one(hour(0, { hour_format: 'hh' }), 13, 5, 30) === '01');
check('12 ч: 13:05 −1 → 12', one(hour(-1, { hour_format: 'hh' }), 13, 5, 30) === '12');
check('12 ч: 13:05 −3 → 10', one(hour(-3, { hour_format: 'hh' }), 13, 5, 30) === '10');
check('12 ч: 13:05 +2 → 03', one(hour(2, { hour_format: 'hh' }), 13, 5, 30) === '03');
check('12 ч: 01:05 −3 → 10 (по кругу)', one(hour(-3, { hour_format: 'hh' }), 1, 5, 30) === '10');
check('12 ч: 11:05 +2 → 01', one(hour(2, { hour_format: 'hh' }), 11, 5, 30) === '01');
check('12 ч без ведущего нуля: 13:05 +2 → 3', one(hour(2, { hour_format: 'hh', hour_leading_zero: false }), 13, 5, 30) === '3');
// Реальный пример с картинки: в 19:xx ряд 04 05 06 [7] 08 09 10 (12 ч, без ведущего нуля у центра)
{
  const row = [-3, -2, -1, 0, 1, 2, 3].map((o) => one(hour(o, { hour_format: 'hh' }), 19, 1, 0));
  check('ряд как на картинке: 04 05 06 07 08 09 10 в 19:01', row.join(' ') === '04 05 06 07 08 09 10', row.join(' '));
}

// Минуты, время 13:05:30
check('минуты +0 → 05', one(minute(0), 13, 5, 30) === '05');
check('минуты −1 → 04', one(minute(-1), 13, 5, 30) === '04');
check('минуты +2 → 07', one(minute(2), 13, 5, 30) === '07');
check('минуты +3 → 08', one(minute(3), 13, 5, 30) === '08');
check('минуты −5 → 00', one(minute(-5), 13, 5, 30) === '00');
check('минуты −6 → 59 (по кругу)', one(minute(-6), 13, 5, 30) === '59');
check('минуты +55 → 00', one(minute(55), 13, 5, 30) === '00');
check('минуты +59 → 04', one(minute(59), 13, 5, 30) === '04');
check('минуты −59 → 06', one(minute(-59), 13, 5, 30) === '06');
check('минуты без ведущего нуля: +2 → 7', one(minute(2, { minute_leading_zero: false }), 13, 5, 30) === '7');
{
  const row = [-3, -2, -1, 0, 1, 2, 3].map((o) => one(minute(o), 13, 1, 0));
  check('ряд минут вокруг 01: 58 59 00 01 02 03 04', row.join(' ') === '58 59 00 01 02 03 04', row.join(' '));
}

// Секунды
check('секунды +40 при :30 → 10', one(second(40), 13, 5, 30) === '10');
check('секунды −31 при :30 → 59', one(second(-31), 13, 5, 30) === '59');

// Универсальный «Текст» с источником «Часы»/«Минуты»
{
  const t1 = fx.mk('t', 'text', { data_source: 'HOUR', hour_format: 'hh', time_offset: -3, text_size: 40, color: '#fff' });
  const t2 = fx.mk('t', 'text', { data_source: 'MINUTE', time_offset: 2, text_size: 40, color: '#fff' });
  check('«Текст» + Часы, 12 ч, −3 → 10', one(t1, 13, 5, 30) === '10');
  check('«Текст» + Минуты, +2 → 07', one(t2, 13, 5, 30) === '07');
}

// Несколько текстов подряд (ряд): все обновляются вместе
{
  const comps = [-1, 0, 1].map((o, i) => fx.mk('h' + i, 'time_hour', { time_offset: o, text_size: 40, color: '#fff' }, { x: 10 + 100 * i, y: 100, w: 90, h: 60 }));
  check('три часа подряд: 12 13 14', texts(comps, 13, 5, 30).out.join(' ') === '12 13 14');
}

// Нулевое смещение не меняет сгенерированный код
{
  const withZero = texts([hour(0), minute(0), second(0)], 13, 5, 30).code;
  const without = texts([fx.mk('h', 'time_hour', { text_size: 40, color: '#fff' }), fx.mk('m', 'time_minute', { text_size: 40, color: '#fff' }), fx.mk('s', 'time_second', { text_size: 40, color: '#fff' })], 13, 5, 30).code;
  check('смещение 0 = код как без свойства', withZero === without);
  check('смещение 0: нет лишнего new Date(...)', !/new Date\(now\.getTime\(\) \+/.test(withZero) && !/getMinutes\(\) \+ /.test(withZero));
}

// Мусорные значения не ломают экспорт
{
  for (const bad of ['abc', null, undefined, NaN, 1.6, '-2', 100, -100]) {
    let r;
    try { r = one(minute(bad), 13, 5, 30); } catch (e) { r = 'ERR ' + e.message; }
    check(`мусорное смещение ${JSON.stringify(bad)} → корректные минуты`, /^\d\d$/.test(r), String(r));
  }
}

console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed ? 1 : 0);
