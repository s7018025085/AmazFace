// Свой набор иконок погоды + прогноз на завтра/послезавтра.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert');
const fx = require('./export-fixtures.js');
const root = path.resolve(__dirname, '..');

const fixedMath = Object.create(Math);
fixedMath.random = () => 0;
const ctx = { console, Math: fixedMath, Date, JSON, window: {} };
vm.createContext(ctx);
for (const rel of ['src/util/slug.js', 'src/components/registry.js', 'src/project/project.js', 'src/assets/weather-icons.js', 'src/exporter/index-js-exporter.js']) {
  vm.runInContext(fs.readFileSync(path.join(root, rel), 'utf8'), ctx, { filename: rel });
}
const run = (code) => vm.runInContext(code, ctx);
const WI = run('WeatherIcons');

// --- recoloring preserves PNG transparency and removes a flat backdrop ---
const transparentPixels = new Uint8ClampedArray([
  0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
]);
WI.recolorPixels(transparentPixels, 4, 2, '#12abef');
assert.deepStrictEqual([...transparentPixels.slice(0, 4)], [18, 171, 239, 255], 'opaque icon pixel receives the selected color');
assert.strictEqual(transparentPixels[7], 0, 'transparent background remains transparent');
const flatPixels = new Uint8ClampedArray(Array.from({ length: 9 }, (_, i) => i === 4 ? [0, 0, 0, 255] : [255, 255, 255, 255]).flat());
WI.recolorPixels(flatPixels, 3, 3, '#12abef');
assert.strictEqual(flatPixels[3], 0, 'flat white backdrop becomes transparent');
assert.deepStrictEqual([...flatPixels.slice(16, 20)], [18, 171, 239, 255], 'monochrome foreground remains fully opaque in the new color');

// --- asset ID collisions with backgrounds ---
ctx.store = { state: { assets: [{ id: 'asset_100', name: 'dial-background' }], fonts: [] } };
const generatedAssetIds = [];
for (let i = 0; i < 29; i++) {
  const id = run('makeAssetId()');
  generatedAssetIds.push(id);
  ctx.store.state.assets.push({ id, weatherIcon: `condition_${i}` });
}
assert.strictEqual(new Set(generatedAssetIds).size, 29, 'batch weather import receives unique IDs');
assert.ok(generatedAssetIds.every((id) => id !== 'asset_100'), 'generated weather IDs never replace the background asset');

const migratedCollision = run(`migrateProject(${JSON.stringify({
  background: { color: '#000000', imageAssetId: 'asset_100' },
  assets: [
    { id: 'asset_100', name: 'dial-background', dataUrl: 'data:image/png;base64,AAAA' },
    { id: 'asset_100', name: 'weather_hazy', dataUrl: 'data:image/png;base64,AAAA', weatherIcon: 'hazy' },
    { id: 'asset_200', name: 'weather_cloudy', dataUrl: 'data:image/png;base64,AAAA', weatherIcon: 'cloudy' },
    { id: 'asset_200', name: 'weather_rain', dataUrl: 'data:image/png;base64,AAAA', weatherIcon: 'rain' },
  ], components: [], fonts: []
})})`);
assert.strictEqual(migratedCollision.background.imageAssetId, 'asset_100', 'migration preserves the selected background link');
assert.strictEqual(migratedCollision.assets[0].id, 'asset_100', 'migration preserves the background asset ID');
assert.strictEqual(new Set(migratedCollision.assets.map((a) => a.id)).size, migratedCollision.assets.length, 'migration repairs legacy weather asset ID collisions');

// --- распознавание имён файлов ---
const m = (n) => WI.matchFileName(n);
assert.strictEqual(m('3_sunny.png'), 3);
assert.strictEqual(m('sunny_night.png'), 28, 'длинное имя важнее короткого (sunny_night, не sunny)');
assert.strictEqual(m('Cloudy-Night.PNG'), 26);
assert.strictEqual(m('weather_light_rain_day.png'), 5);
assert.strictEqual(m('Облачно ночью.png'), 26);
assert.strictEqual(m('Небольшой дождь.png'), 5);
assert.strictEqual(m('07.png'), 7);
assert.strictEqual(m('12_что-то.png'), 12);
assert.strictEqual(m('99.png'), -1);
assert.strictEqual(m('random.png'), -1);

// --- запасные слоты ---
const png = 'data:image/png;base64,AAAA';
const proj = (ids) => ({ assets: ids.map((id, i) => ({ id: 'a' + i, name: 'x', dataUrl: png, width: 8, height: 8, format: 'PNG', size: 3, weatherIcon: id })) });
const none = proj([]);
assert.strictEqual(WI.resolveIndex(none, 3).source, 'generated', 'без своих иконок — прежние заглушки');
assert.strictEqual(WI.customCount(none), 0);
const some = proj(['sunny', 'unknown']);
assert.strictEqual(WI.resolveIndex(some, 3).source, 'own');
assert.strictEqual(WI.resolveIndex(some, 28).source, 'fallback', 'ясно ночью → дневное «Солнечно»');
assert.strictEqual(WI.resolveIndex(some, 28).fromIndex, 3);
assert.strictEqual(WI.resolveIndex(some, 10).fromIndex, 25, 'пустой слот → «Неизвестно»');
const noUnknown = proj(['sunny']);
assert.strictEqual(WI.resolveIndex(noUnknown, 10).source, 'generated');
assert.strictEqual(WI.missing(some).length, 27);
assert.ok(WI.previewAsset(some, 'sunny'));
assert.strictEqual(WI.frameKey({ w: 24, h: 32 }), '24x32', 'weather resources are grouped by component dimensions');
assert.strictEqual(WI.frameKey({ w: 0, h: 0 }), '64x64', 'missing component dimensions use the default weather frame size');

// --- экспорт: свои иконки не попадают в корень assets/, есть предупреждение ---
const ex = vm.runInContext('({ computeAssetFilenames, exportIndexJs })', ctx);
const p = fx.project([fx.mk('w1', 'weather_icon', { src: 'sunny' }, { w: 64, h: 64 })]);
p.assets = some.assets;
assert.deepStrictEqual(Object.keys(ex.computeAssetFilenames(p)), [], 'weather-иконки не получают имени в корне assets/');
const r = ex.exportIndexJs(p, ex.computeAssetFilenames(p), {}, {});
assert.ok(r.validation.warnings.some((w) => /Загружено иконок погоды: 2 из 29/.test(w)), 'предупреждение о пустых слотах');
const r0 = ex.exportIndexJs(fx.project([fx.mk('w1', 'weather_icon', { src: 'sunny' }, { w: 64, h: 64 })]), {}, {}, {});
assert.ok(r0.validation.warnings.some((w) => /встроенные заглушки/.test(w)));
const namesBySize = run('WEATHER_ICON_FILES.slice()').map(name => `24x32/${name}`);
const sizedCurrent = ex.exportIndexJs(
  fx.project([fx.mk('w-small', 'weather_icon', { src: 'sunny' }, { w: 24, h: 32 })]),
  {}, {}, { weatherAssetMap: { '24x32': namesBySize } },
);
assert.ok(sizedCurrent.code.includes('weather/24x32/3_sunny.png'), 'current weather IMG_LEVEL uses its dimension-specific frame set');

// --- прогноз ---
const pf = fx.project([
  fx.mk('f1', 'weather_forecast_icon', { src: 'sunny', forecast_day: '2' }, { w: 64, h: 64 }),
  fx.mk('f2', 'weather_temp', { weather_temp_source: 'D1_HIGH', text_size: 30, color: '#fff', weather_show_degree: true }),
  fx.mk('f3', 'weather_temp', { weather_temp_source: 'CURRENT', text_size: 30, color: '#fff' }),
]);
const rf = ex.exportIndexJs(pf, {}, {}, {});
assert.ok(/import \{[^}]*Weather[^}]*\} from '@zos\/sensor'/.test(rf.code), 'импорт Weather');
assert.ok(/let _weatherFc = null;/.test(rf.code) && /_weatherFc = new Weather\(\)/.test(rf.code));
assert.ok(/forecastData\.data\[2\]/.test(rf.code), 'иконка: послезавтра = индекс 2');
assert.ok(/forecastData\.data\[1\]/.test(rf.code) && /it\.high/.test(rf.code), 'температура: завтра, максимум');
assert.ok(/data_type\.WEATHER_CURRENT/.test(rf.code), 'текущая погода по-прежнему нативная');
assert.ok(rf.validation.warnings.some((w) => /getForecast/.test(w)), 'предупреждение про устаревший датчик');
assert.ok(!/it\.low/.test(rf.code));
const sizedForecastProject = fx.project([
  fx.mk('f-small', 'weather_forecast_icon', { src: 'sunny', forecast_day: '2' }, { w: 24, h: 32 }),
]);
const sizedForecast = ex.exportIndexJs(sizedForecastProject, {}, {}, { weatherAssetMap: { '24x32': namesBySize } });
assert.ok(sizedForecast.code.includes('weather/24x32/3_sunny.png'), 'forecast IMG uses its dimension-specific frame set');
const rd = vm.runInContext('exportIndexJsDual', ctx)(pf, {}, {}, {});
assert.ok(/_weatherFc/.test(rd.code), 'Dual-экспорт тоже содержит прогноз');
// без прогноза Weather не импортируется
const rn = ex.exportIndexJs(fx.project([fx.mk('t', 'weather_temp', { text_size: 30, color: '#fff' })]), {}, {}, {});
assert.ok(!/new Weather\(\)/.test(rn.code));
// Температура сегодня: мин. и макс. — готовые компоненты с нативной привязкой WEATHER_LOW / WEATHER_HIGH
const REG = vm.runInContext('REGISTRY', ctx);
const defProps = (id) => { const o = {}; for (const q of REG[id].properties) if (q.default !== undefined) o[q.key] = q.default; return o; }; // как project.addComponent
for (const [id, src, type] of [['weather_temp_low', 'LOW', 'WEATHER_LOW'], ['weather_temp_high', 'HIGH', 'WEATHER_HIGH']]) {
  const def = REG[id];
  assert.ok(def && def.category === 'Погода' && def.dataSource === 'WEATHER_TEMP', id + ': есть в реестре, категория «Погода»');
  assert.strictEqual(def.properties.find((q) => q.key === 'weather_temp_source').default, src, id + ': источник по умолчанию ' + src);
  const r = ex.exportIndexJs(fx.project([fx.mk('t', id, defProps(id))]), {}, {}, {});
  assert.ok(new RegExp('type: data_type\\.' + type + '\\b').test(r.code), id + ': в index.js привязка к ' + type);
  assert.ok(!/new Weather\(\)/.test(r.code), id + ': без устаревшего датчика Weather');
}
const both = ex.exportIndexJs(fx.project([fx.mk('a', 'weather_temp_low', defProps('weather_temp_low')), fx.mk('b', 'weather_temp_high', defProps('weather_temp_high'))]), {}, {}, {});
assert.ok(/WEATHER_LOW/.test(both.code) && /WEATHER_HIGH/.test(both.code), 'мин. и макс. вместе в одном циферблате');

async function testComponentSizedWeatherFrame() {
  const draws = [];
  ctx.Image = class {
    set src(value) {
      this.naturalWidth = 12;
      this.naturalHeight = 8;
      this.onload();
    }
  };
  ctx.document = {
    createElement: () => ({
      width: 0,
      height: 0,
      getContext: () => ({ clearRect() {}, drawImage(...args) { draws.push(args); } }),
      toDataURL: () => 'data:image/png;base64,BBBB',
    }),
  };
  const result = await WI.dataUrlForComponent(some, { w: 24, h: 32 }, 3);
  assert.strictEqual(result, 'data:image/png;base64,BBBB', 'weather frame is returned as a PNG data URL');
  assert.deepStrictEqual([...draws[0].slice(1)], [6, 12, 12, 8], 'native-size icon is centered on a component-sized transparent frame');
}

testComponentSizedWeatherFrame().then(() => {
  console.log('Weather icons tests passed.');
}).catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
